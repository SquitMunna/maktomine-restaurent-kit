<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

if ( ! is_active_sidebar( 'sidebar-main' ) ) {
	return;
}
?>

<aside id="secondary" class="mkt-widget-area" role="complementary" aria-label="<?php esc_attr_e( 'Main Sidebar', 'maktomine-restaurant-theme' ); ?>">
	<?php dynamic_sidebar( 'sidebar-main' ); ?>
</aside><!-- #secondary -->
