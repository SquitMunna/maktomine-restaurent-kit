<?php
/**
 * Food Catalog Grid Template Part.
 *
 * Renders a collection of presented food items in a responsive grid container.
 * Strictly presentation; never performs queries or business logic.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$raw_items  = $args['items'] ?? [];
$pagination = is_array( $args['pagination'] ?? null ) ? $args['pagination'] : [];
$config     = is_array( $args['config'] ?? null ) ? $args['config'] : [];

// Normalize items array (handles items passed directly or inside a collection array).
$items = isset( $raw_items['items'] ) && is_array( $raw_items['items'] )
	? $raw_items['items']
	: ( is_array( $raw_items ) ? $raw_items : [] );

if ( empty( $pagination ) && isset( $raw_items['pagination'] ) && is_array( $raw_items['pagination'] ) ) {
	$pagination = $raw_items['pagination'];
}

// 1. Controlled column mapping to safe CSS classes (prevents arbitrary raw input injection).
$columns_class_map = [
	1 => 'mkt-catalog-grid--cols-1',
	2 => 'mkt-catalog-grid--cols-2',
	3 => 'mkt-catalog-grid--cols-3',
	4 => 'mkt-catalog-grid--cols-4',
];

$raw_columns = isset( $config['columns'] ) && is_numeric( $config['columns'] ) ? (int) $config['columns'] : 3;
$cols_int    = max( 1, min( 4, $raw_columns ) );
$cols_class  = $columns_class_map[ $cols_int ] ?? 'mkt-catalog-grid--cols-3';

// 2. Canonical configuration normalization.
$sanitized_config = [
	'show_image'      => (bool) ( $config['show_image'] ?? true ),
	'show_badges'     => (bool) ( $config['show_badges'] ?? true ),
	'show_metrics'    => (bool) ( $config['show_metrics'] ?? true ),
	'show_categories' => (bool) ( $config['show_categories'] ?? true ),
	'show_price'      => (bool) ( $config['show_price'] ?? true ),
	'columns'         => $cols_int,
	'layout_style'    => 'grid',
];

// If no items, render the empty state.
if ( empty( $items ) ) {
	get_template_part( 'template-parts/catalog/food-empty' );
	return;
}
?>
<div class="mkt-catalog mkt-catalog--grid">
	<ul class="mkt-catalog-grid <?php echo esc_attr( $cols_class ); ?>">
		<?php foreach ( $items as $item ) : ?>
			<?php if ( is_array( $item ) && ! empty( $item['id'] ) ) : ?>
				<li class="mkt-catalog-grid__item">
					<?php
					get_template_part(
						'template-parts/catalog/food-card',
						null,
						[
							'item'   => $item,
							'config' => $sanitized_config,
						]
					);
					?>
				</li>
			<?php endif; ?>
		<?php endforeach; ?>
	</ul>

	<?php
	if ( ! empty( $pagination ) && (int) ( $pagination['total_pages'] ?? 1 ) > 1 ) {
		get_template_part(
			'template-parts/catalog/food-pagination',
			null,
			[ 'pagination' => $pagination ]
		);
	}
	?>
</div>
