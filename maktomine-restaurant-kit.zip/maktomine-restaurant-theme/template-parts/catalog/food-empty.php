<?php
/**
 * Food Catalog Empty State Template Part.
 *
 * Renders an accessible, localized empty state when no food items are found,
 * when an empty collection is provided, or when Core is inactive.
 * Pure presentation; never executes queries.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$message = isset( $args['message'] ) && is_string( $args['message'] ) && '' !== $args['message']
	? $args['message']
	: __( 'No food items are currently available in this section.', 'maktomine-restaurant-theme' );
?>
<div class="mkt-catalog-empty" role="status">
	<div class="mkt-catalog-empty__icon-wrapper" aria-hidden="true">
		<span class="mkt-catalog-empty__icon dashicons dashicons-food"></span>
	</div>
	<h3 class="mkt-catalog-empty__title">
		<?php esc_html_e( 'No Food Items Found', 'maktomine-restaurant-theme' ); ?>
	</h3>
	<p class="mkt-catalog-empty__message">
		<?php echo esc_html( $message ); ?>
	</p>
</div>
