<?php
/**
 * Single Food Item Gallery Template Part.
 *
 * Renders the primary structured food item image using presented image metadata.
 * Pure presentation; never queries attachments directly.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$item  = is_array( $args['item'] ?? null ) ? $args['item'] : [];
$image = is_array( $item['image'] ?? null ) ? $item['image'] : [];
$title = (string) ( $item['title'] ?? '' );

$image_url    = (string) ( $image['url'] ?? '' );
$image_alt    = (string) ( $image['alt'] ?? $title );
$image_width  = isset( $image['width'] ) && is_numeric( $image['width'] ) ? (int) $image['width'] : null;
$image_height = isset( $image['height'] ) && is_numeric( $image['height'] ) ? (int) $image['height'] : null;
?>
<div class="mkt-food-gallery">
	<div class="mkt-food-gallery__main">
		<?php if ( '' !== $image_url ) : ?>
			<img
				src="<?php echo esc_url( $image_url ); ?>"
				alt="<?php echo esc_attr( $image_alt ); ?>"
				<?php if ( null !== $image_width ) : ?>
					width="<?php echo esc_attr( (string) $image_width ); ?>"
				<?php endif; ?>
				<?php if ( null !== $image_height ) : ?>
					height="<?php echo esc_attr( (string) $image_height ); ?>"
				<?php endif; ?>
				loading="eager"
				decoding="async"
				class="mkt-food-gallery__image"
			/>
		<?php else : ?>
			<div class="mkt-food-gallery__placeholder" aria-hidden="true">
				<span class="mkt-food-gallery__placeholder-icon dashicons dashicons-food"></span>
			</div>
		<?php endif; ?>
	</div>
</div>
