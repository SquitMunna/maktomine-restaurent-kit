<?php
/**
 * Single Food Item Variations Template Part.
 *
 * Renders read-only display of declared attributes and available variations.
 * Strictly presentation; never performs variation resolution or cart handling.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$item       = is_array( $args['item'] ?? null ) ? $args['item'] : [];
$attributes = is_array( $item['attributes'] ?? null ) ? $item['attributes'] : [];

if ( empty( $attributes ) ) {
	return;
}
?>
<div class="mkt-food-variations">
	<h3 class="mkt-food-variations__heading">
		<?php esc_html_e( 'Available Options', 'maktomine-restaurant-theme' ); ?>
	</h3>

	<div class="mkt-food-variations__attributes">
		<?php foreach ( $attributes as $attribute ) : ?>
			<?php
			if ( ! is_array( $attribute ) || empty( $attribute['name'] ) ) {
				continue;
			}
			$attr_name = (string) $attribute['name'];
			$options   = is_array( $attribute['options'] ?? null ) ? $attribute['options'] : [];
			?>
			<div class="mkt-food-attribute">
				<span class="mkt-food-attribute__name">
					<?php echo esc_html( $attr_name ); ?>:
				</span>
				<ul class="mkt-food-attribute__options">
					<?php foreach ( $options as $option ) : ?>
						<?php
						if ( ! is_array( $option ) || empty( $option['label'] ) ) {
							continue;
						}
						?>
						<li class="mkt-food-attribute__option">
							<?php echo esc_html( (string) $option['label'] ); ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endforeach; ?>
	</div>
</div>
