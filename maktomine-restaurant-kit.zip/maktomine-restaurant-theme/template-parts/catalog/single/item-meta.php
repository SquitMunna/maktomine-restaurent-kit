<?php
/**
 * Single Food Item Meta Template Part.
 *
 * Renders categories, tags, and item metrics (prep time, calories).
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$item = is_array( $args['item'] ?? null ) ? $args['item'] : [];

$formatted_prep     = isset( $item['formatted_prep_time'] ) ? (string) $item['formatted_prep_time'] : null;
$formatted_calories = isset( $item['formatted_calories'] ) ? (string) $item['formatted_calories'] : null;
$categories         = is_array( $item['categories'] ?? null ) ? $item['categories'] : [];
$tags               = is_array( $item['tags'] ?? null ) ? $item['tags'] : [];
?>
<div class="mkt-food-meta">
	<?php if ( null !== $formatted_prep || null !== $formatted_calories ) : ?>
		<div class="mkt-food-meta__metrics">
			<?php if ( null !== $formatted_prep ) : ?>
				<span class="mkt-metric mkt-metric--prep">
					<span class="mkt-metric__icon dashicons dashicons-clock" aria-hidden="true"></span>
					<span class="mkt-metric__label"><?php esc_html_e( 'Prep Time:', 'maktomine-restaurant-theme' ); ?></span>
					<span class="mkt-metric__value"><?php echo esc_html( $formatted_prep ); ?></span>
				</span>
			<?php endif; ?>
			<?php if ( null !== $formatted_calories ) : ?>
				<span class="mkt-metric mkt-metric--calories">
					<span class="mkt-metric__icon dashicons dashicons-heart" aria-hidden="true"></span>
					<span class="mkt-metric__label"><?php esc_html_e( 'Calories:', 'maktomine-restaurant-theme' ); ?></span>
					<span class="mkt-metric__value"><?php echo esc_html( $formatted_calories ); ?></span>
				</span>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $categories ) ) : ?>
		<div class="mkt-food-meta__group mkt-food-meta__categories">
			<span class="mkt-food-meta__label"><?php esc_html_e( 'Categories:', 'maktomine-restaurant-theme' ); ?></span>
			<ul class="mkt-food-meta__list">
				<?php foreach ( $categories as $cat ) : ?>
					<?php if ( is_array( $cat ) && ! empty( $cat['name'] ) ) : ?>
						<li class="mkt-food-meta__list-item">
							<span class="mkt-tag"><?php echo esc_html( (string) $cat['name'] ); ?></span>
						</li>
					<?php endif; ?>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $tags ) ) : ?>
		<div class="mkt-food-meta__group mkt-food-meta__tags">
			<span class="mkt-food-meta__label"><?php esc_html_e( 'Tags:', 'maktomine-restaurant-theme' ); ?></span>
			<ul class="mkt-food-meta__list">
				<?php foreach ( $tags as $tag ) : ?>
					<?php if ( is_array( $tag ) && ! empty( $tag['name'] ) ) : ?>
						<li class="mkt-food-meta__list-item">
							<span class="mkt-tag mkt-tag--dietary"><?php echo esc_html( (string) $tag['name'] ); ?></span>
						</li>
					<?php endif; ?>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
</div>
