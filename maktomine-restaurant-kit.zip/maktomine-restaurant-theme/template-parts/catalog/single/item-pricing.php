<?php
/**
 * Single Food Item Pricing Template Part.
 *
 * Renders presentation-ready pricing display including sale prices.
 * Pure presentation; never calculates pricing.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$item = is_array( $args['item'] ?? null ) ? $args['item'] : [];

$formatted_base = (string) ( $item['formatted_base_price'] ?? '' );
$formatted_sale = isset( $item['formatted_sale_price'] ) ? (string) $item['formatted_sale_price'] : null;
$has_sale_price = (bool) ( $item['has_sale_price'] ?? false );

if ( '' === $formatted_base ) {
	return;
}
?>
<div class="mkt-food-pricing">
	<?php if ( $has_sale_price && null !== $formatted_sale ) : ?>
		<span class="screen-reader-text"><?php esc_html_e( 'Original price:', 'maktomine-restaurant-theme' ); ?> </span>
		<del class="mkt-price mkt-price--regular" aria-hidden="true"><?php echo esc_html( $formatted_base ); ?></del>
		<span class="screen-reader-text"><?php esc_html_e( 'Sale price:', 'maktomine-restaurant-theme' ); ?> </span>
		<ins class="mkt-price mkt-price--sale"><?php echo esc_html( $formatted_sale ); ?></ins>
	<?php else : ?>
		<span class="mkt-price mkt-price--current"><?php echo esc_html( $formatted_base ); ?></span>
	<?php endif; ?>
</div>
