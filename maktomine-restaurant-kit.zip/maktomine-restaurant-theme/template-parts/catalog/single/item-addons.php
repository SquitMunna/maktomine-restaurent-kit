<?php
/**
 * Single Food Item Add-ons Template Part.
 *
 * Renders read-only presentation of available add-ons with their presented formatted prices.
 * Strictly presentation; never performs calculations or order handling.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$item   = is_array( $args['item'] ?? null ) ? $args['item'] : [];
$addons = is_array( $item['addons'] ?? null ) ? $item['addons'] : [];

if ( empty( $addons ) ) {
	return;
}
?>
<div class="mkt-food-addons">
	<h3 class="mkt-food-addons__heading">
		<?php esc_html_e( 'Available Add-ons', 'maktomine-restaurant-theme' ); ?>
	</h3>

	<ul class="mkt-food-addons__list">
		<?php foreach ( $addons as $addon ) : ?>
			<?php
			if ( ! is_array( $addon ) || empty( $addon['name'] ) ) {
				continue;
			}
			$addon_name  = (string) $addon['name'];
			$addon_price = (string) ( $addon['formatted_price'] ?? '' );
			$is_required = ! empty( $addon['required'] );
			?>
			<li class="mkt-food-addons__item">
				<div class="mkt-food-addon__info">
					<span class="mkt-food-addon__name">
						<?php echo esc_html( $addon_name ); ?>
					</span>
					<?php if ( $is_required ) : ?>
						<span class="mkt-badge mkt-badge--required">
							<?php esc_html_e( 'Required', 'maktomine-restaurant-theme' ); ?>
						</span>
					<?php endif; ?>
				</div>
				<?php if ( '' !== $addon_price ) : ?>
					<span class="mkt-food-addon__price">
						+<?php echo esc_html( $addon_price ); ?>
					</span>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
