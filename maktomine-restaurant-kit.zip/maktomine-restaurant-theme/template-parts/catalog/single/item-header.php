<?php
/**
 * Single Food Item Header Template Part.
 *
 * Renders title and status badges.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$item = is_array( $args['item'] ?? null ) ? $args['item'] : [];

if ( empty( $item['title'] ) ) {
	return;
}

$title       = (string) $item['title'];
$avail_label = (string) ( $item['availability_label'] ?? '' );
$avail_token = (string) ( $item['availability_token'] ?? '' );
$is_featured = (bool) ( $item['is_featured'] ?? false );
$is_popular  = (bool) ( $item['is_popular'] ?? false );
?>
<header class="mkt-food-header">
	<?php if ( ( '' !== $avail_token && '' !== $avail_label ) || $is_featured || $is_popular ) : ?>
		<div class="mkt-food-header__badges">
			<?php if ( '' !== $avail_token && '' !== $avail_label ) : ?>
				<span class="mkt-badge mkt-badge--availability mkt-badge--<?php echo esc_attr( $avail_token ); ?>">
					<?php echo esc_html( $avail_label ); ?>
				</span>
			<?php endif; ?>
			<?php if ( $is_featured ) : ?>
				<span class="mkt-badge mkt-badge--featured">
					<?php esc_html_e( 'Featured', 'maktomine-restaurant-theme' ); ?>
				</span>
			<?php endif; ?>
			<?php if ( $is_popular ) : ?>
				<span class="mkt-badge mkt-badge--popular">
					<?php esc_html_e( 'Popular', 'maktomine-restaurant-theme' ); ?>
				</span>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<h1 class="mkt-food-header__title">
		<?php echo esc_html( $title ); ?>
	</h1>
</header>
