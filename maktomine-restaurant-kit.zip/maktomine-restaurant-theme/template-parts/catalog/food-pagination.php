<?php
/**
 * Food Catalog Pagination Template Part.
 *
 * Renders pagination navigation strictly based on pre-calculated collection metadata.
 * Pure presentation; never queries the database or calculates totals.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$pagination = is_array( $args['pagination'] ?? null ) ? $args['pagination'] : [];

$total_pages  = (int) ( $pagination['total_pages'] ?? 1 );
$current_page = max( 1, (int) ( $pagination['page'] ?? 1 ) );

if ( $total_pages <= 1 ) {
	return;
}

// Generate pagination links using native WordPress paginate_links.
$paginate_links = paginate_links(
	[
		'base'      => esc_url_raw( add_query_arg( 'paged', '%#%' ) ),
		'format'    => '?paged=%#%',
		'current'   => $current_page,
		'total'     => $total_pages,
		'prev_text' => '&larr; ' . esc_html__( 'Previous', 'maktomine-restaurant-theme' ),
		'next_text' => esc_html__( 'Next', 'maktomine-restaurant-theme' ) . ' &rarr;',
		'type'      => 'array',
	]
);

if ( empty( $paginate_links ) || ! is_array( $paginate_links ) ) {
	return;
}
?>
<nav class="mkt-catalog-pagination" aria-label="<?php esc_attr_e( 'Food catalog pagination', 'maktomine-restaurant-theme' ); ?>">
	<ul class="mkt-catalog-pagination__list">
		<?php foreach ( $paginate_links as $link ) : ?>
			<li class="mkt-catalog-pagination__item">
				<?php echo wp_kses_post( $link ); ?>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>
