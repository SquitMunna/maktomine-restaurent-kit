<?php
/**
 * Food Catalog List Template Part.
 *
 * Renders a collection of presented food items in a structured list presentation.
 * Pure presentation component; reuses the approved food-card with list layout style.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$raw_items  = $args['items'] ?? [];
$pagination = is_array( $args['pagination'] ?? null ) ? $args['pagination'] : [];
$config     = is_array( $args['config'] ?? null ) ? $args['config'] : [];

// Normalize items array.
$items = isset( $raw_items['items'] ) && is_array( $raw_items['items'] )
	? $raw_items['items']
	: ( is_array( $raw_items ) ? $raw_items : [] );

if ( empty( $pagination ) && isset( $raw_items['pagination'] ) && is_array( $raw_items['pagination'] ) ) {
	$pagination = $raw_items['pagination'];
}

// Canonical configuration with list layout style.
$sanitized_config = [
	'show_image'      => (bool) ( $config['show_image'] ?? true ),
	'show_badges'     => (bool) ( $config['show_badges'] ?? true ),
	'show_metrics'    => (bool) ( $config['show_metrics'] ?? true ),
	'show_categories' => (bool) ( $config['show_categories'] ?? true ),
	'show_price'      => (bool) ( $config['show_price'] ?? true ),
	'columns'         => 1,
	'layout_style'    => 'list',
];

// If no items, render the empty state.
if ( empty( $items ) ) {
	get_template_part( 'template-parts/catalog/food-empty' );
	return;
}
?>
<div class="mkt-catalog mkt-catalog--list">
	<ul class="mkt-catalog-list">
		<?php foreach ( $items as $item ) : ?>
			<?php if ( is_array( $item ) && ! empty( $item['id'] ) ) : ?>
				<li class="mkt-catalog-list__item">
					<?php
					get_template_part(
						'template-parts/catalog/food-card',
						null,
						[
							'item'   => $item,
							'config' => $sanitized_config,
						]
					);
					?>
				</li>
			<?php endif; ?>
		<?php endforeach; ?>
	</ul>

	<?php
	if ( ! empty( $pagination ) && (int) ( $pagination['total_pages'] ?? 1 ) > 1 ) {
		get_template_part(
			'template-parts/catalog/food-pagination',
			null,
			[ 'pagination' => $pagination ]
		);
	}
	?>
</div>
