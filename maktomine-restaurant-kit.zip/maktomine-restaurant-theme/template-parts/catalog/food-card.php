<?php
/**
 * Food Card Template Part.
 *
 * Renders a single food catalog item card consuming the approved CatalogPresenter contract.
 * Pure presentation component; never queries database or calculates pricing.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

$item   = is_array( $args['item'] ?? null ) ? $args['item'] : [];
$config = is_array( $args['config'] ?? null ) ? $args['config'] : [];

// Require a valid food item with positive ID.
if ( empty( $item['id'] ) ) {
	return;
}

// Canonical view configuration flags (defaults match Phase 3R contract).
$show_image      = (bool) ( $config['show_image'] ?? true );
$show_badges     = (bool) ( $config['show_badges'] ?? true );
$show_metrics    = (bool) ( $config['show_metrics'] ?? true );
$show_categories = (bool) ( $config['show_categories'] ?? true );
$show_price      = (bool) ( $config['show_price'] ?? true );
$layout_style    = (string) ( $config['layout_style'] ?? 'grid' );

// Extract presentation-ready data.
$id                 = (int) $item['id'];
$title              = (string) ( $item['title'] ?? '' );
$permalink          = (string) ( $item['permalink'] ?? '' );
$formatted_base     = (string) ( $item['formatted_base_price'] ?? '' );
$formatted_sale     = isset( $item['formatted_sale_price'] ) ? (string) $item['formatted_sale_price'] : null;
$has_sale_price     = (bool) ( $item['has_sale_price'] ?? false );
$avail_label        = (string) ( $item['availability_label'] ?? '' );
$avail_token        = (string) ( $item['availability_token'] ?? '' );
$is_featured        = (bool) ( $item['is_featured'] ?? false );
$is_popular         = (bool) ( $item['is_popular'] ?? false );
$formatted_prep     = isset( $item['formatted_prep_time'] ) ? (string) $item['formatted_prep_time'] : null;
$formatted_calories = isset( $item['formatted_calories'] ) ? (string) $item['formatted_calories'] : null;
$image              = is_array( $item['image'] ?? null ) ? $item['image'] : [];
$image_url          = (string) ( $image['url'] ?? '' );
$image_alt          = (string) ( $image['alt'] ?? $title );
$image_width        = isset( $image['width'] ) && is_numeric( $image['width'] ) ? (int) $image['width'] : null;
$image_height       = isset( $image['height'] ) && is_numeric( $image['height'] ) ? (int) $image['height'] : null;
$categories         = is_array( $item['categories'] ?? null ) ? $item['categories'] : [];

$card_classes = [ 'mkt-food-card' ];
if ( 'list' === $layout_style ) {
	$card_classes[] = 'mkt-food-card--list';
}
?>
<article id="mkt-food-item-<?php echo esc_attr( (string) $id ); ?>" class="<?php echo esc_attr( implode( ' ', $card_classes ) ); ?>">
	<?php if ( $show_image ) : ?>
		<div class="mkt-food-card__media">
			<?php if ( '' !== $image_url ) : ?>
				<a href="<?php echo esc_url( $permalink ); ?>" class="mkt-food-card__media-link">
					<img
						src="<?php echo esc_url( $image_url ); ?>"
						alt="<?php echo esc_attr( $image_alt ); ?>"
						<?php if ( null !== $image_width ) : ?>
							width="<?php echo esc_attr( (string) $image_width ); ?>"
						<?php endif; ?>
						<?php if ( null !== $image_height ) : ?>
							height="<?php echo esc_attr( (string) $image_height ); ?>"
						<?php endif; ?>
						loading="lazy"
						decoding="async"
						class="mkt-food-card__image"
					/>
				</a>
			<?php else : ?>
				<div class="mkt-food-card__placeholder" aria-hidden="true">
					<span class="mkt-food-card__placeholder-icon dashicons dashicons-food"></span>
				</div>
			<?php endif; ?>

			<?php if ( $show_badges && ( '' !== $avail_token || $is_featured || $is_popular ) ) : ?>
				<div class="mkt-food-card__badges">
					<?php if ( '' !== $avail_token && '' !== $avail_label ) : ?>
						<span class="mkt-badge mkt-badge--availability mkt-badge--<?php echo esc_attr( $avail_token ); ?>">
							<?php echo esc_html( $avail_label ); ?>
						</span>
					<?php endif; ?>
					<?php if ( $is_featured ) : ?>
						<span class="mkt-badge mkt-badge--featured">
							<?php esc_html_e( 'Featured', 'maktomine-restaurant-theme' ); ?>
						</span>
					<?php endif; ?>
					<?php if ( $is_popular ) : ?>
						<span class="mkt-badge mkt-badge--popular">
							<?php esc_html_e( 'Popular', 'maktomine-restaurant-theme' ); ?>
						</span>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<div class="mkt-food-card__content">
		<?php if ( $show_categories && ! empty( $categories ) ) : ?>
			<div class="mkt-food-card__categories">
				<?php foreach ( $categories as $category ) : ?>
					<?php if ( is_array( $category ) && ! empty( $category['name'] ) ) : ?>
						<span class="mkt-food-card__category">
							<?php echo esc_html( (string) $category['name'] ); ?>
						</span>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<h3 class="mkt-food-card__title">
			<a href="<?php echo esc_url( $permalink ); ?>" class="mkt-food-card__title-link">
				<?php echo esc_html( $title ); ?>
			</a>
		</h3>

		<?php if ( $show_metrics && ( null !== $formatted_prep || null !== $formatted_calories ) ) : ?>
			<div class="mkt-food-card__metrics">
				<?php if ( null !== $formatted_prep ) : ?>
					<span class="mkt-metric mkt-metric--prep">
						<span class="mkt-metric__icon dashicons dashicons-clock" aria-hidden="true"></span>
						<?php echo esc_html( $formatted_prep ); ?>
					</span>
				<?php endif; ?>
				<?php if ( null !== $formatted_calories ) : ?>
					<span class="mkt-metric mkt-metric--calories">
						<span class="mkt-metric__icon dashicons dashicons-heart" aria-hidden="true"></span>
						<?php echo esc_html( $formatted_calories ); ?>
					</span>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="mkt-food-card__footer">
			<?php if ( $show_price && '' !== $formatted_base ) : ?>
				<div class="mkt-food-card__pricing">
					<?php if ( $has_sale_price && null !== $formatted_sale ) : ?>
						<span class="screen-reader-text"><?php esc_html_e( 'Original price:', 'maktomine-restaurant-theme' ); ?> </span>
						<del class="mkt-price mkt-price--regular" aria-hidden="true"><?php echo esc_html( $formatted_base ); ?></del>
						<span class="screen-reader-text"><?php esc_html_e( 'Sale price:', 'maktomine-restaurant-theme' ); ?> </span>
						<ins class="mkt-price mkt-price--sale"><?php echo esc_html( $formatted_sale ); ?></ins>
					<?php else : ?>
						<span class="mkt-price mkt-price--current"><?php echo esc_html( $formatted_base ); ?></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<div class="mkt-food-card__action">
				<a href="<?php echo esc_url( $permalink ); ?>" class="mkt-food-card__link">
					<span><?php esc_html_e( 'View Details', 'maktomine-restaurant-theme' ); ?></span>
					<span class="screen-reader-text">: <?php echo esc_html( $title ); ?></span>
					<span class="mkt-food-card__arrow" aria-hidden="true">&rarr;</span>
				</a>
			</div>
		</div>
	</div>
</article>
