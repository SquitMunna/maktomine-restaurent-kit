<?php
/**
 * Maktomine Restaurant Theme Functions and Definitions.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

// Define core theme constants.
if ( ! defined( 'MAKTOMINE_THEME_VERSION' ) ) {
	define( 'MAKTOMINE_THEME_VERSION', '1.0.0' );
}

if ( ! defined( 'MAKTOMINE_THEME_PATH' ) ) {
	define( 'MAKTOMINE_THEME_PATH', get_template_directory() . '/' );
}

if ( ! defined( 'MAKTOMINE_THEME_URI' ) ) {
	define( 'MAKTOMINE_THEME_URI', get_template_directory_uri() . '/' );
}

// 1. Register PSR-4 Autoloader for Maktomine\RestaurantTheme.
require_once MAKTOMINE_THEME_PATH . 'inc/Autoloader.php';
\Maktomine\RestaurantTheme\Autoloader::register(
	'Maktomine\\RestaurantTheme\\',
	MAKTOMINE_THEME_PATH . 'inc/'
);

// 2. Load Global Theme Helper API.
require_once MAKTOMINE_THEME_PATH . 'inc/Helpers/ThemeHelpers.php';

// 3. Boot Theme Kernel Singleton.
add_action(
	'after_setup_theme',
	function () {
		\Maktomine\RestaurantTheme\Theme::instance()->boot();
	},
	1
);

/**
 * Public template function to render the theme header.
 *
 * @return void
 */
function maktomine_theme_header(): void {
	\Maktomine\RestaurantTheme\Theme::instance()->get_header()->render();
}

/**
 * Public template function to render the theme footer.
 *
 * @return void
 */
function maktomine_theme_footer(): void {
	\Maktomine\RestaurantTheme\Theme::instance()->get_footer()->render();
}
