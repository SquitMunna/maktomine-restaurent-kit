<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (along with style.css).
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();

$has_sidebar = is_active_sidebar( 'sidebar-main' );
?>

<div class="mkt-container">
	<div class="mkt-main-layout <?php echo $has_sidebar ? 'mkt-main-layout--has-sidebar' : ''; ?>">
		<main id="primary" class="site-main">

		<?php
		if ( have_posts() ) :
			if ( is_home() && ! is_front_page() ) :
				?>
				<header class="mkt-page-header">
					<h1 class="mkt-page-title"><?php single_post_title(); ?></h1>
				</header>
				<?php
			endif;
			?>

			<div class="mkt-posts-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'mkt-post-card' ); ?>>
						<?php if ( has_post_thumbnail() ) : ?>
							<a href="<?php the_permalink(); ?>" class="mkt-post-thumbnail" tabindex="-1" aria-hidden="true">
								<?php the_post_thumbnail( 'medium_large' ); ?>
							</a>
						<?php endif; ?>

						<div class="mkt-post-card__body">
							<div class="mkt-post-card__meta">
								<span class="mkt-post-card__date"><?php echo esc_html( get_the_date() ); ?></span>
								<span class="mkt-post-card__author"><?php echo esc_html( get_the_author() ); ?></span>
							</div>

							<h2 class="mkt-post-card__title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>

							<div class="mkt-post-card__excerpt">
								<?php the_excerpt(); ?>
							</div>

							<a href="<?php the_permalink(); ?>" class="mkt-post-card__read-more">
								<?php esc_html_e( 'Read More', 'maktomine-restaurant-theme' ); ?> &rarr;
							</a>
						</div>
					</article>
					<?php
				endwhile;
				?>
			</div>

			<div class="mkt-pagination">
				<?php
				the_posts_pagination(
					[
						'prev_text' => '&larr; ' . esc_html__( 'Previous', 'maktomine-restaurant-theme' ),
						'next_text' => esc_html__( 'Next', 'maktomine-restaurant-theme' ) . ' &rarr;',
					]
				);
				?>
			</div>

		<?php else : ?>

			<section class="mkt-no-results">
				<header class="mkt-page-header">
					<h1 class="mkt-page-title"><?php esc_html_e( 'Nothing Found', 'maktomine-restaurant-theme' ); ?></h1>
				</header>
				<div class="mkt-entry-content">
					<p><?php esc_html_e( 'It seems we cannot find what you are looking for. Perhaps searching can help.', 'maktomine-restaurant-theme' ); ?></p>
					<?php get_search_form(); ?>
				</div>
			</section>

		<?php endif; ?>

		</main><!-- #primary -->

		<?php
		if ( $has_sidebar ) {
			get_sidebar();
		}
		?>
	</div><!-- .mkt-main-layout -->
</div><!-- .mkt-container -->

<?php
get_footer();
