<?php
/**
 * The template for displaying all single posts.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();

$has_sidebar = is_active_sidebar( 'sidebar-main' );
?>

<div class="mkt-container">
	<div class="mkt-main-layout <?php echo $has_sidebar ? 'mkt-main-layout--has-sidebar' : ''; ?>">
		<main id="primary" class="site-main site-main--single">

			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'mkt-single-entry' ); ?>>
					<header class="mkt-page-header">
						<h1 class="mkt-page-title"><?php the_title(); ?></h1>
						<div class="mkt-entry-meta">
							<span class="mkt-entry-meta__date"><?php echo esc_html( get_the_date() ); ?></span>
							<span class="mkt-entry-meta__author"><?php echo esc_html( sprintf( __( 'By %s', 'maktomine-restaurant-theme' ), get_the_author() ) ); ?></span>
						</div>
					</header>

					<?php if ( has_post_thumbnail() ) : ?>
						<div class="mkt-single-featured-image">
							<?php the_post_thumbnail( 'large' ); ?>
						</div>
					<?php endif; ?>

					<div class="mkt-entry-content">
						<?php
						the_content();

						wp_link_pages(
							[
								'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'maktomine-restaurant-theme' ),
								'after'  => '</div>',
							]
						);
						?>
					</div>

					<footer class="mkt-entry-footer">
						<?php the_tags( '<div class="mkt-post-tags"><span class="mkt-post-tags__label">' . esc_html__( 'Tags:', 'maktomine-restaurant-theme' ) . '</span> ', ', ', '</div>' ); ?>
					</footer>

					<?php
					the_post_navigation(
						[
							'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous:', 'maktomine-restaurant-theme' ) . '</span> <span class="nav-title">%title</span>',
							'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next:', 'maktomine-restaurant-theme' ) . '</span> <span class="nav-title">%title</span>',
						]
					);

					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
					?>
				</article>
				<?php
			endwhile;
			?>

		</main><!-- #primary -->

		<?php
		if ( $has_sidebar ) {
			get_sidebar();
		}
		?>
	</div><!-- .mkt-main-layout -->
</div><!-- .mkt-container -->

<?php
get_footer();
