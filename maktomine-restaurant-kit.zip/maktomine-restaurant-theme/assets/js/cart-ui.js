/**
 * Maktomine Restaurant Theme — Browser Cart UI Presentation Layer.
 *
 * Consumes the approved BrowserCart state (window.Maktomine.cart).
 * Exclusively handles DOM rendering, interaction, accessibility, and drawer open/close.
 *
 * STRICT SEPARATION:
 * - BrowserCart owns lines, quantities, persistence, and events.
 * - This UI module owns DOM elements, click handlers, and accessibility.
 * - Core PHP owns pricing, validation, catalog authority, and order persistence.
 * - Zero client-side price calculations, fake subtotals, or direct localStorage access.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

(function (window, document) {
	'use strict';

	/**
	 * Cart UI Controller.
	 */
	class CartUI {
		constructor() {
			this.isOpen = false;
			this.lastFocusedElement = null;

			this.drawer = null;
			this.backdrop = null;
			this.dialog = null;
			this.closeBtn = null;
			this.body = null;
			this.footer = null;
			this.footerCount = null;
			this.headerBadge = null;
			this.clearBtn = null;
			this.footerSubtotal = null;

			// Phase 4N & 4O: In-memory presentation & pricing cache (Map: line_id -> resolved PresentationLine)
			this.presentationCache = new Map();
			this.pricingSnapshot = null;
			this.activeResolutionSeq = 0;
			this.resolveUrl = (window.maktomineCartUIConfig && window.maktomineCartUIConfig.resolveUrl) || '';

			// Phase 4P: View State Management ('lines' | 'checkout' | 'success')
			this.viewMode = 'lines';
			this.isSubmitting = false;
			this.submissionError = null;
			this.lastSubmittedOrder = null;
			this.checkoutButton = null;

			// Phase 4Q: Active in-memory idempotency key for single logical submission lifecycle
			this.activeIdempotencyKey = null;

			// In-memory checkout customer form state (never stored in localStorage/sessionStorage/BrowserCart)
			this.customerFormState = {
				name: '',
				phone: '',
				whatsapp: '',
				order_type: 'delivery',
				delivery_address: '',
				delivery_area: '',
				delivery_landmark: '',
				order_note: '',
			};
			this.fieldErrors = {};

			this.init();
		}

		/**
		 * Retrieve active BrowserCart instance.
		 *
		 * @return {Object|null}
		 */
		getCart() {
			if (window.Maktomine && window.Maktomine.cart) {
				return window.Maktomine.cart;
			}
			return null;
		}

		/**
		 * Check if Elementor visual editor is active.
		 *
		 * @return {boolean}
		 */
		isElementorEditor() {
			return document.body.classList.contains('elementor-editor-active') ||
				Boolean(window.elementorFrontend && typeof window.elementorFrontend.isEditMode === 'function' && window.elementorFrontend.isEditMode());
		}

		/**
		 * Initialize the Cart UI presentation.
		 */
		init() {
			this.ensureDrawerStructure();
			this.bindLauncher();
			this.bindDrawerControls();
			this.bindCartEvents();
			this.render();
		}

		/**
		 * Ensure semantic Cart Drawer DOM structure is present in the document.
		 */
		ensureDrawerStructure() {
			let drawer = document.getElementById('mkt-cart-drawer');
			if (!drawer) {
				drawer = document.createElement('div');
				drawer.id = 'mkt-cart-drawer';
				drawer.className = 'mkt-cart-drawer';
				drawer.setAttribute('aria-hidden', 'true');

				// Backdrop overlay
				const overlay = document.createElement('div');
				overlay.id = 'mkt-cart-backdrop';
				overlay.className = 'mkt-cart-drawer__overlay';
				overlay.setAttribute('tabindex', '-1');
				drawer.appendChild(overlay);

				// Dialog
				const dialog = document.createElement('div');
				dialog.id = 'mkt-cart-dialog';
				dialog.className = 'mkt-cart-drawer__dialog';
				dialog.setAttribute('role', 'dialog');
				dialog.setAttribute('aria-modal', 'true');
				dialog.setAttribute('aria-labelledby', 'mkt-cart-title');

				// Header
				const header = document.createElement('div');
				header.className = 'mkt-cart-drawer__header';

				const headerMain = document.createElement('div');
				headerMain.className = 'mkt-cart-drawer__header-main';

				const title = document.createElement('h2');
				title.id = 'mkt-cart-title';
				title.className = 'mkt-cart-drawer__title';
				title.textContent = 'Your Cart';
				headerMain.appendChild(title);

				const badge = document.createElement('span');
				badge.id = 'mkt-cart-line-badge';
				badge.className = 'mkt-cart-drawer__badge';
				badge.setAttribute('aria-hidden', 'true');
				badge.textContent = '0 items';
				headerMain.appendChild(badge);

				header.appendChild(headerMain);

				const closeBtn = document.createElement('button');
				closeBtn.type = 'button';
				closeBtn.id = 'mkt-cart-close-btn';
				closeBtn.className = 'mkt-cart-drawer__close';
				closeBtn.setAttribute('aria-label', 'Close cart');
				closeBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
				header.appendChild(closeBtn);

				dialog.appendChild(header);

				// Body
				const body = document.createElement('div');
				body.id = 'mkt-cart-body';
				body.className = 'mkt-cart-drawer__body';
				dialog.appendChild(body);

				// Footer
				const footer = document.createElement('div');
				footer.id = 'mkt-cart-footer';
				footer.className = 'mkt-cart-drawer__footer';

				const summary = document.createElement('div');
				summary.className = 'mkt-cart-drawer__summary';

				// Total items row
				const countRow = document.createElement('div');
				countRow.className = 'mkt-cart-drawer__summary-row';

				const summaryLabel = document.createElement('span');
				summaryLabel.className = 'mkt-cart-drawer__summary-label';
				summaryLabel.textContent = 'Total Items';
				countRow.appendChild(summaryLabel);

				const summaryCount = document.createElement('span');
				summaryCount.id = 'mkt-cart-footer-count';
				summaryCount.className = 'mkt-cart-drawer__summary-count';
				summaryCount.textContent = '0';
				countRow.appendChild(summaryCount);

				summary.appendChild(countRow);

				// Authoritative subtotal row
				const subtotalRow = document.createElement('div');
				subtotalRow.className = 'mkt-cart-drawer__summary-row mkt-cart-drawer__subtotal-row';

				const subtotalLabel = document.createElement('span');
				subtotalLabel.className = 'mkt-cart-drawer__subtotal-label';
				subtotalLabel.textContent = 'Subtotal';
				subtotalRow.appendChild(subtotalLabel);

				const subtotalAmount = document.createElement('span');
				subtotalAmount.id = 'mkt-cart-footer-subtotal';
				subtotalAmount.className = 'mkt-cart-drawer__subtotal-amount';
				subtotalAmount.textContent = '—';
				subtotalRow.appendChild(subtotalAmount);

				summary.appendChild(subtotalRow);

				footer.appendChild(summary);

				const actions = document.createElement('div');
				actions.className = 'mkt-cart-drawer__actions';

				// Active checkout button (Phase 4P)
				const checkoutBtn = document.createElement('button');
				checkoutBtn.type = 'button';
				checkoutBtn.className = 'mkt-cart-drawer__checkout-btn';
				checkoutBtn.id = 'mkt-cart-checkout-btn';
				checkoutBtn.textContent = 'Proceed to Checkout';
				actions.appendChild(checkoutBtn);

				// Clear cart button
				const clearBtn = document.createElement('button');
				clearBtn.type = 'button';
				clearBtn.className = 'mkt-cart-drawer__clear-btn';
				clearBtn.id = 'mkt-cart-clear-btn';
				clearBtn.setAttribute('aria-label', 'Clear all items from cart');
				clearBtn.textContent = 'Clear Cart';
				actions.appendChild(clearBtn);

				footer.appendChild(actions);
				dialog.appendChild(footer);

				drawer.appendChild(dialog);
				document.body.appendChild(drawer);
			}

			this.drawer         = drawer;
			this.backdrop       = document.getElementById('mkt-cart-backdrop');
			this.dialog         = document.getElementById('mkt-cart-dialog');
			this.closeBtn       = document.getElementById('mkt-cart-close-btn');
			this.body           = document.getElementById('mkt-cart-body');
			this.footer         = document.getElementById('mkt-cart-footer');
			this.footerCount    = document.getElementById('mkt-cart-footer-count');
			this.footerSubtotal = document.getElementById('mkt-cart-footer-subtotal');
			this.headerBadge    = document.getElementById('mkt-cart-line-badge');
			this.clearBtn       = document.getElementById('mkt-cart-clear-btn');
			this.checkoutBtn    = document.getElementById('mkt-cart-checkout-btn');
		}

		/**
		 * Bind existing Cart Launcher buttons in header/DOM.
		 */
		bindLauncher() {
			const triggers = document.querySelectorAll('#mkt-cart-launcher-trigger, [data-action="toggle-cart"]');
			triggers.forEach((trigger) => {
				trigger.setAttribute('aria-controls', 'mkt-cart-drawer');
				trigger.setAttribute('aria-expanded', 'false');

				trigger.addEventListener('click', (e) => {
					e.preventDefault();
					this.toggle();
				});
			});

			// Also listen to existing theme.js custom toggle event
			window.addEventListener('maktomine/cart/toggle', (e) => {
				e.preventDefault();
				this.toggle();
			});
		}

		/**
		 * Bind drawer event controls (close button, backdrop, keyboard escape, actions).
		 */
		bindDrawerControls() {
			if (this.closeBtn) {
				this.closeBtn.addEventListener('click', (e) => {
					e.preventDefault();
					this.close();
				});
			}

			if (this.backdrop) {
				this.backdrop.addEventListener('click', () => {
					this.close();
				});
			}

			// Escape key listener & focus trapping
			document.addEventListener('keydown', (e) => {
				if (!this.isOpen) return;

				if (e.key === 'Escape') {
					e.preventDefault();
					this.close();
					return;
				}

				// Simple keyboard focus loop within dialog
				if (e.key === 'Tab' && this.dialog) {
					const focusableElements = this.dialog.querySelectorAll(
						'button:not([disabled]), [tabindex]:not([tabindex="-1"])'
					);
					if (focusableElements.length === 0) return;

					const firstElement = focusableElements[0];
					const lastElement = focusableElements[focusableElements.length - 1];

					if (e.shiftKey && document.activeElement === firstElement) {
						e.preventDefault();
						lastElement.focus();
					} else if (!e.shiftKey && document.activeElement === lastElement) {
						e.preventDefault();
						firstElement.focus();
					}
				}
			});

			// Event delegation for line list actions (increase, decrease, remove)
			if (this.body) {
				this.body.addEventListener('click', (e) => {
					const target = e.target.closest('[data-cart-action]');
					if (!target) return;

					e.preventDefault();
					const action = target.getAttribute('data-cart-action');
					const lineId = target.getAttribute('data-line-id');
					if (!lineId) return;

					this.handleLineAction(action, lineId);
				});
			}

			// Proceed to Checkout action (Phase 4P)
			if (this.checkoutBtn) {
				this.checkoutBtn.addEventListener('click', (e) => {
					e.preventDefault();
					const cart = this.getCart();
					if (!cart || cart.isEmpty()) return;
					this.viewMode = 'checkout';
					this.submissionError = null;
					this.fieldErrors = {};
					this.render();
				});
			}

			// Clear Cart action
			if (this.clearBtn) {
				this.clearBtn.addEventListener('click', (e) => {
					e.preventDefault();
					const cart = this.getCart();
					if (cart) {
						cart.clear();
					}
					this.activeIdempotencyKey = null;
				});
			}
		}

		/**
		 * Bind reactive listeners to BrowserCart events.
		 */
		bindCartEvents() {
			const handleCartUpdate = () => {
				// Reset active idempotency key if cart lines change to ensure new logical submission
				this.activeIdempotencyKey = null;
				this.render();
			};

			window.addEventListener('maktomine:cart:updated', handleCartUpdate);
		}

		/**
		 * Open the cart drawer.
		 */
		open() {
			if (this.isOpen) return;

			// Guard against interfering with Elementor editing mode
			if (this.isElementorEditor()) return;

			this.isOpen = true;
			this.lastFocusedElement = document.activeElement;

			if (this.drawer) {
				this.drawer.classList.add('mkt-cart-drawer--open');
				this.drawer.setAttribute('aria-hidden', 'false');
			}

			this.updateLauncherAria(true);
			document.body.style.overflow = 'hidden';

			if (this.closeBtn) {
				this.closeBtn.focus();
			}
		}

		/**
		 * Close the cart drawer.
		 */
		close() {
			if (!this.isOpen) return;

			this.isOpen = false;

			if (this.drawer) {
				this.drawer.classList.remove('mkt-cart-drawer--open');
				this.drawer.setAttribute('aria-hidden', 'true');
			}

			this.updateLauncherAria(false);
			document.body.style.overflow = '';

			if (this.lastFocusedElement && typeof this.lastFocusedElement.focus === 'function') {
				this.lastFocusedElement.focus();
			}
		}

		/**
		 * Toggle open/closed state.
		 */
		toggle() {
			if (this.isOpen) {
				this.close();
			} else {
				this.open();
			}
		}

		/**
		 * Update aria-expanded on all launcher triggers.
		 *
		 * @param {boolean} expanded
		 */
		updateLauncherAria(expanded) {
			const triggers = document.querySelectorAll('#mkt-cart-launcher-trigger, [data-action="toggle-cart"]');
			triggers.forEach((trigger) => {
				trigger.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			});
		}

		/**
		 * Handle a line action from event delegation.
		 *
		 * @param {string} action
		 * @param {string} lineId
		 */
		handleLineAction(action, lineId) {
			const cart = this.getCart();
			if (!cart) return;

			const lines = cart.getLines();
			const line = lines.find((l) => l.line_id === lineId);
			if (!line) return;

			if (action === 'increase') {
				if (line.quantity < 50) {
					cart.updateQuantity(lineId, line.quantity + 1);
				}
			} else if (action === 'decrease') {
				cart.updateQuantity(lineId, line.quantity - 1);
			} else if (action === 'remove') {
				cart.removeLine(lineId);
			}
		}

		/**
		 * Retrieve safe display title for a food item from the DOM catalog if present.
		 *
		 * @param {number} foodId
		 * @return {string}
		 */
		getFoodTitle(foodId) {
			const card = document.getElementById('mkt-food-item-' + foodId);
			if (card) {
				const titleElem = card.querySelector('.mkt-food-card__title a, .mkt-food-card__title');
				if (titleElem && titleElem.textContent.trim()) {
					return titleElem.textContent.trim();
				}
			}
			return 'Food Item #' + foodId;
		}

		/**
		 * Retrieve presentation object for a cart line.
		 * Returns cached catalog data if available, or a safe baseline structure.
		 *
		 * @param {Object} line
		 * @return {Object}
		 */
		getPresentation(line) {
			if (this.presentationCache.has(line.line_id)) {
				return this.presentationCache.get(line.line_id);
			}

			// Safe fallback baseline structure
			const rawVariations = [];
			if (line.selection && typeof line.selection === 'object' && !Array.isArray(line.selection)) {
				Object.keys(line.selection).forEach((k) => {
					rawVariations.push({
						attribute_id: k,
						attribute_label: k,
						option_id: line.selection[k],
						option_label: line.selection[k],
					});
				});
			}

			const rawAddons = [];
			if (Array.isArray(line.addons)) {
				line.addons.forEach((a) => {
					rawAddons.push({
						id: a.id,
						name: a.id,
						quantity: a.quantity || 1,
					});
				});
			}

			return {
				line_id: line.line_id,
				food_id: line.food_id,
				title: this.getFoodTitle(line.food_id),
				image: null,
				quantity: line.quantity,
				status: 'valid',
				is_available: true,
				availability_token: 'in-stock',
				availability_label: 'In Stock',
				variations: rawVariations,
				addons: rawAddons,
				pricing: null,
				error_message: null,
			};
		}

		/**
		 * Asynchronously resolve presentation and authoritative pricing snapshot for cart lines.
		 *
		 * @param {Array} lines
		 */
		resolveLines(lines) {
			if (!this.resolveUrl) return;

			if (!Array.isArray(lines) || lines.length === 0) {
				this.presentationCache.clear();
				this.pricingSnapshot = null;
				if (this.footerSubtotal) {
					this.footerSubtotal.textContent = '—';
				}
				return;
			}

			// Clean up cached lines that are no longer in cart
			const currentLineIds = new Set(lines.map((l) => l.line_id));
			for (const cachedId of this.presentationCache.keys()) {
				if (!currentLineIds.has(cachedId)) {
					this.presentationCache.delete(cachedId);
				}
			}

			// Phase 4O: EVERY CART MUTATION MUST TRIGGER A FRESH AUTHORITATIVE SERVER RE-RESOLUTION.
			// The browser must never assume that a previously received pricing snapshot is still current after a mutation.
			// A cached pricing snapshot MUST NOT be treated as authoritative after a cart mutation.
			const seq = ++this.activeResolutionSeq;

			const payload = {
				lines: lines.map((l) => ({
					line_id: l.line_id,
					food_id: l.food_id,
					selection: l.selection || {},
					addons: l.addons || [],
					quantity: l.quantity,
				})),
			};

			fetch(this.resolveUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': (window.maktomineCartConfig && window.maktomineCartConfig.nonce) || '',
				},
				body: JSON.stringify(payload),
			})
				.then((res) => {
					if (!res.ok) throw new Error(`HTTP ${res.status}`);
					return res.json();
				})
				.then((data) => {
					if (seq !== this.activeResolutionSeq) return; // Stale sequence, discard
					if (data && data.success && data.data) {
						this.pricingSnapshot = {
							subtotal: data.data.subtotal,
							subtotal_formatted: data.data.subtotal_formatted,
							currency: data.data.currency,
							currency_symbol: data.data.currency_symbol,
							currency_position: data.data.currency_position,
							item_count: data.data.item_count,
						};

						if (Array.isArray(data.data.lines)) {
							data.data.lines.forEach((item) => {
								if (item && item.line_id) {
									this.presentationCache.set(item.line_id, item);
								}
							});
						}

						// Re-render lines with freshly resolved catalog presentation and authoritative pricing
						this.render();
					}
				})
				.catch(() => {
					if (seq !== this.activeResolutionSeq) return; // Stale sequence, discard
					// When authoritative resolution request fails:
					// Existing presentation information may be retained as a visual fallback,
					// but cached monetary values must NOT be represented as a newly authoritative/current price.
					this.pricingSnapshot = null;
					if (this.footerSubtotal) {
						this.footerSubtotal.textContent = '—';
					}
				});
		}

		/**
		 * Synchronize cart badge elements in the header and document.
		 *
		 * @param {number} itemCount
		 */
		syncBadges(itemCount) {
			const badges = document.querySelectorAll(
				'#mkt-cart-launcher-count, #mkt-cart-badge-count, .mkt-cart-badge'
			);
			badges.forEach((badge) => {
				badge.textContent = String(itemCount);
				badge.setAttribute('data-count', String(itemCount));
			});

			const triggers = document.querySelectorAll('#mkt-cart-launcher-trigger');
			triggers.forEach((trigger) => {
				trigger.setAttribute('aria-label', `Open Food Cart, ${itemCount} items`);
			});
		}

		/**
		 * Render the Cart UI based on current BrowserCart state.
		 */
		render() {
			const cart = this.getCart();
			const itemCount = cart ? cart.getItemCount() : 0;
			const lines = cart ? cart.getLines() : [];
			const isEmpty = !cart || cart.isEmpty();

			// Prune obsolete cached presentation entries
			const activeLineIds = new Set(lines.map((l) => l.line_id));
			for (const cachedId of this.presentationCache.keys()) {
				if (!activeLineIds.has(cachedId)) {
					this.presentationCache.delete(cachedId);
				}
			}

			// Request authoritative catalog resolution and pricing snapshot for cart lines
			if (!isEmpty) {
				this.resolveLines(lines);
			}

			// 1. Sync header launcher badges
			this.syncBadges(itemCount);

			// 2. Sync drawer header badge
			if (this.headerBadge) {
				const label = itemCount === 1 ? '1 item' : `${itemCount} items`;
				this.headerBadge.textContent = label;
			}

			// 3. Sync footer summary & subtotal
			if (this.footerCount) {
				this.footerCount.textContent = String(itemCount);
			}

			if (this.footerSubtotal) {
				if (this.pricingSnapshot && typeof this.pricingSnapshot.subtotal_formatted === 'string') {
					this.footerSubtotal.textContent = this.pricingSnapshot.subtotal_formatted;
				} else {
					this.footerSubtotal.textContent = '—';
				}
			}

			// 4. Toggle footer visibility & checkout/clear button states based on viewMode
			if (this.footer) {
				if (isEmpty || this.viewMode === 'success' || this.viewMode === 'checkout') {
					this.footer.style.display = 'none';
				} else {
					this.footer.style.display = 'flex';
				}
			}

			// 5. Render drawer body content according to active view state
			if (!this.body) return;

			// Clear current body safely
			while (this.body.firstChild) {
				this.body.removeChild(this.body.firstChild);
			}

			if (this.viewMode === 'success' && this.lastSubmittedOrder) {
				this.renderSuccessState();
			} else if (isEmpty) {
				this.viewMode = 'lines';
				this.renderEmptyState();
			} else if (this.viewMode === 'checkout') {
				this.renderCheckoutForm();
			} else {
				this.renderLineList(lines);
			}
		}

		/**
		 * Render accessible empty-cart state.
		 */
		renderEmptyState() {
			const container = document.createElement('div');
			container.className = 'mkt-cart-empty';

			const iconSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
			iconSvg.setAttribute('class', 'mkt-cart-empty__icon');
			iconSvg.setAttribute('width', '48');
			iconSvg.setAttribute('height', '48');
			iconSvg.setAttribute('viewBox', '0 0 24 24');
			iconSvg.setAttribute('fill', 'none');
			iconSvg.setAttribute('stroke', 'currentColor');
			iconSvg.setAttribute('stroke-width', '1.5');
			iconSvg.setAttribute('stroke-linecap', 'round');
			iconSvg.setAttribute('stroke-linejoin', 'round');
			iconSvg.setAttribute('aria-hidden', 'true');

			const circle1 = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
			circle1.setAttribute('cx', '9');
			circle1.setAttribute('cy', '21');
			circle1.setAttribute('r', '1');
			const circle2 = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
			circle2.setAttribute('cx', '20');
			circle2.setAttribute('cy', '21');
			circle2.setAttribute('r', '1');
			const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
			path.setAttribute('d', 'M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6');

			iconSvg.appendChild(circle1);
			iconSvg.appendChild(circle2);
			iconSvg.appendChild(path);
			container.appendChild(iconSvg);

			const title = document.createElement('h3');
			title.className = 'mkt-cart-empty__title';
			title.textContent = 'Your cart is empty';
			container.appendChild(title);

			const desc = document.createElement('p');
			desc.className = 'mkt-cart-empty__desc';
			desc.textContent = 'Add items from the restaurant menu to begin your order.';
			container.appendChild(desc);

			this.body.appendChild(container);
		}

		/**
		 * Render line list from active BrowserCart lines.
		 *
		 * @param {Array} lines
		 */
		renderLineList(lines) {
			const ul = document.createElement('ul');
			ul.className = 'mkt-cart-lines';
			ul.setAttribute('role', 'list');

			lines.forEach((line) => {
				const presentation = this.getPresentation(line);

				const li = document.createElement('li');
				li.className = 'mkt-cart-line';
				if (!presentation.is_available || presentation.status !== 'valid') {
					li.classList.add(`mkt-cart-line--${presentation.status}`);
				}
				li.setAttribute('data-line-id', line.line_id);

				// Main row containing thumbnail media and content column
				const mainRow = document.createElement('div');
				mainRow.className = 'mkt-cart-line__main';

				// Media thumbnail
				const media = document.createElement('div');
				media.className = 'mkt-cart-line__media';
				if (presentation.image && presentation.image.url) {
					const img = document.createElement('img');
					img.className = 'mkt-cart-line__img';
					img.src = presentation.image.url;
					img.alt = presentation.image.alt || presentation.title || '';
					img.loading = 'lazy';
					img.width = 56;
					img.height = 56;
					media.appendChild(img);
				} else {
					const iconSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
					iconSvg.setAttribute('class', 'mkt-cart-line__media-placeholder');
					iconSvg.setAttribute('width', '24');
					iconSvg.setAttribute('height', '24');
					iconSvg.setAttribute('viewBox', '0 0 24 24');
					iconSvg.setAttribute('fill', 'none');
					iconSvg.setAttribute('stroke', 'currentColor');
					iconSvg.setAttribute('stroke-width', '1.5');
					iconSvg.setAttribute('stroke-linecap', 'round');
					iconSvg.setAttribute('stroke-linejoin', 'round');
					iconSvg.setAttribute('aria-hidden', 'true');

					const p1 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
					p1.setAttribute('d', 'M18 8h1a4 4 0 0 1 0 8h-1');
					const p2 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
					p2.setAttribute('d', 'M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z');
					const l1 = document.createElementNS('http://www.w3.org/2000/svg', 'line');
					l1.setAttribute('x1', '6');
					l1.setAttribute('y1', '1');
					l1.setAttribute('x2', '6');
					l1.setAttribute('y2', '4');
					iconSvg.appendChild(p1);
					iconSvg.appendChild(p2);
					iconSvg.appendChild(l1);
					media.appendChild(iconSvg);
				}
				mainRow.appendChild(media);

				// Content column
				const content = document.createElement('div');
				content.className = 'mkt-cart-line__content';

				// Top row: Title and Remove button
				const topRow = document.createElement('div');
				topRow.className = 'mkt-cart-line__top';

				const title = document.createElement('h4');
				title.className = 'mkt-cart-line__title';
				title.textContent = presentation.title;
				topRow.appendChild(title);

				const removeBtn = document.createElement('button');
				removeBtn.type = 'button';
				removeBtn.className = 'mkt-cart-line__remove-btn';
				removeBtn.setAttribute('data-cart-action', 'remove');
				removeBtn.setAttribute('data-line-id', line.line_id);
				removeBtn.setAttribute('aria-label', `Remove ${presentation.title} from cart`);
				removeBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
				topRow.appendChild(removeBtn);
				content.appendChild(topRow);

				// Authoritative price display (effective unit price)
				if (presentation.pricing && typeof presentation.pricing.effective_unit_price_formatted === 'string') {
					const priceRow = document.createElement('div');
					priceRow.className = 'mkt-cart-line__price-row';

					const unitPrice = document.createElement('span');
					unitPrice.className = 'mkt-cart-line__unit-price';
					unitPrice.textContent = presentation.pricing.effective_unit_price_formatted;
					priceRow.appendChild(unitPrice);

					if (presentation.pricing.addons_total > 0 && typeof presentation.pricing.addons_total_formatted === 'string') {
						const breakdown = document.createElement('span');
						breakdown.className = 'mkt-cart-line__price-breakdown';
						breakdown.textContent = `(${presentation.pricing.unit_price_formatted} base + ${presentation.pricing.addons_total_formatted} add-ons)`;
						priceRow.appendChild(breakdown);
					}

					content.appendChild(priceRow);
				}

				// Status badge if unavailable or invalid
				if (!presentation.is_available || presentation.status !== 'valid') {
					const badge = document.createElement('span');
					badge.className = `mkt-cart-line__badge mkt-cart-line__badge--${presentation.status}`;
					badge.textContent = presentation.availability_label || 'Unavailable';
					content.appendChild(badge);

					if (presentation.error_message) {
						const warn = document.createElement('p');
						warn.className = 'mkt-cart-line__warning';
						warn.textContent = presentation.error_message;
						content.appendChild(warn);
					}
				}

				// Meta row: Variations & Add-ons
				const meta = document.createElement('div');
				meta.className = 'mkt-cart-line__meta';

				// Render resolved variations
				if (Array.isArray(presentation.variations) && presentation.variations.length > 0) {
					presentation.variations.forEach((v) => {
						const tag = document.createElement('span');
						tag.className = 'mkt-cart-meta-tag';
						tag.textContent = `${v.attribute_label}: ${v.option_label}`;
						meta.appendChild(tag);
					});
				}

				// Render resolved add-ons (including authoritative price contribution)
				if (Array.isArray(presentation.addons) && presentation.addons.length > 0) {
					presentation.addons.forEach((a) => {
						const tag = document.createElement('span');
						tag.className = 'mkt-cart-meta-tag mkt-cart-meta-tag--addon';
						const qtySuffix = a.quantity > 1 ? ` ×${a.quantity}` : '';
						const priceSuffix = a.line_total_formatted ? ` (${a.line_total_formatted})` : '';
						tag.textContent = `+ ${a.name}${qtySuffix}${priceSuffix}`;
						meta.appendChild(tag);
					});
				}

				if (meta.children.length > 0) {
					content.appendChild(meta);
				}

				mainRow.appendChild(content);
				li.appendChild(mainRow);

				// Bottom row: Quantity controls & authoritative line total
				const bottomRow = document.createElement('div');
				bottomRow.className = 'mkt-cart-line__bottom';

				const qtySection = document.createElement('div');
				qtySection.className = 'mkt-cart-line__qty-section';

				const qtyLabel = document.createElement('span');
				qtyLabel.className = 'mkt-cart-line__qty-label';
				qtyLabel.textContent = 'Quantity';
				qtySection.appendChild(qtyLabel);

				const qtyGroup = document.createElement('div');
				qtyGroup.className = 'mkt-cart-qty-group';

				// Decrement button
				const decBtn = document.createElement('button');
				decBtn.type = 'button';
				decBtn.className = 'mkt-cart-qty-btn';
				decBtn.setAttribute('data-cart-action', 'decrease');
				decBtn.setAttribute('data-line-id', line.line_id);
				decBtn.setAttribute('aria-label', `Decrease quantity for ${presentation.title}`);
				decBtn.textContent = '−';
				qtyGroup.appendChild(decBtn);

				// Quantity value display
				const qtyVal = document.createElement('span');
				qtyVal.className = 'mkt-cart-qty-val';
				qtyVal.setAttribute('aria-live', 'polite');
				qtyVal.textContent = String(line.quantity);
				qtyGroup.appendChild(qtyVal);

				// Increment button
				const incBtn = document.createElement('button');
				incBtn.type = 'button';
				incBtn.className = 'mkt-cart-qty-btn';
				incBtn.setAttribute('data-cart-action', 'increase');
				incBtn.setAttribute('data-line-id', line.line_id);
				incBtn.setAttribute('aria-label', `Increase quantity for ${presentation.title}`);
				if (line.quantity >= 50) {
					incBtn.setAttribute('disabled', 'disabled');
				}
				incBtn.textContent = '+';
				qtyGroup.appendChild(incBtn);

				qtySection.appendChild(qtyGroup);
				bottomRow.appendChild(qtySection);

				// Authoritative line total (displayed only for priced lines)
				if (presentation.pricing && typeof presentation.pricing.line_total_formatted === 'string') {
					const lineTotalGroup = document.createElement('div');
					lineTotalGroup.className = 'mkt-cart-line__total';

					const lineTotalVal = document.createElement('span');
					lineTotalVal.className = 'mkt-cart-line__total-val';
					lineTotalVal.textContent = presentation.pricing.line_total_formatted;
					lineTotalGroup.appendChild(lineTotalVal);

					bottomRow.appendChild(lineTotalGroup);
				}

				li.appendChild(bottomRow);

				ul.appendChild(li);
			});

			this.body.appendChild(ul);
		}

		/**
		 * Render the customer checkout form (Phase 4P).
		 */
		renderCheckoutForm() {
			const container = document.createElement('div');
			container.className = 'mkt-cart-checkout';

			// Header with Back button and Title
			const header = document.createElement('div');
			header.className = 'mkt-cart-checkout__header';

			const title = document.createElement('h3');
			title.className = 'mkt-cart-checkout__title';
			title.textContent = 'Customer Information';
			header.appendChild(title);

			const backBtn = document.createElement('button');
			backBtn.type = 'button';
			backBtn.className = 'mkt-cart-checkout__back-btn';
			backBtn.setAttribute('aria-label', 'Return to cart items');
			backBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg> Back to Cart';
			if (this.isSubmitting) {
				backBtn.setAttribute('disabled', 'disabled');
			}
			backBtn.addEventListener('click', (e) => {
				e.preventDefault();
				if (this.isSubmitting) return;
				this.viewMode = 'lines';
				this.submissionError = null;
				this.fieldErrors = {};
				this.render();
			});
			header.appendChild(backBtn);
			container.appendChild(header);

			// Live status / Alert area (aria-live region for screen readers)
			const liveRegion = document.createElement('div');
			liveRegion.id = 'mkt-checkout-live-status';
			liveRegion.setAttribute('aria-live', 'polite');
			liveRegion.setAttribute('aria-atomic', 'true');

			if (this.submissionError) {
				const alert = document.createElement('div');
				alert.className = `mkt-cart-alert mkt-cart-alert--${this.submissionError.type || 'error'}`;
				alert.setAttribute('role', 'alert');

				const alertText = document.createElement('span');
				alertText.textContent = this.submissionError.message;
				alert.appendChild(alertText);

				liveRegion.appendChild(alert);
			}
			container.appendChild(liveRegion);

			// Form element
			const form = document.createElement('form');
			form.className = 'mkt-checkout-form';
			form.setAttribute('novalidate', 'novalidate');

			// --- Fieldset: Order Type (Pickup / Delivery) ---
			const typeFieldset = document.createElement('fieldset');
			typeFieldset.className = 'mkt-checkout-form__fieldset';

			const typeLegend = document.createElement('legend');
			typeLegend.className = 'mkt-checkout-form__legend';
			typeLegend.textContent = 'Fulfillment Method';
			typeFieldset.appendChild(typeLegend);

			const typeToggle = document.createElement('div');
			typeToggle.className = 'mkt-order-type-toggle';
			typeToggle.setAttribute('role', 'radiogroup');
			typeToggle.setAttribute('aria-label', 'Fulfillment Method');

			// Delivery option
			const deliveryBtn = document.createElement('button');
			deliveryBtn.type = 'button';
			deliveryBtn.className = 'mkt-order-type-btn' + (this.customerFormState.order_type === 'delivery' ? ' mkt-order-type-btn--active' : '');
			deliveryBtn.setAttribute('role', 'radio');
			deliveryBtn.setAttribute('aria-checked', this.customerFormState.order_type === 'delivery' ? 'true' : 'false');
			deliveryBtn.textContent = 'Delivery';
			if (this.isSubmitting) deliveryBtn.setAttribute('disabled', 'disabled');
			deliveryBtn.addEventListener('click', (e) => {
				e.preventDefault();
				if (this.isSubmitting) return;
				this.customerFormState.order_type = 'delivery';
				delete this.fieldErrors.delivery_address;
				this.render();
			});
			typeToggle.appendChild(deliveryBtn);

			// Pickup option
			const pickupBtn = document.createElement('button');
			pickupBtn.type = 'button';
			pickupBtn.className = 'mkt-order-type-btn' + (this.customerFormState.order_type === 'pickup' ? ' mkt-order-type-btn--active' : '');
			pickupBtn.setAttribute('role', 'radio');
			pickupBtn.setAttribute('aria-checked', this.customerFormState.order_type === 'pickup' ? 'true' : 'false');
			pickupBtn.textContent = 'Pickup';
			if (this.isSubmitting) pickupBtn.setAttribute('disabled', 'disabled');
			pickupBtn.addEventListener('click', (e) => {
				e.preventDefault();
				if (this.isSubmitting) return;
				this.customerFormState.order_type = 'pickup';
				delete this.fieldErrors.delivery_address;
				this.render();
			});
			typeToggle.appendChild(pickupBtn);

			typeFieldset.appendChild(typeToggle);
			form.appendChild(typeFieldset);

			// --- Fieldset: Customer Contact Details ---
			const contactFieldset = document.createElement('fieldset');
			contactFieldset.className = 'mkt-checkout-form__fieldset';

			const contactLegend = document.createElement('legend');
			contactLegend.className = 'mkt-checkout-form__legend';
			contactLegend.textContent = 'Contact Details';
			contactFieldset.appendChild(contactLegend);

			// 1. Customer Name (Required, 2-191 chars)
			contactFieldset.appendChild(
				this.createFormField({
					id: 'mkt-field-name',
					name: 'name',
					label: 'Full Name',
					required: true,
					type: 'text',
					value: this.customerFormState.name,
					placeholder: 'e.g. John Doe',
					maxLength: 191,
					error: this.fieldErrors.name,
					onInput: (val) => {
						this.customerFormState.name = val;
						if (this.fieldErrors.name) {
							delete this.fieldErrors.name;
							this.clearFieldError('mkt-field-name');
						}
					},
				})
			);

			// 2. Phone (Required, basic format check)
			contactFieldset.appendChild(
				this.createFormField({
					id: 'mkt-field-phone',
					name: 'phone',
					label: 'Phone Number',
					required: true,
					type: 'tel',
					value: this.customerFormState.phone,
					placeholder: 'e.g. +1234567890 or 01712345678',
					maxLength: 32,
					error: this.fieldErrors.phone,
					onInput: (val) => {
						this.customerFormState.phone = val;
						if (this.fieldErrors.phone) {
							delete this.fieldErrors.phone;
							this.clearFieldError('mkt-field-phone');
						}
					},
				})
			);

			// 3. WhatsApp (Optional)
			contactFieldset.appendChild(
				this.createFormField({
					id: 'mkt-field-whatsapp',
					name: 'whatsapp',
					label: 'WhatsApp Number',
					required: false,
					optionalText: '(Optional)',
					type: 'tel',
					value: this.customerFormState.whatsapp,
					placeholder: 'Leave blank to use phone number',
					maxLength: 32,
					error: this.fieldErrors.whatsapp,
					onInput: (val) => {
						this.customerFormState.whatsapp = val;
						if (this.fieldErrors.whatsapp) {
							delete this.fieldErrors.whatsapp;
							this.clearFieldError('mkt-field-whatsapp');
						}
					},
				})
			);

			form.appendChild(contactFieldset);

			// --- Fieldset: Delivery Address (when order_type === 'delivery') ---
			const deliveryFieldset = document.createElement('fieldset');
			deliveryFieldset.className = 'mkt-checkout-form__fieldset mkt-delivery-fields' +
				(this.customerFormState.order_type === 'pickup' ? ' mkt-delivery-fields--hidden' : '');

			const deliveryLegend = document.createElement('legend');
			deliveryLegend.className = 'mkt-checkout-form__legend';
			deliveryLegend.textContent = 'Delivery Address';
			deliveryFieldset.appendChild(deliveryLegend);

			// Delivery Address (Required for delivery)
			deliveryFieldset.appendChild(
				this.createFormField({
					id: 'mkt-field-delivery-address',
					name: 'delivery_address',
					label: 'Street Address',
					required: this.customerFormState.order_type === 'delivery',
					type: 'text',
					value: this.customerFormState.delivery_address,
					placeholder: 'House, road, flat, or building address',
					maxLength: 500,
					error: this.fieldErrors.delivery_address,
					disabled: this.customerFormState.order_type === 'pickup',
					onInput: (val) => {
						this.customerFormState.delivery_address = val;
						if (this.fieldErrors.delivery_address) {
							delete this.fieldErrors.delivery_address;
							this.clearFieldError('mkt-field-delivery-address');
						}
					},
				})
			);

			// Delivery Area (Optional)
			deliveryFieldset.appendChild(
				this.createFormField({
					id: 'mkt-field-delivery-area',
					name: 'delivery_area',
					label: 'Area / Neighborhood',
					required: false,
					optionalText: '(Optional)',
					type: 'text',
					value: this.customerFormState.delivery_area,
					placeholder: 'e.g. Downtown / Sector 4',
					maxLength: 191,
					disabled: this.customerFormState.order_type === 'pickup',
					onInput: (val) => {
						this.customerFormState.delivery_area = val;
					},
				})
			);

			// Delivery Landmark (Optional)
			deliveryFieldset.appendChild(
				this.createFormField({
					id: 'mkt-field-delivery-landmark',
					name: 'delivery_landmark',
					label: 'Nearby Landmark',
					required: false,
					optionalText: '(Optional)',
					type: 'text',
					value: this.customerFormState.delivery_landmark,
					placeholder: 'e.g. Opposite City Park',
					maxLength: 191,
					disabled: this.customerFormState.order_type === 'pickup',
					onInput: (val) => {
						this.customerFormState.delivery_landmark = val;
					},
				})
			);

			form.appendChild(deliveryFieldset);

			// --- Fieldset: Order Note (Optional, max 1000 chars) ---
			const noteFieldset = document.createElement('fieldset');
			noteFieldset.className = 'mkt-checkout-form__fieldset';

			const noteLegend = document.createElement('legend');
			noteLegend.className = 'mkt-checkout-form__legend';
			noteLegend.textContent = 'Additional Notes';
			noteFieldset.appendChild(noteLegend);

			noteFieldset.appendChild(
				this.createFormField({
					id: 'mkt-field-order-note',
					name: 'order_note',
					label: 'Order Notes / Kitchen Instructions',
					required: false,
					optionalText: '(Optional)',
					type: 'textarea',
					value: this.customerFormState.order_note,
					placeholder: 'Special requests, allergies, or gate code (max 1000 chars)',
					maxLength: 1000,
					onInput: (val) => {
						this.customerFormState.order_note = val;
					},
				})
			);

			form.appendChild(noteFieldset);

			// --- Submit Button & Lock ---
			const submitBtn = document.createElement('button');
			submitBtn.type = 'submit';
			submitBtn.id = 'mkt-checkout-submit-btn';
			submitBtn.className = 'mkt-checkout-submit-btn';
			submitBtn.setAttribute('aria-label', this.isSubmitting ? 'Submitting order...' : 'Place Order');

			if (this.isSubmitting) {
				submitBtn.setAttribute('disabled', 'disabled');
				submitBtn.setAttribute('aria-disabled', 'true');

				const spinner = document.createElement('span');
				spinner.className = 'mkt-spinner';
				spinner.setAttribute('aria-hidden', 'true');
				submitBtn.appendChild(spinner);

				const btnText = document.createElement('span');
				btnText.textContent = 'Placing Order...';
				submitBtn.appendChild(btnText);
			} else {
				const btnText = document.createElement('span');
				btnText.textContent = 'Place Order';
				submitBtn.appendChild(btnText);
			}

			form.addEventListener('submit', (e) => {
				e.preventDefault();
				this.handleFormSubmit();
			});

			form.appendChild(submitBtn);
			container.appendChild(form);

			this.body.appendChild(container);
		}

		/**
		 * Helper to create an accessible form field group with label, input, and error container.
		 *
		 * @param {Object} options
		 * @return {HTMLElement}
		 */
		createFormField(options) {
			const group = document.createElement('div');
			group.className = 'mkt-form-group';
			group.id = `${options.id}-group`;

			// Label
			const label = document.createElement('label');
			label.className = 'mkt-form-label';
			label.htmlFor = options.id;

			const labelTitle = document.createElement('span');
			labelTitle.textContent = options.label;
			label.appendChild(labelTitle);

			if (options.required) {
				const req = document.createElement('span');
				req.className = 'mkt-form-label__required';
				req.setAttribute('aria-hidden', 'true');
				req.textContent = ' *';
				label.appendChild(req);
			} else if (options.optionalText) {
				const opt = document.createElement('span');
				opt.className = 'mkt-form-label__optional';
				opt.textContent = options.optionalText;
				label.appendChild(opt);
			}
			group.appendChild(label);

			// Input or Textarea
			let input;
			if (options.type === 'textarea') {
				input = document.createElement('textarea');
				input.rows = 3;
				input.className = 'mkt-form-textarea';
			} else {
				input = document.createElement('input');
				input.type = options.type || 'text';
				input.className = 'mkt-form-input';
			}

			input.id = options.id;
			input.name = options.name;
			input.value = options.value || '';
			if (options.placeholder) input.placeholder = options.placeholder;
			if (options.maxLength) input.maxLength = options.maxLength;
			if (options.required) input.setAttribute('required', 'required');
			if (options.disabled || this.isSubmitting) input.setAttribute('disabled', 'disabled');

			if (options.error) {
				input.setAttribute('aria-invalid', 'true');
				input.setAttribute('aria-describedby', `${options.id}-error`);
			}

			input.addEventListener('input', (e) => {
				if (typeof options.onInput === 'function') {
					options.onInput(e.target.value);
				}
			});

			group.appendChild(input);

			// Error message container
			const errorSpan = document.createElement('span');
			errorSpan.id = `${options.id}-error`;
			errorSpan.className = 'mkt-form-error';
			errorSpan.setAttribute('role', 'alert');
			if (options.error) {
				errorSpan.textContent = options.error;
			}
			group.appendChild(errorSpan);

			return group;
		}

		/**
		 * Clear an existing field-level error dynamically.
		 *
		 * @param {string} fieldId
		 */
		clearFieldError(fieldId) {
			const input = document.getElementById(fieldId);
			if (input) {
				input.removeAttribute('aria-invalid');
				input.removeAttribute('aria-describedby');
			}
			const errorSpan = document.getElementById(`${fieldId}-error`);
			if (errorSpan) {
				errorSpan.textContent = '';
			}
		}

		/**
		 * Client-side UX validation for customer form before submission.
		 * Server remains the ultimate authoritative validator.
		 *
		 * @return {boolean}
		 */
		validateCustomerForm() {
			this.fieldErrors = {};

			const name = (this.customerFormState.name || '').trim();
			if (!name) {
				this.fieldErrors.name = 'Please enter your full name.';
			} else if (name.length < 2 || name.length > 191) {
				this.fieldErrors.name = 'Name must be between 2 and 191 characters.';
			}

			const phone = (this.customerFormState.phone || '').trim();
			if (!phone) {
				this.fieldErrors.phone = 'Please enter your phone number.';
			} else {
				// Basic client phone format check (digits, optional +, space, dashes, parens, 6-32 chars)
				const phoneRegex = /^[+]?[\d\s\-().]{6,32}$/;
				if (!phoneRegex.test(phone)) {
					this.fieldErrors.phone = 'Please enter a valid phone number (e.g. +1234567890).';
				}
			}

			const whatsapp = (this.customerFormState.whatsapp || '').trim();
			if (whatsapp) {
				const waRegex = /^[+]?[\d\s\-().]{6,32}$/;
				if (!waRegex.test(whatsapp)) {
					this.fieldErrors.whatsapp = 'Please enter a valid WhatsApp number or leave blank.';
				}
			}

			if (this.customerFormState.order_type === 'delivery') {
				const address = (this.customerFormState.delivery_address || '').trim();
				if (!address) {
					this.fieldErrors.delivery_address = 'Please enter your delivery street address.';
				} else if (address.length > 500) {
					this.fieldErrors.delivery_address = 'Address cannot exceed 500 characters.';
				}
			}

			const note = (this.customerFormState.order_note || '').trim();
			if (note && note.length > 1000) {
				this.fieldErrors.order_note = 'Order note cannot exceed 1000 characters.';
			}

			return Object.keys(this.fieldErrors).length === 0;
		}

		/**
		 * Handle customer form submission with single-flight locking and authoritative orderClient dispatch.
		 */
		handleFormSubmit() {
			// 1. Single-flight submission lock check
			if (this.isSubmitting) return;

			const cart = this.getCart();
			if (!cart || cart.isEmpty()) {
				this.submissionError = {
					type: 'error',
					message: 'Your cart is empty. Please add items before placing an order.',
				};
				this.viewMode = 'lines';
				this.render();
				return;
			}

			// 2. Perform client UX validation
			if (!this.validateCustomerForm()) {
				this.submissionError = {
					type: 'error',
					message: 'Please correct the highlighted fields below.',
				};
				this.render();
				return;
			}

			// 3. Resolve or generate active idempotency key for this logical submission.
			// Reuses existing key across retries (network drop, 409 conflict, 500 server error, malformed 201).
			// Generates fresh key only for a new logical submission.
			if (!this.activeIdempotencyKey) {
				const keyGenerator = (window.Maktomine && typeof window.Maktomine.generateIdempotencyKey === 'function')
					? window.Maktomine.generateIdempotencyKey
					: null;

				const key = keyGenerator ? keyGenerator() : null;
				if (!key) {
					this.submissionError = {
						type: 'error',
						message: 'Unable to establish a secure idempotency key. Please ensure your browser supports cryptographic security.',
					};
					this.render();
					return;
				}
				this.activeIdempotencyKey = key;
			}

			// 4. Acquire submission lock
			this.isSubmitting = true;
			this.submissionError = null;
			this.render();

			// 5. Construct payload adhering strictly to frozen contracts
			// BrowserCart lines payload without client prices
			const cartPayload = {
				lines: cart.getLines().map((l) => ({
					line_id: l.line_id,
					food_id: l.food_id,
					selection: l.selection || {},
					addons: l.addons || [],
					quantity: l.quantity,
				})),
			};

			// REST customer payload schema (OrderRestController maps these to Core keys)
			const customerPayload = {
				name: this.customerFormState.name.trim(),
				phone: this.customerFormState.phone.trim(),
				whatsapp: this.customerFormState.whatsapp.trim() || undefined,
				order_type: this.customerFormState.order_type,
				delivery_address: this.customerFormState.order_type === 'delivery'
					? this.customerFormState.delivery_address.trim()
					: undefined,
				delivery_area: this.customerFormState.order_type === 'delivery' && this.customerFormState.delivery_area.trim()
					? this.customerFormState.delivery_area.trim()
					: undefined,
				delivery_landmark: this.customerFormState.order_type === 'delivery' && this.customerFormState.delivery_landmark.trim()
					? this.customerFormState.delivery_landmark.trim()
					: undefined,
				order_note: this.customerFormState.order_note.trim() || undefined,
			};

			// Remove undefined keys to keep payload clean
			Object.keys(customerPayload).forEach((k) => {
				if (customerPayload[k] === undefined) {
					delete customerPayload[k];
				}
			});

			const orderClient = window.Maktomine && window.Maktomine.orderClient;
			if (!orderClient || typeof orderClient.submitOrder !== 'function') {
				this.isSubmitting = false;
				this.submissionError = {
					type: 'error',
					message: 'Order client transport is not available. Please try refreshing the page.',
				};
				this.render();
				return;
			}

			// 6. Dispatch order submission via OrderRestClient with active idempotency key
			orderClient.submitOrder(cartPayload, customerPayload, this.activeIdempotencyKey)
				.then((response) => {
					// 7. Release submission lock
					this.isSubmitting = false;

					// 8. Strict Success Verification Condition (Phase 4P Response Contract):
					// Treated as successfully persisted ONLY when:
					// 1. response.success === true
					// 2. response.status === 201
					// 3. response.order is an object with a non-empty string order_reference
					// 4. response.whatsapp is an object with boolean attempted, boolean dispatched, and non-empty string status
					const isPersisted = Boolean(
						response &&
						response.success === true &&
						response.status === 201 &&
						response.order &&
						typeof response.order === 'object' &&
						typeof response.order.order_reference === 'string' &&
						response.order.order_reference.trim() !== '' &&
						response.whatsapp &&
						typeof response.whatsapp === 'object' &&
						typeof response.whatsapp.attempted === 'boolean' &&
						typeof response.whatsapp.dispatched === 'boolean' &&
						typeof response.whatsapp.status === 'string' &&
						response.whatsapp.status.trim() !== ''
					);

					if (isPersisted) {
						// Logical submission completed successfully.
						// Reset active idempotency key so any subsequent order generates a new key.
						this.activeIdempotencyKey = null;

						// Store submitted order confirmation details for presentation
						this.lastSubmittedOrder = {
							order: response.order,
							whatsapp: response.whatsapp,
						};

						// Clear the browser cart ONLY after confirmed successful order persistence
						cart.clear();

						// Reset form state in memory
						this.customerFormState = {
							name: '',
							phone: '',
							whatsapp: '',
							order_type: 'delivery',
							delivery_address: '',
							delivery_area: '',
							delivery_landmark: '',
							order_note: '',
						};
						this.fieldErrors = {};
						this.submissionError = null;

						// Switch to success view mode
						this.viewMode = 'success';
						this.render();

						// Fire maktomine:order:submitted event
						try {
							window.dispatchEvent(new CustomEvent('maktomine:order:submitted', {
								detail: {
									order: response.order,
									whatsapp: response.whatsapp,
								},
							}));
						} catch (e) {
							// Ignore custom event dispatch errors
						}
					} else {
						// Server error or malformed/incomplete response structure.
						// Do NOT clear cart, do NOT clear activeIdempotencyKey, do NOT emit maktomine:order:submitted.
						this.handleSubmissionError(response || { status: 500, code: 'submission_failed', message: 'Unexpected response from server.' });
					}
				})
				.catch((err) => {
					this.isSubmitting = false;
					this.handleSubmissionError({
						status: 0,
						code: 'network_error',
						message: err && err.message ? err.message : 'A network error occurred while connecting to the server.',
					});
				});
		}

		/**
		 * Handle and map submission errors (HTTP 400, 409, 500, network errors).
		 *
		 * @param {Object} err
		 */
		handleSubmissionError(err) {
			const status = err.status || 0;
			const code = err.code || 'unknown_error';
			const message = err.message || 'An error occurred while submitting your order.';

			// Fire maktomine:order:failed event for genuine order submission failures
			try {
				window.dispatchEvent(new CustomEvent('maktomine:order:failed', {
					detail: {
						code: code,
						message: message,
						status: status,
					},
				}));
			} catch (e) {
				// Ignore custom event dispatch errors
			}

			// Map error presentation based on HTTP status
			if (status === 400) {
				// Input validation error
				this.submissionError = {
					type: 'error',
					message: message || 'Please check your submitted details and try again.',
				};
			} else if (status === 409) {
				// Catalog availability or pricing conflict
				this.submissionError = {
					type: 'warning',
					message: 'One or more items in your cart are no longer available or catalog details have changed. Please return to your cart to review your items.',
				};
				// Request fresh authoritative resolution for cart items
				const cart = this.getCart();
				if (cart) {
					this.resolveLines(cart.getLines());
				}
			} else if (status === 0 || code === 'network_error') {
				// Ambiguous network failure: do not clear cart, do not auto retry
				this.submissionError = {
					type: 'error',
					message: 'Network connection error: We could not confirm if your order reached the restaurant. Please check your internet connection before trying again.',
				};
			} else {
				// HTTP 500 or generic server failure
				this.submissionError = {
					type: 'error',
					message: message || 'An unexpected server error occurred while processing your order. Please try again.',
				};
			}

			this.render();
		}

		/**
		 * Render successful order confirmation screen (Phase 4P).
		 */
		renderSuccessState() {
			const data = this.lastSubmittedOrder;
			if (!data || !data.order) return;

			const order = data.order;
			const whatsapp = data.whatsapp || {};

			const container = document.createElement('div');
			container.className = 'mkt-order-confirmation';
			container.setAttribute('role', 'region');
			container.setAttribute('aria-label', 'Order Confirmation');

			// Success checkmark icon
			const iconWrap = document.createElement('div');
			iconWrap.className = 'mkt-order-confirmation__icon-wrap';
			iconWrap.innerHTML = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"></polyline></svg>';
			container.appendChild(iconWrap);

			// Title
			const title = document.createElement('h3');
			title.className = 'mkt-order-confirmation__title';
			title.textContent = 'Order Placed Successfully!';
			container.appendChild(title);

			// Order reference box
			const refBox = document.createElement('div');
			refBox.className = 'mkt-order-confirmation__ref-box';

			const refLabel = document.createElement('span');
			refLabel.className = 'mkt-order-confirmation__ref-label';
			refLabel.textContent = 'Your Order Reference';
			refBox.appendChild(refLabel);

			const refVal = document.createElement('div');
			refVal.className = 'mkt-order-confirmation__ref-val';
			refVal.textContent = order.order_reference;
			refBox.appendChild(refVal);

			container.appendChild(refBox);

			// Order summary details (strictly server-provided values)
			const details = document.createElement('div');
			details.className = 'mkt-order-confirmation__details';

			const currency = order.currency || '';

			if (order.subtotal !== undefined) {
				const subRow = document.createElement('div');
				subRow.className = 'mkt-order-confirmation__row';
				const subLbl = document.createElement('span');
				subLbl.textContent = 'Subtotal';
				const subVal = document.createElement('span');
				subVal.textContent = `${order.subtotal} ${currency}`.trim();
				subRow.appendChild(subLbl);
				subRow.appendChild(subVal);
				details.appendChild(subRow);
			}

			if (order.delivery_charge !== undefined) {
				const delRow = document.createElement('div');
				delRow.className = 'mkt-order-confirmation__row';
				const delLbl = document.createElement('span');
				delLbl.textContent = 'Delivery Charge';
				const delVal = document.createElement('span');
				delVal.textContent = `${order.delivery_charge} ${currency}`.trim();
				delRow.appendChild(delLbl);
				delRow.appendChild(delVal);
				details.appendChild(delRow);
			}

			if (order.total_amount !== undefined) {
				const totRow = document.createElement('div');
				totRow.className = 'mkt-order-confirmation__row mkt-order-confirmation__row--total';
				const totLbl = document.createElement('span');
				totLbl.textContent = 'Total Amount';
				const totVal = document.createElement('span');
				totVal.textContent = `${order.total_amount} ${currency}`.trim();
				totRow.appendChild(totLbl);
				totRow.appendChild(totVal);
				details.appendChild(totRow);
			}

			container.appendChild(details);

			// WhatsApp Notification Status note
			const waNote = document.createElement('div');
			waNote.className = 'mkt-order-confirmation__whatsapp-note';

			if (whatsapp.dispatched === true || whatsapp.status === 'dispatched') {
				waNote.classList.add('mkt-cart-alert', 'mkt-cart-alert--info');
				waNote.textContent = 'Order details were sent to the restaurant via WhatsApp.';
			} else if (whatsapp.status === 'not_configured') {
				waNote.classList.add('mkt-cart-alert', 'mkt-cart-alert--info');
				waNote.textContent = 'Your order is recorded. WhatsApp notification is currently not configured for this restaurant.';
			} else if (whatsapp.status === 'failed') {
				waNote.classList.add('mkt-cart-alert', 'mkt-cart-alert--warning');
				waNote.textContent = 'Your order has been placed successfully in our system, though the restaurant WhatsApp notification channel could not be completed at this time.';
			} else {
				waNote.classList.add('mkt-cart-alert', 'mkt-cart-alert--info');
				waNote.textContent = 'Your order has been recorded.';
			}
			container.appendChild(waNote);

			// Done button to close drawer and reset view mode
			const doneBtn = document.createElement('button');
			doneBtn.type = 'button';
			doneBtn.className = 'mkt-order-confirmation__done-btn';
			doneBtn.textContent = 'Close';
			doneBtn.addEventListener('click', (e) => {
				e.preventDefault();
				this.viewMode = 'lines';
				this.lastSubmittedOrder = null;
				this.close();
				this.render();
			});
			container.appendChild(doneBtn);

			this.body.appendChild(container);
		}
	}

	// Initialize UI presentation on DOM ready
	function bootstrapCartUI() {
		if (window.Maktomine) {
			window.Maktomine.cartUI = new CartUI();
		} else {
			window.Maktomine = {
				cartUI: new CartUI(),
			};
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', bootstrapCartUI);
	} else {
		bootstrapCartUI();
	}

})(window, document);
