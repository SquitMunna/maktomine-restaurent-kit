/**
 * Maktomine Restaurant Theme — Vanilla JS Runtime.
 *
 * Provides lightweight interactions: accessible mobile drawer,
 * sticky header state, and UI event bus. Zero external libraries.
 *
 * @package Maktomine\RestaurantTheme
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', () => {
		initMobileDrawer();
		initStickyHeader();
		initAccessibleDropdowns();
		initCartLauncherNotice();
	});

	/**
	 * Accessible Mobile Menu Drawer Handler.
	 */
	function initMobileDrawer() {
		const toggleBtn = document.getElementById('mkt-mobile-toggle-btn');
		const closeBtn  = document.getElementById('mkt-mobile-close-btn');
		const backdrop  = document.getElementById('mkt-mobile-drawer-backdrop');
		const drawer    = document.getElementById('mkt-mobile-menu-drawer');

		if (!toggleBtn || !drawer) {
			return;
		}

		function openDrawer() {
			drawer.classList.add('mkt-mobile-drawer--open');
			drawer.setAttribute('aria-hidden', 'false');
			toggleBtn.setAttribute('aria-expanded', 'true');
			document.body.style.overflow = 'hidden';
			if (closeBtn) {
				closeBtn.focus();
			}
		}

		function closeDrawer() {
			drawer.classList.remove('mkt-mobile-drawer--open');
			drawer.setAttribute('aria-hidden', 'true');
			toggleBtn.setAttribute('aria-expanded', 'false');
			document.body.style.overflow = '';
			toggleBtn.focus();
		}

		toggleBtn.addEventListener('click', (e) => {
			e.preventDefault();
			const isOpen = drawer.classList.contains('mkt-mobile-drawer--open');
			if (isOpen) {
				closeDrawer();
			} else {
				openDrawer();
			}
		});

		if (closeBtn) {
			closeBtn.addEventListener('click', (e) => {
				e.preventDefault();
				closeDrawer();
			});
		}

		if (backdrop) {
			backdrop.addEventListener('click', closeDrawer);
		}

		// Close on Escape key press
		document.addEventListener('keydown', (e) => {
			if (e.key === 'Escape' && drawer.classList.contains('mkt-mobile-drawer--open')) {
				closeDrawer();
			}
		});
	}

	/**
	 * Sticky Header Scroll Elevation.
	 */
	function initStickyHeader() {
		const header = document.getElementById('masthead');
		if (!header || !header.classList.contains('mkt-header--sticky')) {
			return;
		}

		let lastKnownScroll = 0;
		let ticking = false;

		window.addEventListener('scroll', () => {
			lastKnownScroll = window.scrollY;
			if (!ticking) {
				window.requestAnimationFrame(() => {
					if (lastKnownScroll > 30) {
						header.classList.add('mkt-header--scrolled');
					} else {
						header.classList.remove('mkt-header--scrolled');
					}
					ticking = false;
				});
				ticking = true;
			}
		}, { passive: true });
	}

	/**
	 * Keyboard Navigation accessibility for desktop sub-menus.
	 */
	function initAccessibleDropdowns() {
		const menuItems = document.querySelectorAll('.mkt-menu li');
		menuItems.forEach((item) => {
			const link = item.querySelector('a');
			if (!link) return;

			link.addEventListener('focus', () => {
				item.classList.add('focus-within');
			});

			link.addEventListener('blur', () => {
				// Defer removal to see if focus moved to a child link
				setTimeout(() => {
					if (!item.contains(document.activeElement)) {
						item.classList.remove('focus-within');
					}
				}, 10);
			});
		});
	}

	/**
	 * Cart Launcher presentation trigger.
	 * Dispatches DOM event 'maktomine/cart/open' for Phase 4 reactive cart.
	 */
	function initCartLauncherNotice() {
		const cartBtn = document.getElementById('mkt-cart-launcher-trigger');
		if (!cartBtn) return;

		cartBtn.addEventListener('click', (e) => {
			e.preventDefault();
			// Dispatch event for Core cart or future Phase 4 drawer
			const event = new CustomEvent('maktomine/cart/toggle', { bubbles: true });
			window.dispatchEvent(event);
		});
	}
})();
