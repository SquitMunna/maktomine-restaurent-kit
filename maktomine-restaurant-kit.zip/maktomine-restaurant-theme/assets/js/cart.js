/**
 * Maktomine Restaurant Theme — Browser Cart & REST Client Module.
 *
 * Provides client-side cart state management, defensive local persistence,
 * deterministic line identity matching Core Cart domain, and thin REST transport
 * to POST /maktomine/v1/orders.
 *
 * Responsibility Boundary:
 * - Owns: In-memory selection state, line identity generation, line quantity adjustment,
 *   untrusted localStorage caching, cart count calculation, REST submission transport.
 * - Excludes: Authoritative pricing, authoritative availability, catalog validation,
 *   direct WhatsApp provider calls, order status mutations, database queries, PII persistence.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

(function (window, document) {
	'use strict';

	// Boundaries matching Core Cart domain rules.
	const CART_VERSION = 1;
	const MAX_CART_LINES = 25;
	const MIN_LINE_QUANTITY = 1;
	const MAX_LINE_QUANTITY = 50;
	const DEFAULT_STORAGE_KEY = 'maktomine_cart_v1';

	/**
	 * SHA-256 deterministic digest (FIPS 180-4 compliant).
	 * Synchronous, zero-dependency implementation producing a 64-character lowercase hex string.
	 * Identical output to PHP hash('sha256', string).
	 *
	 * @param {string} str Input string.
	 * @return {string} 64-character lowercase hexadecimal hash.
	 */
	function sha256(str) {
		function rightRotate(v, n) {
			return (v >>> n) | (v << (32 - n));
		}

		const K = [
			0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
			0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
			0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
			0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
			0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
			0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
			0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
			0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
		];

		const H = [
			0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
			0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
		];

		const bytes = new TextEncoder().encode(str);
		const bitLen = bytes.length * 8;
		const newLen = (((bytes.length + 8) >> 6) + 1) << 6;
		const padded = new Uint8Array(newLen);
		padded.set(bytes);
		padded[bytes.length] = 0x80;

		const view = new DataView(padded.buffer);
		view.setUint32(newLen - 4, bitLen, false);

		const W = new Uint32Array(64);
		for (let i = 0; i < newLen; i += 64) {
			for (let t = 0; t < 16; t++) {
				W[t] = view.getUint32(i + (t * 4), false);
			}
			for (let t = 16; t < 64; t++) {
				const s0 = rightRotate(W[t - 15], 7) ^ rightRotate(W[t - 15], 18) ^ (W[t - 15] >>> 3);
				const s1 = rightRotate(W[t - 2], 17) ^ rightRotate(W[t - 2], 19) ^ (W[t - 2] >>> 10);
				W[t] = (W[t - 16] + s0 + W[t - 7] + s1) >>> 0;
			}
			let [a, b, c, d, e, f, g, h] = H;
			for (let t = 0; t < 64; t++) {
				const S1 = rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25);
				const ch = (e & f) ^ ((~e) & g);
				const temp1 = (h + S1 + ch + K[t] + W[t]) >>> 0;
				const S0 = rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22);
				const maj = (a & b) ^ (a & c) ^ (b & c);
				const temp2 = (S0 + maj) >>> 0;
				h = g;
				g = f;
				f = e;
				e = (d + temp1) >>> 0;
				d = c;
				c = b;
				b = a;
				a = (temp1 + temp2) >>> 0;
			}
			H[0] = (H[0] + a) >>> 0;
			H[1] = (H[1] + b) >>> 0;
			H[2] = (H[2] + c) >>> 0;
			H[3] = (H[3] + d) >>> 0;
			H[4] = (H[4] + e) >>> 0;
			H[5] = (H[5] + f) >>> 0;
			H[6] = (H[6] + g) >>> 0;
			H[7] = (H[7] + h) >>> 0;
		}

		return H.map((x) => x.toString(16).padStart(8, '0')).join('');
	}

	/**
	 * Canonical Line Identity Generator.
	 * Exactly reproduces PHP CartLine::generate_line_id():
	 * - food_id: integer
	 * - selection: keys sorted alphabetically; encoded as [] if empty, {"attr":"opt"} if non-empty
	 * - addons: array of {id, quantity} sorted by id ascending; encoded as [] if empty
	 * - quantity: strictly excluded from identity
	 *
	 * @param {number} foodId Food item ID.
	 * @param {Object} selection Variation selection map { attr: opt }.
	 * @param {Array}  addons Add-on selections [{ id: string, quantity: number }].
	 * @return {string} SHA-256 canonical configuration hash.
	 */
	function generateLineId(foodId, selection, addons) {
		const normFoodId = parseInt(foodId, 10);

		// Normalize and sort variation selection map (matching PHP validate_selection: non-empty string, no mutative trimming).
		const normSelection = {};
		const selKeys = Object.keys(selection || {}).sort((a, b) => (a < b ? -1 : (a > b ? 1 : 0)));
		for (const k of selKeys) {
			const val = selection[k];
			if (typeof val === 'string' && val !== '') {
				normSelection[k] = val;
			}
		}
		const isSelEmpty = Object.keys(normSelection).length === 0;

		// Normalize and sort add-on selections by id (matching PHP validate_addons: non-empty string, unique, binary sort).
		const seenAddonIds = new Set();
		const normAddons = [];
		for (const a of (addons || [])) {
			if (a && typeof a.id === 'string' && a.id !== '') {
				const aid = a.id;
				if (!seenAddonIds.has(aid)) {
					seenAddonIds.add(aid);
					normAddons.push({
						id: aid,
						quantity: Math.max(1, parseInt(a.quantity, 10) || 1),
					});
				}
			}
		}
		normAddons.sort((a, b) => (a.id < b.id ? -1 : (a.id > b.id ? 1 : 0)));

		// In PHP, when $selection is an empty array [], json_encode encodes it as [].
		// When non-empty associative array, it encodes as {"key":"val"}.
		const payload = {
			food_id: normFoodId,
			selection: isSelEmpty ? [] : normSelection,
			addons: normAddons,
		};

		const canonicalJson = JSON.stringify(payload);
		return sha256(canonicalJson);
	}

	/**
	 * Server-compatible idempotency key grammar regex.
	 * Matches ^[A-Za-z0-9_-]{16,64}$
	 */
	const IDEMPOTENCY_KEY_REGEX = /^[A-Za-z0-9_-]{16,64}$/;

	/**
	 * Check whether a candidate string is a valid idempotency key conforming to server grammar.
	 *
	 * @param {*} key Candidate key.
	 * @return {boolean}
	 */
	function isValidIdempotencyKey(key) {
		return typeof key === 'string' && IDEMPOTENCY_KEY_REGEX.test(key.trim());
	}

	/**
	 * Cryptographically Secure Client Idempotency Key Generator.
	 *
	 * Adheres strictly to Phase 4Q idempotency constraints:
	 * - Uses Web Crypto API (crypto.randomUUID or crypto.getRandomValues).
	 * - Alphabet: [A-Za-z0-9_-].
	 * - Length: 16–64 characters (36 chars for UUID, 48 chars for 24-byte hex).
	 * - Zero Math.random().
	 * - Zero customer PII or cart-derived seeds.
	 * - Returns null if Web Crypto is unavailable (allowing safe failure).
	 *
	 * @return {string|null} Valid idempotency key string or null if crypto unavailable.
	 */
	function generateIdempotencyKey() {
		if (typeof window !== 'undefined' && window.crypto) {
			// Modern standard: crypto.randomUUID() produces 36-char lowercase UUIDv4
			if (typeof window.crypto.randomUUID === 'function') {
				try {
					const uuid = window.crypto.randomUUID();
					if (isValidIdempotencyKey(uuid)) {
						return uuid;
					}
				} catch (e) {
					// Fall through to getRandomValues
				}
			}

			// Web Crypto fallback: 24 cryptographically random bytes = 48 hex characters
			if (typeof window.crypto.getRandomValues === 'function') {
				try {
					const bytes = new Uint8Array(24);
					window.crypto.getRandomValues(bytes);
					let hex = '';
					for (let i = 0; i < bytes.length; i++) {
						hex += bytes[i].toString(16).padStart(2, '0');
					}
					if (isValidIdempotencyKey(hex)) {
						return hex;
					}
				} catch (e) {
					// Return null on crypto failure
				}
			}
		}

		// Never silently fall back to Math.random() or predictable seeds
		return null;
	}

	/**
	 * Safe Browser Storage Wrapper.
	 * Operates defensively: handles storage quota exceptions, privacy blocks,
	 * corrupted schemas, and treats all retrieved contents as untrusted.
	 */
	class BrowserCartStorage {
		constructor(storageKey) {
			this.storageKey = storageKey || DEFAULT_STORAGE_KEY;
		}

		/**
		 * Retrieve and validate serialized cart from localStorage.
		 *
		 * @return {Array|null} Array of raw line objects or null if unavailable/invalid.
		 */
		load() {
			try {
				if (!window.localStorage) {
					return null;
				}
				const raw = window.localStorage.getItem(this.storageKey);
				if (!raw) {
					return null;
				}

				const parsed = JSON.parse(raw);
				if (!parsed || typeof parsed !== 'object') {
					this.clear();
					return null;
				}

				// Enforce strict schema versioning.
				if (parsed.version !== CART_VERSION || !Array.isArray(parsed.lines)) {
					this.clear();
					return null;
				}

				// Enforce line count ceiling.
				if (parsed.lines.length > MAX_CART_LINES) {
					this.clear();
					return null;
				}

				return parsed.lines;
			} catch (e) {
				// Local storage disabled, corrupted JSON, or security block.
				return null;
			}
		}

		/**
		 * Save valid cart lines to localStorage.
		 * Never persists prices, totals, customer PII, or verification hashes.
		 *
		 * @param {Array} lines Sanitized cart line objects.
		 * @return {boolean} True if successfully stored, false on failure.
		 */
		save(lines) {
			try {
				if (!window.localStorage) {
					return false;
				}
				const envelope = {
					version: CART_VERSION,
					lines: lines,
				};
				window.localStorage.setItem(this.storageKey, JSON.stringify(envelope));
				return true;
			} catch (e) {
				// Storage full, quota exceeded, or private browsing block.
				return false;
			}
		}

		/**
		 * Clear persisted cart from localStorage.
		 *
		 * @return {boolean}
		 */
		clear() {
			try {
				if (window.localStorage) {
					window.localStorage.removeItem(this.storageKey);
					return true;
				}
			} catch (e) {
				// Storage unavailable.
			}
			return false;
		}
	}

	/**
	 * Reactive Browser Cart Coordinator.
	 * Encapsulates in-memory cart state, boundary checks, and DOM update dispatching.
	 */
	class BrowserCart {
		constructor(storage) {
			this.storage = storage || new BrowserCartStorage();
			this.lines = []; // Array of CartLine plain objects.
			this.init();
		}

		/**
		 * Initialize and hydrate cart from storage.
		 */
		init() {
			const savedLines = this.storage.load();
			if (Array.isArray(savedLines)) {
				this.hydrateLines(savedLines);
			}
			this.notify();
		}

		/**
		 * Defensive hydration of untrusted line arrays.
		 * Re-verifies food_id, selection, addons, quantities, and recomputes canonical line_id.
		 *
		 * @param {Array} rawLines Untrusted line objects.
		 */
		hydrateLines(rawLines) {
			this.lines = [];
			const seenLineIds = new Set();

			for (const raw of rawLines) {
				if (this.lines.length >= MAX_CART_LINES) {
					break;
				}
				if (!raw || typeof raw !== 'object') {
					continue;
				}

				const foodId = parseInt(raw.food_id, 10);
				if (!foodId || foodId <= 0) {
					continue;
				}

				// Normalize selection map.
				const selection = {};
				if (raw.selection && typeof raw.selection === 'object' && !Array.isArray(raw.selection)) {
					for (const [k, v] of Object.entries(raw.selection)) {
						if (typeof k === 'string' && typeof v === 'string' && k !== '' && v !== '') {
							selection[k] = v;
						}
					}
				}

				// Normalize addons array (strictly rejecting lines with duplicate add-on IDs).
				const addons = [];
				const seenAddonIds = new Set();
				let hasDuplicateAddon = false;
				if (Array.isArray(raw.addons)) {
					for (const a of raw.addons) {
						if (a && typeof a.id === 'string' && a.id !== '') {
							const aid = a.id;
							if (seenAddonIds.has(aid)) {
								hasDuplicateAddon = true;
								break;
							}
							seenAddonIds.add(aid);
							const qty = parseInt(a.quantity, 10);
							if (qty >= 1) {
								addons.push({ id: aid, quantity: qty });
							}
						}
					}
				}
				if (hasDuplicateAddon) {
					continue;
				}

				// Validate quantity bounds.
				let quantity = parseInt(raw.quantity, 10);
				if (isNaN(quantity) || quantity < MIN_LINE_QUANTITY) {
					quantity = MIN_LINE_QUANTITY;
				} else if (quantity > MAX_LINE_QUANTITY) {
					quantity = MAX_LINE_QUANTITY;
				}

				// Authoritatively derive line_id.
				const lineId = generateLineId(foodId, selection, addons);

				// Prevent duplicate line configurations.
				if (seenLineIds.has(lineId)) {
					continue;
				}
				seenLineIds.add(lineId);

				this.lines.push({
					line_id: lineId,
					food_id: foodId,
					selection: selection,
					addons: addons,
					quantity: quantity,
				});
			}

			// Synchronize validated lines back to storage.
			this.storage.save(this.lines);
		}

		/**
		 * Add an item to the cart or increment quantity if already present.
		 *
		 * @param {number} foodId Food item ID.
		 * @param {Object} selection Variation attribute selection { size: 'large' }.
		 * @param {Array}  addons Add-on selections [{ id: 'extra-cheese', quantity: 1 }].
		 * @param {number} quantity Integer quantity (1-50).
		 * @return {Object} Result { success: boolean, lineId?: string, error?: string }.
		 */
		addLine(foodId, selection = {}, addons = [], quantity = 1) {
			const validFoodId = parseInt(foodId, 10);
			if (!validFoodId || validFoodId <= 0) {
				return { success: false, error: 'invalid_food_id' };
			}

			// Validate duplicate add-on IDs (strictly matching PHP CartLine::validate_addons policy).
			const seenAddonIds = new Set();
			for (const a of (addons || [])) {
				if (a && typeof a.id === 'string' && a.id !== '') {
					const aid = a.id;
					if (seenAddonIds.has(aid)) {
						return { success: false, error: 'duplicate_addon_id' };
					}
					seenAddonIds.add(aid);
				}
			}

			const lineId = generateLineId(validFoodId, selection, addons);
			const existingIndex = this.lines.findIndex((l) => l.line_id === lineId);

			const addQty = Math.max(MIN_LINE_QUANTITY, parseInt(quantity, 10) || 1);

			if (existingIndex > -1) {
				// Update existing line quantity (clamped to max).
				const newQty = Math.min(MAX_LINE_QUANTITY, this.lines[existingIndex].quantity + addQty);
				this.lines[existingIndex].quantity = newQty;
			} else {
				// Enforce line capacity.
				if (this.lines.length >= MAX_CART_LINES) {
					return { success: false, error: 'cart_line_limit_exceeded' };
				}

				// Clean selection and addons.
				const cleanSelection = {};
				for (const [k, v] of Object.entries(selection || {})) {
					if (typeof k === 'string' && typeof v === 'string' && k !== '' && v !== '') {
						cleanSelection[k] = v;
					}
				}

				const cleanAddons = (addons || [])
					.filter((a) => a && typeof a.id === 'string' && a.id !== '')
					.map((a) => ({ id: a.id, quantity: Math.max(1, parseInt(a.quantity, 10) || 1) }));

				this.lines.push({
					line_id: lineId,
					food_id: validFoodId,
					selection: cleanSelection,
					addons: cleanAddons,
					quantity: Math.min(MAX_LINE_QUANTITY, addQty),
				});
			}

			this.storage.save(this.lines);
			this.notify();
			return { success: true, lineId: lineId };
		}

		/**
		 * Update quantity of an existing line.
		 *
		 * @param {string} lineId Deterministic line ID.
		 * @param {number} newQuantity New integer quantity (0 removes line).
		 * @return {boolean}
		 */
		updateQuantity(lineId, newQuantity) {
			const index = this.lines.findIndex((l) => l.line_id === lineId);
			if (index === -1) {
				return false;
			}

			const qty = parseInt(newQuantity, 10);
			if (isNaN(qty) || qty < MIN_LINE_QUANTITY) {
				return this.removeLine(lineId);
			}

			this.lines[index].quantity = Math.min(MAX_LINE_QUANTITY, qty);
			this.storage.save(this.lines);
			this.notify();
			return true;
		}

		/**
		 * Remove a line from the cart.
		 *
		 * @param {string} lineId Deterministic line ID.
		 * @return {boolean}
		 */
		removeLine(lineId) {
			const initialLength = this.lines.length;
			this.lines = this.lines.filter((l) => l.line_id !== lineId);
			if (this.lines.length !== initialLength) {
				this.storage.save(this.lines);
				this.notify();
				return true;
			}
			return false;
		}

		/**
		 * Empty the cart.
		 */
		clear() {
			this.lines = [];
			this.storage.clear();
			this.notify();
		}

		/**
		 * Get deep copy of cart lines.
		 *
		 * @return {Array}
		 */
		getLines() {
			return JSON.parse(JSON.stringify(this.lines));
		}

		/**
		 * Calculate total individual food item unit count across all lines.
		 *
		 * @return {number}
		 */
		getItemCount() {
			return this.lines.reduce((acc, line) => acc + (line.quantity || 0), 0);
		}

		/**
		 * Get distinct configuration line count.
		 *
		 * @return {number}
		 */
		getLineCount() {
			return this.lines.length;
		}

		/**
		 * Check if cart is empty.
		 *
		 * @return {boolean}
		 */
		isEmpty() {
			return this.lines.length === 0;
		}

		/**
		 * Generate clean, canonical submission payload conforming to Phase 4I/4K REST contract.
		 * Strictly excludes prices, subtotals, totals, currency, order status, or verification hashes.
		 *
		 * @return {Object} Serialized cart structure matching Cart::to_array().
		 */
		toPayload() {
			return {
				version: CART_VERSION,
				lines: this.getLines(),
			};
		}

		/**
		 * Dispatch DOM notification and synchronize badge.
		 */
		notify() {
			const count = this.getItemCount();
			const event = new CustomEvent('maktomine:cart:updated', {
				bubbles: true,
				detail: {
					itemCount: count,
					lineCount: this.getLineCount(),
					isEmpty: this.isEmpty(),
				},
			});
			window.dispatchEvent(event);

			// Synchronize header cart launcher badge if present in DOM.
			const badge = document.getElementById('mkt-cart-launcher-count');
			if (badge) {
				badge.textContent = String(count);
				badge.setAttribute('data-count', String(count));
			}
		}
	}

	/**
	 * Thin Browser REST Client.
	 * Dispatches POST /maktomine/v1/orders with JSON payload.
	 *
	 * Adheres strictly to transport boundaries:
	 * - Zero price calculation
	 * - Zero catalog validation duplication
	 * - Zero direct WhatsApp calling
	 * - Zero DB access
	 */
	class OrderRestClient {
		constructor(config) {
			this.restUrl = (config && typeof config.restUrl === 'string' && config.restUrl.trim() !== '')
				? config.restUrl.trim()
				: '';
			this.nonce = (config && typeof config.nonce === 'string')
				? config.nonce.trim()
				: '';
		}

		/**
		 * Submit an order to the Phase 4K REST endpoint with Phase 4Q Idempotency-Key header.
		 *
		 * @param {Object} cartPayload Canonical serialized cart from BrowserCart::toPayload().
		 * @param {Object} customerData Customer fulfillment details.
		 * @param {string|null} [idempotencyKey=null] Optional client idempotency key for deduplication.
		 * @return {Promise<Object>} Safe standardized result envelope.
		 */
		async submitOrder(cartPayload, customerData, idempotencyKey = null) {
			// Fail safely if WordPress localized REST URL is missing rather than guessing site paths.
			if (!this.restUrl) {
				return {
					success: false,
					status: 500,
					code: 'missing_rest_url',
					message: 'WordPress REST API endpoint URL configuration is missing.',
				};
			}
			// Validate payload shapes defensively.
			if (!cartPayload || typeof cartPayload !== 'object' || !Array.isArray(cartPayload.lines)) {
				return {
					success: false,
					status: 400,
					code: 'invalid_cart_payload',
					message: 'Client cart payload is malformed.',
				};
			}

			if (!customerData || typeof customerData !== 'object') {
				return {
					success: false,
					status: 400,
					code: 'invalid_customer_payload',
					message: 'Customer information is missing or malformed.',
				};
			}

			// Resolve and validate idempotency key.
			// If provided by caller (e.g. from CartUI managing logical submission lifecycle), validate it.
			// If omitted, generate a fresh cryptographically secure key.
			let key = (typeof idempotencyKey === 'string' && idempotencyKey.trim() !== '')
				? idempotencyKey.trim()
				: null;

			if (!key) {
				key = generateIdempotencyKey();
			}

			// If no cryptographically secure key could be provided or generated, fail safely without submitting.
			if (!key || !isValidIdempotencyKey(key)) {
				return {
					success: false,
					status: 0,
					code: 'crypto_unavailable',
					message: 'A cryptographically secure idempotency key could not be established. Please ensure your browser supports cryptographic security.',
				};
			}

			// Construct canonical request body conforming to Phase 4I/4K.
			const body = {
				cart: {
					version: parseInt(cartPayload.version, 10) || CART_VERSION,
					lines: cartPayload.lines.map((l) => ({
						line_id: l.line_id,
						food_id: parseInt(l.food_id, 10),
						selection: l.selection || {},
						addons: Array.isArray(l.addons) ? l.addons : [],
						quantity: parseInt(l.quantity, 10) || 1,
					})),
				},
				customer: {
					name: String(customerData.name || '').trim(),
					phone: String(customerData.phone || '').trim(),
					whatsapp: String(customerData.whatsapp || '').trim(),
					order_type: String(customerData.order_type || 'delivery').trim(),
					delivery_address: String(customerData.delivery_address || '').trim(),
					delivery_area: String(customerData.delivery_area || '').trim(),
					delivery_landmark: String(customerData.delivery_landmark || '').trim(),
					order_note: String(customerData.order_note || '').trim(),
				},
			};

			const headers = {
				'Content-Type': 'application/json',
				'Accept': 'application/json',
				'Idempotency-Key': key,
			};

			// Nonce is optional for the public customer endpoint, but included if configured.
			if (this.nonce) {
				headers['X-WP-Nonce'] = this.nonce;
			}

			try {
				const response = await fetch(this.restUrl, {
					method: 'POST',
					headers: headers,
					body: JSON.stringify(body),
				});

				let json = null;
				try {
					json = await response.json();
				} catch (err) {
					// Non-JSON response from server (e.g., 502/504 gateway error or fatal).
					return {
						success: false,
						status: response.status,
						code: 'invalid_server_response',
						message: 'Server returned a non-JSON response.',
					};
				}

				// HTTP 201 Created: Successful order creation and submission.
				if (response.status === 201) {
					const data = (json && typeof json === 'object' && json.data && typeof json.data === 'object')
						? json.data
						: null;

					const rawOrder = (data && typeof data.order === 'object' && data.order !== null)
						? data.order
						: null;

					const rawWhatsapp = (data && typeof data.whatsapp === 'object' && data.whatsapp !== null)
						? data.whatsapp
						: null;

					// Enforce Phase 4P contract:
					// order.order_reference must be a non-empty string.
					// whatsapp must be an object with boolean attempted, boolean dispatched, and non-empty string status.
					const hasValidOrder = Boolean(
						rawOrder &&
						typeof rawOrder.order_reference === 'string' &&
						rawOrder.order_reference.trim() !== ''
					);

					const hasValidWhatsapp = Boolean(
						rawWhatsapp &&
						typeof rawWhatsapp.attempted === 'boolean' &&
						typeof rawWhatsapp.dispatched === 'boolean' &&
						typeof rawWhatsapp.status === 'string' &&
						rawWhatsapp.status.trim() !== ''
					);

					if (hasValidOrder && hasValidWhatsapp) {
						// Preserve any additional fields (e.g. error_code) while ensuring contract compliance
						const whatsappPayload = Object.assign({}, rawWhatsapp, {
							attempted: rawWhatsapp.attempted,
							dispatched: rawWhatsapp.dispatched,
							status: rawWhatsapp.status.trim(),
						});

						return {
							success: true,
							status: 201,
							message: json.message || 'Order submitted successfully.',
							order: rawOrder,
							whatsapp: whatsappPayload,
						};
					}

					// Malformed 201 response (missing or invalid order / whatsapp fields)
					return {
						success: false,
						status: 201,
						code: 'malformed_201_response',
						message: 'Order was acknowledged by the server but the response structure was incomplete.',
						data: json.data || null,
					};
				}

				// HTTP 400 (Validation), 409 (Availability conflict), 500 (Persistence failure).
				return {
					success: false,
					status: response.status,
					code: json.code || 'order_submission_error',
					message: json.message || 'Order submission failed.',
					errors: json.data || null,
				};
			} catch (networkError) {
				// Network drop, CORS failure, or browser offline.
				return {
					success: false,
					status: 0,
					code: 'network_error',
					message: networkError.message || 'Network request failed. Please check your connection.',
				};
			}
		}
	}

	// Read localized WordPress configuration if present.
	const config = window.maktomineCartConfig || {};
	const storageAdapter = new BrowserCartStorage(config.storageKey || DEFAULT_STORAGE_KEY);
	const cartInstance = new BrowserCart(storageAdapter);
	const restClientInstance = new OrderRestClient(config);

	// Expose clean public API under Maktomine namespace.
	window.Maktomine = window.Maktomine || {};
	window.Maktomine.cart = cartInstance;
	window.Maktomine.orderClient = restClientInstance;
	window.Maktomine.generateLineId = generateLineId;
	window.Maktomine.generateIdempotencyKey = generateIdempotencyKey;
	window.Maktomine.isValidIdempotencyKey = isValidIdempotencyKey;

	// Initial DOMContentLoaded synchronization.
	document.addEventListener('DOMContentLoaded', () => {
		cartInstance.notify();
	});

})(window, document);
