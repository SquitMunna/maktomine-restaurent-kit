<?php
/**
 * The template for displaying a single Food Item.
 *
 * Pure layout template coordinating with CatalogRenderer.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="mkt-container">
	<main id="primary" class="site-main site-main--food-single">
		<?php
		if ( have_posts() ) :
			while ( have_posts() ) :
				the_post();
				\Maktomine\RestaurantTheme\Catalog\CatalogRenderer::render_single( (int) get_the_ID() );
			endwhile;
		else :
			get_template_part( 'template-parts/catalog/food-empty' );
		endif;
		?>
	</main>
</div>

<?php
get_footer();
