<?php
/**
 * The template for displaying archive pages.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();

$has_sidebar = is_active_sidebar( 'sidebar-main' );
?>

<div class="mkt-container">
	<div class="mkt-main-layout <?php echo $has_sidebar ? 'mkt-main-layout--has-sidebar' : ''; ?>">
		<main id="primary" class="site-main site-main--archive">

		<?php if ( have_posts() ) : ?>

			<header class="mkt-page-header">
				<?php
				the_archive_title( '<h1 class="mkt-page-title">', '</h1>' );
				the_archive_description( '<div class="mkt-page-description">', '</div>' );
				?>
			</header>

			<div class="mkt-posts-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'mkt-post-card' ); ?>>
						<?php if ( has_post_thumbnail() ) : ?>
							<a href="<?php the_permalink(); ?>" class="mkt-post-thumbnail" tabindex="-1" aria-hidden="true">
								<?php the_post_thumbnail( 'medium_large' ); ?>
							</a>
						<?php endif; ?>

						<div class="mkt-post-card__body">
							<div class="mkt-post-card__meta">
								<span class="mkt-post-card__date"><?php echo esc_html( get_the_date() ); ?></span>
							</div>

							<h2 class="mkt-post-card__title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>

							<div class="mkt-post-card__excerpt">
								<?php the_excerpt(); ?>
							</div>

							<a href="<?php the_permalink(); ?>" class="mkt-post-card__read-more">
								<?php esc_html_e( 'Read More', 'maktomine-restaurant-theme' ); ?> &rarr;
							</a>
						</div>
					</article>
					<?php
				endwhile;
				?>
			</div>

			<div class="mkt-pagination">
				<?php
				the_posts_pagination(
					[
						'prev_text' => '&larr; ' . esc_html__( 'Previous', 'maktomine-restaurant-theme' ),
						'next_text' => esc_html__( 'Next', 'maktomine-restaurant-theme' ) . ' &rarr;',
					]
				);
				?>
			</div>

		<?php else : ?>

			<section class="mkt-no-results">
				<header class="mkt-page-header">
					<h1 class="mkt-page-title"><?php esc_html_e( 'No Posts Found', 'maktomine-restaurant-theme' ); ?></h1>
				</header>
				<div class="mkt-entry-content">
					<p><?php esc_html_e( 'No posts were found in this archive.', 'maktomine-restaurant-theme' ); ?></p>
				</div>
			</section>

		<?php endif; ?>

		</main><!-- #primary -->

		<?php
		if ( $has_sidebar ) {
			get_sidebar();
		}
		?>
	</div><!-- .mkt-main-layout -->
</div><!-- .mkt-container -->

<?php
get_footer();
