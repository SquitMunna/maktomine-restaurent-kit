<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="mkt-container">
	<main id="primary" class="site-main site-main--404">
		<section class="mkt-error-404">
			<div class="mkt-error-404__code"><?php esc_html_e( '404', 'maktomine-restaurant-theme' ); ?></div>
			<h1 class="mkt-error-404__title"><?php esc_html_e( 'Page Not Found', 'maktomine-restaurant-theme' ); ?></h1>
			<p class="mkt-error-404__desc">
				<?php esc_html_e( 'The page or menu item you are looking for may have been moved or is no longer available.', 'maktomine-restaurant-theme' ); ?>
			</p>

			<div class="mkt-error-404__search">
				<?php get_search_form(); ?>
			</div>

			<div class="mkt-error-404__action" style="margin-top: 24px;">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="mkt-btn mkt-btn--primary">
					<?php esc_html_e( 'Return to Homepage', 'maktomine-restaurant-theme' ); ?>
				</a>
			</div>
		</section>
	</main><!-- #primary -->
</div><!-- .mkt-container -->

<?php
get_footer();
