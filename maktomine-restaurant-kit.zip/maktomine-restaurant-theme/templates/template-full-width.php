<?php
/**
 * Template Name: Full Width (No Sidebar)
 * Template Post Type: page, post
 *
 * A full-width layout template designed for custom landing pages,
 * full-bleed menus, and Elementor visual designs.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="primary" class="site-main site-main--full-width">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'mkt-full-width-entry' ); ?>>
			<div class="mkt-entry-content">
				<?php
				the_content();

				wp_link_pages(
					[
						'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'maktomine-restaurant-theme' ),
						'after'  => '</div>',
					]
				);
				?>
			</div>

			<?php
			if ( comments_open() || get_comments_number() ) :
				?>
				<div class="mkt-container">
					<?php comments_template(); ?>
				</div>
				<?php
			endif;
			?>
		</article>
		<?php
	endwhile;
	?>
</main><!-- #primary -->

<?php
get_footer();
