<?php
/**
 * The template for displaying the header.
 *
 * Displays all of the <head> section and everything up till <div id="content">.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="mkt-skip-link screen-reader-text" href="#primary">
	<?php esc_html_e( 'Skip to content', 'maktomine-restaurant-theme' ); ?>
</a>

<div id="page" class="site">
	<?php
	/**
	 * Renders theme header (or yields to Elementor Pro if configured).
	 */
	maktomine_theme_header();
	?>

	<div id="content" class="site-content">
