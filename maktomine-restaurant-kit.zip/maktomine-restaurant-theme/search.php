<?php
/**
 * The template for displaying search results pages.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();

$has_sidebar = is_active_sidebar( 'sidebar-main' );
?>

<div class="mkt-container">
	<div class="mkt-main-layout <?php echo $has_sidebar ? 'mkt-main-layout--has-sidebar' : ''; ?>">
		<main id="primary" class="site-main site-main--search">

		<?php if ( have_posts() ) : ?>

			<header class="mkt-page-header">
				<h1 class="mkt-page-title">
					<?php
					printf(
						/* translators: %s: Search query term */
						esc_html__( 'Search Results for: %s', 'maktomine-restaurant-theme' ),
						'<span>' . esc_html( get_search_query() ) . '</span>'
					);
					?>
				</h1>
			</header>

			<div class="mkt-posts-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'mkt-post-card' ); ?>>
						<div class="mkt-post-card__body">
							<div class="mkt-post-card__meta">
								<span class="mkt-post-card__type"><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ?? '' ); ?></span>
							</div>

							<h2 class="mkt-post-card__title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>

							<div class="mkt-post-card__excerpt">
								<?php the_excerpt(); ?>
							</div>

							<a href="<?php the_permalink(); ?>" class="mkt-post-card__read-more">
								<?php esc_html_e( 'View Details', 'maktomine-restaurant-theme' ); ?> &rarr;
							</a>
						</div>
					</article>
					<?php
				endwhile;
				?>
			</div>

			<div class="mkt-pagination">
				<?php
				the_posts_pagination(
					[
						'prev_text' => '&larr; ' . esc_html__( 'Previous', 'maktomine-restaurant-theme' ),
						'next_text' => esc_html__( 'Next', 'maktomine-restaurant-theme' ) . ' &rarr;',
					]
				);
				?>
			</div>

		<?php else : ?>

			<section class="mkt-no-results">
				<header class="mkt-page-header">
					<h1 class="mkt-page-title"><?php esc_html_e( 'No Matches Found', 'maktomine-restaurant-theme' ); ?></h1>
				</header>
				<div class="mkt-entry-content">
					<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'maktomine-restaurant-theme' ); ?></p>
					<?php get_search_form(); ?>
				</div>
			</section>

		<?php endif; ?>

		</main><!-- #primary -->

		<?php
		if ( $has_sidebar ) {
			get_sidebar();
		}
		?>
	</div><!-- .mkt-main-layout -->
</div><!-- .mkt-container -->

<?php
get_footer();
