<?php
/**
 * The template for displaying the Food Item catalog archive.
 *
 * Pure layout template coordinating with CatalogRenderer.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();

$paged = max( 1, (int) get_query_var( 'paged', 1 ) );
?>

<div class="mkt-container">
	<main id="primary" class="site-main site-main--food-archive">
		<header class="mkt-page-header">
			<h1 class="mkt-page-title"><?php esc_html_e( 'Our Menu', 'maktomine-restaurant-theme' ); ?></h1>
			<div class="mkt-page-description">
				<p><?php esc_html_e( 'Explore our curated menu of chef-crafted dishes and seasonal specials.', 'maktomine-restaurant-theme' ); ?></p>
			</div>
		</header>

		<?php
		\Maktomine\RestaurantTheme\Catalog\CatalogRenderer::render_collection(
			[
				'page'     => $paged,
				'per_page' => 12,
			],
			[
				'show_image'      => true,
				'show_badges'     => true,
				'show_metrics'    => true,
				'show_categories' => true,
				'show_price'      => true,
				'columns'         => 3,
				'layout_style'    => 'grid',
			]
		);
		?>
	</main>
</div>

<?php
get_footer();
