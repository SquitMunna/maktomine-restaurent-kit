<?php
/**
 * The template for displaying all pages.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="mkt-container">
	<main id="primary" class="site-main site-main--page">

		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'mkt-page-entry' ); ?>>
				<header class="mkt-page-header">
					<h1 class="mkt-page-title"><?php the_title(); ?></h1>
				</header>

				<div class="mkt-entry-content">
					<?php
					the_content();

					wp_link_pages(
						[
							'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'maktomine-restaurant-theme' ),
							'after'  => '</div>',
						]
					);
					?>
				</div>

				<?php
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;
				?>
			</article>
			<?php
		endwhile;
		?>

	</main><!-- #primary -->
</div><!-- .mkt-container -->

<?php
get_footer();
