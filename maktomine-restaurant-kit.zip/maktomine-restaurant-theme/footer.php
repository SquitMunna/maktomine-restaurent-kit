<?php
/**
 * The template for displaying the footer.
 *
 * Closes the #content div and all remaining open body/html tags.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;
?>
	</div><!-- #content -->

	<?php
	/**
	 * Renders theme footer (or yields to Elementor Pro if configured).
	 */
	maktomine_theme_footer();
	?>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
