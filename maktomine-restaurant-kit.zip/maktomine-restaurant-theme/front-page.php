<?php
/**
 * The template for displaying the front page.
 *
 * Fully compatible with Elementor page layouts, standard page content,
 * or default latest posts loop.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="primary" class="site-main site-main--front-page">
	<?php
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'mkt-front-page-article' ); ?>>
				<div class="mkt-entry-content">
					<?php the_content(); ?>
				</div>
			</article>
			<?php
		endwhile;
	else :
		?>
		<div class="mkt-container">
			<section class="mkt-no-results">
				<h1 class="mkt-page-title"><?php esc_html_e( 'Welcome to Maktomine Restaurant', 'maktomine-restaurant-theme' ); ?></h1>
				<p><?php esc_html_e( 'Configure your front page in WordPress Settings > Reading.', 'maktomine-restaurant-theme' ); ?></p>
			</section>
		</div>
		<?php
	endif;
	?>
</main><!-- #primary -->

<?php
get_footer();
