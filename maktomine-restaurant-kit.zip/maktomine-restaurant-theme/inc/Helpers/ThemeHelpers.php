<?php
/**
 * Global Public Helper Functions for Maktomine Restaurant Theme.
 *
 * Provides safe presentation helpers with defensive fallbacks when
 * Core or Elementor is missing or inactive.
 *
 * @package Maktomine\RestaurantTheme\Helpers
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

use Maktomine\RestaurantTheme\Compatibility;
use Maktomine\RestaurantTheme\Settings\ThemeSettings;

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'maktomine_theme_is_core_available' ) ) {
	/**
	 * Check if Maktomine Restaurant Core is loaded and operational.
	 *
	 * @return bool
	 */
	function maktomine_theme_is_core_available(): bool {
		return Compatibility::is_core_active();
	}
}

if ( ! function_exists( 'maktomine_theme_is_elementor_available' ) ) {
	/**
	 * Check if Elementor Free is active.
	 *
	 * @return bool
	 */
	function maktomine_theme_is_elementor_available(): bool {
		return Compatibility::is_elementor_active();
	}
}

if ( ! function_exists( 'maktomine_theme_is_elementor_pro_available' ) ) {
	/**
	 * Check if Elementor Pro is active.
	 *
	 * @return bool
	 */
	function maktomine_theme_is_elementor_pro_available(): bool {
		return Compatibility::is_elementor_pro_active();
	}
}

if ( ! function_exists( 'maktomine_theme_get_option' ) ) {
	/**
	 * Retrieve a presentation theme option by key with fallback.
	 *
	 * @param string $key     Option key or dot notation path.
	 * @param mixed  $default Fallback value if option is unset.
	 * @return mixed
	 */
	function maktomine_theme_get_option( string $key, mixed $default = null ): mixed {
		return ThemeSettings::get( $key, $default );
	}
}

if ( ! function_exists( 'maktomine_theme_get_restaurant_info' ) ) {
	/**
	 * Safely retrieve restaurant business data owned by Core.
	 * Never throws or fatals if Core is missing.
	 *
	 * @param string $key     Business info key (e.g. 'phone', 'whatsapp', 'address').
	 * @param mixed  $default Fallback value if Core is inactive or key unset.
	 * @return mixed
	 */
	function maktomine_theme_get_restaurant_info( string $key, mixed $default = '' ): mixed {
		if ( function_exists( 'maktomine_get_restaurant_info' ) ) {
			return maktomine_get_restaurant_info( $key, $default );
		}

		// Fallback to bloginfo where applicable if Core is not active.
		if ( 'restaurant_name' === $key ) {
			return get_bloginfo( 'name' );
		}
		if ( 'tagline' === $key ) {
			return get_bloginfo( 'description' );
		}
		if ( 'email' === $key ) {
			return get_bloginfo( 'admin_email' );
		}

		return $default;
	}
}

if ( ! function_exists( 'maktomine_theme_format_price' ) ) {
	/**
	 * Safely format a price string using Core currency settings if available,
	 * or a graceful standard currency fallback if Core is inactive.
	 *
	 * @param float|int|string $amount Numerical monetary value.
	 * @return string
	 */
	function maktomine_theme_format_price( float|int|string $amount ): string {
		$numeric_amount = (float) $amount;

		if ( function_exists( 'maktomine_format_price' ) ) {
			return maktomine_format_price( $numeric_amount );
		}

		// Graceful theme fallback if Core is absent.
		return sprintf( '$%.2f', $numeric_amount );
	}
}

if ( ! function_exists( 'maktomine_theme_get_currency_symbol' ) ) {
	/**
	 * Safely retrieve current currency symbol from Core or default to $.
	 *
	 * @return string
	 */
	function maktomine_theme_get_currency_symbol(): string {
		if ( function_exists( 'maktomine_get_currency_symbol' ) ) {
			return maktomine_get_currency_symbol();
		}

		return '$';
	}
}

if ( ! function_exists( 'maktomine_theme_get_cart_count' ) ) {
	/**
	 * Safely retrieve active cart items count from Core or default to 0.
	 *
	 * @return int
	 */
	function maktomine_theme_get_cart_count(): int {
		if ( function_exists( 'maktomine_get_cart_count' ) ) {
			return (int) maktomine_get_cart_count();
		}

		return 0;
	}
}

if ( ! function_exists( 'maktomine_theme_get_whatsapp_url' ) ) {
	/**
	 * Safely retrieve WhatsApp click-to-chat URL via Core helper if available,
	 * or construct a safe basic link if phone is provided.
	 *
	 * @param string $message      Optional pre-filled message text.
	 * @param string $target_phone Optional specific target phone number.
	 * @return string Safe WhatsApp URL or empty string.
	 */
	function maktomine_theme_get_whatsapp_url( string $message = '', string $target_phone = '' ): string {
		if ( function_exists( 'maktomine_get_whatsapp_url' ) ) {
			return (string) maktomine_get_whatsapp_url( $message, ! empty( $target_phone ) ? $target_phone : null );
		}

		$phone = preg_replace( '/[^0-9]/', '', $target_phone );
		if ( empty( $phone ) ) {
			return '';
		}

		$url = 'https://wa.me/' . $phone;
		if ( ! empty( $message ) ) {
			$url .= '?text=' . rawurlencode( $message );
		}

		return $url;
	}
}
