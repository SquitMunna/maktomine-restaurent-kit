<?php
/**
 * Footer Architecture & Rendering Foundation.
 *
 * Implements a structured, responsive footer architecture supporting CTA pre-footer,
 * multi-column layout, and bottom copyright bar.
 *
 * @package Maktomine\RestaurantTheme\Footer
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme\Footer;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantTheme\Elementor\ElementorCompatibility;
use Maktomine\RestaurantTheme\Settings\ThemeSettings;

final class FooterManager {

	/**
	 * Render the complete footer.
	 *
	 * Checks for Elementor Pro Theme Builder override before rendering theme markup.
	 *
	 * @return void
	 */
	public function render(): void {
		// If Elementor Pro has a footer template assigned, let it render and return.
		if ( ElementorCompatibility::has_elementor_pro_footer() ) {
			return;
		}

		do_action( 'maktomine/footer/before' );
		?>
		<footer id="colophon" class="mkt-footer site-footer" role="contentinfo">
			<?php
			if ( ThemeSettings::get( 'footer.show_cta_row', true ) ) {
				$this->render_cta_row();
			}

			$this->render_main_footer();
			$this->render_bottom_bar();
			?>
		</footer>
		<?php
		do_action( 'maktomine/footer/after' );
	}

	/**
	 * Render Pre-Footer Call to Action row.
	 *
	 * @return void
	 */
	protected function render_cta_row(): void {
		$site_name = maktomine_theme_get_restaurant_info( 'restaurant_name', get_bloginfo( 'name' ) );
		$phone     = maktomine_theme_get_restaurant_info( 'phone', '' );
		?>
		<div class="mkt-footer-cta">
			<div class="mkt-container mkt-footer-cta__inner">
				<div class="mkt-footer-cta__content">
					<h3 class="mkt-footer-cta__title"><?php echo esc_html( sprintf( __( 'Experience Fine Dining at %s', 'maktomine-restaurant-theme' ), $site_name ) ); ?></h3>
					<p class="mkt-footer-cta__desc"><?php esc_html_e( 'Order online or reserve a table for an unforgettable culinary experience.', 'maktomine-restaurant-theme' ); ?></p>
				</div>
				<div class="mkt-footer-cta__actions">
					<?php if ( ! empty( $phone ) ) : ?>
						<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $phone ) ); ?>" class="mkt-btn mkt-btn--outline">
							<?php esc_html_e( 'Call Us', 'maktomine-restaurant-theme' ); ?>
						</a>
					<?php endif; ?>
					<a href="<?php echo esc_url( home_url( '/#reservation' ) ); ?>" class="mkt-btn mkt-btn--primary">
						<?php esc_html_e( 'Reserve Table', 'maktomine-restaurant-theme' ); ?>
					</a>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render Main Footer with configurable column structure.
	 *
	 * @return void
	 */
	protected function render_main_footer(): void {
		$cols = absint( ThemeSettings::get( 'footer.columns', 4 ) );
		?>
		<div class="mkt-footer-main">
			<div class="mkt-container mkt-footer-grid mkt-footer-grid--cols-<?php echo esc_attr( (string) $cols ); ?>">
				<div class="mkt-footer-col mkt-footer-col--1">
					<?php $this->col_about(); ?>
				</div>
				<div class="mkt-footer-col mkt-footer-col--2">
					<?php $this->col_hours(); ?>
				</div>
				<div class="mkt-footer-col mkt-footer-col--3">
					<?php $this->col_contact(); ?>
				</div>
				<div class="mkt-footer-col mkt-footer-col--4">
					<?php $this->col_links(); ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Column 1: Restaurant Brand & About blurb.
	 */
	protected function col_about(): void {
		$site_name = maktomine_theme_get_restaurant_info( 'restaurant_name', get_bloginfo( 'name' ) );
		$tagline   = maktomine_theme_get_restaurant_info( 'tagline', get_bloginfo( 'description' ) );
		?>
		<div class="mkt-footer-widget">
			<h4 class="mkt-footer-widget__title"><?php echo esc_html( $site_name ); ?></h4>
			<?php if ( ! empty( $tagline ) ) : ?>
				<p class="mkt-footer-about-text"><?php echo esc_html( (string) $tagline ); ?></p>
			<?php endif; ?>
			<div class="mkt-footer-social">
				<?php $this->render_social_links(); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Column 2: Restaurant Opening Hours (Safely consumed from Core).
	 */
	protected function col_hours(): void {
		$hours = maktomine_theme_get_restaurant_info( 'opening_hours', [] );
		?>
		<div class="mkt-footer-widget">
			<h4 class="mkt-footer-widget__title"><?php esc_html_e( 'Opening Hours', 'maktomine-restaurant-theme' ); ?></h4>
			<?php if ( ! empty( $hours ) && is_array( $hours ) ) : ?>
				<ul class="mkt-hours-list">
					<?php
					$days = [
						'monday'    => __( 'Monday', 'maktomine-restaurant-theme' ),
						'tuesday'   => __( 'Tuesday', 'maktomine-restaurant-theme' ),
						'wednesday' => __( 'Wednesday', 'maktomine-restaurant-theme' ),
						'thursday'  => __( 'Thursday', 'maktomine-restaurant-theme' ),
						'friday'    => __( 'Friday', 'maktomine-restaurant-theme' ),
						'saturday'  => __( 'Saturday', 'maktomine-restaurant-theme' ),
						'sunday'    => __( 'Sunday', 'maktomine-restaurant-theme' ),
					];
					foreach ( $days as $day_key => $day_label ) :
						$day_data = $hours[ $day_key ] ?? null;
						?>
						<li class="mkt-hours-list__item">
							<span class="mkt-hours-list__day"><?php echo esc_html( $day_label ); ?></span>
							<span class="mkt-hours-list__time">
								<?php
								if ( ! empty( $day_data['closed'] ) ) {
									esc_html_e( 'Closed', 'maktomine-restaurant-theme' );
								} elseif ( ! empty( $day_data['open'] ) && ! empty( $day_data['close'] ) ) {
									echo esc_html( $day_data['open'] . ' - ' . $day_data['close'] );
								} else {
									esc_html_e( 'Open', 'maktomine-restaurant-theme' );
								}
								?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p class="mkt-footer-text"><?php esc_html_e( 'Open 7 days a week for lunch & dinner service.', 'maktomine-restaurant-theme' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Column 3: Contact Details (Safely consumed from Core).
	 */
	protected function col_contact(): void {
		$address = maktomine_theme_get_restaurant_info( 'address', '' );
		$city    = maktomine_theme_get_restaurant_info( 'city', '' );
		$phone   = maktomine_theme_get_restaurant_info( 'phone', '' );
		$email   = maktomine_theme_get_restaurant_info( 'email', '' );
		?>
		<div class="mkt-footer-widget">
			<h4 class="mkt-footer-widget__title"><?php esc_html_e( 'Contact Us', 'maktomine-restaurant-theme' ); ?></h4>
			<ul class="mkt-contact-list">
				<?php if ( ! empty( $address ) ) : ?>
					<li class="mkt-contact-list__item mkt-contact-list__address">
						<svg class="mkt-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
							<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
							<circle cx="12" cy="10" r="3"></circle>
						</svg>
						<span><?php echo esc_html( (string) $address . ( $city ? ', ' . (string) $city : '' ) ); ?></span>
					</li>
				<?php endif; ?>
				<?php if ( ! empty( $phone ) ) : ?>
					<li class="mkt-contact-list__item mkt-contact-list__phone">
						<svg class="mkt-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
							<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
						</svg>
						<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $phone ) ); ?>"><?php echo esc_html( (string) $phone ); ?></a>
					</li>
				<?php endif; ?>
				<?php if ( ! empty( $email ) ) : ?>
					<li class="mkt-contact-list__item mkt-contact-list__email">
						<svg class="mkt-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
							<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
							<polyline points="22,6 12,13 2,6"></polyline>
						</svg>
						<a href="mailto:<?php echo esc_attr( (string) $email ); ?>"><?php echo esc_html( (string) $email ); ?></a>
					</li>
				<?php endif; ?>
			</ul>
		</div>
		<?php
	}

	/**
	 * Column 4: Quick Links / Navigation.
	 */
	protected function col_links(): void {
		?>
		<div class="mkt-footer-widget">
			<h4 class="mkt-footer-widget__title"><?php esc_html_e( 'Quick Links', 'maktomine-restaurant-theme' ); ?></h4>
			<?php
			if ( has_nav_menu( 'footer' ) ) {
				wp_nav_menu(
					[
						'theme_location' => 'footer',
						'menu_class'     => 'mkt-menu mkt-menu--footer',
						'container'      => false,
						'depth'          => 1,
						'fallback_cb'    => false,
					]
				);
			} else {
				?>
				<ul class="mkt-menu mkt-menu--footer">
					<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'maktomine-restaurant-theme' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/#menu' ) ); ?>"><?php esc_html_e( 'Food Menu', 'maktomine-restaurant-theme' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/#reservation' ) ); ?>"><?php esc_html_e( 'Bookings', 'maktomine-restaurant-theme' ); ?></a></li>
				</ul>
				<?php
			}
			?>
		</div>
		<?php
	}

	/**
	 * Social icons renderer.
	 */
	protected function render_social_links(): void {
		$socials = maktomine_theme_get_restaurant_info( 'social_profiles', [] );
		if ( empty( $socials ) || ! is_array( $socials ) ) {
			return;
		}

		echo '<div class="mkt-social-icons">';
		foreach ( $socials as $network => $url ) {
			if ( ! empty( $url ) ) {
				printf(
					'<a href="%s" target="_blank" rel="noopener noreferrer" class="mkt-social-icon mkt-social-icon--%s" aria-label="%s">%s</a>',
					esc_url( (string) $url ),
					esc_attr( (string) $network ),
					esc_attr( ucfirst( (string) $network ) ),
					esc_html( ucfirst( (string) $network ) )
				);
			}
		}
		echo '</div>';
	}

	/**
	 * Render Bottom Copyright Bar.
	 *
	 * @return void
	 */
	protected function render_bottom_bar(): void {
		$copyright_raw = ThemeSettings::get( 'footer.copyright_text', '© {year} {sitename}. All rights reserved.' );
		$site_name = maktomine_theme_get_restaurant_info( 'restaurant_name', get_bloginfo( 'name' ) );

		$copyright_parsed = str_replace(
			[ '{year}', '{sitename}' ],
			[ gmdate( 'Y' ), esc_html( $site_name ) ],
			(string) $copyright_raw
		);
		?>
		<div class="mkt-footer-bottom">
			<div class="mkt-container mkt-footer-bottom__inner">
				<div class="mkt-footer-copyright">
					<p><?php echo wp_kses_post( $copyright_parsed ); ?></p>
				</div>
				<div class="mkt-footer-bottom-brand">
					<span class="mkt-powered-by"><?php esc_html_e( 'Powered by Maktomine Restaurant System', 'maktomine-restaurant-theme' ); ?></span>
				</div>
			</div>
		</div>
		<?php
	}
}
