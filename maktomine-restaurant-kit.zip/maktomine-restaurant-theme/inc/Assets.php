<?php
/**
 * Asset Loading and Optimization Manager.
 *
 * Enqueues CSS variables, modular stylesheets, and lightweight vanilla JS.
 * Never introduces jQuery or render-blocking external dependencies.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantTheme\Settings\ThemeSettings;

final class Assets {

	/**
	 * Register asset hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_assets' ] );
		add_filter( 'script_loader_tag', [ $this, 'enforce_script_defer' ], 10, 2 );
	}

	/**
	 * Enqueue front-end stylesheets and scripts.
	 *
	 * @return void
	 */
	public function enqueue_frontend_assets(): void {
		$theme_version = defined( 'MAKTOMINE_THEME_VERSION' ) ? MAKTOMINE_THEME_VERSION : '1.0.0';
		$theme_uri     = get_template_directory_uri();

		// 1. Base CSS Variable Layer.
		wp_enqueue_style(
			'maktomine-variables',
			$theme_uri . '/assets/css/variables.css',
			[],
			$theme_version
		);

		// Inject dynamic CSS custom properties compiled from theme presentation settings.
		wp_add_inline_style( 'maktomine-variables', ThemeSettings::get_css_variables() );

		// 2. Responsive Layout & Grid Layer.
		wp_enqueue_style(
			'maktomine-layout',
			$theme_uri . '/assets/css/layout.css',
			[ 'maktomine-variables' ],
			$theme_version
		);

		// 3. Visual Components Layer (Header, Navigation, Buttons, Cards).
		wp_enqueue_style(
			'maktomine-components',
			$theme_uri . '/assets/css/components.css',
			[ 'maktomine-variables', 'maktomine-layout' ],
			$theme_version
		);

		// 4. Main Theme Stylesheet.
		wp_enqueue_style(
			'maktomine-main',
			$theme_uri . '/assets/css/main.css',
			[ 'maktomine-components' ],
			$theme_version
		);

		// 5. Active Theme Style (style.css metadata header & custom overrides).
		wp_enqueue_style(
			'maktomine-style',
			get_stylesheet_uri(),
			[ 'maktomine-main' ],
			$theme_version
		);

		// 6. RTL Stylesheet (conditionally loaded when text direction is right-to-left).
		if ( is_rtl() ) {
			wp_enqueue_style(
				'maktomine-rtl',
				$theme_uri . '/rtl.css',
				[ 'maktomine-style' ],
				$theme_version
			);
		}

		// 7. Catalog Stylesheet (registered, conditionally enqueued on food items, archives, and catalog taxonomies).
		wp_register_style(
			'maktomine-catalog',
			$theme_uri . '/assets/css/catalog.css',
			[ 'maktomine-variables', 'maktomine-layout', 'maktomine-components' ],
			$theme_version
		);

		if ( is_singular( 'mkt_food_item' ) || is_post_type_archive( 'mkt_food_item' ) || is_tax( [ 'mkt_food_category', 'mkt_food_tag' ] ) ) {
			wp_enqueue_style( 'maktomine-catalog' );
		}

		// 7b. Cart Drawer & Panel Stylesheet.
		wp_register_style(
			'maktomine-cart',
			$theme_uri . '/assets/css/cart.css',
			[ 'maktomine-variables', 'maktomine-components' ],
			$theme_version
		);

		// 8. Vanilla JS Theme Script (No jQuery, loaded in footer).
		// Uses WP 6.3+ args array; backwards-compatible with WP 6.2 (coerces to true for in_footer).
		wp_enqueue_script(
			'maktomine-theme-js',
			$theme_uri . '/assets/js/theme.js',
			[],
			$theme_version,
			[
				'strategy'  => 'defer',
				'in_footer' => true,
			]
		);

		// 9. Browser Cart & REST Client Module (Vanilla ES6+, deferred, loaded in footer).
		wp_register_script(
			'maktomine-cart',
			$theme_uri . '/assets/js/cart.js',
			[ 'maktomine-theme-js' ],
			$theme_version,
			[
				'strategy'  => 'defer',
				'in_footer' => true,
			]
		);

		wp_localize_script(
			'maktomine-cart',
			'maktomineCartConfig',
			[
				'restUrl'     => esc_url_raw( rest_url( 'maktomine/v1/orders' ) ),
				'storageKey'  => 'maktomine_cart_v1',
				'cartVersion' => 1,
			]
		);

		// 10. Browser Cart UI Presentation Module (Vanilla ES6+, deferred, loaded in footer).
		wp_register_script(
			'maktomine-cart-ui',
			$theme_uri . '/assets/js/cart-ui.js',
			[ 'maktomine-cart' ],
			$theme_version,
			[
				'strategy'  => 'defer',
				'in_footer' => true,
			]
		);

		wp_localize_script(
			'maktomine-cart-ui',
			'maktomineCartUIConfig',
			[
				'resolveUrl' => esc_url_raw( rest_url( 'maktomine/v1/cart/resolve' ) ),
			]
		);

		$should_enqueue_cart = is_singular( 'mkt_food_item' )
			|| is_post_type_archive( 'mkt_food_item' )
			|| is_tax( [ 'mkt_food_category', 'mkt_food_tag' ] )
			|| is_front_page()
			|| (bool) ThemeSettings::get( 'header.show_cart_launcher', true );

		if ( apply_filters( 'maktomine/cart/enqueue', $should_enqueue_cart ) ) {
			wp_enqueue_style( 'maktomine-cart' );
			wp_enqueue_script( 'maktomine-cart' );
			wp_enqueue_script( 'maktomine-cart-ui' );
		}

		// Comment reply script if comments are enabled.
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}

	/**
	 * Enforce defer attribute on theme scripts across all supported WP versions (6.2+).
	 *
	 * WordPress 6.3 introduced native 'strategy' => 'defer'. This filter ensures
	 * defer is also added reliably in WordPress 6.2 environments.
	 *
	 * @param string $tag    The <script> tag for the enqueued script.
	 * @param string $handle The script's registered handle.
	 * @return string Modified script tag.
	 */
	public function enforce_script_defer( string $tag, string $handle ): string {
		if ( in_array( $handle, [ 'maktomine-theme-js', 'maktomine-cart', 'maktomine-cart-ui' ], true ) && ! str_contains( $tag, 'defer' ) ) {
			return str_replace( ' src', ' defer src', $tag );
		}

		return $tag;
	}
}
