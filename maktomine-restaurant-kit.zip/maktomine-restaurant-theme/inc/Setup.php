<?php
/**
 * Theme Setup and Core Registration.
 *
 * Configures theme supports, navigation menus, widget areas,
 * and textdomain loading according to WordPress standards.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantTheme\Settings\ThemeSettings;

final class Setup {

	/**
	 * Register hooks for theme setup.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'after_setup_theme', [ $this, 'setup_theme' ] );
		add_action( 'after_setup_theme', [ $this, 'set_content_width' ], 0 );
		add_action( 'widgets_init', [ $this, 'register_sidebars' ] );
		add_action( 'after_switch_theme', [ $this, 'on_theme_activation' ] );
	}

	/**
	 * Setup theme defaults and register support for various WordPress features.
	 *
	 * @return void
	 */
	public function setup_theme(): void {
		// Load textdomain for i18n.
		load_theme_textdomain( 'maktomine-restaurant-theme', get_template_directory() . '/languages' );

		// Add default RSS feed links to <head>.
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the document title.
		add_theme_support( 'title-tag' );

		// Enable support for Post Thumbnails on posts and pages.
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 1200, 800, true );

		// Register standard navigation menus.
		register_nav_menus(
			[
				'primary' => esc_html__( 'Primary Navigation', 'maktomine-restaurant-theme' ),
				'mobile'  => esc_html__( 'Mobile Navigation', 'maktomine-restaurant-theme' ),
				'footer'  => esc_html__( 'Footer Navigation', 'maktomine-restaurant-theme' ),
			]
		);

		// Switch default core markup for search form, comment form, and comments to output valid HTML5.
		add_theme_support(
			'html5',
			[
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			]
		);

		// Custom logo support.
		add_theme_support(
			'custom-logo',
			[
				'height'      => 90,
				'width'       => 280,
				'flex-height' => true,
				'flex-width'  => true,
			]
		);

		// Editor & Block support.
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'align-wide' );
		add_theme_support( 'editor-styles' );
		add_theme_support( 'wp-block-styles' );
	}

	/**
	 * Set the content width in pixels, based on the theme's design and stylesheet.
	 *
	 * @global int $content_width
	 * @return void
	 */
	public function set_content_width(): void {
		$GLOBALS['content_width'] = apply_filters(
			'maktomine/theme/content_width',
			absint( ThemeSettings::get( 'layout.content_width', 840 ) )
		);
	}

	/**
	 * Register widget areas for sidebars and footer.
	 *
	 * @return void
	 */
	public function register_sidebars(): void {
		register_sidebar(
			[
				'name'          => esc_html__( 'Main Sidebar', 'maktomine-restaurant-theme' ),
				'id'            => 'sidebar-main',
				'description'   => esc_html__( 'Add widgets here to appear in your sidebar.', 'maktomine-restaurant-theme' ),
				'before_widget' => '<section id="%1$s" class="mkt-widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h3 class="mkt-widget__title">',
				'after_title'   => '</h3>',
			]
		);

		for ( $i = 1; $i <= 4; $i++ ) {
			register_sidebar(
				[
					'name'          => sprintf( esc_html__( 'Footer Column %d', 'maktomine-restaurant-theme' ), $i ),
					'id'            => "footer-col-{$i}",
					'description'   => sprintf( esc_html__( 'Add widgets here to appear in footer column %d.', 'maktomine-restaurant-theme' ), $i ),
					'before_widget' => '<div id="%1$s" class="mkt-footer-widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h4 class="mkt-footer-widget__title">',
					'after_title'   => '</h4>',
				]
			);
		}
	}

	/**
	 * Non-destructive initialization on theme switch.
	 * Establishes presentation defaults in mkt_theme_options if not present.
	 * NEVER touches database tables or Core data.
	 *
	 * @return void
	 */
	public function on_theme_activation(): void {
		$existing = get_option( ThemeSettings::OPTION_KEY, null );
		if ( null === $existing ) {
			update_option( ThemeSettings::OPTION_KEY, ThemeSettings::get_defaults() );
		}
	}
}
