<?php
/**
 * Presentation Theme Settings Manager.
 *
 * Exclusively manages styling, typography, container widths, layout modes,
 * and aesthetic tokens. Contains ZERO restaurant business data.
 *
 * @package Maktomine\RestaurantTheme\Settings
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme\Settings;

defined( 'ABSPATH' ) || exit;

final class ThemeSettings {

	public const OPTION_KEY = 'mkt_theme_options';

	/**
	 * Cached settings array.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $cached_settings = null;

	/**
	 * Register settings hooks with WordPress.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'admin_init', [ $this, 'register_settings' ] );
	}

	/**
	 * Register settings using WordPress Settings API.
	 *
	 * @return void
	 */
	public function register_settings(): void {
		register_setting(
			'maktomine_theme_options_group',
			self::OPTION_KEY,
			[
				'type'              => 'array',
				'description'       => 'Maktomine Restaurant Theme Presentation Options',
				'sanitize_callback' => [ $this, 'sanitize_settings' ],
				'show_in_rest'      => false,
				'default'           => self::get_defaults(),
			]
		);
	}

	/**
	 * Retrieve all theme options merged with default fallbacks.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_all(): array {
		if ( null !== self::$cached_settings ) {
			return self::$cached_settings;
		}

		$stored = get_option( self::OPTION_KEY, [] );
		if ( ! is_array( $stored ) ) {
			$stored = [];
		}

		self::$cached_settings = array_replace_recursive( self::get_defaults(), $stored );
		return self::$cached_settings;
	}

	/**
	 * Retrieve a specific theme option by key.
	 *
	 * @param string $key     Dot-separated or top-level key.
	 * @param mixed  $default Fallback value.
	 * @return mixed
	 */
	public static function get( string $key, mixed $default = null ): mixed {
		$options = self::get_all();

		if ( array_key_exists( $key, $options ) ) {
			return $options[ $key ];
		}

		// Support dot notation for nested options (e.g. 'colors.primary').
		if ( str_contains( $key, '.' ) ) {
			$segments = explode( '.', $key );
			$current = $options;

			foreach ( $segments as $segment ) {
				if ( is_array( $current ) && array_key_exists( $segment, $current ) ) {
					$current = $current[ $segment ];
				} else {
					return $default;
				}
			}

			return $current;
		}

		return $default;
	}

	/**
	 * Default presentation configuration values.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_defaults(): array {
		return [
			'layout'      => [
				'container_width' => 1240, // pixels
				'content_width'   => 840,  // pixels
				'layout_mode'     => 'fluid', // 'fluid', 'boxed', 'framed'
			],
			'typography'  => [
				'font_family_body'    => '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif',
				'font_family_heading' => 'Georgia, "Times New Roman", Times, serif',
				'font_size_base'      => 16, // px
				'line_height_base'    => 1.6,
			],
			'colors'      => [
				'primary'    => '#c2410c', // Deep appetizing terracotta/amber
				'secondary'  => '#1c1917', // Rich warm slate
				'accent'     => '#d97706', // Golden amber
				'text'       => '#292524', // Dark neutral text
				'heading'    => '#1c1917', // Dark heading
				'background' => '#ffffff', // Clean canvas
				'surface'    => '#fafaf9', // Neutral subtle card/row background
				'border'     => '#e7e5e4', // Clean border
			],
			'radius'      => [
				'sm' => 4,  // px
				'md' => 8,  // px
				'lg' => 14, // px
			],
			'spacing'     => [
				'xs' => 8,  // px
				'sm' => 16, // px
				'md' => 24, // px
				'lg' => 40, // px
				'xl' => 64, // px
			],
			'header'      => [
				'height'         => 80, // px
				'is_sticky'      => true,
				'show_top_row'   => true,
				'show_bottom_row'=> false,
			],
			'footer'      => [
				'columns'        => 4,
				'show_cta_row'   => true,
				'copyright_text' => '© {year} {sitename}. ' . __( 'All rights reserved.', 'maktomine-restaurant-theme' ),
			],
			'breakpoints' => [
				'desktop' => 1200,
				'tablet'  => 768,
				'mobile'  => 480,
			],
		];
	}

	/**
	 * Compile dynamic theme options into CSS custom properties.
	 * Injected cleanly into wp_add_inline_style with zero disk overhead.
	 *
	 * @return string CSS variable declarations string.
	 */
	public static function get_css_variables(): string {
		$options = self::get_all();

		$container_width = absint( $options['layout']['container_width'] ?? 1240 );
		$content_width   = absint( $options['layout']['content_width'] ?? 840 );
		$header_height   = absint( $options['header']['height'] ?? 80 );

		$colors = $options['colors'] ?? [];
		$c_primary    = sanitize_hex_color( $colors['primary'] ?? '#c2410c' ) ?: '#c2410c';
		$c_secondary  = sanitize_hex_color( $colors['secondary'] ?? '#1c1917' ) ?: '#1c1917';
		$c_accent     = sanitize_hex_color( $colors['accent'] ?? '#d97706' ) ?: '#d97706';
		$c_text       = sanitize_hex_color( $colors['text'] ?? '#292524' ) ?: '#292524';
		$c_heading    = sanitize_hex_color( $colors['heading'] ?? '#1c1917' ) ?: '#1c1917';
		$c_background = sanitize_hex_color( $colors['background'] ?? '#ffffff' ) ?: '#ffffff';
		$c_surface    = sanitize_hex_color( $colors['surface'] ?? '#fafaf9' ) ?: '#fafaf9';
		$c_border     = sanitize_hex_color( $colors['border'] ?? '#e7e5e4' ) ?: '#e7e5e4';

		$radius = $options['radius'] ?? [];
		$r_sm = absint( $radius['sm'] ?? 4 );
		$r_md = absint( $radius['md'] ?? 8 );
		$r_lg = absint( $radius['lg'] ?? 14 );

		$spacing = $options['spacing'] ?? [];
		$s_xs = absint( $spacing['xs'] ?? 8 );
		$s_sm = absint( $spacing['sm'] ?? 16 );
		$s_md = absint( $spacing['md'] ?? 24 );
		$s_lg = absint( $spacing['lg'] ?? 40 );
		$s_xl = absint( $spacing['xl'] ?? 64 );

		$typography = $options['typography'] ?? [];
		$font_size_base   = absint( $typography['font_size_base'] ?? 16 );
		$line_height_base = floatval( $typography['line_height_base'] ?? 1.6 );

		return sprintf(
			':root {
	--mkt-container-width: %dpx;
	--mkt-content-width: %dpx;
	--mkt-header-height: %dpx;
	--mkt-color-primary: %s;
	--mkt-color-secondary: %s;
	--mkt-color-accent: %s;
	--mkt-color-text: %s;
	--mkt-color-heading: %s;
	--mkt-color-background: %s;
	--mkt-color-surface: %s;
	--mkt-color-border: %s;
	--mkt-radius-sm: %dpx;
	--mkt-radius-md: %dpx;
	--mkt-radius-lg: %dpx;
	--mkt-spacing-xs: %dpx;
	--mkt-spacing-sm: %dpx;
	--mkt-spacing-md: %dpx;
	--mkt-spacing-lg: %dpx;
	--mkt-spacing-xl: %dpx;
	--mkt-font-size-base: %dpx;
	--mkt-line-height-base: %.2f;
}',
			$container_width,
			$content_width,
			$header_height,
			$c_primary,
			$c_secondary,
			$c_accent,
			$c_text,
			$c_heading,
			$c_background,
			$c_surface,
			$c_border,
			$r_sm,
			$r_md,
			$r_lg,
			$s_xs,
			$s_sm,
			$s_md,
			$s_lg,
			$s_xl,
			$font_size_base,
			$line_height_base
		);
	}

	/**
	 * Sanitize presentation settings before saving to database.
	 *
	 * @param mixed $input Submitted raw values.
	 * @return array<string, mixed> Clean sanitized presentation values.
	 */
	public function sanitize_settings( mixed $input ): array {
		if ( ! is_array( $input ) ) {
			return self::get_defaults();
		}

		$defaults = self::get_defaults();
		$clean = $defaults;

		// Layout
		if ( isset( $input['layout'] ) && is_array( $input['layout'] ) ) {
			if ( isset( $input['layout']['container_width'] ) ) {
				$val = absint( $input['layout']['container_width'] );
				$clean['layout']['container_width'] = ( $val >= 600 && $val <= 2400 ) ? $val : $defaults['layout']['container_width'];
			}
			if ( isset( $input['layout']['content_width'] ) ) {
				$val = absint( $input['layout']['content_width'] );
				$clean['layout']['content_width'] = ( $val >= 400 && $val <= 1600 ) ? $val : $defaults['layout']['content_width'];
			}
			if ( isset( $input['layout']['layout_mode'] ) ) {
				$allowed = [ 'fluid', 'boxed', 'framed' ];
				$val = sanitize_key( $input['layout']['layout_mode'] );
				$clean['layout']['layout_mode'] = in_array( $val, $allowed, true ) ? $val : 'fluid';
			}
		}

		// Colors
		if ( isset( $input['colors'] ) && is_array( $input['colors'] ) ) {
			$color_keys = [ 'primary', 'secondary', 'accent', 'text', 'heading', 'background', 'surface', 'border' ];
			foreach ( $color_keys as $ck ) {
				if ( isset( $input['colors'][ $ck ] ) ) {
					$hex = sanitize_hex_color( (string) $input['colors'][ $ck ] );
					if ( $hex ) {
						$clean['colors'][ $ck ] = $hex;
					}
				}
			}
		}

		// Header
		if ( isset( $input['header'] ) && is_array( $input['header'] ) ) {
			if ( isset( $input['header']['height'] ) ) {
				$clean['header']['height'] = min( 200, max( 40, absint( $input['header']['height'] ) ) );
			}
			$clean['header']['is_sticky'] = ! empty( $input['header']['is_sticky'] );
			$clean['header']['show_top_row'] = ! empty( $input['header']['show_top_row'] );
			$clean['header']['show_bottom_row'] = ! empty( $input['header']['show_bottom_row'] );
		}

		// Footer
		if ( isset( $input['footer'] ) && is_array( $input['footer'] ) ) {
			if ( isset( $input['footer']['columns'] ) ) {
				$cols = absint( $input['footer']['columns'] );
				$clean['footer']['columns'] = in_array( $cols, [ 1, 2, 3, 4, 5, 6 ], true ) ? $cols : 4;
			}
			$clean['footer']['show_cta_row'] = ! empty( $input['footer']['show_cta_row'] );
			if ( isset( $input['footer']['copyright_text'] ) ) {
				$clean['footer']['copyright_text'] = sanitize_text_field( (string) $input['footer']['copyright_text'] );
			}
		}

		self::$cached_settings = $clean;
		return $clean;
	}
}
