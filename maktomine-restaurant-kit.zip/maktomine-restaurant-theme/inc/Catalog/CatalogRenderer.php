<?php
/**
 * Theme Catalog Renderer Controller.
 *
 * Serves as the Theme boundary controller between Core catalog services and Theme template parts.
 * Coordinates CatalogService instance access, CatalogPresenter presentation transformation,
 * and passes presentation-ready data into theme partials.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme\Catalog;

use Maktomine\RestaurantTheme\Compatibility;

/**
 * CatalogRenderer class.
 */
final class CatalogRenderer {

	/**
	 * Verify if Maktomine Restaurant Core and catalog classes are active and available.
	 *
	 * @return bool True if Core and catalog classes exist, false otherwise.
	 */
	public static function is_catalog_ready(): bool {
		if ( ! Compatibility::is_core_active() ) {
			return false;
		}

		return class_exists( '\Maktomine\RestaurantCore\Catalog\CatalogService' )
			&& class_exists( '\Maktomine\RestaurantCore\Catalog\CatalogPresenter' );
	}

	/**
	 * Retrieve a presentation-ready food item for a given post ID.
	 *
	 * @param int $post_id Post ID of the food item.
	 * @return array<string, mixed>|null Presentation-ready item array, or null if unavailable or error.
	 */
	public static function get_food_item( int $post_id ): ?array {
		if ( ! self::is_catalog_ready() || $post_id <= 0 ) {
			return null;
		}

		$service  = \Maktomine\RestaurantCore\Catalog\CatalogService::instance();
		$raw_item = $service->get_food_item( $post_id );

		if ( is_wp_error( $raw_item ) || empty( $raw_item ) ) {
			return null;
		}

		return \Maktomine\RestaurantCore\Catalog\CatalogPresenter::present_item( $raw_item );
	}

	/**
	 * Retrieve a presentation-ready collection of food items.
	 *
	 * Only passes approved arguments ('page', 'per_page') to CatalogService.
	 *
	 * @param array<string, mixed> $args Query arguments ('page', 'per_page').
	 * @return array{items: array<int, array<string, mixed>>, pagination: array<string, int>}|null Collection array or null.
	 */
	public static function get_food_items( array $args = [] ): ?array {
		if ( ! self::is_catalog_ready() ) {
			return null;
		}

		$service    = \Maktomine\RestaurantCore\Catalog\CatalogService::instance();
		$query_args = [];

		if ( isset( $args['page'] ) ) {
			$query_args['page'] = max( 1, (int) $args['page'] );
		}

		if ( isset( $args['per_page'] ) ) {
			$query_args['per_page'] = min( 50, max( 1, (int) $args['per_page'] ) );
		}

		if ( isset( $args['category'] ) && is_string( $args['category'] ) && '' !== trim( $args['category'] ) ) {
			$query_args['category'] = sanitize_title( $args['category'] );
		}

		if ( isset( $args['tag'] ) && is_string( $args['tag'] ) && '' !== trim( $args['tag'] ) ) {
			$query_args['tag'] = sanitize_title( $args['tag'] );
		}

		if ( isset( $args['featured'] ) ) {
			$query_args['featured'] = (bool) $args['featured'];
		}

		if ( isset( $args['popular'] ) ) {
			$query_args['popular'] = (bool) $args['popular'];
		}

		if ( isset( $args['availability_status'] ) && is_string( $args['availability_status'] ) ) {
			$query_args['availability_status'] = sanitize_key( $args['availability_status'] );
		}

		if ( isset( $args['orderby'] ) && is_string( $args['orderby'] ) ) {
			$query_args['orderby'] = sanitize_key( $args['orderby'] );
		}

		$raw_collection = $service->get_food_items( $query_args );

		if ( is_wp_error( $raw_collection ) || empty( $raw_collection ) ) {
			return null;
		}

		return \Maktomine\RestaurantCore\Catalog\CatalogPresenter::present_collection( $raw_collection );
	}

	/**
	 * Normalize and sanitize catalog view configuration to the canonical contract.
	 *
	 * Single centralized boundary for view configuration.
	 *
	 * @param array<string, mixed> $config Raw configuration array.
	 * @return array{
	 *     show_image: bool,
	 *     show_badges: bool,
	 *     show_metrics: bool,
	 *     show_categories: bool,
	 *     show_price: bool,
	 *     columns: int,
	 *     layout_style: string
	 * } Normalized configuration adhering to canonical contract.
	 */
	public static function normalize_config( array $config = [] ): array {
		$raw_columns = isset( $config['columns'] ) && is_numeric( $config['columns'] )
			? (int) $config['columns']
			: 3;

		$layout_style = isset( $config['layout_style'] ) && 'list' === $config['layout_style']
			? 'list'
			: 'grid';

		return [
			'show_image'      => (bool) ( $config['show_image'] ?? true ),
			'show_badges'     => (bool) ( $config['show_badges'] ?? true ),
			'show_metrics'    => (bool) ( $config['show_metrics'] ?? true ),
			'show_categories' => (bool) ( $config['show_categories'] ?? true ),
			'show_price'      => (bool) ( $config['show_price'] ?? true ),
			'columns'         => max( 1, min( 4, $raw_columns ) ),
			'layout_style'    => $layout_style,
		];
	}

	/**
	 * Render the full single food item view.
	 *
	 * @param int $post_id Post ID of the food item (defaults to current post).
	 * @return void
	 */
	public static function render_single( int $post_id = 0 ): void {
		if ( 0 === $post_id ) {
			$post_id = (int) get_the_ID();
		}

		$item = self::get_food_item( $post_id );

		if ( empty( $item ) ) {
			get_template_part( 'template-parts/catalog/food-empty' );
			return;
		}
		?>
		<article id="mkt-food-single-<?php echo esc_attr( (string) $item['id'] ); ?>" class="mkt-food-single">
			<div class="mkt-food-single__container">
				<div class="mkt-food-single__gallery-col">
					<?php
					get_template_part(
						'template-parts/catalog/single/item-gallery',
						null,
						[ 'item' => $item ]
					);
					?>
				</div>

				<div class="mkt-food-single__content-col">
					<?php
					get_template_part(
						'template-parts/catalog/single/item-header',
						null,
						[ 'item' => $item ]
					);

					get_template_part(
						'template-parts/catalog/single/item-pricing',
						null,
						[ 'item' => $item ]
					);

					get_template_part(
						'template-parts/catalog/single/item-meta',
						null,
						[ 'item' => $item ]
					);
					?>

					<?php if ( '' !== get_the_content() ) : ?>
						<div class="mkt-food-single__description entry-content">
							<?php the_content(); ?>
						</div>
					<?php endif; ?>

					<?php
					get_template_part(
						'template-parts/catalog/single/item-variations',
						null,
						[ 'item' => $item ]
					);

					get_template_part(
						'template-parts/catalog/single/item-addons',
						null,
						[ 'item' => $item ]
					);
					?>
				</div>
			</div>
		</article>
		<?php
	}

	/**
	 * Render a collection in grid or list format.
	 *
	 * Normalizes configuration once at the boundary before delegating to layout templates.
	 *
	 * @param array<string, mixed> $query_args Query arguments for CatalogService ('page', 'per_page').
	 * @param array<string, mixed> $config     Canonical view configuration.
	 * @return void
	 */
	public static function render_collection( array $query_args = [], array $config = [] ): void {
		$collection = self::get_food_items( $query_args );

		if ( empty( $collection ) || empty( $collection['items'] ) ) {
			get_template_part( 'template-parts/catalog/food-empty' );
			return;
		}

		$normalized_config = self::normalize_config( $config );

		$template = 'list' === $normalized_config['layout_style']
			? 'template-parts/catalog/food-list'
			: 'template-parts/catalog/food-grid';

		get_template_part(
			$template,
			null,
			[
				'items'      => $collection['items'],
				'pagination' => $collection['pagination'],
				'config'     => $normalized_config,
			]
		);
	}
}
