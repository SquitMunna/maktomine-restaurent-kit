<?php
/**
 * Compatibility and Ecosystem Detector.
 *
 * Safely inspects the availability of Core, Elementor, and environment features
 * without triggering extraneous autoloading or fatal errors.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme;

defined( 'ABSPATH' ) || exit;

final class Compatibility {

	/**
	 * Check if Maktomine Restaurant Core plugin is active and booted.
	 *
	 * @return bool
	 */
	public static function is_core_active(): bool {
		// Prefer the dedicated public core helper if loaded.
		if ( function_exists( 'maktomine_is_core_active' ) ) {
			return (bool) maktomine_is_core_active();
		}

		// Fallback check on Core Plugin singleton if helper isn't loaded yet.
		if ( class_exists( '\Maktomine\RestaurantCore\Core\Plugin', false ) ) {
			return \Maktomine\RestaurantCore\Core\Plugin::is_active();
		}

		return false;
	}

	/**
	 * Check if Elementor Free is active.
	 *
	 * @return bool
	 */
	public static function is_elementor_active(): bool {
		return did_action( 'elementor/loaded' ) || defined( 'ELEMENTOR_VERSION' );
	}

	/**
	 * Check if Elementor Pro is active.
	 *
	 * @return bool
	 */
	public static function is_elementor_pro_active(): bool {
		return defined( 'ELEMENTOR_PRO_VERSION' ) || class_exists( '\ElementorPro\Plugin', false );
	}

	/**
	 * Check if WooCommerce is active (used purely for diagnostics; zero reliance).
	 *
	 * @return bool
	 */
	public static function is_woocommerce_active(): bool {
		return class_exists( '\WooCommerce', false );
	}

	/**
	 * Get ecosystem status snapshot for debugging or admin diagnostics.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_status(): array {
		return [
			'core_active'          => self::is_core_active(),
			'elementor_active'     => self::is_elementor_active(),
			'elementor_pro_active' => self::is_elementor_pro_active(),
			'woocommerce_active'   => self::is_woocommerce_active(),
			'php_version'          => PHP_VERSION,
			'wp_version'           => get_bloginfo( 'version' ),
		];
	}
}
