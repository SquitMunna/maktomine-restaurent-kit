<?php
/**
 * PSR-4 Autoloader for Maktomine Restaurant Theme.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme;

defined( 'ABSPATH' ) || exit;

final class Autoloader {

	/**
	 * Map of namespace prefix to base directory path.
	 *
	 * @var array<string, string>
	 */
	private static array $prefixes = [];

	/**
	 * Register a namespace prefix and its corresponding base directory.
	 *
	 * @param string $prefix   Namespace prefix with trailing backslash.
	 * @param string $base_dir Absolute path to base directory with trailing slash.
	 * @return void
	 */
	public static function register( string $prefix, string $base_dir ): void {
		$prefix = trim( $prefix, '\\' ) . '\\';
		$base_dir = rtrim( $base_dir, '/\\' ) . DIRECTORY_SEPARATOR;

		if ( empty( self::$prefixes ) ) {
			spl_autoload_register( [ __CLASS__, 'load' ] );
		}

		self::$prefixes[ $prefix ] = $base_dir;
	}

	/**
	 * Attempt to load the class file for a given fully-qualified class name.
	 *
	 * @param string $class Fully-qualified class name.
	 * @return bool True if loaded, false otherwise.
	 */
	public static function load( string $class ): bool {
		foreach ( self::$prefixes as $prefix => $base_dir ) {
			$prefix_len = strlen( $prefix );

			if ( strncmp( $prefix, $class, $prefix_len ) !== 0 ) {
				continue;
			}

			$relative_class = substr( $class, $prefix_len );
			$file = $base_dir . str_replace( '\\', DIRECTORY_SEPARATOR, $relative_class ) . '.php';

			if ( file_exists( $file ) ) {
				require_once $file;
				return true;
			}
		}

		return false;
	}
}
