<?php
/**
 * Elementor & Elementor Pro Compatibility Foundation.
 *
 * Implements Elementor theme locations, template takeover detection,
 * and page-builder canvas support without hard-requiring Elementor.
 *
 * @package Maktomine\RestaurantTheme\Elementor
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme\Elementor;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantTheme\Compatibility;

final class ElementorCompatibility {

	/**
	 * Register hooks for Elementor integration.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'after_setup_theme', [ $this, 'add_theme_support' ] );
		add_action( 'elementor/theme/register_locations', [ $this, 'register_elementor_locations' ] );
	}

	/**
	 * Declare theme support for Elementor capabilities.
	 *
	 * @return void
	 */
	public function add_theme_support(): void {
		// Declare Elementor theme support for full-width and canvas templates.
		add_theme_support( 'elementor' );
	}

	/**
	 * Register Theme Builder locations with Elementor Pro.
	 * Allows users with Elementor Pro to assign custom header/footer templates.
	 *
	 * @param mixed $elementor_theme_manager ThemeManager instance passed by Elementor.
	 * @return void
	 */
	public function register_elementor_locations( mixed $elementor_theme_manager ): void {
		if ( is_object( $elementor_theme_manager ) && method_exists( $elementor_theme_manager, 'register_all_core_location' ) ) {
			$elementor_theme_manager->register_all_core_location();
		} elseif ( is_object( $elementor_theme_manager ) && method_exists( $elementor_theme_manager, 'register_location' ) ) {
			$elementor_theme_manager->register_location(
				'header',
				[
					'label'           => __( 'Header', 'maktomine-restaurant-theme' ),
					'multiple'        => false,
					'edit_in_content' => false,
				]
			);
			$elementor_theme_manager->register_location(
				'footer',
				[
					'label'           => __( 'Footer', 'maktomine-restaurant-theme' ),
					'multiple'        => false,
					'edit_in_content' => false,
				]
			);
		}
	}

	/**
	 * Check whether Elementor Pro has taken over the header location.
	 *
	 * When a custom Header template is assigned in Elementor Pro Theme Builder,
	 * elementor_theme_do_location() renders the template markup directly and returns true.
	 *
	 * @return bool True if Elementor Pro rendered the header.
	 */
	public static function has_elementor_pro_header(): bool {
		if ( function_exists( 'elementor_theme_do_location' ) ) {
			return (bool) elementor_theme_do_location( 'header' );
		}

		return false;
	}

	/**
	 * Check whether Elementor Pro has taken over the footer location.
	 *
	 * When a custom Footer template is assigned in Elementor Pro Theme Builder,
	 * elementor_theme_do_location() renders the template markup directly and returns true.
	 *
	 * @return bool True if Elementor Pro rendered the footer.
	 */
	public static function has_elementor_pro_footer(): bool {
		if ( function_exists( 'elementor_theme_do_location' ) ) {
			return (bool) elementor_theme_do_location( 'footer' );
		}

		return false;
	}
}
