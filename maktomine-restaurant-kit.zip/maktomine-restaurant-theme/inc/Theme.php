<?php
/**
 * Main Theme Kernel Singleton.
 *
 * Coordinates theme initialization, service registration, and module lifecycle.
 *
 * @package Maktomine\RestaurantTheme
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantTheme\Settings\ThemeSettings;
use Maktomine\RestaurantTheme\Header\HeaderManager;
use Maktomine\RestaurantTheme\Footer\FooterManager;
use Maktomine\RestaurantTheme\Elementor\ElementorCompatibility;

final class Theme {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Subsystem instances.
	 */
	private Setup $setup;
	private Assets $assets;
	private ThemeSettings $settings;
	private HeaderManager $header;
	private FooterManager $footer;
	private ElementorCompatibility $elementor;

	/**
	 * Boot state flag.
	 */
	private bool $is_booted = false;

	/**
	 * Retrieve singleton instance.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Private constructor.
	 */
	private function __construct() {
		$this->setup     = new Setup();
		$this->assets    = new Assets();
		$this->settings  = new ThemeSettings();
		$this->header    = new HeaderManager();
		$this->footer    = new FooterManager();
		$this->elementor = new ElementorCompatibility();
	}

	/**
	 * Boot the theme services and attach hooks.
	 *
	 * @return void
	 */
	public function boot(): void {
		if ( $this->is_booted ) {
			return;
		}

		$this->setup->register();
		$this->assets->register();
		$this->settings->register();
		$this->elementor->register();

		$this->is_booted = true;

		do_action( 'maktomine/theme/loaded', $this );
	}

	/**
	 * Access HeaderManager.
	 *
	 * @return HeaderManager
	 */
	public function get_header(): HeaderManager {
		return $this->header;
	}

	/**
	 * Access FooterManager.
	 *
	 * @return FooterManager
	 */
	public function get_footer(): FooterManager {
		return $this->footer;
	}

	/**
	 * Access ThemeSettings.
	 *
	 * @return ThemeSettings
	 */
	public function get_settings(): ThemeSettings {
		return $this->settings;
	}

	/**
	 * Prevent cloning.
	 */
	private function __clone() {}

	/**
	 * Prevent unserializing.
	 */
	public function __wakeup() {
		throw new \Exception( 'Cannot unserialize singleton' );
	}
}
