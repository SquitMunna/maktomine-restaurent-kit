<?php
/**
 * Header Architecture & Rendering Foundation.
 *
 * Implements a 3-row, 3-column structured header renderer that can be driven
 * by default layout configs or future visual Header Builder configurations.
 *
 * @package Maktomine\RestaurantTheme\Header
 * @license GPL-2.0-or-later
 */

declare(strict_types=1);

namespace Maktomine\RestaurantTheme\Header;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantTheme\Elementor\ElementorCompatibility;
use Maktomine\RestaurantTheme\Settings\ThemeSettings;

final class HeaderManager {

	/**
	 * Render the complete header.
	 *
	 * Checks for Elementor Pro Theme Builder override before rendering theme markup.
	 *
	 * @return void
	 */
	public function render(): void {
		// If Elementor Pro has a header template assigned, let it render and return.
		if ( ElementorCompatibility::has_elementor_pro_header() ) {
			return;
		}

		$config = $this->get_header_config();

		do_action( 'maktomine/header/before' );
		?>
		<header id="masthead" class="mkt-header site-header <?php echo esc_attr( $this->get_header_classes() ); ?>" role="banner">
			<?php
			if ( ! empty( $config['top']['enabled'] ) ) {
				$this->render_row( 'top', $config['top'] );
			}

			if ( ! empty( $config['main']['enabled'] ) ) {
				$this->render_row( 'main', $config['main'] );
			}

			if ( ! empty( $config['bottom']['enabled'] ) ) {
				$this->render_row( 'bottom', $config['bottom'] );
			}
			?>
		</header>
		<?php
		$this->render_mobile_drawer();
		do_action( 'maktomine/header/after' );
	}

	/**
	 * Render a specific header row (top, main, bottom).
	 *
	 * @param string               $row_id Row identifier.
	 * @param array<string, mixed> $row_config Row structure and elements.
	 * @return void
	 */
	protected function render_row( string $row_id, array $row_config ): void {
		do_action( "maktomine/header/row_before", $row_id, $row_config );
		?>
		<div class="mkt-header-row mkt-header-row--<?php echo esc_attr( $row_id ); ?>">
			<div class="mkt-container mkt-header-row__inner">
				<div class="mkt-header-col mkt-header-col--left">
					<?php $this->render_column_elements( $row_config['left'] ?? [] ); ?>
				</div>
				<div class="mkt-header-col mkt-header-col--center">
					<?php $this->render_column_elements( $row_config['center'] ?? [] ); ?>
				</div>
				<div class="mkt-header-col mkt-header-col--right">
					<?php $this->render_column_elements( $row_config['right'] ?? [] ); ?>
				</div>
			</div>
		</div>
		<?php
		do_action( "maktomine/header/row_after", $row_id, $row_config );
	}

	/**
	 * Render list of element identifiers inside a header column.
	 *
	 * @param array<string> $elements List of element keys.
	 * @return void
	 */
	protected function render_column_elements( array $elements ): void {
		foreach ( $elements as $element_id ) {
			$this->render_element( $element_id );
		}
	}

	/**
	 * Dispatch rendering of a specific header element.
	 *
	 * @param string $element_id Element key.
	 * @return void
	 */
	public function render_element( string $element_id ): void {
		// Allow extensions/plugins to intercept or provide custom elements.
		if ( has_action( "maktomine/header/render_element_{$element_id}" ) ) {
			do_action( "maktomine/header/render_element_{$element_id}" );
			return;
		}

		switch ( $element_id ) {
			case 'logo':
				$this->element_logo();
				break;
			case 'navigation':
				$this->element_navigation();
				break;
			case 'mobile_toggle':
				$this->element_mobile_toggle();
				break;
			case 'phone':
				$this->element_phone();
				break;
			case 'whatsapp':
				$this->element_whatsapp();
				break;
			case 'cart_launcher':
				$this->element_cart_launcher();
				break;
			case 'opening_hours':
				$this->element_opening_hours();
				break;
			case 'restaurant_notice':
				$this->element_restaurant_notice();
				break;
			case 'search':
				$this->element_search();
				break;
			case 'reservation_trigger':
				$this->element_reservation_trigger();
				break;
			default:
				do_action( 'maktomine/header/render_element_default', $element_id );
				break;
		}
	}

	/**
	 * Element: Site Logo / Title.
	 */
	protected function element_logo(): void {
		?>
		<div class="mkt-header-element mkt-header-logo">
			<?php
			if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
				the_custom_logo();
			} else {
				$site_name = maktomine_theme_get_restaurant_info( 'restaurant_name', get_bloginfo( 'name' ) );
				?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="mkt-site-title" rel="home">
					<span class="mkt-site-title__text"><?php echo esc_html( $site_name ); ?></span>
				</a>
				<?php
			}
			?>
		</div>
		<?php
	}

	/**
	 * Element: Primary Navigation.
	 */
	protected function element_navigation(): void {
		if ( ! has_nav_menu( 'primary' ) ) {
			return;
		}
		?>
		<nav class="mkt-header-element mkt-header-nav" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'maktomine-restaurant-theme' ); ?>">
			<?php
			wp_nav_menu(
				[
					'theme_location' => 'primary',
					'menu_class'     => 'mkt-menu mkt-menu--primary',
					'container'      => false,
					'fallback_cb'    => false,
					'depth'          => 3,
				]
			);
			?>
		</nav>
		<?php
	}

	/**
	 * Element: Accessible Mobile Menu Toggle.
	 */
	protected function element_mobile_toggle(): void {
		?>
		<div class="mkt-header-element mkt-header-mobile-toggle">
			<button type="button" class="mkt-btn-toggle" id="mkt-mobile-toggle-btn" aria-expanded="false" aria-controls="mkt-mobile-menu-drawer" aria-label="<?php esc_attr_e( 'Toggle navigation menu', 'maktomine-restaurant-theme' ); ?>">
				<span class="mkt-btn-toggle__icon" aria-hidden="true"></span>
				<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'maktomine-restaurant-theme' ); ?></span>
			</button>
		</div>
		<?php
	}

	/**
	 * Element: Restaurant Phone (Consumes Core business data safely).
	 */
	protected function element_phone(): void {
		$phone = maktomine_theme_get_restaurant_info( 'phone', '' );
		if ( empty( $phone ) ) {
			return;
		}

		$clean_phone = preg_replace( '/[^0-9+]/', '', (string) $phone );
		?>
		<div class="mkt-header-element mkt-header-phone">
			<a href="tel:<?php echo esc_attr( $clean_phone ); ?>" class="mkt-phone-link" aria-label="<?php esc_attr_e( 'Call Restaurant', 'maktomine-restaurant-theme' ); ?>">
				<svg class="mkt-icon mkt-icon--phone" aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
				</svg>
				<span class="mkt-phone-link__text"><?php echo esc_html( (string) $phone ); ?></span>
			</a>
		</div>
		<?php
	}

	/**
	 * Element: WhatsApp Contact Trigger (Consumes Core WhatsApp link safely).
	 */
	protected function element_whatsapp(): void {
		$whatsapp = maktomine_theme_get_restaurant_info( 'whatsapp', '' );
		if ( empty( $whatsapp ) ) {
			return;
		}

		$wa_url = maktomine_theme_get_whatsapp_url(
			__( 'Hello, I would like to inquire about your restaurant.', 'maktomine-restaurant-theme' ),
			(string) $whatsapp
		);

		if ( empty( $wa_url ) ) {
			return;
		}
		?>
		<div class="mkt-header-element mkt-header-whatsapp">
			<a href="<?php echo esc_url( $wa_url ); ?>" target="_blank" rel="noopener noreferrer" class="mkt-whatsapp-btn" aria-label="<?php esc_attr_e( 'Contact us on WhatsApp', 'maktomine-restaurant-theme' ); ?>">
				<svg class="mkt-icon mkt-icon--whatsapp" aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
					<path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.007c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.303-.058.116-.087.188-.173.289l-.26.303c-.087.087-.177.182-.076.355.101.173.45 1.018 1.037 1.54.755.672 1.391.88 1.587.978.196.097.311.082.427-.05.116-.13.491-.57.621-.766.13-.196.26-.164.448-.094.188.07 1.199.565 1.405.669.206.104.343.155.393.242.05.087.05.505-.094.91z"/>
				</svg>
				<span><?php esc_html_e( 'WhatsApp', 'maktomine-restaurant-theme' ); ?></span>
			</a>
		</div>
		<?php
	}

	/**
	 * Element: Cart Launcher Presentation Hook.
	 * Consumes Core cart count public helper. Does NOT calculate totals or execute business logic.
	 */
	protected function element_cart_launcher(): void {
		$cart_count = maktomine_theme_get_cart_count();
		?>
		<div class="mkt-header-element mkt-header-cart-launcher">
			<button type="button" class="mkt-cart-launcher-btn" id="mkt-cart-launcher-trigger" aria-controls="mkt-cart-drawer" aria-expanded="false" aria-label="<?php echo esc_attr( sprintf( __( 'Open Food Cart, %d items', 'maktomine-restaurant-theme' ), $cart_count ) ); ?>">
				<svg class="mkt-icon mkt-icon--cart" aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<circle cx="9" cy="21" r="1"></circle>
					<circle cx="20" cy="21" r="1"></circle>
					<path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
				</svg>
				<span class="mkt-cart-badge" id="mkt-cart-launcher-count" data-count="<?php echo esc_attr( (string) $cart_count ); ?>"><?php echo esc_html( (string) $cart_count ); ?></span>
			</button>
		</div>
		<?php
	}

	/**
	 * Element: Restaurant Opening Hours notice.
	 */
	protected function element_opening_hours(): void {
		$hours = maktomine_theme_get_restaurant_info( 'opening_hours', [] );
		if ( empty( $hours ) || ! is_array( $hours ) ) {
			return;
		}

		$current_day = strtolower( gmdate( 'l' ) );
		$today_hours = $hours[ $current_day ] ?? null;

		$status_text = __( 'Open Daily', 'maktomine-restaurant-theme' );
		if ( is_array( $today_hours ) ) {
			if ( ! empty( $today_hours['closed'] ) ) {
				$status_text = __( 'Closed Today', 'maktomine-restaurant-theme' );
			} elseif ( ! empty( $today_hours['open'] ) && ! empty( $today_hours['close'] ) ) {
				$status_text = sprintf(
					/* translators: 1: Open time, 2: Close time */
					__( 'Today: %1$s – %2$s', 'maktomine-restaurant-theme' ),
					$today_hours['open'],
					$today_hours['close']
				);
			}
		}
		?>
		<div class="mkt-header-element mkt-header-hours">
			<svg class="mkt-icon mkt-icon--clock" aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
				<circle cx="12" cy="12" r="10"></circle>
				<polyline points="12 6 12 12 16 14"></polyline>
			</svg>
			<span class="mkt-hours-text"><?php echo esc_html( $status_text ); ?></span>
		</div>
		<?php
	}

	/**
	 * Element: Header Announcement / Restaurant Notice.
	 */
	protected function element_restaurant_notice(): void {
		$tagline = maktomine_theme_get_restaurant_info( 'tagline', get_bloginfo( 'description' ) );
		if ( empty( $tagline ) ) {
			return;
		}
		?>
		<div class="mkt-header-element mkt-header-notice">
			<span class="mkt-notice-text"><?php echo esc_html( (string) $tagline ); ?></span>
		</div>
		<?php
	}

	/**
	 * Element: Search trigger.
	 */
	protected function element_search(): void {
		?>
		<div class="mkt-header-element mkt-header-search">
			<form role="search" method="get" class="mkt-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<label>
					<span class="screen-reader-text"><?php esc_html_e( 'Search menu:', 'maktomine-restaurant-theme' ); ?></span>
					<input type="search" class="mkt-search-field" placeholder="<?php esc_attr_e( 'Search dishes...', 'maktomine-restaurant-theme' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
				</label>
				<button type="submit" class="mkt-search-submit" aria-label="<?php esc_attr_e( 'Search', 'maktomine-restaurant-theme' ); ?>">
					<svg class="mkt-icon mkt-icon--search" aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
						<circle cx="11" cy="11" r="8"></circle>
						<line x1="21" y1="21" x2="16.65" y2="16.65"></line>
					</svg>
				</button>
			</form>
		</div>
		<?php
	}

	/**
	 * Element: Table Reservation Trigger button.
	 */
	protected function element_reservation_trigger(): void {
		$target_link = apply_filters( 'maktomine/theme/reservation_url', home_url( '/#reservation' ) );
		?>
		<div class="mkt-header-element mkt-header-reservation">
			<a href="<?php echo esc_url( $target_link ); ?>" class="mkt-btn mkt-btn--sm mkt-btn--primary">
				<?php esc_html_e( 'Book Table', 'maktomine-restaurant-theme' ); ?>
			</a>
		</div>
		<?php
	}

	/**
	 * Render Accessible Mobile Menu Drawer.
	 *
	 * @return void
	 */
	protected function render_mobile_drawer(): void {
		?>
		<div id="mkt-mobile-menu-drawer" class="mkt-mobile-drawer" aria-hidden="true">
			<div class="mkt-mobile-drawer__overlay" id="mkt-mobile-drawer-backdrop" tabindex="-1"></div>
			<div class="mkt-mobile-drawer__dialog" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Mobile Navigation Drawer', 'maktomine-restaurant-theme' ); ?>">
				<div class="mkt-mobile-drawer__header">
					<span class="mkt-mobile-drawer__title"><?php esc_html_e( 'Navigation', 'maktomine-restaurant-theme' ); ?></span>
					<button type="button" class="mkt-mobile-drawer__close" id="mkt-mobile-close-btn" aria-label="<?php esc_attr_e( 'Close navigation menu', 'maktomine-restaurant-theme' ); ?>">
						<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
							<line x1="18" y1="6" x2="6" y2="18"></line>
							<line x1="6" y1="6" x2="18" y2="18"></line>
						</svg>
					</button>
				</div>
				<div class="mkt-mobile-drawer__content">
					<?php
					if ( has_nav_menu( 'mobile' ) ) {
						wp_nav_menu(
							[
								'theme_location' => 'mobile',
								'menu_class'     => 'mkt-menu mkt-menu--mobile',
								'container'      => false,
								'fallback_cb'    => false,
							]
						);
					} elseif ( has_nav_menu( 'primary' ) ) {
						wp_nav_menu(
							[
								'theme_location' => 'primary',
								'menu_class'     => 'mkt-menu mkt-menu--mobile',
								'container'      => false,
								'fallback_cb'    => false,
							]
						);
					}
					?>
					<div class="mkt-mobile-drawer__actions">
						<?php
						$this->element_phone();
						$this->element_whatsapp();
						?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Compute CSS classes for header container.
	 *
	 * @return string
	 */
	protected function get_header_classes(): string {
		$classes = [];
		if ( ThemeSettings::get( 'header.is_sticky', true ) ) {
			$classes[] = 'mkt-header--sticky';
		}
		return implode( ' ', $classes );
	}

	/**
	 * Structured Header Layout Configuration.
	 *
	 * Can be overridden by future Header Builder or filters.
	 *
	 * @return array<string, mixed>
	 */
	public function get_header_config(): array {
		$show_top = (bool) ThemeSettings::get( 'header.show_top_row', true );
		$show_bottom = (bool) ThemeSettings::get( 'header.show_bottom_row', false );

		$defaults = [
			'top'    => [
				'enabled' => $show_top,
				'left'    => [ 'opening_hours' ],
				'center'  => [ 'restaurant_notice' ],
				'right'   => [ 'phone', 'whatsapp' ],
			],
			'main'   => [
				'enabled' => true,
				'left'    => [ 'logo' ],
				'center'  => [ 'navigation' ],
				'right'   => [ 'search', 'cart_launcher', 'reservation_trigger', 'mobile_toggle' ],
			],
			'bottom' => [
				'enabled' => $show_bottom,
				'left'    => [],
				'center'  => [],
				'right'   => [],
			],
		];

		return apply_filters( 'maktomine/header/configuration', $defaults );
	}
}
