<?php
/**
 * Uninstallation Script for Maktomine Restaurant Core.
 *
 * Runs only when user clicks "Delete" in the WordPress Plugins administration screen.
 * Follows strict data preservation principles: Never removes restaurant orders, bookings,
 * menus, reviews, or business data unless explicit opt-in setting 'mkt_uninstall_wipe_data' is enabled.
 *
 * @package Maktomine\RestaurantCore
 */

declare(strict_types=1);

// Security guard: Exit immediately if called outside WordPress uninstall workflow.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Check if administrator has explicitly opted into complete data destruction.
$wipe_data_enabled = (bool) get_option( 'mkt_uninstall_wipe_data', false );

if ( ! $wipe_data_enabled ) {
	// Preserve all data safely for potential future re-installation.
	return;
}

global $wpdb;

// 1. Remove custom database tables.
$tables = [
	$wpdb->prefix . 'maktomine_idempotency_keys',
	$wpdb->prefix . 'maktomine_order_items',
	$wpdb->prefix . 'maktomine_orders',
	$wpdb->prefix . 'maktomine_bookings',
];

foreach ( $tables as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
}

// 2. Remove all CPT posts (food items, blocks, reviews, galleries).
$post_types = [ 'mkt_food_item', 'mkt_block', 'mkt_review', 'mkt_gallery' ];
foreach ( $post_types as $pt ) {
	$post_ids = get_posts( [
		'post_type'   => $pt,
		'post_status' => 'any',
		'numberposts' => -1,
		'fields'      => 'ids',
	] );

	foreach ( $post_ids as $pid ) {
		wp_delete_post( (int) $pid, true );
	}
}

// 3. Remove custom taxonomies terms.
$taxonomies = [ 'mkt_food_category', 'mkt_food_tag', 'mkt_gallery_category' ];
foreach ( $taxonomies as $tax ) {
	$terms = get_terms( [
		'taxonomy'   => $tax,
		'hide_empty' => false,
		'fields'     => 'ids',
	] );

	if ( is_array( $terms ) ) {
		foreach ( $terms as $term_id ) {
			wp_delete_term( (int) $term_id, $tax );
		}
	}
}

// 4. Remove plugin options.
delete_option( 'mkt_db_version' );
delete_option( 'mkt_business_info' );
delete_option( 'mkt_uninstall_wipe_data' );

// 5. Remove all registered capabilities cleanly.
$autoloader_path = plugin_dir_path( __FILE__ ) . 'includes/Autoloader.php';
if ( file_exists( $autoloader_path ) ) {
	require_once $autoloader_path;
	\Maktomine\RestaurantCore\Autoloader::register( 'Maktomine\\RestaurantCore\\', plugin_dir_path( __FILE__ ) . 'includes/' );
	if ( class_exists( '\Maktomine\RestaurantCore\Capabilities\CapabilityManager' ) ) {
		\Maktomine\RestaurantCore\Capabilities\CapabilityManager::remove_capabilities();
		return;
	}
}

// Fallback explicit capability cleanup if class file is absent.
$roles = [ 'administrator', 'editor' ];
$capabilities = [
	'edit_restaurant_food_items',
	'edit_others_restaurant_food_items',
	'publish_restaurant_food_items',
	'read_private_restaurant_food_items',
	'delete_restaurant_food_items',
	'delete_private_restaurant_food_items',
	'delete_published_restaurant_food_items',
	'delete_others_restaurant_food_items',
	'edit_private_restaurant_food_items',
	'edit_published_restaurant_food_items',
	'manage_restaurant_menu',
	'manage_restaurant_orders',
	'view_restaurant_orders',
	'manage_restaurant_bookings',
	'manage_restaurant_reviews',
	'manage_restaurant_gallery',
	'manage_restaurant_blocks',
	'manage_restaurant_settings',
];

foreach ( $roles as $role_slug ) {
	$role = get_role( $role_slug );
	if ( ! $role ) {
		continue;
	}
	foreach ( $capabilities as $cap ) {
		$role->remove_cap( $cap );
	}
}
