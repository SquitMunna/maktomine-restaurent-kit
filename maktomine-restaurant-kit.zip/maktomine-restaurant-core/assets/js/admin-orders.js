/**
 * Maktomine Restaurant Core - Admin Orders List & Detail Client
 *
 * Consumes the authoritative REST endpoints:
 * - Collection: GET /wp-json/maktomine/v1/admin/orders
 * - Detail:     GET /wp-json/maktomine/v1/admin/orders/{id}
 *
 * Provides accessible, responsive, server-paginated, filtered, sorted,
 * and historical snapshot order detail presentation without direct database
 * access, catalog price re-hydration, or client-side recalculation.
 *
 * @package Maktomine\RestaurantCore\Admin
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var config = window.mktAdminOrdersConfig || null;
		if (!config || !config.restUrl) {
			return;
		}

		// View Container References
		var listViewWrap    = document.getElementById('mkt-orders-list-view');
		var detailViewWrap  = document.getElementById('mkt-orders-detail-view');
		var announcements   = document.getElementById('mkt-orders-announcements');

		// List View Elements
		var filterForm      = document.getElementById('mkt-orders-filter-form');
		var statusSelect    = document.getElementById('mkt-filter-status');
		var typeSelect      = document.getElementById('mkt-filter-type');
		var dateFromInput   = document.getElementById('mkt-filter-date-from');
		var dateToInput     = document.getElementById('mkt-filter-date-to');
		var searchInput     = document.getElementById('mkt-filter-search');
		var clearButton     = document.getElementById('mkt-filter-clear');
		var perPageSelect   = document.getElementById('mkt-per-page-select');
		var tableTbody      = document.getElementById('mkt-orders-tbody');
		var countIndicator  = document.getElementById('mkt-orders-count-indicator');
		var listNoticeWrap  = document.getElementById('mkt-orders-notice-container');

		// List Pagination Elements
		var pageFirstBtn   = document.getElementById('mkt-page-first');
		var pagePrevBtn    = document.getElementById('mkt-page-prev');
		var pageNextBtn    = document.getElementById('mkt-page-next');
		var pageLastBtn    = document.getElementById('mkt-page-last');
		var currentPageEl  = document.getElementById('mkt-current-page-num');
		var totalPagesEl   = document.getElementById('mkt-total-pages-num');
		var totalItemsEl   = document.getElementById('mkt-pagination-total-items');

		// Detail View Elements
		var backToListBtn          = document.getElementById('mkt-back-to-list-btn');
		var detailTitle            = document.getElementById('mkt-detail-title');
		var detailStatusBadge      = document.getElementById('mkt-detail-status-badge');
		var detailTypeBadge        = document.getElementById('mkt-detail-type-badge');
		var detailNoticeWrap       = document.getElementById('mkt-detail-notice-wrap');
		var detailLoading          = document.getElementById('mkt-detail-loading');
		var detailContent          = document.getElementById('mkt-detail-content');
		var detailRef              = document.getElementById('mkt-detail-ref');
		var detailFulfillment      = document.getElementById('mkt-detail-fulfillment');
		var detailCreated          = document.getElementById('mkt-detail-created');
		var detailUpdated          = document.getElementById('mkt-detail-updated');
		var detailCustomerName     = document.getElementById('mkt-detail-customer-name');
		var detailCustomerPhone    = document.getElementById('mkt-detail-customer-phone');
		var detailDeliveryInfo     = document.getElementById('mkt-detail-delivery-info');
		var detailAddress          = document.getElementById('mkt-detail-address');
		var detailArea             = document.getElementById('mkt-detail-area');
		var detailAreaDt           = document.getElementById('mkt-detail-area-dt');
		var detailLandmark         = document.getElementById('mkt-detail-landmark');
		var detailLandmarkDt       = document.getElementById('mkt-detail-landmark-dt');
		var detailPickupInfo       = document.getElementById('mkt-detail-pickup-info');
		var detailItemsTbody       = document.getElementById('mkt-detail-items-tbody');
		var detailSubtotal         = document.getElementById('mkt-detail-subtotal');
		var detailDeliveryCharge   = document.getElementById('mkt-detail-delivery-charge');
		var detailTotal            = document.getElementById('mkt-detail-total');
		var detailNoteCard         = document.getElementById('mkt-detail-note-card');
		var detailOrderNote        = document.getElementById('mkt-detail-order-note');

		// Detail View Elements - Status Management
		var detailCardStatusBadge  = document.getElementById('mkt-detail-card-status-badge');
		var detailStatusSelect     = document.getElementById('mkt-detail-status-select');
		var updateStatusBtn        = document.getElementById('mkt-update-status-btn');
		var statusFeedbackEl       = document.getElementById('mkt-detail-status-feedback');

		// Query State Model
		var state = {
			currentView: 'list',
			currentOrderId: '',
			page: 1,
			perPage: parseInt(config.defaultPerPage, 10) || 20,
			status: '',
			type: '',
			dateFrom: '',
			dateTo: '',
			search: '',
			orderby: 'created_at',
			order: 'DESC',
			totalItems: 0,
			totalPages: 0,
			isLoading: false
		};

		var activeAbortController = null;
		var currentRequestSequence = 0;
		var listHasLoaded = false;
		var lastFocusedElement = null;
		var isMutatingStatus = false;
		var currentOrderSnapshot = null;

		/**
		 * Read initial query state from URL search parameters if available.
		 */
		function initQueryStateFromUrl() {
			var params = new URLSearchParams(window.location.search);

			if (params.has('order_id') && params.get('order_id').trim() !== '') {
				state.currentOrderId = params.get('order_id').trim();
				state.currentView = 'detail';
			} else if (config.initialOrderId && String(config.initialOrderId).trim() !== '') {
				state.currentOrderId = String(config.initialOrderId).trim();
				state.currentView = 'detail';
			}

			if (params.has('order_page')) {
				var p = parseInt(params.get('order_page'), 10);
				if (p >= 1) state.page = p;
			}
			if (params.has('order_per_page')) {
				var pp = parseInt(params.get('order_per_page'), 10);
				if (pp >= 1 && pp <= config.maxPerPage) state.perPage = pp;
			}
			if (params.has('order_status')) {
				state.status = (params.get('order_status') || '').trim();
			}
			if (params.has('order_type')) {
				state.type = (params.get('order_type') || '').trim();
			}
			if (params.has('order_date_from')) {
				state.dateFrom = (params.get('order_date_from') || '').trim();
			}
			if (params.has('order_date_to')) {
				state.dateTo = (params.get('order_date_to') || '').trim();
			}
			if (params.has('order_search')) {
				state.search = (params.get('order_search') || '').trim();
			}
			if (params.has('order_orderby')) {
				var ob = (params.get('order_orderby') || '').trim();
				if (['created_at', 'id', 'order_reference', 'order_status', 'total_amount'].indexOf(ob) !== -1) {
					state.orderby = ob;
				}
			}
			if (params.has('order_order')) {
				var dir = (params.get('order_order') || '').toUpperCase().trim();
				if (dir === 'ASC' || dir === 'DESC') {
					state.order = dir;
				}
			}

			// Synchronize form inputs with initial state
			if (statusSelect) statusSelect.value = state.status;
			if (typeSelect) typeSelect.value = state.type;
			if (dateFromInput) dateFromInput.value = state.dateFrom;
			if (dateToInput) dateToInput.value = state.dateTo;
			if (searchInput) searchInput.value = state.search;
			if (perPageSelect) perPageSelect.value = String(state.perPage);
		}

		/**
		 * Synchronize active query state to browser URL.
		 *
		 * @param {boolean} [shouldPush=false] Whether to create a new browser history entry.
		 */
		function syncUrlState(shouldPush) {
			if (!window.history || !window.history.replaceState) {
				return;
			}

			var url = new URL(window.location.href);

			if (state.currentView === 'detail' && state.currentOrderId) {
				url.searchParams.set('order_id', state.currentOrderId);
			} else {
				url.searchParams.delete('order_id');
			}

			if (state.page > 1) url.searchParams.set('order_page', String(state.page));
			else url.searchParams.delete('order_page');

			if (state.perPage !== 20) url.searchParams.set('order_per_page', String(state.perPage));
			else url.searchParams.delete('order_per_page');

			if (state.status) url.searchParams.set('order_status', state.status);
			else url.searchParams.delete('order_status');

			if (state.type) url.searchParams.set('order_type', state.type);
			else url.searchParams.delete('order_type');

			if (state.dateFrom) url.searchParams.set('order_date_from', state.dateFrom);
			else url.searchParams.delete('order_date_from');

			if (state.dateTo) url.searchParams.set('order_date_to', state.dateTo);
			else url.searchParams.delete('order_date_to');

			if (state.search) url.searchParams.set('order_search', state.search);
			else url.searchParams.delete('order_search');

			if (state.orderby !== 'created_at') url.searchParams.set('order_orderby', state.orderby);
			else url.searchParams.delete('order_orderby');

			if (state.order !== 'DESC') url.searchParams.set('order_order', state.order);
			else url.searchParams.delete('order_order');

			var historyPayload = { view: state.currentView, orderId: state.currentOrderId };
			if (shouldPush && window.history.pushState) {
				window.history.pushState(historyPayload, '', url.toString());
			} else {
				window.history.replaceState(historyPayload, '', url.toString());
			}
		}

		/**
		 * Announce message to screen readers via aria-live container.
		 *
		 * @param {string} msg Text message.
		 */
		function announceToScreenReader(msg) {
			if (announcements) {
				announcements.textContent = msg;
			}
		}

		/**
		 * Format currency total based on configured symbol & position without recalculation.
		 *
		 * @param {number|string} amount Numeric total from server.
		 * @param {string} currency Currency code.
		 * @return {string} Formatted price string.
		 */
		function formatPrice(amount, currency) {
			var symbol = config.currencySymbol || '$';
			var position = config.currencyPosition || 'left';

			if (amount === null || amount === undefined || amount === '') {
				amount = 0;
			}

			var num = parseFloat(amount);
			if (isNaN(num)) num = 0.00;
			var formattedNum = num.toFixed(2);

			switch (position) {
				case 'right':
					return formattedNum + symbol;
				case 'right_space':
					return formattedNum + ' ' + symbol;
				case 'left_space':
					return symbol + ' ' + formattedNum;
				case 'left':
				default:
					return symbol + formattedNum;
			}
		}

		/**
		 * Render list error notice.
		 *
		 * @param {string} message Error message.
		 * @param {boolean} showRetry Whether to show retry button.
		 */
		function showListError(message, showRetry) {
			if (!listNoticeWrap) return;
			listNoticeWrap.innerHTML = '';
			listNoticeWrap.style.display = 'flex';

			var textSpan = document.createElement('span');
			textSpan.textContent = message;
			listNoticeWrap.appendChild(textSpan);

			if (showRetry) {
				var retryBtn = document.createElement('button');
				retryBtn.type = 'button';
				retryBtn.className = 'button button-secondary';
				retryBtn.textContent = config.i18n.retry || 'Retry';
				retryBtn.addEventListener('click', function () {
					loadOrders();
				});
				listNoticeWrap.appendChild(retryBtn);
			}

			announceToScreenReader(message);
		}

		/**
		 * Clear active list notice banner.
		 */
		function clearListNotice() {
			if (listNoticeWrap) {
				listNoticeWrap.innerHTML = '';
				listNoticeWrap.style.display = 'none';
			}
		}

		/**
		 * Render detail error notice with retry and back to list actions.
		 *
		 * @param {string} message Error message.
		 * @param {boolean} showRetry Whether to show retry button.
		 */
		function showDetailError(message, showRetry) {
			if (!detailNoticeWrap) return;
			detailNoticeWrap.innerHTML = '';
			detailNoticeWrap.style.display = 'flex';

			var textSpan = document.createElement('span');
			textSpan.className = 'mkt-notice-text';
			textSpan.textContent = message;
			detailNoticeWrap.appendChild(textSpan);

			var btnGroup = document.createElement('div');
			btnGroup.className = 'mkt-notice-actions';

			if (showRetry) {
				var retryBtn = document.createElement('button');
				retryBtn.type = 'button';
				retryBtn.className = 'button button-secondary';
				retryBtn.textContent = config.i18n.retry || 'Retry';
				retryBtn.addEventListener('click', function () {
					loadOrderDetail(state.currentOrderId);
				});
				btnGroup.appendChild(retryBtn);
			}

			var backBtn = document.createElement('button');
			backBtn.type = 'button';
			backBtn.className = 'button button-link';
			backBtn.textContent = config.i18n.backToOrders || 'Back to Orders';
			backBtn.addEventListener('click', function () {
				showListView(true);
			});
			btnGroup.appendChild(backBtn);

			detailNoticeWrap.appendChild(btnGroup);
			announceToScreenReader(message);
		}

		/**
		 * Clear active detail notice banner.
		 */
		function clearDetailNotice() {
			if (detailNoticeWrap) {
				detailNoticeWrap.innerHTML = '';
				detailNoticeWrap.style.display = 'none';
			}
		}

		/**
		 * Render loading state table row for order collection list.
		 */
		function renderLoadingState() {
			if (!tableTbody) return;
			tableTbody.innerHTML = '';

			var tr = document.createElement('tr');
			tr.className = 'mkt-loading-row';

			var td = document.createElement('td');
			td.colSpan = 8;
			td.className = 'mkt-loading-cell';

			var spinner = document.createElement('div');
			spinner.className = 'mkt-loading-spinner';
			spinner.setAttribute('aria-hidden', 'true');

			var label = document.createElement('span');
			label.textContent = config.i18n.loading || 'Loading orders...';

			td.appendChild(spinner);
			td.appendChild(label);
			tr.appendChild(td);
			tableTbody.appendChild(tr);

			if (countIndicator) {
				countIndicator.textContent = config.i18n.loading || 'Loading orders...';
			}
		}

		/**
		 * Render empty state row for order collection list.
		 *
		 * @param {boolean} isFiltered Whether filters are active.
		 */
		function renderEmptyState(isFiltered) {
			if (!tableTbody) return;
			tableTbody.innerHTML = '';

			var tr = document.createElement('tr');
			tr.className = 'mkt-empty-row';

			var td = document.createElement('td');
			td.colSpan = 8;

			var wrapper = document.createElement('div');
			wrapper.className = 'mkt-empty-state-content';

			var title = document.createElement('h3');
			title.className = 'mkt-empty-title';
			title.textContent = isFiltered ? (config.i18n.noFilteredOrders || 'No orders match current filters.') : (config.i18n.noOrders || 'No orders found.');

			wrapper.appendChild(title);

			if (isFiltered) {
				var clearBtn = document.createElement('button');
				clearBtn.type = 'button';
				clearBtn.className = 'button button-secondary';
				clearBtn.textContent = config.i18n.clearFilters || 'Clear Filters';
				clearBtn.addEventListener('click', function () {
					resetFilters();
				});
				wrapper.appendChild(clearBtn);
			}

			td.appendChild(wrapper);
			tr.appendChild(td);
			tableTbody.appendChild(tr);

			announceToScreenReader(title.textContent);
		}

		/**
		 * Render order rows into the table body.
		 *
		 * @param {Array} items List of order summary items from REST endpoint.
		 */
		function renderOrderRows(items) {
			if (!tableTbody) return;
			tableTbody.innerHTML = '';

			items.forEach(function (order) {
				var tr = document.createElement('tr');
				tr.setAttribute('data-order-id', String(order.id || ''));

				// 1. Order Reference
				var tdOrder = document.createElement('td');
				tdOrder.className = 'column-order';
				var refSpan = document.createElement('span');
				refSpan.className = 'mkt-order-ref';
				refSpan.textContent = order.order_reference ? '#' + order.order_reference : (config.i18n.na || 'N/A');
				tdOrder.appendChild(refSpan);
				tr.appendChild(tdOrder);

				// 2. Customer
				var tdCustomer = document.createElement('td');
				tdCustomer.className = 'column-customer';
				var customerDiv = document.createElement('div');
				customerDiv.className = 'mkt-customer-info';
				var nameSpan = document.createElement('span');
				nameSpan.className = 'mkt-customer-name';
				nameSpan.textContent = order.customer_name || (config.i18n.na || 'N/A');
				var phoneSpan = document.createElement('span');
				phoneSpan.className = 'mkt-customer-phone';
				phoneSpan.textContent = order.customer_phone || '';
				customerDiv.appendChild(nameSpan);
				if (order.customer_phone) {
					customerDiv.appendChild(phoneSpan);
				}
				tdCustomer.appendChild(customerDiv);
				tr.appendChild(tdCustomer);

				// 3. Type
				var tdType = document.createElement('td');
				tdType.className = 'column-type';
				var typeSpan = document.createElement('span');
				var rawType = String(order.order_type || 'delivery').toLowerCase();
				typeSpan.className = 'mkt-badge-type mkt-type-' + rawType;
				typeSpan.textContent = (config.types && config.types[rawType]) ? config.types[rawType] : rawType;
				tdType.appendChild(typeSpan);
				tr.appendChild(tdType);

				// 4. Status
				var tdStatus = document.createElement('td');
				tdStatus.className = 'column-status';
				var statusSpan = document.createElement('span');
				var rawStatus = String(order.order_status || 'pending_whatsapp');
				statusSpan.className = 'mkt-badge-status mkt-status-' + rawStatus;
				statusSpan.textContent = (config.statuses && config.statuses[rawStatus]) ? config.statuses[rawStatus] : rawStatus;
				tdStatus.appendChild(statusSpan);
				tr.appendChild(tdStatus);

				// 5. Total
				var tdTotal = document.createElement('td');
				tdTotal.className = 'column-total';
				var totalSpan = document.createElement('span');
				totalSpan.className = 'mkt-total-amount';
				totalSpan.textContent = formatPrice(order.total_amount, order.currency);
				tdTotal.appendChild(totalSpan);
				tr.appendChild(tdTotal);

				// 6. Created
				var tdCreated = document.createElement('td');
				tdCreated.className = 'column-created mkt-date-cell';
				var createdTime = document.createElement('time');
				createdTime.dateTime = order.created_at || '';
				createdTime.textContent = order.created_at || (config.i18n.na || 'N/A');
				tdCreated.appendChild(createdTime);
				tr.appendChild(tdCreated);

				// 7. Updated
				var tdUpdated = document.createElement('td');
				tdUpdated.className = 'column-updated mkt-date-cell';
				var updatedTime = document.createElement('time');
				updatedTime.dateTime = order.updated_at || '';
				updatedTime.textContent = order.updated_at || (config.i18n.na || 'N/A');
				tdUpdated.appendChild(updatedTime);
				tr.appendChild(tdUpdated);

				// 8. Action (Interactive Read-Only View Button)
				var tdAction = document.createElement('td');
				tdAction.className = 'column-action';
				var viewBtn = document.createElement('button');
				viewBtn.type = 'button';
				viewBtn.className = 'button button-small mkt-action-view';
				viewBtn.textContent = config.i18n.view || 'View';
				viewBtn.setAttribute('data-order-id', String(order.id || ''));
				viewBtn.setAttribute('data-order-ref', String(order.order_reference || ''));
				var orderLabel = order.order_reference ? '#' + order.order_reference : '#' + (order.id || '');
				viewBtn.setAttribute('aria-label', (config.i18n.viewOrderAria || 'View details for order %s').replace('%s', orderLabel));
				viewBtn.title = config.i18n.viewDetailNotice || 'View full historical order details and item snapshot.';

				viewBtn.addEventListener('click', function (e) {
					e.preventDefault();
					var targetIdentifier = order.id ? String(order.id) : (order.order_reference || '');
					navigateToOrderDetail(targetIdentifier);
				});

				tdAction.appendChild(viewBtn);
				tr.appendChild(tdAction);
			});
		}

		/**
		 * Update pagination controls and header counter based on server metadata.
		 */
		function updatePagination() {
			var totalItems = state.totalItems;
			var totalPages = state.totalPages;
			var page = state.page;
			var perPage = state.perPage;

			if (totalItemsEl) {
				totalItemsEl.textContent = (config.i18n.itemsCount || '%s items').replace('%s', String(totalItems));
			}

			if (currentPageEl) currentPageEl.textContent = String(page);
			if (totalPagesEl) totalPagesEl.textContent = String(Math.max(1, totalPages));

			if (countIndicator) {
				if (totalItems === 0) {
					countIndicator.textContent = config.i18n.noOrders || '0 orders';
				} else {
					var from = (page - 1) * perPage + 1;
					var to = Math.min(page * perPage, totalItems);
					var countText = (config.i18n.showingCount || 'Showing %1$d–%2$d of %3$d orders')
						.replace('%1$d', String(from))
						.replace('%2$d', String(to))
						.replace('%3$d', String(totalItems));
					countIndicator.textContent = countText;
				}
			}

			// Update button disabled states
			if (pageFirstBtn) pageFirstBtn.disabled = (page <= 1);
			if (pagePrevBtn) pagePrevBtn.disabled = (page <= 1);
			if (pageNextBtn) pageNextBtn.disabled = (page >= totalPages || totalPages === 0);
			if (pageLastBtn) pageLastBtn.disabled = (page >= totalPages || totalPages === 0);
		}

		/**
		 * Update header sort indicators and aria-sort attributes.
		 */
		function updateSortHeaders() {
			var sortHeaders = document.querySelectorAll('th.column-sortable');
			sortHeaders.forEach(function (th) {
				var btn = th.querySelector('.mkt-sort-button');
				if (!btn) return;
				var field = btn.getAttribute('data-sort');

				th.classList.remove('sorted-asc', 'sorted-desc');
				if (field === state.orderby) {
					var sortAttr = (state.order === 'ASC') ? 'ascending' : 'descending';
					th.setAttribute('aria-sort', sortAttr);
					th.classList.add(state.order === 'ASC' ? 'sorted-asc' : 'sorted-desc');
					btn.setAttribute('aria-label', (config.i18n.sortBy || 'Sort by %s').replace('%s', field) + ' (' + sortAttr + ')');
				} else {
					th.setAttribute('aria-sort', 'none');
					btn.setAttribute('aria-label', (config.i18n.sortBy || 'Sort by %s').replace('%s', field));
				}
			});
		}

		/**
		 * Check whether any query filter is active.
		 *
		 * @return {boolean}
		 */
		function hasActiveFilters() {
			return Boolean(state.status || state.type || state.dateFrom || state.dateTo || state.search);
		}

		/**
		 * Switch UI presentation to list view.
		 *
		 * @param {boolean} [shouldPush=false] Whether to push history entry.
		 */
		function showListView(shouldPush) {
			state.currentView = 'list';
			state.currentOrderId = '';

			if (listViewWrap) listViewWrap.style.display = 'block';
			if (detailViewWrap) detailViewWrap.style.display = 'none';

			clearDetailNotice();
			syncUrlState(Boolean(shouldPush));
			announceToScreenReader('Returned to restaurant orders list.');

			if (!listHasLoaded) {
				updateSortHeaders();
				loadOrders();
			}

			// Restore focus to trigger element for accessibility
			if (lastFocusedElement && typeof lastFocusedElement.focus === 'function' && document.body.contains(lastFocusedElement)) {
				lastFocusedElement.focus();
				lastFocusedElement = null;
			}
		}

		/**
		 * Switch UI presentation to detail view.
		 *
		 * @param {boolean} [shouldPush=false] Whether to push history entry.
		 */
		function showDetailView(shouldPush) {
			state.currentView = 'detail';

			if (listViewWrap) listViewWrap.style.display = 'none';
			if (detailViewWrap) detailViewWrap.style.display = 'block';

			clearListNotice();
			syncUrlState(Boolean(shouldPush));
		}

		/**
		 * Navigate to order detail view and trigger REST fetch.
		 *
		 * @param {string} orderIdentifier Numeric ID or order reference string.
		 */
		function navigateToOrderDetail(orderIdentifier) {
			if (!orderIdentifier) return;
			lastFocusedElement = document.activeElement;
			state.currentOrderId = String(orderIdentifier);
			showDetailView(true);
			loadOrderDetail(orderIdentifier);
		}

		/**
		 * Fetch orders from server REST endpoint with sequence checking and cancellation.
		 */
		function loadOrders() {
			if (activeAbortController) {
				activeAbortController.abort();
			}

			activeAbortController = new AbortController();
			var signal = activeAbortController.signal;
			var sequence = ++currentRequestSequence;

			clearListNotice();
			renderLoadingState();
			state.isLoading = true;

			// Construct REST query URL with strictly whitelisted parameters
			var queryUrl = new URL(config.restUrl, window.location.origin);
			queryUrl.searchParams.set('page', String(state.page));
			queryUrl.searchParams.set('per_page', String(state.perPage));
			if (state.status) queryUrl.searchParams.set('status', state.status);
			if (state.type) queryUrl.searchParams.set('type', state.type);
			if (state.dateFrom) queryUrl.searchParams.set('date_from', state.dateFrom);
			if (state.dateTo) queryUrl.searchParams.set('date_to', state.dateTo);
			if (state.search) queryUrl.searchParams.set('search', state.search);
			queryUrl.searchParams.set('orderby', state.orderby);
			queryUrl.searchParams.set('order', state.order);

			fetch(queryUrl.toString(), {
				method: 'GET',
				headers: {
					'X-WP-Nonce': config.nonce || '',
					'Accept': 'application/json'
				},
				signal: signal
			})
			.then(function (res) {
				if (sequence !== currentRequestSequence) return null;

				if (!res.ok) {
					if (res.status === 401 || res.status === 403) {
						throw new Error(config.i18n.errorUnauthorized || 'Permission denied.');
					}
					if (res.status === 400) {
						throw new Error(config.i18n.errorInvalidParams || 'Invalid query parameters.');
					}
					if (res.status >= 500) {
						throw new Error(config.i18n.errorServer || 'Server error.');
					}
					throw new Error(config.i18n.errorNetwork || 'Network error.');
				}

				return res.json();
			})
			.then(function (payload) {
				if (sequence !== currentRequestSequence || !payload) return;

				// Response contract validation
				if (!payload || typeof payload !== 'object' || payload.success !== true || !payload.data) {
					throw new Error(config.i18n.errorMalformed || 'Malformed server response.');
				}

				var data = payload.data;
				var items = Array.isArray(data.items) ? data.items : [];
				state.totalItems = typeof data.total_items === 'number' ? data.total_items : items.length;
				state.totalPages = typeof data.total_pages === 'number' ? data.total_pages : 0;
				state.page = typeof data.current_page === 'number' ? data.current_page : state.page;
				state.perPage = typeof data.per_page === 'number' ? data.per_page : state.perPage;

				if (items.length === 0) {
					renderEmptyState(hasActiveFilters());
				} else {
					renderOrderRows(items);
					announceToScreenReader(
						(config.i18n.itemsCount || '%s items').replace('%s', String(state.totalItems)) + ' loaded.'
					);
				}

				listHasLoaded = true;
				updatePagination();
				updateSortHeaders();
				syncUrlState(false);
			})
			.catch(function (err) {
				if (err.name === 'AbortError' || sequence !== currentRequestSequence) {
					return;
				}
				if (tableTbody) tableTbody.innerHTML = '';
				showListError(err.message || config.i18n.errorNetwork || 'Request failed.', true);
			})
			.finally(function () {
				if (sequence === currentRequestSequence) {
					state.isLoading = false;
				}
			});
		}

		/**
		 * Fetch single order details from the authoritative REST endpoint.
		 *
		 * @param {string} identifier Order database ID or reference string.
		 */
		function loadOrderDetail(identifier) {
			if (!identifier) return;

			if (activeAbortController) {
				activeAbortController.abort();
			}

			activeAbortController = new AbortController();
			var signal = activeAbortController.signal;
			var sequence = ++currentRequestSequence;

			clearDetailNotice();

			// Reset stale state from previous order before loading
			if (detailTitle) {
				detailTitle.textContent = config.i18n.loadingDetail || 'Loading order details...';
			}
			if (detailStatusBadge) {
				detailStatusBadge.className = 'mkt-badge-status';
				detailStatusBadge.textContent = '';
				detailStatusBadge.removeAttribute('aria-label');
			}
			if (detailTypeBadge) {
				detailTypeBadge.className = 'mkt-badge-type';
				detailTypeBadge.textContent = '';
				detailTypeBadge.removeAttribute('aria-label');
			}
			if (detailCardStatusBadge) {
				detailCardStatusBadge.className = 'mkt-badge-status';
				detailCardStatusBadge.textContent = '';
				detailCardStatusBadge.removeAttribute('aria-label');
			}
			if (statusFeedbackEl) {
				statusFeedbackEl.style.display = 'none';
				statusFeedbackEl.textContent = '';
				statusFeedbackEl.className = 'mkt-detail-status-feedback';
			}
			if (updateStatusBtn) {
				updateStatusBtn.disabled = false;
				updateStatusBtn.textContent = config.i18n.updateStatus || 'Update Status';
				updateStatusBtn.removeAttribute('aria-busy');
			}
			if (detailStatusSelect) {
				detailStatusSelect.disabled = false;
			}
			isMutatingStatus = false;
			currentOrderSnapshot = null;

			if (detailLoading) detailLoading.style.display = 'flex';
			if (detailContent) detailContent.style.display = 'none';

			var detailUrl = new URL(config.restUrl + '/' + encodeURIComponent(identifier), window.location.origin);

			fetch(detailUrl.toString(), {
				method: 'GET',
				headers: {
					'X-WP-Nonce': config.nonce || '',
					'Accept': 'application/json'
				},
				signal: signal
			})
			.then(function (res) {
				if (sequence !== currentRequestSequence) return null;

				if (!res.ok) {
					if (res.status === 404) {
						throw new Error(config.i18n.orderNotFound || 'Order not found.');
					}
					if (res.status === 401 || res.status === 403) {
						throw new Error(config.i18n.errorUnauthorized || 'Permission denied.');
					}
					if (res.status === 400) {
						throw new Error(config.i18n.errorInvalidParams || 'Invalid order identifier.');
					}
					if (res.status >= 500) {
						throw new Error(config.i18n.errorServer || 'Server error occurred while retrieving order.');
					}
					throw new Error(config.i18n.errorNetwork || 'Network error.');
				}

				return res.json();
			})
			.then(function (payload) {
				if (sequence !== currentRequestSequence || !payload) return;

				if (!payload || typeof payload !== 'object' || payload.success !== true || !payload.data) {
					throw new Error(config.i18n.errorMalformed || 'Malformed server response.');
				}

				renderOrderDetail(payload.data);

				// Move focus to back button for keyboard & screen reader accessibility
				if (backToListBtn && typeof backToListBtn.focus === 'function') {
					backToListBtn.focus();
				}
			})
			.catch(function (err) {
				if (err.name === 'AbortError' || sequence !== currentRequestSequence) {
					return;
				}
				if (detailLoading) detailLoading.style.display = 'none';
				if (detailContent) detailContent.style.display = 'none';
				if (detailTitle) {
					detailTitle.textContent = config.i18n.orderTitle ? config.i18n.orderTitle.replace('%s', identifier) : 'Order #' + identifier;
				}
				showDetailError(err.message || config.i18n.errorNetwork || 'Request failed.', true);
			});
		}

		/**
		 * Render single order detail presentation into the detail view shell.
		 *
		 * @param {Object} order Detailed order object from REST response.
		 */
		function renderOrderDetail(order) {
			if (!order) return;

			currentOrderSnapshot = order;

			var cleanRef = (order.order_reference && String(order.order_reference).trim() !== '') ? String(order.order_reference).trim() : '';
			var cleanId = (order.id !== null && order.id !== undefined && String(order.id).trim() !== '') ? String(order.id).trim() : '';
			var orderRef = cleanRef ? '#' + cleanRef : (cleanId ? '#' + cleanId : (config.i18n.na || 'N/A'));
			var displayRef = cleanRef || cleanId || (config.i18n.na || 'N/A');

			var rawStatus = (order.order_status && typeof order.order_status === 'string') ? order.order_status.trim() : '';
			var statusLabel = rawStatus ? ((config.statuses && config.statuses[rawStatus]) ? config.statuses[rawStatus] : rawStatus) : (config.i18n.na || 'N/A');

			var rawType = (order.order_type && typeof order.order_type === 'string') ? order.order_type.trim().toLowerCase() : '';
			var typeLabel = rawType ? ((config.types && config.types[rawType]) ? config.types[rawType] : rawType) : (config.i18n.na || 'N/A');

			// Header Bar
			if (detailTitle) {
				detailTitle.textContent = (config.i18n.orderTitle || 'Order #%s').replace('%s', displayRef);
			}
			if (detailStatusBadge) {
				detailStatusBadge.className = 'mkt-badge-status' + (rawStatus ? ' mkt-status-' + rawStatus.toLowerCase().replace(/[^a-z0-9_-]/g, '_') : '');
				detailStatusBadge.textContent = statusLabel;
				detailStatusBadge.setAttribute('aria-label', (config.i18n.statusLabel || 'Status: %s').replace('%s', statusLabel));
			}
			if (detailTypeBadge) {
				detailTypeBadge.className = 'mkt-badge-type' + (rawType ? ' mkt-type-' + rawType.replace(/[^a-z0-9_-]/g, '_') : '');
				detailTypeBadge.textContent = typeLabel;
				detailTypeBadge.setAttribute('aria-label', (config.i18n.typeLabel || 'Fulfillment: %s').replace('%s', typeLabel));
			}

			// Status Management Card
			if (detailCardStatusBadge) {
				detailCardStatusBadge.className = 'mkt-badge-status' + (rawStatus ? ' mkt-status-' + rawStatus.toLowerCase().replace(/[^a-z0-9_-]/g, '_') : '');
				detailCardStatusBadge.textContent = statusLabel;
				detailCardStatusBadge.setAttribute('aria-label', (config.i18n.statusLabel || 'Status: %s').replace('%s', statusLabel));
			}
			populateDetailStatusOptions(rawStatus);

			// Overview Card
			if (detailRef) detailRef.textContent = orderRef;
			if (detailFulfillment) detailFulfillment.textContent = typeLabel;

			if (detailCreated) {
				detailCreated.innerHTML = '';
				var createdStr = (order.created_at && typeof order.created_at === 'string') ? order.created_at.trim() : '';
				if (createdStr !== '') {
					var createdTimeEl = document.createElement('time');
					createdTimeEl.dateTime = createdStr;
					createdTimeEl.textContent = createdStr;
					detailCreated.appendChild(createdTimeEl);
				} else {
					detailCreated.textContent = config.i18n.na || 'N/A';
				}
			}

			if (detailUpdated) {
				detailUpdated.innerHTML = '';
				var updatedStr = (order.updated_at && typeof order.updated_at === 'string') ? order.updated_at.trim() : '';
				if (updatedStr !== '') {
					var updatedTimeEl = document.createElement('time');
					updatedTimeEl.dateTime = updatedStr;
					updatedTimeEl.textContent = updatedStr;
					detailUpdated.appendChild(updatedTimeEl);
				} else {
					detailUpdated.textContent = config.i18n.na || 'N/A';
				}
			}

			// Customer Card
			if (detailCustomerName) {
				var custName = (order.customer_name && typeof order.customer_name === 'string') ? order.customer_name.trim() : '';
				detailCustomerName.textContent = custName !== '' ? custName : (config.i18n.na || 'N/A');
			}

			if (detailCustomerPhone) {
				detailCustomerPhone.innerHTML = '';
				var rawPhone = (order.customer_phone && typeof order.customer_phone === 'string') ? order.customer_phone.trim() : '';
				if (rawPhone !== '') {
					var telDigits = rawPhone.replace(/[^0-9+]/g, '');
					if (telDigits !== '' && telDigits !== '+') {
						var phoneLink = document.createElement('a');
						phoneLink.href = 'tel:' + telDigits;
						phoneLink.className = 'mkt-phone-link';
						phoneLink.textContent = rawPhone;
						phoneLink.title = 'Call ' + rawPhone;
						detailCustomerPhone.appendChild(phoneLink);
					} else {
						detailCustomerPhone.textContent = rawPhone;
					}
				} else {
					detailCustomerPhone.textContent = config.i18n.na || 'N/A';
				}
			}

			// Fulfillment Card
			if (rawType === 'pickup') {
				if (detailDeliveryInfo) detailDeliveryInfo.style.display = 'none';
				if (detailPickupInfo) detailPickupInfo.style.display = 'block';
			} else {
				if (detailPickupInfo) detailPickupInfo.style.display = 'none';
				if (detailDeliveryInfo) detailDeliveryInfo.style.display = 'block';

				if (detailAddress) {
					var addrStr = (order.delivery_address && typeof order.delivery_address === 'string') ? order.delivery_address.trim() : '';
					detailAddress.textContent = addrStr !== '' ? addrStr : (config.i18n.na || 'N/A');
				}

				if (order.delivery_area && order.delivery_area.trim() !== '') {
					if (detailAreaDt) detailAreaDt.style.display = '';
					if (detailArea) {
						detailArea.style.display = '';
						detailArea.textContent = order.delivery_area;
					}
				} else {
					if (detailAreaDt) detailAreaDt.style.display = 'none';
					if (detailArea) detailArea.style.display = 'none';
				}

				if (order.delivery_landmark && order.delivery_landmark.trim() !== '') {
					if (detailLandmarkDt) detailLandmarkDt.style.display = '';
					if (detailLandmark) {
						detailLandmark.style.display = '';
						detailLandmark.textContent = order.delivery_landmark;
					}
				} else {
					if (detailLandmarkDt) detailLandmarkDt.style.display = 'none';
					if (detailLandmark) detailLandmark.style.display = 'none';
				}
			}

			// Customer Order Note
			if (order.order_note && order.order_note.trim() !== '') {
				if (detailNoteCard) detailNoteCard.style.display = 'block';
				if (detailOrderNote) detailOrderNote.textContent = order.order_note;
			} else {
				if (detailNoteCard) detailNoteCard.style.display = 'none';
			}

			// Order Items Table
			if (detailItemsTbody) {
				detailItemsTbody.innerHTML = '';
				var items = Array.isArray(order.items) ? order.items : [];

				if (items.length === 0) {
					var trEmpty = document.createElement('tr');
					var tdEmpty = document.createElement('td');
					tdEmpty.colSpan = 4;
					tdEmpty.className = 'mkt-detail-empty-items';
					tdEmpty.textContent = config.i18n.noItems || 'No items recorded for this order.';
					trEmpty.appendChild(tdEmpty);
					detailItemsTbody.appendChild(trEmpty);
				} else {
					items.forEach(function (item) {
						var tr = document.createElement('tr');

						// Column 1: Description
						var tdItem = document.createElement('td');
						var titleSpan = document.createElement('span');
						titleSpan.className = 'mkt-item-title';
						titleSpan.textContent = item.item_name || (config.i18n.na || 'Item');
						tdItem.appendChild(titleSpan);

						var metaDiv = document.createElement('div');
						metaDiv.className = 'mkt-item-meta';

						// Variation summary check
						if (item.variation_summary && typeof item.variation_summary === 'string' && item.variation_summary.trim() !== '') {
							var varSpan = document.createElement('span');
							varSpan.className = 'mkt-item-variation';
							varSpan.textContent = item.variation_summary;
							metaDiv.appendChild(varSpan);
						}

						// Add-ons summary check
						if (item.addons_summary && typeof item.addons_summary === 'string' && item.addons_summary.trim() !== '') {
							var addonSpan = document.createElement('span');
							addonSpan.className = 'mkt-item-addons';
							addonSpan.textContent = item.addons_summary;
							metaDiv.appendChild(addonSpan);
						}

						if (metaDiv.childNodes.length > 0) {
							tdItem.appendChild(metaDiv);
						}
						tr.appendChild(tdItem);

						// Column 2: Quantity (preserves historical zero, converts NaN to 0)
						var tdQty = document.createElement('td');
						tdQty.className = 'mkt-col-qty';
						var rawQty = parseInt(item.quantity, 10);
						var safeQty = !isNaN(rawQty) ? rawQty : 0;
						tdQty.textContent = String(safeQty);
						tr.appendChild(tdQty);

						// Column 3: Unit Price
						var tdUnitPrice = document.createElement('td');
						tdUnitPrice.className = 'mkt-col-price';
						tdUnitPrice.textContent = formatPrice(item.unit_price, order.currency);
						tr.appendChild(tdUnitPrice);

						// Column 4: Line Total
						var tdLineTotal = document.createElement('td');
						tdLineTotal.className = 'mkt-col-total';
						tdLineTotal.textContent = formatPrice(item.line_total, order.currency);
						tr.appendChild(tdLineTotal);

						detailItemsTbody.appendChild(tr);
					});
				}
			}

			// Financial Summary (Strictly persisted server figures)
			if (detailSubtotal) detailSubtotal.textContent = formatPrice(order.subtotal, order.currency);
			if (detailDeliveryCharge) detailDeliveryCharge.textContent = formatPrice(order.delivery_charge, order.currency);
			if (detailTotal) detailTotal.textContent = formatPrice(order.total_amount, order.currency);

			// Reveal content
			if (detailLoading) detailLoading.style.display = 'none';
			if (detailContent) detailContent.style.display = 'grid';

			announceToScreenReader('Order ' + orderRef + ' details loaded.');
		}

		/**
		 * Populate status select dropdown options with authoritative labels.
		 *
		 * @param {string} currentStatus Currently active order status.
		 */
		function populateDetailStatusOptions(currentStatus) {
			if (!detailStatusSelect) return;
			detailStatusSelect.innerHTML = '';

			var statuses = config.statuses || {};
			var statusKeys = Object.keys(statuses);
			if (statusKeys.length === 0) {
				statusKeys = ['pending_whatsapp', 'confirmed', 'preparing', 'ready', 'completed', 'cancelled'];
			}

			// If current status is unrecognized/future status, insert it as an option safely
			if (currentStatus && statusKeys.indexOf(currentStatus) === -1) {
				var customOpt = document.createElement('option');
				customOpt.value = currentStatus;
				customOpt.textContent = currentStatus;
				detailStatusSelect.appendChild(customOpt);
			}

			statusKeys.forEach(function (key) {
				var opt = document.createElement('option');
				opt.value = key;
				opt.textContent = statuses[key] || key;
				if (key === currentStatus) {
					opt.selected = true;
				}
				detailStatusSelect.appendChild(opt);
			});

			detailStatusSelect.value = currentStatus || '';
		}

		/**
		 * Display status mutation feedback message (success or error).
		 *
		 * @param {string} message Text message to display.
		 * @param {string} type 'success' or 'error'.
		 * @param {boolean} [allowRefresh=false] Whether to provide a reload action button on conflicts.
		 */
		function showStatusFeedback(message, type, allowRefresh) {
			if (!statusFeedbackEl) return;
			statusFeedbackEl.innerHTML = '';

			var textSpan = document.createElement('span');
			textSpan.textContent = message;
			statusFeedbackEl.appendChild(textSpan);

			if (allowRefresh && state.currentOrderId) {
				var refreshBtn = document.createElement('button');
				refreshBtn.type = 'button';
				refreshBtn.className = 'button button-secondary mkt-status-refresh-btn';
				refreshBtn.textContent = config.i18n.retry || 'Refresh';
				refreshBtn.style.marginLeft = '10px';
				refreshBtn.addEventListener('click', function () {
					loadOrderDetail(state.currentOrderId);
				});
				statusFeedbackEl.appendChild(refreshBtn);
			}

			statusFeedbackEl.className = 'mkt-detail-status-feedback mkt-feedback-' + (type === 'success' ? 'success' : 'error');
			statusFeedbackEl.style.display = 'block';
		}

		/**
		 * Synchronize status update to cached list table row if rendered in DOM.
		 *
		 * @param {number|string} orderId Database order ID.
		 * @param {string} newStatus New persisted order status.
		 */
		function updateCachedListOrder(orderId, newStatus) {
			if (!orderId || !tableTbody) return;
			var row = tableTbody.querySelector('tr[data-order-id="' + orderId + '"]');
			if (!row) return;

			var statusSpan = row.querySelector('.column-status .mkt-badge-status');
			if (statusSpan) {
				var statusLabel = (config.statuses && config.statuses[newStatus]) ? config.statuses[newStatus] : newStatus;
				var sanitized = newStatus ? newStatus.toLowerCase().replace(/[^a-z0-9_-]/g, '_') : '';
				statusSpan.className = 'mkt-badge-status mkt-status-' + sanitized;
				statusSpan.textContent = statusLabel;
			}
		}

		/**
		 * Handle administrative order status transition submission via PATCH.
		 */
		function handleStatusUpdate() {
			if (isMutatingStatus) return;
			if (!currentOrderSnapshot) return;
			if (!detailStatusSelect) return;

			var targetStatus = detailStatusSelect.value ? detailStatusSelect.value.trim() : '';
			if (!targetStatus) return;

			var currentStatus = (currentOrderSnapshot.order_status || '').trim();

			// Clear previous feedback
			if (statusFeedbackEl) {
				statusFeedbackEl.style.display = 'none';
				statusFeedbackEl.textContent = '';
				statusFeedbackEl.className = 'mkt-detail-status-feedback';
			}

			// Determine authoritative order identifier
			var orderIdentifier = '';
			if (currentOrderSnapshot.id !== null && currentOrderSnapshot.id !== undefined && String(currentOrderSnapshot.id).trim() !== '') {
				orderIdentifier = String(currentOrderSnapshot.id).trim();
			} else if (currentOrderSnapshot.order_reference && String(currentOrderSnapshot.order_reference).trim() !== '') {
				orderIdentifier = String(currentOrderSnapshot.order_reference).trim();
			} else if (state.currentOrderId) {
				orderIdentifier = state.currentOrderId;
			}

			if (!orderIdentifier) {
				showStatusFeedback(config.i18n.errorInvalidParams || 'Missing order identifier.', 'error', false);
				return;
			}

			// Single-flight protection: lock controls
			isMutatingStatus = true;
			detailStatusSelect.disabled = true;
			if (updateStatusBtn) {
				updateStatusBtn.disabled = true;
				updateStatusBtn.textContent = config.i18n.updatingStatus || 'Updating status...';
				updateStatusBtn.setAttribute('aria-busy', 'true');
			}

			var mutationUrl = new URL(config.restUrl + '/' + encodeURIComponent(orderIdentifier) + '/status', window.location.origin);

			fetch(mutationUrl.toString(), {
				method: 'PATCH',
				headers: {
					'X-WP-Nonce': config.nonce || '',
					'Content-Type': 'application/json',
					'Accept': 'application/json'
				},
				body: JSON.stringify({
					new_status: targetStatus
				})
			})
			.then(function (res) {
				return res.json().then(function (payload) {
					return { ok: res.ok, status: res.status, payload: payload };
				}).catch(function () {
					return { ok: res.ok, status: res.status, payload: null };
				});
			})
			.then(function (result) {
				isMutatingStatus = false;
				if (detailStatusSelect) detailStatusSelect.disabled = false;
				if (updateStatusBtn) {
					updateStatusBtn.disabled = false;
					updateStatusBtn.textContent = config.i18n.updateStatus || 'Update Status';
					updateStatusBtn.removeAttribute('aria-busy');
				}

				if (!result.ok || !result.payload || result.payload.success !== true) {
					var errMsg = '';
					if (result.status === 400) {
						errMsg = (result.payload && result.payload.message) ? result.payload.message : (config.i18n.statusUpdateFailed || 'Unable to update the order status. Please choose a valid status.');
					} else if (result.status === 401 || result.status === 403) {
						errMsg = config.i18n.statusForbidden || 'You do not have permission to update order status.';
					} else if (result.status === 404) {
						errMsg = config.i18n.orderNotFound || 'Order not found.';
					} else if (result.status === 409) {
						errMsg = config.i18n.statusConflict || 'The order status could not be updated because the order changed. Refresh the order and try again.';
					} else if (result.status >= 500) {
						errMsg = config.i18n.errorServer || 'Server error occurred while updating order status.';
					} else {
						errMsg = (result.payload && result.payload.message) ? result.payload.message : (config.i18n.statusUpdateFailed || 'Unable to update order status.');
					}

					// Stale / concurrent update safety: reset select back to persisted current status
					if (detailStatusSelect) {
						detailStatusSelect.value = currentStatus;
					}

					showStatusFeedback(errMsg, 'error', result.status === 409);
					announceToScreenReader(errMsg);
					return;
				}

				// Success handling: use authoritative server-returned order_status
				var updatedData = result.payload.data;
				var persistedStatus = (updatedData && updatedData.order_status) ? String(updatedData.order_status).trim() : targetStatus;
				currentOrderSnapshot.order_status = persistedStatus;

				var statusLabel = (config.statuses && config.statuses[persistedStatus]) ? config.statuses[persistedStatus] : persistedStatus;
				var sanitizedClass = persistedStatus ? persistedStatus.toLowerCase().replace(/[^a-z0-9_-]/g, '_') : '';

				// Update header status badge
				if (detailStatusBadge) {
					detailStatusBadge.className = 'mkt-badge-status' + (sanitizedClass ? ' mkt-status-' + sanitizedClass : '');
					detailStatusBadge.textContent = statusLabel;
					detailStatusBadge.setAttribute('aria-label', (config.i18n.statusLabel || 'Status: %s').replace('%s', statusLabel));
				}

				// Update card status badge
				if (detailCardStatusBadge) {
					detailCardStatusBadge.className = 'mkt-badge-status' + (sanitizedClass ? ' mkt-status-' + sanitizedClass : '');
					detailCardStatusBadge.textContent = statusLabel;
					detailCardStatusBadge.setAttribute('aria-label', (config.i18n.statusLabel || 'Status: %s').replace('%s', statusLabel));
				}

				// Update select value
				if (detailStatusSelect) {
					detailStatusSelect.value = persistedStatus;
				}

				// Update cached order in list view if present
				updateCachedListOrder(currentOrderSnapshot.id, persistedStatus);

				var successMsg = (config.i18n.statusUpdated || 'Order status updated successfully to %s.').replace('%s', statusLabel);
				showStatusFeedback(successMsg, 'success', false);
				announceToScreenReader(successMsg);
			})
			.catch(function (err) {
				isMutatingStatus = false;
				if (detailStatusSelect) {
					detailStatusSelect.disabled = false;
					detailStatusSelect.value = currentStatus;
				}
				if (updateStatusBtn) {
					updateStatusBtn.disabled = false;
					updateStatusBtn.textContent = config.i18n.updateStatus || 'Update Status';
					updateStatusBtn.removeAttribute('aria-busy');
				}

				var networkMsg = config.i18n.errorNetwork || 'Network error occurred while updating status.';
				showStatusFeedback(networkMsg, 'error', false);
				announceToScreenReader(networkMsg);
			});
		}

		/**
		 * Reset all filters to default state.
		 */
		function resetFilters() {
			state.status = '';
			state.type = '';
			state.dateFrom = '';
			state.dateTo = '';
			state.search = '';
			state.page = 1;

			if (statusSelect) statusSelect.value = '';
			if (typeSelect) typeSelect.value = '';
			if (dateFromInput) dateFromInput.value = '';
			if (dateToInput) dateToInput.value = '';
			if (searchInput) searchInput.value = '';

			loadOrders();
		}

		// Event Listener: Filter Form Submission
		if (filterForm) {
			filterForm.addEventListener('submit', function (evt) {
				evt.preventDefault();
				state.status = statusSelect ? statusSelect.value.trim() : '';
				state.type = typeSelect ? typeSelect.value.trim() : '';
				state.dateFrom = dateFromInput ? dateFromInput.value.trim() : '';
				state.dateTo = dateToInput ? dateToInput.value.trim() : '';
				state.search = searchInput ? searchInput.value.trim() : '';
				state.page = 1;

				loadOrders();
			});
		}

		// Event Listener: Clear Filters Button
		if (clearButton) {
			clearButton.addEventListener('click', function () {
				resetFilters();
			});
		}

		// Event Listener: Per Page Select
		if (perPageSelect) {
			perPageSelect.addEventListener('change', function () {
				var val = parseInt(perPageSelect.value, 10);
				if (val >= 1 && val <= config.maxPerPage) {
					state.perPage = val;
					state.page = 1;
					loadOrders();
				}
			});
		}

		// Event Listener: Sorting Buttons in Table Header
		document.querySelectorAll('th.column-sortable .mkt-sort-button').forEach(function (button) {
			button.addEventListener('click', function () {
				var field = button.getAttribute('data-sort');
				if (!field) return;

				if (state.orderby === field) {
					// Toggle direction
					state.order = (state.order === 'ASC') ? 'DESC' : 'ASC';
				} else {
					state.orderby = field;
					state.order = 'DESC';
				}

				state.page = 1;
				loadOrders();
			});
		});

		// Event Listeners: Pagination Buttons
		if (pageFirstBtn) {
			pageFirstBtn.addEventListener('click', function () {
				if (state.page > 1) {
					state.page = 1;
					loadOrders();
				}
			});
		}

		if (pagePrevBtn) {
			pagePrevBtn.addEventListener('click', function () {
				if (state.page > 1) {
					state.page = state.page - 1;
					loadOrders();
				}
			});
		}

		if (pageNextBtn) {
			pageNextBtn.addEventListener('click', function () {
				if (state.page < state.totalPages) {
					state.page = state.page + 1;
					loadOrders();
				}
			});
		}

		if (pageLastBtn) {
			pageLastBtn.addEventListener('click', function () {
				if (state.page < state.totalPages) {
					state.page = state.totalPages;
					loadOrders();
				}
			});
		}

		// Event Listener: Back to Orders Button
		if (backToListBtn) {
			backToListBtn.addEventListener('click', function (e) {
				e.preventDefault();
				showListView(true);
			});
		}

		// Event Listener: Update Order Status Button
		if (updateStatusBtn) {
			updateStatusBtn.addEventListener('click', function (e) {
				e.preventDefault();
				handleStatusUpdate();
			});
		}

		if (detailStatusSelect) {
			detailStatusSelect.addEventListener('keydown', function (e) {
				if (e.key === 'Enter') {
					e.preventDefault();
					handleStatusUpdate();
				}
			});
		}

		// Event Listener: Popstate Browser Back/Forward Navigation
		window.addEventListener('popstate', function () {
			var params = new URLSearchParams(window.location.search);
			if (params.has('order_id') && params.get('order_id').trim() !== '') {
				var targetId = params.get('order_id').trim();
				state.currentOrderId = targetId;
				showDetailView(false);
				loadOrderDetail(targetId);
			} else {
				showListView(false);
			}
		});

		// Initial Execution Routing
		initQueryStateFromUrl();

		if (state.currentView === 'detail' && state.currentOrderId) {
			showDetailView(false);
			loadOrderDetail(state.currentOrderId);
		} else {
			showListView(false);
			updateSortHeaders();
			loadOrders();
		}
	});
})();
