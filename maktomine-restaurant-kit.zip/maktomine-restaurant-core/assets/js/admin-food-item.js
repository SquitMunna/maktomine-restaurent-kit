/**
 * Maktomine Restaurant Core - Food Item Admin JS
 * Handles WordPress Media Library integration, attributes, variations, and add-ons schema editing.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

(function () {
	'use strict';

	/**
	 * Normalize a string into a machine-safe slug matching FoodSchemaValidator::normalize_id().
	 *
	 * @param {string} str Raw string.
	 * @return {string} Normalized slug.
	 */
	function normalizeId(str) {
		if (!str || typeof str !== 'string') {
			return '';
		}

		return str
			.toLowerCase()
			.trim()
			.replace(/[\s_\/]+/g, '-')
			.replace(/[^a-z0-9\-]/g, '')
			.replace(/-+/g, '-')
			.replace(/^-+|-+$/g, '');
	}

	document.addEventListener('DOMContentLoaded', function () {
		// =========================================================================
		// 1. WordPress Media Library Integration (Food Catalog Image)
		// =========================================================================
		var selectBtn = document.getElementById('mkt_select_image_btn');
		var removeBtn = document.getElementById('mkt_remove_image_btn');
		var imageInput = document.getElementById('mkt_image_id');
		var imagePreview = document.getElementById('mkt_image_preview');

		if (selectBtn && imageInput && imagePreview) {
			var frame;

			selectBtn.addEventListener('click', function (event) {
				event.preventDefault();

				if (typeof wp === 'undefined' || !wp.media) {
					return;
				}

				if (frame) {
					frame.open();
					return;
				}

				var modalTitle = selectBtn.getAttribute('data-uploader-title') || 'Select Food Item Image';
				var buttonText = selectBtn.getAttribute('data-uploader-button-text') || 'Use Image';

				frame = wp.media({
					title: modalTitle,
					button: {
						text: buttonText
					},
					multiple: false,
					library: {
						type: 'image'
					}
				});

				frame.on('select', function () {
					var attachment = frame.state().get('selection').first().toJSON();
					if (!attachment || !attachment.id) {
						return;
					}

					imageInput.value = attachment.id;

					var previewUrl = attachment.url;
					if (attachment.sizes && attachment.sizes.thumbnail) {
						previewUrl = attachment.sizes.thumbnail.url;
					} else if (attachment.sizes && attachment.sizes.medium) {
						previewUrl = attachment.sizes.medium.url;
					}

					var img = document.createElement('img');
					img.src = previewUrl;
					img.alt = attachment.alt || '';
					img.style.maxWidth = '140px';
					img.style.maxHeight = '140px';
					img.style.height = 'auto';
					img.style.borderRadius = '4px';
					img.style.border = '1px solid #dcdcde';
					img.style.display = 'block';

					imagePreview.innerHTML = '';
					imagePreview.appendChild(img);

					if (removeBtn) {
						removeBtn.style.display = 'inline-block';
					}

					selectBtn.textContent = selectBtn.getAttribute('data-replace-text') || 'Replace Image';
				});

				frame.open();
			});

			if (removeBtn) {
				removeBtn.addEventListener('click', function (event) {
					event.preventDefault();

					imageInput.value = '0';

					var emptyText = removeBtn.getAttribute('data-empty-text') || 'No catalog image selected.';
					imagePreview.innerHTML = '<span class="description" style="font-style:italic;">' + emptyText + '</span>';

					removeBtn.style.display = 'none';
					selectBtn.textContent = selectBtn.getAttribute('data-select-text') || 'Select Image';
				});
			}
		}

		// =========================================================================
		// 2. Configuration & Schema UI Containers
		// =========================================================================
		var config = window.mktFoodItemConfig || {
			maxAttributes: 3,
			maxVariations: 60,
			currency: '$',
			i18n: {
				maxAttributesReached: 'Maximum 3 attributes reached.',
				maxVariationsReached: 'Maximum 60 variations reached.',
				confirmRemoveAttr: 'Are you sure you want to remove this attribute and its options?',
				noAttributesNotice: 'Please define attributes with at least one option before adding variations.',
				selectOptionPrompt: '-- Select Option --'
			}
		};

		var attrContainer = document.getElementById('mkt_attributes_container');
		var addAttrBtn = document.getElementById('mkt_add_attribute_btn');
		var attrCountEl = document.getElementById('mkt_attr_count');

		var varTbody = document.getElementById('mkt_variations_tbody');
		var addVarBtn = document.getElementById('mkt_add_variation_btn');
		var varCountEl = document.getElementById('mkt_var_count');

		var addonTbody = document.getElementById('mkt_addons_tbody');
		var addAddonBtn = document.getElementById('mkt_add_addon_btn');

		var tmplAttr = document.getElementById('mkt_tmpl_attribute');
		var tmplOpt = document.getElementById('mkt_tmpl_option');
		var tmplVar = document.getElementById('mkt_tmpl_variation');
		var tmplAddon = document.getElementById('mkt_tmpl_addon');

		// =========================================================================
		// 3. Helper Functions
		// =========================================================================

		function updateAttributeCount() {
			if (!attrContainer || !attrCountEl || !addAttrBtn) {
				return;
			}
			var count = attrContainer.querySelectorAll('.mkt-attr-card').length;
			attrCountEl.textContent = count;
			addAttrBtn.disabled = count >= config.maxAttributes;
		}

		function updateVariationCount() {
			if (!varTbody || !varCountEl || !addVarBtn) {
				return;
			}
			var count = varTbody.querySelectorAll('.mkt-var-row').length;
			varCountEl.textContent = count;
			addVarBtn.disabled = count >= config.maxVariations;

			var emptyRow = varTbody.querySelector('.mkt-no-vars-row');
			if (emptyRow) {
				emptyRow.style.display = count === 0 ? '' : 'none';
			}
		}

		function updateAddonCount() {
			if (!addonTbody) {
				return;
			}
			var count = addonTbody.querySelectorAll('.mkt-addon-row').length;
			var emptyRow = addonTbody.querySelector('.mkt-no-addons-row');
			if (emptyRow) {
				emptyRow.style.display = count === 0 ? '' : 'none';
			}
		}

		/**
		 * Read declared attributes and their options from the DOM.
		 *
		 * @return {Array<{id: string, name: string, options: Array<{id: string, label: string}>}>}
		 */
		function getDeclaredAttributes() {
			if (!attrContainer) {
				return [];
			}

			var cards = attrContainer.querySelectorAll('.mkt-attr-card');
			var result = [];

			cards.forEach(function (card) {
				var nameInput = card.querySelector('.mkt-attr-name-input');
				var idInput = card.querySelector('.mkt-attr-id-input');

				var name = nameInput ? nameInput.value.trim() : '';
				var id = idInput ? idInput.value.trim() : '';
				if (!id && name) {
					id = normalizeId(name);
				}

				if (!id || !name) {
					return;
				}

				var optRows = card.querySelectorAll('.mkt-opt-row');
				var options = [];

				optRows.forEach(function (row) {
					var optLabelInput = row.querySelector('.mkt-opt-label-input');
					var optIdInput = row.querySelector('.mkt-opt-id-input');

					var label = optLabelInput ? optLabelInput.value.trim() : '';
					var optId = optIdInput ? optIdInput.value.trim() : '';
					if (!optId && label) {
						optId = normalizeId(label);
					}

					if (optId && label) {
						options.push({ id: optId, label: label });
					}
				});

				if (options.length > 0) {
					result.push({ id: id, name: name, options: options });
				}
			});

			return result;
		}

		// =========================================================================
		// 4. Attributes Management
		// =========================================================================

		if (addAttrBtn && tmplAttr && attrContainer) {
			addAttrBtn.addEventListener('click', function (e) {
				e.preventDefault();
				var currentCount = attrContainer.querySelectorAll('.mkt-attr-card').length;
				if (currentCount >= config.maxAttributes) {
					alert(config.i18n.maxAttributesReached);
					return;
				}

				var uniqueIndex = Date.now();
				var html = tmplAttr.innerHTML.replace(/__ATTR_INDEX__/g, uniqueIndex);
				var tempWrapper = document.createElement('div');
				tempWrapper.innerHTML = html.trim();
				var newCard = tempWrapper.firstElementChild;

				attrContainer.appendChild(newCard);
				updateAttributeCount();

				var nameInput = newCard.querySelector('.mkt-attr-name-input');
				if (nameInput) {
					nameInput.focus();
				}
			});
		}

		// Event delegation for attributes container (add/remove options, remove attribute, auto-slug)
		if (attrContainer) {
			attrContainer.addEventListener('click', function (e) {
				var target = e.target;

				// Remove Attribute
				if (target.classList.contains('mkt-remove-attr-btn')) {
					e.preventDefault();
					if (confirm(config.i18n.confirmRemoveAttr)) {
						var card = target.closest('.mkt-attr-card');
						if (card) {
							card.remove();
							updateAttributeCount();
						}
					}
					return;
				}

				// Add Option to Attribute
				if (target.classList.contains('mkt-add-opt-btn')) {
					e.preventDefault();
					var card = target.closest('.mkt-attr-card');
					if (!card || !tmplOpt) {
						return;
					}

					var attrIndex = card.getAttribute('data-index');
					var tbody = card.querySelector('.mkt-options-tbody');
					if (!tbody) {
						return;
					}

					var optIndex = Date.now();
					var html = tmplOpt.innerHTML
						.replace(/__ATTR_INDEX__/g, attrIndex)
						.replace(/__OPT_INDEX__/g, optIndex);

					var tempWrapper = document.createElement('tbody');
					tempWrapper.innerHTML = html.trim();
					var newRow = tempWrapper.firstElementChild;

					tbody.appendChild(newRow);

					var labelInput = newRow.querySelector('.mkt-opt-label-input');
					if (labelInput) {
						labelInput.focus();
					}
					return;
				}

				// Remove Option from Attribute
				if (target.classList.contains('mkt-remove-opt-btn')) {
					e.preventDefault();
					var row = target.closest('.mkt-opt-row');
					var tbody = target.closest('.mkt-options-tbody');
					if (row && tbody) {
						if (tbody.querySelectorAll('.mkt-opt-row').length > 1) {
							row.remove();
						} else {
							// Clear inputs rather than removing the last option to guarantee min 1
							var inputs = row.querySelectorAll('input');
							inputs.forEach(function (inp) {
								inp.value = '';
							});
						}
					}
				}
			});

			// Auto-slug on typing attribute name or option label
			attrContainer.addEventListener('input', function (e) {
				var target = e.target;

				// Attribute name changed
				if (target.classList.contains('mkt-attr-name-input')) {
					var card = target.closest('.mkt-attr-card');
					if (card) {
						var titleEl = card.querySelector('.mkt-attr-card-title');
						if (titleEl) {
							titleEl.textContent = target.value.trim() || 'New Attribute';
						}

						var idInput = card.querySelector('.mkt-attr-id-input');
						if (idInput && !idInput.dataset.manual) {
							idInput.value = normalizeId(target.value);
						}
					}
				}

				// Option label changed
				if (target.classList.contains('mkt-opt-label-input')) {
					var row = target.closest('.mkt-opt-row');
					if (row) {
						var optIdInput = row.querySelector('.mkt-opt-id-input');
						if (optIdInput && !optIdInput.dataset.manual) {
							optIdInput.value = normalizeId(target.value);
						}
					}
				}
			});

			// Track if user manually edits slug IDs
			attrContainer.addEventListener('change', function (e) {
				var target = e.target;
				if (target.classList.contains('mkt-attr-id-input') || target.classList.contains('mkt-opt-id-input')) {
					target.dataset.manual = target.value.trim() !== '' ? '1' : '';
					target.value = normalizeId(target.value);
				}
			});
		}

		// =========================================================================
		// 5. Variations Management
		// =========================================================================

		if (addVarBtn && tmplVar && varTbody) {
			addVarBtn.addEventListener('click', function (e) {
				e.preventDefault();
				var currentCount = varTbody.querySelectorAll('.mkt-var-row').length;
				if (currentCount >= config.maxVariations) {
					alert(config.i18n.maxVariationsReached);
					return;
				}

				var declaredAttrs = getDeclaredAttributes();
				if (declaredAttrs.length === 0) {
					alert(config.i18n.noAttributesNotice);
					return;
				}

				var uniqueIndex = Date.now();
				var html = tmplVar.innerHTML.replace(/__VAR_INDEX__/g, uniqueIndex);
				var tempWrapper = document.createElement('tbody');
				tempWrapper.innerHTML = html.trim();
				var newRow = tempWrapper.firstElementChild;

				// Construct select elements for each declared attribute
				var attrsWrap = newRow.querySelector('.mkt-var-attrs-wrap');
				if (attrsWrap) {
					attrsWrap.innerHTML = '';
					var autoSlugParts = [];

					declaredAttrs.forEach(function (attr) {
						var pairDiv = document.createElement('div');
						pairDiv.className = 'mkt-var-attr-pair';
						pairDiv.setAttribute('data-attr-id', attr.id);
						pairDiv.style.fontSize = '11px';

						var titleSpan = document.createElement('span');
						titleSpan.style.fontWeight = '600';
						titleSpan.style.display = 'block';
						titleSpan.textContent = attr.name + ':';
						pairDiv.appendChild(titleSpan);

						var select = document.createElement('select');
						select.name = 'mkt_variations[' + uniqueIndex + '][attributes][' + attr.id + ']';
						select.className = 'mkt-var-attr-select';

						attr.options.forEach(function (opt, idx) {
							var optEl = document.createElement('option');
							optEl.value = opt.id;
							optEl.textContent = opt.label;
							select.appendChild(optEl);

							if (idx === 0) {
								autoSlugParts.push(attr.id + '-' + opt.id);
							}
						});

						pairDiv.appendChild(select);
						attrsWrap.appendChild(pairDiv);
					});

					// Set initial variation slug ID
					var idInput = newRow.querySelector('.mkt-var-id-input');
					if (idInput && autoSlugParts.length > 0) {
						idInput.value = normalizeId(autoSlugParts.join('-'));
					}
				}

				varTbody.appendChild(newRow);
				updateVariationCount();
			});
		}

		if (varTbody) {
			// Remove variation row
			varTbody.addEventListener('click', function (e) {
				if (e.target.classList.contains('mkt-remove-var-btn')) {
					e.preventDefault();
					var row = e.target.closest('.mkt-var-row');
					if (row) {
						row.remove();
						updateVariationCount();
					}
				}
			});

			// Auto-update variation slug on combination select change
			varTbody.addEventListener('change', function (e) {
				var target = e.target;
				if (target.classList.contains('mkt-var-attr-select')) {
					var row = target.closest('.mkt-var-row');
					if (!row) {
						return;
					}

					var idInput = row.querySelector('.mkt-var-id-input');
					if (idInput && !idInput.dataset.manual) {
						var selects = row.querySelectorAll('.mkt-var-attr-select');
						var parts = [];
						selects.forEach(function (sel) {
							var pair = sel.closest('.mkt-var-attr-pair');
							var attrId = pair ? pair.getAttribute('data-attr-id') : '';
							if (attrId && sel.value) {
								parts.push(attrId + '-' + sel.value);
							}
						});
						if (parts.length > 0) {
							idInput.value = normalizeId(parts.join('-'));
						}
					}
				} else if (target.classList.contains('mkt-var-id-input')) {
					target.dataset.manual = target.value.trim() !== '' ? '1' : '';
					target.value = normalizeId(target.value);
				}
			});
		}

		// =========================================================================
		// 6. Add-ons Management
		// =========================================================================

		if (addAddonBtn && tmplAddon && addonTbody) {
			addAddonBtn.addEventListener('click', function (e) {
				e.preventDefault();
				var uniqueIndex = Date.now();
				var html = tmplAddon.innerHTML.replace(/__ADDON_INDEX__/g, uniqueIndex);
				var tempWrapper = document.createElement('tbody');
				tempWrapper.innerHTML = html.trim();
				var newRow = tempWrapper.firstElementChild;

				addonTbody.appendChild(newRow);
				updateAddonCount();

				var nameInput = newRow.querySelector('.mkt-addon-name-input');
				if (nameInput) {
					nameInput.focus();
				}
			});
		}

		if (addonTbody) {
			// Remove add-on row
			addonTbody.addEventListener('click', function (e) {
				if (e.target.classList.contains('mkt-remove-addon-btn')) {
					e.preventDefault();
					var row = e.target.closest('.mkt-addon-row');
					if (row) {
						row.remove();
						updateAddonCount();
					}
				}
			});

			// Auto-slug add-on name
			addonTbody.addEventListener('input', function (e) {
				var target = e.target;
				if (target.classList.contains('mkt-addon-name-input')) {
					var row = target.closest('.mkt-addon-row');
					if (row) {
						var idInput = row.querySelector('.mkt-addon-id-input');
						if (idInput && !idInput.dataset.manual) {
							idInput.value = normalizeId(target.value);
						}
					}
				}
			});

			// Manual slug tracking
			addonTbody.addEventListener('change', function (e) {
				var target = e.target;
				if (target.classList.contains('mkt-addon-id-input')) {
					target.dataset.manual = target.value.trim() !== '' ? '1' : '';
					target.value = normalizeId(target.value);
				}
			});
		}

		// Initialize counters and visibility states
		updateAttributeCount();
		updateVariationCount();
		updateAddonCount();
	});
})();
