<?php
/**
 * Lightweight PSR-4 Autoloader for Maktomine Restaurant Core.
 *
 * @package Maktomine\RestaurantCore
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore;

defined( 'ABSPATH' ) || exit;

final class Autoloader {

	/**
	 * Registered namespace prefixes and their base directories.
	 *
	 * @var array<string, string>
	 */
	private static array $prefixes = [];

	/**
	 * Register a namespace prefix and its corresponding base directory.
	 *
	 * @param string $prefix  Namespace prefix (must end with a backslash).
	 * @param string $base_dir Absolute base directory path (must end with a slash).
	 * @return void
	 */
	public static function register( string $prefix, string $base_dir ): void {
		if ( empty( self::$prefixes ) ) {
			spl_autoload_register( [ self::class, 'load' ] );
		}

		self::$prefixes[ rtrim( $prefix, '\\' ) . '\\' ] = rtrim( $base_dir, '/\\' ) . DIRECTORY_SEPARATOR;
	}

	/**
	 * Autoload callback.
	 *
	 * @param string $class Fully-qualified class name.
	 * @return bool True if loaded, false otherwise.
	 */
	public static function load( string $class ): bool {
		foreach ( self::$prefixes as $prefix => $base_dir ) {
			$len = strlen( $prefix );
			if ( strncmp( $prefix, $class, $len ) !== 0 ) {
				continue;
			}

			$relative_class = substr( $class, $len );
			$file = $base_dir . str_replace( '\\', DIRECTORY_SEPARATOR, $relative_class ) . '.php';

			if ( is_readable( $file ) ) {
				require_once $file;
				return true;
			}
		}

		return false;
	}
}
