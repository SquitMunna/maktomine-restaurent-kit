<?php
/**
 * Database Migration Manager.
 * Orchestrates schema migrations using version tracking.
 *
 * @package Maktomine\RestaurantCore\Database
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Database;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Contracts\MigrationInterface;
use Maktomine\RestaurantCore\Database\Migrations\CreateInitialTablesMigration;
use Maktomine\RestaurantCore\Database\Migrations\AddIdempotencySupportMigration;
use Maktomine\RestaurantCore\Core\Logger;

final class DatabaseManager {

	public const DB_VERSION_OPTION = 'mkt_db_version';

	/**
	 * Ordered list of migration classes.
	 *
	 * @var array<class-string<MigrationInterface>>
	 */
	private array $migrations = [
		CreateInitialTablesMigration::class,
		AddIdempotencySupportMigration::class,
	];

	/**
	 * Execute all pending database migrations.
	 *
	 * @return bool True if migrations ran successfully or no update was needed.
	 */
	public function migrate(): bool {
		$installed_version = (string) get_option( self::DB_VERSION_OPTION, '0.0.0' );

		foreach ( $this->migrations as $migration_class ) {
			/** @var MigrationInterface $migration */
			$migration = new $migration_class();
			$migration_version = $migration->get_version();

			if ( version_compare( $installed_version, $migration_version, '<' ) ) {
				Logger::info( sprintf( 'Running database migration: %s (v%s)', $migration_class, $migration_version ) );

				$success = $migration->up();
				if ( ! $success ) {
					Logger::error( sprintf( 'Database migration failed: %s', $migration_class ) );
					return false;
				}

				update_option( self::DB_VERSION_OPTION, $migration_version, true );
				$installed_version = $migration_version;
			}
		}

		/**
		 * Action triggered after database migration completes.
		 *
		 * @param string $installed_version Current database version.
		 */
		do_action( 'maktomine/database/migrated', $installed_version );

		return true;
	}

	/**
	 * Automatically check if installed schema version is behind and run migrations.
	 * Safe for plugin update lifecycle without requiring re-activation.
	 *
	 * @return bool True if up to date or successfully migrated.
	 */
	public function maybe_migrate(): bool {
		$installed_version = (string) get_option( self::DB_VERSION_OPTION, '0.0.0' );
		$target_version = defined( 'MAKTOMINE_CORE_DB_VERSION' ) ? MAKTOMINE_CORE_DB_VERSION : '1.0.0';

		if ( version_compare( $installed_version, $target_version, '<' ) ) {
			return $this->migrate();
		}

		return true;
	}

	/**
	 * Get current installed database schema version.
	 *
	 * @return string
	 */
	public function get_installed_version(): string {
		return (string) get_option( self::DB_VERSION_OPTION, '0.0.0' );
	}
}
