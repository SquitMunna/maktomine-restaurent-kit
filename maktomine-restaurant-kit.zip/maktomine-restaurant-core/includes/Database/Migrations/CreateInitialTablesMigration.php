<?php
/**
 * Initial Database Schema Migration for Maktomine Restaurant Core.
 * Creates dedicated transactional tables for Orders, Order Items, and Bookings.
 *
 * @package Maktomine\RestaurantCore\Database\Migrations
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Database\Migrations;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Contracts\MigrationInterface;
use Maktomine\RestaurantCore\Core\Logger;

final class CreateInitialTablesMigration implements MigrationInterface {

	public function get_version(): string {
		return '1.0.0';
	}

	public function up(): bool {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		// Table 1: wp_maktomine_orders
		$orders_table = $wpdb->prefix . 'maktomine_orders';
		$orders_sql = "CREATE TABLE {$orders_table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			order_reference VARCHAR(32) NOT NULL,
			customer_name VARCHAR(191) NOT NULL,
			customer_phone VARCHAR(32) NOT NULL,
			customer_whatsapp VARCHAR(32) DEFAULT '',
			order_type VARCHAR(16) NOT NULL DEFAULT 'delivery',
			delivery_address TEXT DEFAULT NULL,
			delivery_area VARCHAR(191) DEFAULT '',
			delivery_landmark VARCHAR(191) DEFAULT '',
			order_note TEXT DEFAULT NULL,
			subtotal DECIMAL(10,2) NOT NULL DEFAULT '0.00',
			delivery_charge DECIMAL(10,2) NOT NULL DEFAULT '0.00',
			total_amount DECIMAL(10,2) NOT NULL DEFAULT '0.00',
			currency VARCHAR(8) NOT NULL DEFAULT 'USD',
			order_status VARCHAR(32) NOT NULL DEFAULT 'pending_whatsapp',
			verification_hash VARCHAR(64) NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY order_reference (order_reference),
			KEY order_status (order_status),
			KEY customer_phone (customer_phone),
			KEY created_at (created_at)
		) {$charset_collate};";

		// Table 2: wp_maktomine_order_items
		$order_items_table = $wpdb->prefix . 'maktomine_order_items';
		$order_items_sql = "CREATE TABLE {$order_items_table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			order_id BIGINT(20) UNSIGNED NOT NULL,
			food_id BIGINT(20) UNSIGNED NOT NULL,
			item_name VARCHAR(191) NOT NULL,
			variation_id VARCHAR(64) DEFAULT NULL,
			variation_summary TEXT DEFAULT NULL,
			addons_summary TEXT DEFAULT NULL,
			unit_price DECIMAL(10,2) NOT NULL DEFAULT '0.00',
			quantity INT(11) NOT NULL DEFAULT 1,
			line_total DECIMAL(10,2) NOT NULL DEFAULT '0.00',
			PRIMARY KEY  (id),
			KEY order_id (order_id),
			KEY food_id (food_id)
		) {$charset_collate};";

		// Table 3: wp_maktomine_bookings
		$bookings_table = $wpdb->prefix . 'maktomine_bookings';
		$bookings_sql = "CREATE TABLE {$bookings_table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			booking_reference VARCHAR(32) NOT NULL,
			customer_name VARCHAR(191) NOT NULL,
			customer_phone VARCHAR(32) NOT NULL,
			customer_email VARCHAR(191) NOT NULL,
			booking_date DATE NOT NULL,
			booking_time TIME NOT NULL,
			guest_count INT(11) NOT NULL DEFAULT 2,
			table_preference VARCHAR(64) DEFAULT '',
			special_request TEXT DEFAULT NULL,
			booking_status VARCHAR(32) NOT NULL DEFAULT 'pending',
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY booking_reference (booking_reference),
			KEY booking_slot (booking_date, booking_time),
			KEY booking_status (booking_status),
			KEY customer_phone (customer_phone)
		) {$charset_collate};";

		dbDelta( $orders_sql );
		dbDelta( $order_items_sql );
		dbDelta( $bookings_sql );

		// Verification: Confirm that all required tables were created.
		$required_tables = [ $orders_table, $order_items_table, $bookings_table ];
		foreach ( $required_tables as $table_name ) {
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) );
			if ( $found !== $table_name ) {
				Logger::error(
					sprintf( 'Table verification failed for %s. Database Error: %s', $table_name, $wpdb->last_error )
				);
				return false;
			}
		}

		return true;
	}

	public function down(): bool {
		global $wpdb;

		$tables = [
			$wpdb->prefix . 'maktomine_order_items',
			$wpdb->prefix . 'maktomine_orders',
			$wpdb->prefix . 'maktomine_bookings',
		];

		foreach ( $tables as $table ) {
			// Direct drop table query used only during explicit complete uninstallation.
			$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		}

		return true;
	}
}
