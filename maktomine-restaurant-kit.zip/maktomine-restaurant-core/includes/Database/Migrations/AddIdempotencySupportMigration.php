<?php
/**
 * Database Schema Migration for Order Submission Idempotency Support.
 *
 * Adds unique idempotency_key column to wp_maktomine_orders and creates
 * the dedicated wp_maktomine_idempotency_keys table.
 *
 * @package Maktomine\RestaurantCore\Database\Migrations
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Database\Migrations;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Contracts\MigrationInterface;
use Maktomine\RestaurantCore\Core\Logger;

final class AddIdempotencySupportMigration implements MigrationInterface {

	/**
	 * Schema version string.
	 *
	 * @return string
	 */
	public function get_version(): string {
		return '1.1.0';
	}

	/**
	 * Execute the schema upgrade logic.
	 *
	 * 1. Creates dedicated wp_maktomine_idempotency_keys table.
	 * 2. Adds nullable idempotency_key VARCHAR(64) column to wp_maktomine_orders.
	 * 3. Adds UNIQUE KEY idempotency_key on wp_maktomine_orders.
	 *
	 * @return bool True on success, false on failure.
	 */
	public function up(): bool {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		$orders_table      = $wpdb->prefix . 'maktomine_orders';
		$idempotency_table = $wpdb->prefix . 'maktomine_idempotency_keys';

		// Part A: Create dedicated wp_maktomine_idempotency_keys table via dbDelta.
		$idempotency_sql = "CREATE TABLE {$idempotency_table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			idempotency_key VARCHAR(64) NOT NULL,
			request_hash VARCHAR(64) NOT NULL,
			order_id BIGINT(20) UNSIGNED DEFAULT NULL,
			order_reference VARCHAR(32) DEFAULT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'processing',
			response_code INT(11) NOT NULL DEFAULT 201,
			response_body LONGTEXT DEFAULT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			expires_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY status_expires (status, expires_at),
			KEY order_id (order_id)
		) {$charset_collate};";

		dbDelta( $idempotency_sql );

		// Part B: Ensure idempotency_key column exists on wp_maktomine_orders.
		// Existing orders remain valid with NULL.
		$column_check = $wpdb->get_results(
			$wpdb->prepare(
				"SHOW COLUMNS FROM {$orders_table} LIKE %s",
				'idempotency_key'
			)
		);

		if ( empty( $column_check ) ) {
			$add_column_result = $wpdb->query(
				"ALTER TABLE {$orders_table} ADD COLUMN idempotency_key VARCHAR(64) DEFAULT NULL AFTER order_reference"
			);

			if ( false === $add_column_result ) {
				Logger::error(
					sprintf( 'Failed to add idempotency_key column to %s. Database Error: %s', $orders_table, $wpdb->last_error )
				);
				return false;
			}
		}

		// Part C: Ensure unique index idempotency_key exists on wp_maktomine_orders.
		// Inspect all rows for Key_name = 'idempotency_key'.
		$index_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SHOW INDEX FROM {$orders_table} WHERE Key_name = %s",
				'idempotency_key'
			),
			ARRAY_A
		);

		// Distinguish unexpected database query failure from empty/non-empty results.
		if ( null === $index_rows ) {
			Logger::error(
				sprintf( 'Failed to query indexes for %s. Database Error: %s', $orders_table, $wpdb->last_error )
			);
			return false;
		}

		$is_valid_unique_index = false;
		$needs_drop_index      = false;

		if ( ! empty( $index_rows ) ) {
			// A valid unique index on idempotency_key must consist of exactly ONE column row
			// with Key_name = 'idempotency_key', Non_unique = 0, Column_name = 'idempotency_key', and Seq_in_index = 1.
			if ( 1 === count( $index_rows ) ) {
				$first_row = $index_rows[0];
				$key_name  = (string) ( $first_row['Key_name'] ?? $first_row['key_name'] ?? '' );
				$non_uniq  = (int) ( $first_row['Non_unique'] ?? $first_row['non_unique'] ?? 1 );
				$col_name  = (string) ( $first_row['Column_name'] ?? $first_row['column_name'] ?? '' );

				if ( 'idempotency_key' === $key_name && 0 === $non_uniq && 'idempotency_key' === $col_name ) {
					$is_valid_unique_index = true;
				} else {
					$needs_drop_index = true;
				}
			} else {
				// Multiple columns or unexpected multi-part index named 'idempotency_key'.
				$needs_drop_index = true;
			}
		}

		// Case C: If an index named 'idempotency_key' exists but is not the required UNIQUE single-column index,
		// safely drop it to converge to the required invariant without touching unrelated indexes.
		if ( $needs_drop_index ) {
			Logger::warning(
				sprintf( 'Index idempotency_key on %s exists but does not match required UNIQUE invariant. Dropping to recreate.', $orders_table )
			);

			$drop_res = $wpdb->query( "ALTER TABLE {$orders_table} DROP INDEX idempotency_key" );
			if ( false === $drop_res ) {
				Logger::error(
					sprintf( 'Failed to drop non-conforming idempotency_key index on %s. Database Error: %s', $orders_table, $wpdb->last_error )
				);
				return false;
			}
			$is_valid_unique_index = false;
		}

		// Case B: If no valid unique index exists, create it.
		if ( ! $is_valid_unique_index ) {
			$add_index_result = $wpdb->query(
				"ALTER TABLE {$orders_table} ADD UNIQUE KEY idempotency_key (idempotency_key)"
			);

			if ( false === $add_index_result ) {
				Logger::error(
					sprintf( 'Failed to add unique index idempotency_key to %s. Database Error: %s', $orders_table, $wpdb->last_error )
				);
				return false;
			}
		}

		// --- FINAL SCHEMA VERIFICATION ---

		// 1. Verification: Confirm dedicated idempotency table exists.
		$found_table = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $idempotency_table ) );
		if ( $found_table !== $idempotency_table ) {
			Logger::error(
				sprintf( 'Table verification failed for %s. Database Error: %s', $idempotency_table, $wpdb->last_error )
			);
			return false;
		}

		// 2. Verification: Confirm column exists on orders table with compatible type and DEFAULT NULL.
		$found_column = $wpdb->get_row(
			$wpdb->prepare(
				"SHOW COLUMNS FROM {$orders_table} LIKE %s",
				'idempotency_key'
			),
			ARRAY_A
		);
		if ( empty( $found_column ) ) {
			Logger::error(
				sprintf( 'Column verification failed for %s.idempotency_key. Database Error: %s', $orders_table, $wpdb->last_error )
			);
			return false;
		}

		$col_type = strtolower( (string) ( $found_column['Type'] ?? $found_column['type'] ?? '' ) );
		$col_null = strtoupper( (string) ( $found_column['Null'] ?? $found_column['null'] ?? '' ) );
		$col_def  = $found_column['Default'] ?? $found_column['default'] ?? null;

		if ( false === strpos( $col_type, 'varchar(64)' ) ) {
			Logger::error(
				sprintf( 'Column %s.idempotency_key type "%s" is incompatible with VARCHAR(64).', $orders_table, $col_type )
			);
			return false;
		}

		if ( 'YES' !== $col_null || null !== $col_def ) {
			Logger::error(
				sprintf( 'Column %s.idempotency_key nullability "%s" or default is incompatible with DEFAULT NULL.', $orders_table, $col_null )
			);
			return false;
		}

		// 3. Verification: Confirm unique index exists on orders table and conforms strictly to invariant.
		$verify_index_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SHOW INDEX FROM {$orders_table} WHERE Key_name = %s",
				'idempotency_key'
			),
			ARRAY_A
		);

		if ( empty( $verify_index_rows ) || 1 !== count( $verify_index_rows ) ) {
			Logger::error(
				sprintf( 'Unique index verification failed for %s.idempotency_key: expected exactly one index row. Database Error: %s', $orders_table, $wpdb->last_error )
			);
			return false;
		}

		$ver_row      = $verify_index_rows[0];
		$ver_key_name = (string) ( $ver_row['Key_name'] ?? $ver_row['key_name'] ?? '' );
		$ver_non_uniq = (int) ( $ver_row['Non_unique'] ?? $ver_row['non_unique'] ?? 1 );
		$ver_col_name = (string) ( $ver_row['Column_name'] ?? $ver_row['column_name'] ?? '' );

		if ( 'idempotency_key' !== $ver_key_name || 0 !== $ver_non_uniq || 'idempotency_key' !== $ver_col_name ) {
			Logger::error(
				sprintf(
					'Unique index verification failed for %s.idempotency_key: Key_name="%s", Non_unique=%d, Column_name="%s". Invariant requires unique index on idempotency_key.',
					$orders_table,
					$ver_key_name,
					$ver_non_uniq,
					$ver_col_name
				)
			);
			return false;
		}

		return true;
	}

	/**
	 * Roll back the schema modification.
	 *
	 * Used only during uninstallation or explicit downgrade.
	 *
	 * @return bool True on success, false on failure.
	 */
	public function down(): bool {
		global $wpdb;

		$idempotency_table = $wpdb->prefix . 'maktomine_idempotency_keys';
		$orders_table      = $wpdb->prefix . 'maktomine_orders';

		// Drop dedicated idempotency keys table.
		$wpdb->query( "DROP TABLE IF EXISTS {$idempotency_table}" );

		// Remove unique key and column from orders table if present.
		$index_check = $wpdb->get_results(
			$wpdb->prepare(
				"SHOW INDEX FROM {$orders_table} WHERE Key_name = %s",
				'idempotency_key'
			)
		);

		if ( ! empty( $index_check ) ) {
			$wpdb->query( "ALTER TABLE {$orders_table} DROP INDEX idempotency_key" );
		}

		$column_check = $wpdb->get_results(
			$wpdb->prepare(
				"SHOW COLUMNS FROM {$orders_table} LIKE %s",
				'idempotency_key'
			)
		);

		if ( ! empty( $column_check ) ) {
			$wpdb->query( "ALTER TABLE {$orders_table} DROP COLUMN idempotency_key" );
		}

		return true;
	}
}
