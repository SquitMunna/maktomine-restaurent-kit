<?php
/**
 * Base REST API Controller.
 * Provides security, permission checking, and consistent JSON responses for Maktomine endpoints.
 *
 * @package Maktomine\RestaurantCore\REST
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\REST;

defined( 'ABSPATH' ) || exit;

use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

abstract class BaseRestController extends WP_REST_Controller {

	/**
	 * Canonical REST API namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'maktomine/v1';

	/**
	 * Verify that user has administrative restaurant capability.
	 *
	 * @param WP_REST_Request $request REST request instance.
	 * @return bool|WP_Error
	 */
	public function check_admin_permission( WP_REST_Request $request ): bool|WP_Error {
		if ( ! current_user_can( 'manage_restaurant_settings' ) && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'You do not have permission to access this restaurant resource.', 'maktomine-restaurant-core' ),
				[ 'status' => rest_authorization_required_code() ]
			);
		}

		return true;
	}

	/**
	 * Standard public permission check for consumer-facing endpoints (e.g. food query, cart validation).
	 *
	 * @param WP_REST_Request $request REST request instance.
	 * @return bool
	 */
	public function public_permission_callback( WP_REST_Request $request ): bool {
		return true;
	}

	/**
	 * Return a standardized success response.
	 *
	 * @param mixed  $data    Payload.
	 * @param string $message Optional status message.
	 * @param int    $status  HTTP status code.
	 * @return WP_REST_Response
	 */
	protected function respond_success( mixed $data = [], string $message = 'Success', int $status = 200 ): WP_REST_Response {
		return new WP_REST_Response( [
			'success' => true,
			'message' => $message,
			'data'    => $data,
		], $status );
	}

	/**
	 * Return a standardized error response.
	 *
	 * @param string $code    Machine-readable code.
	 * @param string $message Human-readable error message.
	 * @param int    $status  HTTP status code.
	 * @param array  $details Optional diagnostic details.
	 * @return WP_Error
	 */
	protected function respond_error( string $code, string $message, int $status = 400, array $details = [] ): WP_Error {
		return new WP_Error( $code, $message, [
			'status'  => $status,
			'details' => $details,
		] );
	}
}
