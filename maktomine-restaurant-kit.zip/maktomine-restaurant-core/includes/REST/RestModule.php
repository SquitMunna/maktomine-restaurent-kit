<?php
/**
 * REST API Module.
 * Initializes the maktomine/v1 REST namespace and foundational endpoints.
 *
 * @package Maktomine\RestaurantCore\REST
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\REST;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Contracts\ModuleInterface;
use WP_REST_Server;
use WP_REST_Request;
use WP_REST_Response;

final class RestModule extends BaseRestController implements ModuleInterface {

	public function get_id(): string {
		return 'rest';
	}

	public function register(): void {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	public function boot(): void {
		// REST endpoints active.
	}

	/**
	 * Register foundational REST routes under maktomine/v1.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		// Foundational System Health & Ecosystem Status Endpoint.
		register_rest_route(
			$this->namespace,
			'/system/status',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_system_status' ],
				'permission_callback' => [ $this, 'public_permission_callback' ],
			]
		);

		// Public Restaurant Catalog Controller.
		$catalog_controller = new CatalogRestController();
		$catalog_controller->register_routes();

		// Public Restaurant Order Controller.
		$order_controller = new OrderRestController();
		$order_controller->register_routes();
	}

	/**
	 * Public endpoint returning active plugin capability and currency configurations.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function get_system_status( WP_REST_Request $request ): WP_REST_Response {
		$info = \Maktomine\RestaurantCore\Settings\BusinessInfoRepository::get();

		return $this->respond_success( [
			'core_version'     => MAKTOMINE_CORE_VERSION,
			'currency'         => $info['currency'] ?? 'USD',
			'currency_symbol'  => $info['currency_symbol'] ?? '$',
			'currency_position'=> $info['currency_position'] ?? 'left',
			'delivery_enabled' => (bool) ( $info['delivery_enabled'] ?? true ),
			'pickup_enabled'   => (bool) ( $info['pickup_enabled'] ?? true ),
			'server_time'      => gmdate( 'Y-m-d H:i:s' ),
		], 'Maktomine Restaurant Core REST API Active' );
	}
}
