<?php
/**
 * Catalog REST Controller.
 * Exposes read-only public catalog endpoints for single food item retrieval,
 * variation resolution, and effective price calculation.
 *
 * @package Maktomine\RestaurantCore\REST
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\REST;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Catalog\CatalogService;
use Maktomine\RestaurantCore\Catalog\VariationMatrixResolver;
use Maktomine\RestaurantCore\Catalog\PriceCalculator;
use Maktomine\RestaurantCore\Catalog\CartItemPresentationResolver;
use Maktomine\RestaurantCore\Cart\Cart;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Error;

/**
 * Class CatalogRestController
 *
 * HTTP/REST adapter consuming CatalogService without embedding catalog business logic.
 */
final class CatalogRestController extends BaseRestController {

	/**
	 * Catalog domain service instance.
	 *
	 * @var CatalogService
	 */
	private CatalogService $catalog_service;

	/**
	 * Constructor.
	 *
	 * @param CatalogService|null $catalog_service Optional injected service instance.
	 */
	public function __construct( ?CatalogService $catalog_service = null ) {
		$this->catalog_service = $catalog_service ?? CatalogService::instance();
	}

	/**
	 * Register catalog REST routes under maktomine/v1.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		// Food items collection retrieval endpoint.
		register_rest_route(
			$this->namespace,
			'/food-items',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items' ],
					'permission_callback' => [ $this, 'public_permission_callback' ],
					'args'                => [
						'page'                => [
							'description'       => __( 'Current page of the collection.', 'maktomine-restaurant-core' ),
							'type'              => 'integer',
							'default'           => 1,
							'minimum'           => 1,
							'validate_callback' => [ $this, 'validate_page_param' ],
							'sanitize_callback' => 'absint',
							'required'          => false,
						],
						'per_page'            => [
							'description'       => __( 'Maximum number of items to be returned in result set.', 'maktomine-restaurant-core' ),
							'type'              => 'integer',
							'default'           => 20,
							'minimum'           => 1,
							'maximum'           => 50,
							'validate_callback' => [ $this, 'validate_per_page_param' ],
							'sanitize_callback' => 'absint',
							'required'          => false,
						],
						'category'            => [
							'description'       => __( 'Filter by menu category term slug.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_title',
						],
						'tag'                 => [
							'description'       => __( 'Filter by dietary tag term slug.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_title',
						],
						'featured'            => [
							'description'       => __( 'Filter by featured flag (1, 0, true, false).', 'maktomine-restaurant-core' ),
							'type'              => 'boolean',
							'required'          => false,
						],
						'popular'             => [
							'description'       => __( 'Filter by popular flag (1, 0, true, false).', 'maktomine-restaurant-core' ),
							'type'              => 'boolean',
							'required'          => false,
						],
						'availability_status' => [
							'description'       => __( 'Filter by stock/availability status.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'enum'              => [ 'in_stock', 'out_of_stock', 'pre_order_only' ],
							'required'          => false,
							'sanitize_callback' => 'sanitize_key',
						],
						'orderby'             => [
							'description'       => __( 'Sort order of the collection.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'enum'              => [ 'date_desc', 'date_asc', 'title_asc', 'title_desc', 'menu_order' ],
							'default'           => 'date_desc',
							'required'          => false,
							'sanitize_callback' => 'sanitize_key',
						],
					],
				],
			]
		);

		// Single food item retrieval endpoint.
		register_rest_route(
			$this->namespace,
			'/food-items/(?P<id>[\d]+)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_item' ],
					'permission_callback' => [ $this, 'public_permission_callback' ],
					'args'                => [
						'id' => [
							'description'       => __( 'Unique identifier for the food item.', 'maktomine-restaurant-core' ),
							'type'              => 'integer',
							'validate_callback' => [ $this, 'validate_id_param' ],
							'sanitize_callback' => 'absint',
							'required'          => true,
						],
					],
				],
			]
		);

		// Variation selection resolution endpoint.
		register_rest_route(
			$this->namespace,
			'/food-items/(?P<id>[\d]+)/resolve',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'resolve_selection' ],
					'permission_callback' => [ $this, 'public_permission_callback' ],
					'args'                => [
						'id'        => [
							'description'       => __( 'Unique identifier for the food item.', 'maktomine-restaurant-core' ),
							'type'              => 'integer',
							'validate_callback' => [ $this, 'validate_id_param' ],
							'sanitize_callback' => 'absint',
							'required'          => true,
						],
						'selection' => [
							'description'       => __( 'Customer attribute selections mapping attribute ID to option ID.', 'maktomine-restaurant-core' ),
							'type'              => 'object',
							'required'          => true,
							'validate_callback' => [ $this, 'validate_selection_param' ],
						],
					],
				],
			]
		);

		// Effective price calculation endpoint.
		register_rest_route(
			$this->namespace,
			'/food-items/(?P<id>[\d]+)/price',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'calculate_price' ],
					'permission_callback' => [ $this, 'public_permission_callback' ],
					'args'                => [
						'id'        => [
							'description'       => __( 'Unique identifier for the food item.', 'maktomine-restaurant-core' ),
							'type'              => 'integer',
							'validate_callback' => [ $this, 'validate_id_param' ],
							'sanitize_callback' => 'absint',
							'required'          => true,
						],
						'selection' => [
							'description'       => __( 'Customer attribute selections mapping attribute ID to option ID.', 'maktomine-restaurant-core' ),
							'type'              => 'object',
							'required'          => false,
							'default'           => [],
							'validate_callback' => [ $this, 'validate_optional_selection_param' ],
						],
					],
				],
			]
		);

		// Cart item presentation resolution endpoint (read-only query, public).
		register_rest_route(
			$this->namespace,
			'/cart/resolve',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'resolve_cart_lines' ],
					'permission_callback' => [ $this, 'public_permission_callback' ],
					'args'                => [
						'lines' => [
							'description'       => __( 'Array of cart line objects to resolve for presentation.', 'maktomine-restaurant-core' ),
							'type'              => 'array',
							'required'          => true,
							'validate_callback' => [ $this, 'validate_cart_lines_param' ],
						],
					],
				],
			]
		);
	}

	/**
	 * Retrieve a collection of published food items.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items( $request ) {
		$page     = (int) ( $request->get_param( 'page' ) ?? 1 );
		$per_page = (int) ( $request->get_param( 'per_page' ) ?? 20 );

		if ( $page < 1 ) {
			$page = 1;
		}
		if ( $per_page < 1 || $per_page > 50 ) {
			$per_page = 20;
		}

		$args = [
			'page'     => $page,
			'per_page' => $per_page,
			'status'   => 'publish',
		];

		if ( $request->has_param( 'category' ) && '' !== trim( (string) $request->get_param( 'category' ) ) ) {
			$args['category'] = sanitize_title( (string) $request->get_param( 'category' ) );
		}

		if ( $request->has_param( 'tag' ) && '' !== trim( (string) $request->get_param( 'tag' ) ) ) {
			$args['tag'] = sanitize_title( (string) $request->get_param( 'tag' ) );
		}

		if ( $request->has_param( 'featured' ) ) {
			$args['featured'] = rest_sanitize_boolean( $request->get_param( 'featured' ) );
		}

		if ( $request->has_param( 'popular' ) ) {
			$args['popular'] = rest_sanitize_boolean( $request->get_param( 'popular' ) );
		}

		if ( $request->has_param( 'availability_status' ) && '' !== trim( (string) $request->get_param( 'availability_status' ) ) ) {
			$args['availability_status'] = sanitize_key( (string) $request->get_param( 'availability_status' ) );
		}

		if ( $request->has_param( 'orderby' ) && '' !== trim( (string) $request->get_param( 'orderby' ) ) ) {
			$args['orderby'] = sanitize_key( (string) $request->get_param( 'orderby' ) );
		}

		$result = $this->catalog_service->get_food_items( $args );
		if ( is_wp_error( $result ) ) {
			return $this->handle_service_error( $result );
		}

		return $this->respond_success(
			$result,
			__( 'Food items retrieved successfully.', 'maktomine-restaurant-core' )
		);
	}

	/**
	 * Retrieve a single food item by ID.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_item( $request ) {
		$id = (int) $request->get_param( 'id' );

		$food_item = $this->catalog_service->get_food_item( $id );
		if ( is_wp_error( $food_item ) ) {
			return $this->handle_service_error( $food_item );
		}

		// Public visibility check: only published items are exposed through public REST.
		if ( ! $this->is_publicly_visible( $food_item ) ) {
			return $this->respond_error(
				CatalogService::ERROR_FOOD_NOT_FOUND,
				__( 'Food item not found.', 'maktomine-restaurant-core' ),
				404
			);
		}

		return $this->respond_success(
			$food_item,
			__( 'Food item retrieved successfully.', 'maktomine-restaurant-core' )
		);
	}

	/**
	 * Resolve variation matching for customer attribute selection.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function resolve_selection( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$id = (int) $request->get_param( 'id' );

		// Verify food item exists and is published prior to resolution.
		$food_item = $this->catalog_service->get_food_item( $id );
		if ( is_wp_error( $food_item ) ) {
			return $this->handle_service_error( $food_item );
		}

		if ( ! $this->is_publicly_visible( $food_item ) ) {
			return $this->respond_error(
				CatalogService::ERROR_FOOD_NOT_FOUND,
				__( 'Food item not found.', 'maktomine-restaurant-core' ),
				404
			);
		}

		$selection = $request->get_param( 'selection' );
		if ( ! is_array( $selection ) ) {
			return $this->respond_error(
				VariationMatrixResolver::ERROR_INVALID_SELECTION,
				__( 'Selection must be an object/associative array.', 'maktomine-restaurant-core' ),
				400
			);
		}

		$resolution = $this->catalog_service->resolve_food_item_selection( $id, $selection );
		if ( is_wp_error( $resolution ) ) {
			return $this->handle_service_error( $resolution );
		}

		$data = [
			'food_id'   => (int) ( $resolution['food_id'] ?? $id ),
			'matched'   => (bool) ( $resolution['matched'] ?? false ),
			'variation' => $resolution['variation'] ?? null,
			'selection' => $resolution['selection'] ?? $selection,
		];

		return $this->respond_success(
			$data,
			__( 'Variation resolved successfully.', 'maktomine-restaurant-core' )
		);
	}

	/**
	 * Calculate effective unit price for given attribute selection.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function calculate_price( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$id = (int) $request->get_param( 'id' );

		// Verify food item exists and is published prior to calculation.
		$food_item = $this->catalog_service->get_food_item( $id );
		if ( is_wp_error( $food_item ) ) {
			return $this->handle_service_error( $food_item );
		}

		if ( ! $this->is_publicly_visible( $food_item ) ) {
			return $this->respond_error(
				CatalogService::ERROR_FOOD_NOT_FOUND,
				__( 'Food item not found.', 'maktomine-restaurant-core' ),
				404
			);
		}

		$selection = $request->get_param( 'selection' ) ?? [];
		if ( ! is_array( $selection ) ) {
			return $this->respond_error(
				VariationMatrixResolver::ERROR_INVALID_SELECTION,
				__( 'Selection must be an object/associative array.', 'maktomine-restaurant-core' ),
				400
			);
		}

		$price_result = $this->catalog_service->calculate_food_item_price( $id, $selection );
		if ( is_wp_error( $price_result ) ) {
			return $this->handle_service_error( $price_result );
		}

		$data = [
			'food_id'         => (int) ( $price_result['food_id'] ?? $id ),
			'price'           => (float) ( $price_result['price'] ?? 0.0 ),
			'source'          => (string) ( $price_result['source'] ?? 'base' ),
			'base_price'      => (float) ( $price_result['base_price'] ?? 0.0 ),
			'sale_price'      => isset( $price_result['sale_price'] ) && null !== $price_result['sale_price'] ? (float) $price_result['sale_price'] : null,
			'variation_price' => isset( $price_result['variation_price'] ) && null !== $price_result['variation_price'] ? (float) $price_result['variation_price'] : null,
			'variation_id'    => $price_result['variation_id'] ?? null,
			'selection'       => $price_result['selection'] ?? $selection,
		];

		return $this->respond_success(
			$data,
			__( 'Price calculated successfully.', 'maktomine-restaurant-core' )
		);
	}

	/**
	 * Validate positive integer route parameter.
	 *
	 * @param mixed           $value   Parameter value.
	 * @param WP_REST_Request $request Current request.
	 * @param string          $param   Parameter key name.
	 * @return bool|WP_Error
	 */
	public function validate_id_param( mixed $value, WP_REST_Request $request, string $param ): bool|WP_Error {
		if ( ! is_numeric( $value ) || (int) $value <= 0 ) {
			return new WP_Error(
				'rest_invalid_param',
				__( 'Food item ID must be a positive integer.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		return true;
	}

	/**
	 * Validate page parameter.
	 *
	 * @param mixed           $value   Parameter value.
	 * @param WP_REST_Request $request Current request.
	 * @param string          $param   Parameter key name.
	 * @return bool|WP_Error
	 */
	public function validate_page_param( mixed $value, WP_REST_Request $request, string $param ): bool|WP_Error {
		if ( ! is_numeric( $value ) || (int) $value < 1 ) {
			return new WP_Error(
				'rest_invalid_param',
				__( 'The page parameter must be a positive integer greater than or equal to 1.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		return true;
	}

	/**
	 * Validate per_page parameter.
	 *
	 * @param mixed           $value   Parameter value.
	 * @param WP_REST_Request $request Current request.
	 * @param string          $param   Parameter key name.
	 * @return bool|WP_Error
	 */
	public function validate_per_page_param( mixed $value, WP_REST_Request $request, string $param ): bool|WP_Error {
		if ( ! is_numeric( $value ) || (int) $value < 1 || (int) $value > 50 ) {
			return new WP_Error(
				'rest_invalid_param',
				__( 'The per_page parameter must be an integer between 1 and 50.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		return true;
	}

	/**
	 * Validate selection parameter as an associative array/object.
	 *
	 * @param mixed           $value   Parameter value.
	 * @param WP_REST_Request $request Current request.
	 * @param string          $param   Parameter key name.
	 * @return bool|WP_Error
	 */
	public function validate_selection_param( mixed $value, WP_REST_Request $request, string $param ): bool|WP_Error {
		if ( ! is_array( $value ) ) {
			return new WP_Error(
				VariationMatrixResolver::ERROR_INVALID_SELECTION,
				__( 'Selection must be an object/associative array.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		return true;
	}

	/**
	 * Validate optional selection parameter.
	 *
	 * @param mixed           $value   Parameter value.
	 * @param WP_REST_Request $request Current request.
	 * @param string          $param   Parameter key name.
	 * @return bool|WP_Error
	 */
	public function validate_optional_selection_param( mixed $value, WP_REST_Request $request, string $param ): bool|WP_Error {
		if ( null !== $value && ! is_array( $value ) ) {
			return new WP_Error(
				VariationMatrixResolver::ERROR_INVALID_SELECTION,
				__( 'Selection must be an object/associative array.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		return true;
	}

	/**
	 * Check whether the normalized food item record is publicly visible.
	 *
	 * @param array $food_item Normalized food item record.
	 * @return bool
	 */
	private function is_publicly_visible( array $food_item ): bool {
		return isset( $food_item['status'] ) && 'publish' === $food_item['status'];
	}

	/**
	 * Resolve an array of cart lines into safe presentation objects.
	 *
	 * Read-only query endpoint. Does NOT mutate cart state, persist data, or calculate prices.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response
	 */
	public function resolve_cart_lines( WP_REST_Request $request ): WP_REST_Response {
		$lines = $request->get_param( 'lines' );
		if ( ! is_array( $lines ) ) {
			return $this->respond_error(
				'invalid_cart_lines',
				__( 'Lines parameter must be an array of cart line objects.', 'maktomine-restaurant-core' ),
				400
			);
		}

		$resolver = new CartItemPresentationResolver( $this->catalog_service );
		$snapshot = $resolver->resolve_cart_snapshot( $lines );

		return $this->respond_success(
			$snapshot,
			__( 'Cart lines resolved successfully.', 'maktomine-restaurant-core' )
		);
	}

	/**
	 * Validate cart lines array parameter.
	 *
	 * @param mixed           $param   Incoming parameter value.
	 * @param WP_REST_Request $request REST request.
	 * @param string          $key     Parameter key.
	 * @return bool|WP_Error
	 */
	public function validate_cart_lines_param( mixed $param, WP_REST_Request $request, string $key ): bool|WP_Error {
		if ( ! is_array( $param ) ) {
			return new WP_Error(
				'invalid_cart_lines',
				__( 'The lines parameter must be an array.', 'maktomine-restaurant-core' )
			);
		}

		if ( count( $param ) > Cart::MAX_CART_LINES ) {
			return new WP_Error(
				'too_many_lines',
				sprintf(
					/* translators: %d: maximum allowable cart lines */
					__( 'Cannot resolve more than %d cart lines in a single request.', 'maktomine-restaurant-core' ),
					Cart::MAX_CART_LINES
				)
			);
		}

		return true;
	}

	/**
	 * Map lower-level service, resolver, and calculator errors to appropriate REST error responses.
	 *
	 * @param WP_Error $error Service error instance.
	 * @return WP_Error
	 */
	private function handle_service_error( WP_Error $error ): WP_Error {
		$code    = $error->get_error_code();
		$message = $error->get_error_message();

		$status = match ( $code ) {
			CatalogService::ERROR_INVALID_FOOD_ID,
			CatalogService::ERROR_INVALID_SLUG,
			CatalogService::ERROR_INVALID_ARGUMENT,
			VariationMatrixResolver::ERROR_INVALID_SELECTION => 400,

			CatalogService::ERROR_FOOD_NOT_FOUND,
			CatalogService::ERROR_INVALID_TYPE => 404,

			VariationMatrixResolver::ERROR_UNKNOWN_ATTRIBUTE,
			VariationMatrixResolver::ERROR_UNKNOWN_OPTION,
			VariationMatrixResolver::ERROR_MISSING_REQUIRED,
			VariationMatrixResolver::ERROR_VARIATION_NOT_FOUND => 422,

			CatalogService::ERROR_INVALID_CATALOG_DATA,
			CatalogService::ERROR_INVALID_SCHEMA,
			VariationMatrixResolver::ERROR_DUPLICATE_COMBINATION,
			PriceCalculator::ERROR_INVALID_BASE_PRICE,
			PriceCalculator::ERROR_INVALID_SALE_PRICE,
			PriceCalculator::ERROR_INVALID_VARIATION_PRICE => 500,

			default => 400,
		};

		return new WP_Error( $code, $message, [ 'status' => $status ] );
	}
}
