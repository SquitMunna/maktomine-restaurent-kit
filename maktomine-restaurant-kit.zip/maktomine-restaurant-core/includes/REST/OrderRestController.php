<?php
/**
 * Order REST Controller.
 *
 * Exposes the public order submission endpoint: POST /maktomine/v1/orders.
 * Coordinates untrusted client request data through Cart hydration,
 * request-scoped CartStateService, idempotency claim orchestration,
 * and the authoritative OrderSubmissionService.
 *
 * Responsibility Boundary:
 * - Owns: REST route registration under maktomine/v1, public permission callback,
 *   untrusted request payload boundary validation, idempotency key extraction (header & body),
 *   canonical request hashing, delegating to OrderIdempotencyService::claim(),
 *   completed response replay, in-flight order reconciliation, mapping domain/service errors to HTTP statuses,
 *   caching public responses upon completion, returning clean, safe success responses.
 * - Excludes: Direct SQL / $wpdb queries, catalog database queries, pricing logic,
 *   order transaction management, cart storage clearing, WhatsApp dispatch, customer account checks.
 *
 * @package Maktomine\RestaurantCore\REST
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\REST;

use Maktomine\RestaurantCore\Capabilities\CapabilityManager;
use Maktomine\RestaurantCore\Cart\Cart;
use Maktomine\RestaurantCore\Cart\CartLine;
use Maktomine\RestaurantCore\Cart\CartStateService;
use Maktomine\RestaurantCore\Cart\CartValidatorService;
use Maktomine\RestaurantCore\Core\Logger;
use Maktomine\RestaurantCore\Orders\Order;
use Maktomine\RestaurantCore\Orders\OrderCreationService;
use Maktomine\RestaurantCore\Orders\OrderIdempotencyService;
use Maktomine\RestaurantCore\Orders\OrderService;
use Maktomine\RestaurantCore\Orders\OrderSubmissionService;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

defined( 'ABSPATH' ) || exit;

/**
 * Class OrderRestController
 */
final class OrderRestController extends BaseRestController {

	/**
	 * Canonical endpoint route names.
	 */
	public const ROUTE_ORDERS             = '/orders';
	public const ROUTE_ADMIN_ORDERS       = '/admin/orders';
	public const ROUTE_ADMIN_ORDER        = '/admin/orders/(?P<id>[a-zA-Z0-9_\-]+)';
	public const ROUTE_ADMIN_ORDER_STATUS = '/admin/orders/(?P<id>[a-zA-Z0-9_\-]+)/status';

	/**
	 * Error codes.
	 */
	public const ERROR_INVALID_REQUEST_BODY      = 'invalid_request_body';
	public const ERROR_INVALID_CART              = 'invalid_cart';
	public const ERROR_INVALID_CUSTOMER          = 'invalid_customer';
	public const ERROR_IDEMPOTENCY_KEY_MISMATCH  = 'idempotency_key_mismatch';
	public const ERROR_IDEMPOTENCY_HASH_MISMATCH = 'idempotency_hash_mismatch';
	public const ERROR_IDEMPOTENCY_PROCESSING    = 'idempotency_conflict_processing';

	/**
	 * Order domain service instance.
	 *
	 * @var OrderService|null
	 */
	private ?OrderService $order_service;

	/**
	 * Order submission application service instance.
	 *
	 * @var OrderSubmissionService|null
	 */
	private ?OrderSubmissionService $order_submission_service;

	/**
	 * Order idempotency domain service instance.
	 *
	 * @var OrderIdempotencyService|null
	 */
	private ?OrderIdempotencyService $order_idempotency_service;

	/**
	 * Constructor.
	 *
	 * @param OrderSubmissionService|null  $order_submission_service  Optional injected submission service.
	 * @param OrderIdempotencyService|null $order_idempotency_service Optional injected idempotency service.
	 * @param OrderService|null            $order_service             Optional injected order domain service.
	 */
	public function __construct(
		?OrderSubmissionService $order_submission_service = null,
		?OrderIdempotencyService $order_idempotency_service = null,
		?OrderService $order_service = null
	) {
		$this->order_submission_service  = $order_submission_service;
		$this->order_idempotency_service = $order_idempotency_service;
		$this->order_service             = $order_service;
	}

	/**
	 * Register order REST routes under maktomine/v1.
	 *
	 * 1. Consumer endpoint: POST /maktomine/v1/orders (Public permission callback)
	 * 2. Administrative endpoint: GET /maktomine/v1/admin/orders (Protected by CapabilityManager::VIEW_ORDERS)
	 * 3. Administrative single-order read: GET /maktomine/v1/admin/orders/{id} (Protected by CapabilityManager::VIEW_ORDERS)
	 * 4. Administrative order status mutation: PATCH /maktomine/v1/admin/orders/{id}/status (Protected by CapabilityManager::MANAGE_ORDERS)
	 *
	 * @return void
	 */
	public function register_routes(): void {
		// 1. Consumer Order Submission (Public)
		register_rest_route(
			$this->namespace,
			self::ROUTE_ORDERS,
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create_order' ],
					'permission_callback' => [ $this, 'public_permission_callback' ],
					'args'                => [
						'cart'            => [
							'description'       => __( 'Serialized cart state containing version and lines.', 'maktomine-restaurant-core' ),
							'type'              => 'object',
							'required'          => true,
							'validate_callback' => [ $this, 'validate_cart_param' ],
						],
						'customer'        => [
							'description'       => __( 'Customer checkout details and fulfillment choices.', 'maktomine-restaurant-core' ),
							'type'              => 'object',
							'required'          => true,
							'validate_callback' => [ $this, 'validate_customer_param' ],
						],
						'idempotency_key' => [
							'description'       => __( 'Optional client idempotency key for deduplication.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => false,
							'validate_callback' => [ $this, 'validate_idempotency_key_param' ],
						],
					],
				],
			]
		);

		// 2. Administrative Multi-Order Listing (Protected)
		register_rest_route(
			$this->namespace,
			self::ROUTE_ADMIN_ORDERS,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_admin_orders' ],
					'permission_callback' => [ $this, 'check_view_orders_permission' ],
					'args'                => [
						'page'       => [
							'description'       => __( 'Current page number (1-indexed).', 'maktomine-restaurant-core' ),
							'type'              => 'integer',
							'default'           => 1,
							'minimum'           => 1,
							'sanitize_callback' => 'absint',
							'validate_callback' => static fn( $val ) => is_numeric( $val ) && (int) $val >= 1,
						],
						'per_page'   => [
							'description'       => __( 'Number of orders per page (bounded between 1 and 100).', 'maktomine-restaurant-core' ),
							'type'              => 'integer',
							'default'           => 20,
							'minimum'           => 1,
							'maximum'           => 100,
							'sanitize_callback' => 'absint',
							'validate_callback' => static fn( $val ) => is_numeric( $val ) && (int) $val >= 1 && (int) $val <= 100,
						],
						'status'     => [
							'description'       => __( 'Filter by lifecycle order status.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_key',
						],
						'type'       => [
							'description'       => __( 'Filter by order fulfillment type (delivery or pickup).', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_key',
						],
						'date_from'  => [
							'description'       => __( 'Filter orders created on or after date (YYYY-MM-DD or YYYY-MM-DD HH:MM:SS).', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						],
						'date_to'    => [
							'description'       => __( 'Filter orders created on or before date (YYYY-MM-DD or YYYY-MM-DD HH:MM:SS).', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						],
						'search'     => [
							'description'       => __( 'Search term across order reference, customer phone, or customer name.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						],
						'orderby'    => [
							'description'       => __( 'Sort field (created_at, id, order_reference, order_status, total_amount).', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'default'           => 'created_at',
							'sanitize_callback' => 'sanitize_key',
						],
						'order'      => [
							'description'       => __( 'Sort direction (ASC or DESC).', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'default'           => 'DESC',
							'sanitize_callback' => static fn( $val ) => strtoupper( trim( (string) $val ) ),
						],
					],
				],
			]
		);

		// 3. Administrative Single-Order Detail (Protected)
		register_rest_route(
			$this->namespace,
			self::ROUTE_ADMIN_ORDER,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_admin_order' ],
					'permission_callback' => [ $this, 'check_view_orders_permission' ],
					'args'                => [
						'id' => [
							'description'       => __( 'Order database ID or unique order reference.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						],
					],
				],
			]
		);

		// 4. Administrative Order Status Transition (Protected)
		register_rest_route(
			$this->namespace,
			self::ROUTE_ADMIN_ORDER_STATUS,
			[
				[
					'methods'             => 'PATCH',
					'callback'            => [ $this, 'update_admin_order_status' ],
					'permission_callback' => [ $this, 'check_manage_orders_permission' ],
					'args'                => [
						'id'         => [
							'description'       => __( 'Order database ID or unique order reference.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						],
						'new_status' => [
							'description'       => __( 'Target lifecycle order status.', 'maktomine-restaurant-core' ),
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_key',
						],
					],
				],
			]
		);
	}

	/**
	 * Verify that user possesses the authoritative restaurant order view capability.
	 *
	 * Enforces CapabilityManager::VIEW_ORDERS ('view_restaurant_orders').
	 *
	 * @param WP_REST_Request $request REST request instance.
	 * @return bool|WP_Error True if authorized, WP_Error with 401 or 403 on authorization failure.
	 */
	public function check_view_orders_permission( WP_REST_Request $request ): bool|WP_Error {
		if ( ! current_user_can( CapabilityManager::VIEW_ORDERS ) ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'You do not have permission to view restaurant orders.', 'maktomine-restaurant-core' ),
				[ 'status' => rest_authorization_required_code() ]
			);
		}

		return true;
	}

	/**
	 * Verify that user possesses the authoritative restaurant order management capability.
	 *
	 * Enforces CapabilityManager::MANAGE_ORDERS ('manage_restaurant_orders').
	 *
	 * @param WP_REST_Request $request REST request instance.
	 * @return bool|WP_Error True if authorized, WP_Error with 401 or 403 on authorization failure.
	 */
	public function check_manage_orders_permission( WP_REST_Request $request ): bool|WP_Error {
		if ( ! current_user_can( CapabilityManager::MANAGE_ORDERS ) ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'You do not have permission to manage restaurant orders.', 'maktomine-restaurant-core' ),
				[ 'status' => rest_authorization_required_code() ]
			);
		}

		return true;
	}

	/**
	 * Handle administrative multi-order list query: GET /maktomine/v1/admin/orders.
	 *
	 * Delegates parameter forwarding strictly to OrderService::get_orders().
	 * Emits standard JSON envelope without unnecessary sensitive detail columns.
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error Response object with items and pagination, or WP_Error.
	 */
	public function get_admin_orders( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$order_service = $this->order_service ?? OrderService::instance();

		// Construct controlled query arguments associative array (no arbitrary request forwarding)
		$query_args = [
			'page'     => max( 1, (int) $request->get_param( 'page' ) ),
			'per_page' => max( 1, min( 100, (int) $request->get_param( 'per_page' ) ) ),
		];

		$status = $request->get_param( 'status' );
		if ( null !== $status && '' !== trim( (string) $status ) ) {
			$query_args['status'] = sanitize_key( (string) $status );
		}

		$type = $request->get_param( 'type' );
		if ( null !== $type && '' !== trim( (string) $type ) ) {
			$query_args['type'] = sanitize_key( (string) $type );
		}

		$date_from = $request->get_param( 'date_from' );
		if ( null !== $date_from && '' !== trim( (string) $date_from ) ) {
			$query_args['date_from'] = sanitize_text_field( trim( (string) $date_from ) );
		}

		$date_to = $request->get_param( 'date_to' );
		if ( null !== $date_to && '' !== trim( (string) $date_to ) ) {
			$query_args['date_to'] = sanitize_text_field( trim( (string) $date_to ) );
		}

		$search = $request->get_param( 'search' );
		if ( null !== $search && '' !== trim( (string) $search ) ) {
			$query_args['search'] = sanitize_text_field( trim( (string) $search ) );
		}

		$orderby = $request->get_param( 'orderby' );
		if ( null !== $orderby && '' !== trim( (string) $orderby ) ) {
			$query_args['orderby'] = sanitize_key( (string) $orderby );
		}

		$order = $request->get_param( 'order' );
		if ( null !== $order && '' !== trim( (string) $order ) ) {
			$query_args['order'] = strtoupper( trim( (string) $order ) );
		}

		$result = $order_service->get_orders( $query_args );

		if ( is_wp_error( $result ) ) {
			return $this->handle_service_error( $result );
		}

		$response_data = [
			'items'        => $result['items'] ?? [],
			'total_items'  => (int) ( $result['total_items'] ?? 0 ),
			'total_pages'  => (int) ( $result['total_pages'] ?? 0 ),
			'current_page' => (int) ( $result['current_page'] ?? 1 ),
			'per_page'     => (int) ( $result['per_page'] ?? 20 ),
		];

		return $this->respond_success(
			$response_data,
			__( 'Orders retrieved successfully.', 'maktomine-restaurant-core' ),
			200
		);
	}

	/**
	 * Handle administrative single-order read query: GET /maktomine/v1/admin/orders/{id}.
	 *
	 * Delegates strictly to OrderService::get_order() or OrderService::get_order_by_reference().
	 * Projects persisted snapshot data excluding internal verification hash and idempotency keys.
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error Response object with order details, or WP_Error.
	 */
	public function get_admin_order( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$order_service  = $this->order_service ?? OrderService::instance();
		$raw_identifier = (string) $request->get_param( 'id' );
		$identifier     = trim( $raw_identifier );

		if ( '' === $identifier ) {
			return new WP_Error(
				'invalid_order_identifier',
				__( 'Order identifier cannot be empty.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		$order = null;
		if ( ctype_digit( $identifier ) ) {
			$order_id = (int) $identifier;
			$order    = $order_service->get_order( $order_id );
		} else {
			$order    = $order_service->get_order_by_reference( $identifier );
		}

		if ( null === $order ) {
			return new WP_Error(
				'order_not_found',
				__( 'Order not found.', 'maktomine-restaurant-core' ),
				[ 'status' => 404 ]
			);
		}

		$detail = $this->format_admin_order_detail( $order );

		return $this->respond_success(
			$detail,
			__( 'Order retrieved successfully.', 'maktomine-restaurant-core' ),
			200
		);
	}

	/**
	 * Handle administrative order status transition: PATCH /maktomine/v1/admin/orders/{id}/status.
	 *
	 * Delegates strictly to OrderService::transition_status().
	 * Enforces domain state machine, capability verification, and concurrency protection at the domain layer.
	 * Returns minimal authoritative post-transition state projection.
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error Response object with updated status snapshot, or WP_Error.
	 */
	public function update_admin_order_status( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$order_service  = $this->order_service ?? OrderService::instance();
		$raw_identifier = (string) $request->get_param( 'id' );
		$identifier     = trim( $raw_identifier );

		if ( '' === $identifier ) {
			return new WP_Error(
				'invalid_order_identifier',
				__( 'Order identifier cannot be empty.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		$order = null;
		if ( ctype_digit( $identifier ) ) {
			$order_id = (int) $identifier;
			$order    = $order_service->get_order( $order_id );
		} else {
			$order    = $order_service->get_order_by_reference( $identifier );
		}

		if ( null === $order ) {
			return new WP_Error(
				'order_not_found',
				__( 'Order not found.', 'maktomine-restaurant-core' ),
				[ 'status' => 404 ]
			);
		}

		$raw_status = $request->get_param( 'new_status' );
		if ( null === $raw_status || ! is_string( $raw_status ) || '' === trim( $raw_status ) ) {
			return new WP_Error(
				'missing_new_status',
				__( 'Target order status parameter ("new_status") is required.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		$target_status = sanitize_key( trim( $raw_status ) );
		if ( '' === $target_status ) {
			return new WP_Error(
				'invalid_new_status',
				__( 'Target order status parameter ("new_status") cannot be empty.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		$order_db_id       = (int) $order->get_id();
		$transition_result = $order_service->transition_status( $order_db_id, $target_status, true );

		if ( is_wp_error( $transition_result ) ) {
			return $this->handle_service_error( $transition_result );
		}

		$updated_order = $order_service->get_order( $order_db_id );
		$order_status  = null !== $updated_order
			? (string) $updated_order->get_order_status()
			: $target_status;

		return $this->respond_success(
			[
				'id'              => $order_db_id,
				'order_reference' => (string) $order->get_order_reference(),
				'order_status'    => $order_status,
			],
			__( 'Order status updated successfully.', 'maktomine-restaurant-core' ),
			200
		);
	}

	/**
	 * Format an Order domain entity into the approved administrative detail presentation projection.
	 *
	 * Excludes internal catalog food IDs, item row IDs, variation IDs, verification hash,
	 * idempotency keys, and customer WhatsApp number.
	 *
	 * @param Order $order Order domain entity.
	 * @return array<string, mixed>
	 */
	private function format_admin_order_detail( Order $order ): array {
		$items = [];
		foreach ( $order->get_items() as $item ) {
			$items[] = [
				'item_name'         => (string) $item->get_item_name(),
				'variation_summary' => null !== $item->get_variation_summary() ? (string) $item->get_variation_summary() : null,
				'addons_summary'    => null !== $item->get_addons_summary() ? (string) $item->get_addons_summary() : null,
				'unit_price'        => (float) $item->get_unit_price(),
				'quantity'          => (int) $item->get_quantity(),
				'line_total'        => (float) $item->get_line_total(),
			];
		}

		return [
			'id'                => (int) ( $order->get_id() ?? 0 ),
			'order_reference'   => (string) $order->get_order_reference(),
			'order_status'      => (string) $order->get_order_status(),
			'order_type'        => (string) $order->get_order_type(),
			'created_at'        => null !== $order->get_created_at() ? (string) $order->get_created_at() : null,
			'updated_at'        => null !== $order->get_updated_at() ? (string) $order->get_updated_at() : null,
			'currency'          => (string) $order->get_currency(),
			'customer_name'     => (string) $order->get_customer_name(),
			'customer_phone'    => (string) $order->get_customer_phone(),
			'delivery_address'  => null !== $order->get_delivery_address() ? (string) $order->get_delivery_address() : null,
			'delivery_area'     => null !== $order->get_delivery_area() ? (string) $order->get_delivery_area() : null,
			'delivery_landmark' => null !== $order->get_delivery_landmark() ? (string) $order->get_delivery_landmark() : null,
			'order_note'        => null !== $order->get_order_note() ? (string) $order->get_order_note() : null,
			'subtotal'          => (float) $order->get_subtotal(),
			'delivery_charge'   => (float) $order->get_delivery_charge(),
			'total_amount'      => (float) $order->get_total_amount(),
			'items'             => $items,
		];
	}

	/**
	 * Handle order submission: POST /maktomine/v1/orders.
	 *
	 * Workflow:
	 * 1. Resolves and validates optional client idempotency key from header and/or body.
	 * 2. Defensively validates presence and types of cart and customer payloads.
	 * 3. Hydrates CartStateService strictly from untrusted serialized cart data (Phase 4B rules).
	 * 4. Transforms REST customer schema to canonical Core customer schema.
	 * 5. If idempotency key is present:
	 *    a. Computes deterministic canonical request digest (SHA-256).
	 *    b. Invokes OrderIdempotencyService::claim().
	 *    c. Evaluates claim result via centralized handler:
	 *       - Replays cached response if previously completed.
	 *       - Reconciles persisted order and replays if in-flight processing crashed or complete() previously failed.
	 *       - Rejects with 400 if request hash mismatches prior attempt.
	 *       - Rejects with 409 Conflict if genuine in-flight processing is active.
	 *       - Resets failed attempts to allow clean retries with concurrency protection.
	 * 6. Invokes OrderSubmissionService::submit() with customer data and idempotency key.
	 * 7. On submission failure, marks idempotency claim failed (if applicable) and maps error.
	 * 8. On success, constructs safe public response without sensitive internals.
	 * 9. If idempotent, marks claim completed. If complete() returns error, attempts immediate
	 *    service-level reconciliation to establish the completed state or returns a 500 error.
	 * 10. Returns standardized HTTP 201 Created success response.
	 *
	 * @param WP_REST_Request $request REST request instance.
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_order( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		// 1. Resolve and validate optional client idempotency key from header and/or body.
		$idempotency_key = $this->resolve_idempotency_key( $request );
		if ( is_wp_error( $idempotency_key ) ) {
			return $idempotency_key;
		}

		$raw_cart     = $request->get_param( 'cart' );
		$raw_customer = $request->get_param( 'customer' );

		// 2. Defensively verify both main payload blocks are associative arrays.
		if ( ! is_array( $raw_cart ) || empty( $raw_cart ) ) {
			return $this->respond_error(
				self::ERROR_INVALID_CART,
				__( 'The cart payload must be a non-empty object.', 'maktomine-restaurant-core' ),
				400
			);
		}

		if ( ! is_array( $raw_customer ) || empty( $raw_customer ) ) {
			return $this->respond_error(
				self::ERROR_INVALID_CUSTOMER,
				__( 'The customer payload must be a non-empty object.', 'maktomine-restaurant-core' ),
				400
			);
		}

		// 3. Hydrate CartStateService strictly from untrusted serialized cart data (Phase 4B rules).
		// Cart::from_array() enforces version check, line limit (25), line structure, SHA-256 hash, and duplicates.
		$request_cart_state = CartStateService::from_array( $raw_cart );
		if ( is_wp_error( $request_cart_state ) ) {
			return $this->handle_service_error( $request_cart_state );
		}

		// 4. Transform REST customer schema to canonical Core customer schema.
		$customer_data = $this->transform_customer_payload( $raw_customer );

		// 5. Idempotency claim and state orchestration (Phase 4Q).
		$idempotency_service = $this->order_idempotency_service ?? OrderIdempotencyService::instance();

		if ( null !== $idempotency_key ) {
			$request_hash = $this->compute_request_hash( $request_cart_state->get_cart(), $customer_data );

			$claim_result = $idempotency_service->claim( $idempotency_key, $request_hash );
			if ( is_wp_error( $claim_result ) ) {
				return $this->handle_service_error( $claim_result );
			}

			$claim_outcome = $this->handle_claim_result(
				$claim_result,
				$idempotency_key,
				$request_hash,
				$idempotency_service
			);

			if ( true !== $claim_outcome ) {
				return $claim_outcome;
			}
		}

		// 6. Coordinate order submission using request-scoped composition.
		// If an OrderSubmissionService was injected (e.g. for testing), use it;
		// otherwise, compose a request-scoped instance encapsulating the hydrated CartStateService.
		$submission_service = $this->order_submission_service ?? new OrderSubmissionService( null, null, $request_cart_state );

		try {
			$result = $submission_service->submit( $customer_data, $idempotency_key );
		} catch ( \Throwable $e ) {
			Logger::error(
				'OrderRestController: Unexpected exception during order submission.',
				[
					'operation'       => 'order_submission_exception',
					'error_category'  => 'unexpected_submission_exception',
					'exception_class' => get_class( $e ),
				]
			);

			if ( null !== $idempotency_key ) {
				$persisted_order = $idempotency_service->find_order_by_idempotency_key( $idempotency_key );
				if ( null === $persisted_order ) {
					$idempotency_service->fail( $idempotency_key );
				}
			}

			return $this->respond_error(
				OrderService::ERROR_ORDER_CREATION_FAILED,
				__( 'Unexpected error occurred during order submission.', 'maktomine-restaurant-core' ),
				500
			);
		}

		// 7. Handle submission failure.
		if ( is_wp_error( $result ) ) {
			if ( null !== $idempotency_key && OrderService::ERROR_IDEMPOTENCY_COLLISION !== $result->get_error_code() ) {
				$idempotency_service->fail( $idempotency_key );
			}

			return $this->handle_service_error( $result );
		}

		if ( ! is_array( $result ) || ! isset( $result['order'] ) || ! ( $result['order'] instanceof Order ) ) {
			Logger::error( 'OrderRestController: OrderSubmissionService returned an invalid result.' );

			if ( null !== $idempotency_key ) {
				$persisted_order = $idempotency_service->find_order_by_idempotency_key( $idempotency_key );
				if ( null === $persisted_order ) {
					$idempotency_service->fail( $idempotency_key );
				}
			}

			return $this->respond_error(
				OrderService::ERROR_ORDER_CREATION_FAILED,
				__( 'Unexpected error occurred during order creation.', 'maktomine-restaurant-core' ),
				500
			);
		}

		$order    = $result['order'];
		$whatsapp = $result['whatsapp'] ?? [];

		// 8. Construct safe, public order submission response.
		// Excludes verification_hash, customer PII, database column names, full snapshots,
		// WhatsApp message body, destination phone, transport credentials, and internal error codes.
		$response_data = [
			'order'    => [
				'id'              => $order->get_id(),
				'order_reference' => $order->get_order_reference(),
				'order_status'    => $order->get_order_status(),
				'currency'        => $order->get_currency(),
				'subtotal'        => $order->get_subtotal(),
				'delivery_charge' => $order->get_delivery_charge(),
				'total_amount'    => $order->get_total_amount(),
			],
			'whatsapp' => [
				'attempted'  => (bool) ( $whatsapp['attempted'] ?? false ),
				'dispatched' => (bool) ( $whatsapp['dispatched'] ?? false ),
				'status'     => (string) ( $whatsapp['status'] ?? OrderSubmissionService::DISPATCH_STATUS_NOT_CONFIGURED ),
			],
		];

		$success_message = __( 'Order submitted successfully.', 'maktomine-restaurant-core' );

		// 9. If idempotent request, mark record completed and cache public response.
		if ( null !== $idempotency_key ) {
			$full_envelope = [
				'success' => true,
				'message' => $success_message,
				'data'    => $response_data,
			];
			$response_json = (string) wp_json_encode( $full_envelope );

			$complete_result = $idempotency_service->complete(
				$idempotency_key,
				(int) $order->get_id(),
				(string) $order->get_order_reference(),
				201,
				$response_json
			);

			if ( is_wp_error( $complete_result ) ) {
				Logger::warning(
					'OrderRestController: Initial complete() returned error, attempting service reconciliation.',
					[
						'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
						'order_id'                => $order->get_id(),
						'error_code'              => $complete_result->get_error_code(),
					]
				);

				// If complete() failed because record is already completed, re-read and replay.
				if ( OrderIdempotencyService::ERROR_INVALID_STATUS_TRANSITION === $complete_result->get_error_code() ) {
					$existing_rec = $idempotency_service->get( $idempotency_key );
					if ( null !== $existing_rec && OrderIdempotencyService::STATUS_COMPLETED === $existing_rec['status'] ) {
						return $this->replay_cached_response( $existing_rec );
					}
				}

				// Attempt immediate service reconciliation.
				$reconcile_res = $idempotency_service->reconcile_order(
					$idempotency_key,
					(int) $order->get_id(),
					(string) $order->get_order_reference(),
					201,
					$response_json
				);

				if ( is_wp_error( $reconcile_res ) ) {
					// Check if reconciliation failed because it's already completed.
					if ( OrderIdempotencyService::ERROR_INVALID_STATUS_TRANSITION === $reconcile_res->get_error_code() ) {
						$existing_rec = $idempotency_service->get( $idempotency_key );
						if ( null !== $existing_rec && OrderIdempotencyService::STATUS_COMPLETED === $existing_rec['status'] ) {
							return $this->replay_cached_response( $existing_rec );
						}
					}

					Logger::error(
						'OrderRestController: Failed to complete or reconcile idempotency record after order creation.',
						[
							'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
							'order_id'                => $order->get_id(),
							'error_code'              => $reconcile_res->get_error_code(),
						]
					);

					return $this->respond_error(
						OrderIdempotencyService::ERROR_STORAGE_FAILED,
						__( 'A database error occurred while finalizing the order request. Please contact support.', 'maktomine-restaurant-core' ),
						500
					);
				} else {
					Logger::info(
						'OrderRestController: Successfully recovered and completed idempotency record via service reconciliation.',
						[
							'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
							'order_id'                => $order->get_id(),
							'order_reference'         => $order->get_order_reference(),
						]
					);
				}
			}
		}

		return $this->respond_success(
			$response_data,
			$success_message,
			201
		);
	}

	/**
	 * Centralized handler for evaluating and resolving an idempotency claim result.
	 *
	 * Handles:
	 * - Hash mismatch -> 400 Bad Request
	 * - Completed state -> Replay cached response
	 * - In-flight processing state -> Check for existing persisted order; reconcile and replay if found, else 409
	 * - Failed state -> Safe retry check, delete, and re-claim
	 * - Claimed state -> returns true to allow proceeding to submission
	 *
	 * @param array<string, mixed>    $claim_result        Result array from OrderIdempotencyService::claim().
	 * @param string                  $idempotency_key     Client idempotency key.
	 * @param string                  $request_hash        Canonical SHA-256 request hash.
	 * @param OrderIdempotencyService $idempotency_service Idempotency service instance.
	 * @return WP_REST_Response|WP_Error|true True if claimed and ready to submit, or response/error to return immediately.
	 */
	private function handle_claim_result(
		array $claim_result,
		string $idempotency_key,
		string $request_hash,
		OrderIdempotencyService $idempotency_service
	): WP_REST_Response|WP_Error|true {
		$claim_status      = (string) ( $claim_result['status'] ?? '' );
		$record            = (array) ( $claim_result['record'] ?? [] );
		$has_hash_mismatch = (bool) ( $claim_result['has_hash_mismatch'] ?? false );

		// Check A: Hash mismatch (payload altered for existing key).
		if ( $has_hash_mismatch || OrderIdempotencyService::STATUS_MISMATCH === $claim_status ) {
			Logger::warning(
				'OrderRestController: Idempotency claim rejected due to payload hash mismatch.',
				[
					'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
				]
			);

			return $this->respond_error(
				self::ERROR_IDEMPOTENCY_HASH_MISMATCH,
				__( 'The provided idempotency key was previously used with a different request payload.', 'maktomine-restaurant-core' ),
				400
			);
		}

		// Check B: Existing completed record -> Replay cached response without re-executing order or dispatch.
		if ( OrderIdempotencyService::STATUS_COMPLETED === $claim_status ) {
			Logger::info(
				'OrderRestController: Idempotency claim completed; replaying authoritative cached response.',
				[
					'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
					'order_id'                => $record['order_id'] ?? null,
					'order_reference'         => $record['order_reference'] ?? null,
				]
			);

			return $this->replay_cached_response( $record );
		}

		// Check C: Existing in-flight processing record -> Attempt reconciliation against persisted order or return 409.
		if ( OrderIdempotencyService::STATUS_PROCESSING === $claim_status ) {
			Logger::info(
				'OrderRestController: Idempotency claim is currently in processing status; evaluating recovery.',
				[
					'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
				]
			);

			return $this->handle_processing_state( $idempotency_key, $idempotency_service );
		}

		// Check D: Existing failed record -> Safely retry via controlled re-claim.
		if ( OrderIdempotencyService::STATUS_FAILED === $claim_status ) {
			Logger::info(
				'OrderRestController: Idempotency claim is in failed status; attempting safe recovery and reclaim.',
				[
					'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
				]
			);

			return $this->handle_failed_state( $idempotency_key, $request_hash, $idempotency_service );
		}

		// Check E: Successfully claimed new in-flight record.
		if ( 'claimed' === $claim_status ) {
			Logger::debug(
				'OrderRestController: New idempotency claim registered in processing state.',
				[
					'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
				]
			);

			return true;
		}

		return $this->respond_error(
			self::ERROR_IDEMPOTENCY_PROCESSING,
			__( 'Unable to process request with this idempotency key. Please retry shortly.', 'maktomine-restaurant-core' ),
			409
		);
	}

	/**
	 * Handle an idempotency record in 'processing' status.
	 *
	 * Checks whether an order was already persisted in wp_maktomine_orders for this idempotency key.
	 * If an order is found:
	 * - Inspects the idempotency record itself via get(). If response_body is already stored,
	 *   replays that authoritative cached response without re-executing or fabricating state.
	 * - If response_body is absent (e.g. prior crash before completion), returns a safe server error
	 *   to avoid fabricating historical WhatsApp dispatch results or emitting an incomplete response.
	 * - Completely bypasses OrderSubmissionService and WhatsAppDispatchService (never submits or dispatches again).
	 * If no order exists, preserves in-flight concurrency protection by returning 409 Conflict.
	 *
	 * @param string                  $idempotency_key     Client idempotency key.
	 * @param OrderIdempotencyService $idempotency_service Idempotency service instance.
	 * @return WP_REST_Response|WP_Error Replay response if order found, or 409 Conflict WP_Error.
	 */
	private function handle_processing_state(
		string $idempotency_key,
		OrderIdempotencyService $idempotency_service
	): WP_REST_Response|WP_Error {
		// Ask OrderIdempotencyService whether the key is already anchored to a persisted order.
		$existing_order = $idempotency_service->find_order_by_idempotency_key( $idempotency_key );

		if ( is_object( $existing_order ) && isset( $existing_order->id, $existing_order->order_reference ) ) {
			// 1. Inspect the idempotency record itself.
			$existing_record = $idempotency_service->get( $idempotency_key );

			// CASE A: Stored response_body exists in idempotency record.
			if ( null !== $existing_record && ! empty( $existing_record['response_body'] ) ) {
				$decoded = json_decode( (string) $existing_record['response_body'], true );
				if (
					is_array( $decoded ) &&
					isset( $decoded['data'] ) &&
					is_array( $decoded['data'] ) &&
					isset( $decoded['data']['order'], $decoded['data']['whatsapp'] ) &&
					is_array( $decoded['data']['order'] ) &&
					is_array( $decoded['data']['whatsapp'] )
				) {
					// If not yet marked completed, reconcile with the authoritative cached body.
					if ( OrderIdempotencyService::STATUS_COMPLETED !== $existing_record['status'] ) {
						$reconcile_res = $idempotency_service->reconcile_order(
							$idempotency_key,
							(int) $existing_order->id,
							(string) $existing_order->order_reference,
							(int) ( $existing_record['response_code'] ?? 201 ),
							(string) $existing_record['response_body']
						);

						if ( is_wp_error( $reconcile_res ) ) {
							$recheck = $idempotency_service->get( $idempotency_key );
							if ( null === $recheck || OrderIdempotencyService::STATUS_COMPLETED !== $recheck['status'] ) {
								Logger::error(
									'OrderRestController: Failed to reconcile idempotency record with cached body.',
									[
										'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
										'order_id'                => (int) $existing_order->id,
										'error_code'              => $reconcile_res->get_error_code(),
									]
								);
								return $this->handle_service_error( $reconcile_res );
							}
						} else {
							Logger::info(
								'OrderRestController: Successfully reconciled idempotency record with authoritative order.',
								[
									'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
									'order_id'                => (int) $existing_order->id,
									'order_reference'         => (string) $existing_order->order_reference,
								]
							);
						}
					}

					return new WP_REST_Response( $decoded, (int) ( $existing_record['response_code'] ?? 201 ) );
				}
			}

			// CASE B: response_body is absent (prior crash before completion).
			// The persistence layer (wp_maktomine_orders) does not store WhatsApp dispatch state.
			// To strictly preserve the Phase 4P contract without fabricating historical WhatsApp state
			// or returning an incomplete 201 envelope, return a safe server error.
			// Never call OrderSubmissionService, never call WhatsAppDispatchService, never create duplicate order.
			Logger::error(
				'OrderRestController: Persisted order found during processing recovery, but idempotency response_body is missing and WhatsApp state cannot be proven.',
				[
					'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
					'order_id'                => (int) $existing_order->id,
				]
			);

			return $this->respond_error(
				OrderIdempotencyService::ERROR_STORAGE_FAILED,
				__( 'A database error occurred while finalizing the order request. Please contact support.', 'maktomine-restaurant-core' ),
				500
			);
		}

		// No order persisted yet: genuine in-flight concurrent processing.
		Logger::warning(
			'OrderRestController: Concurrent in-flight order submission detected; returning 409 conflict.',
			[
				'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
			]
		);

		return $this->respond_error(
			self::ERROR_IDEMPOTENCY_PROCESSING,
			__( 'An order submission with this idempotency key is currently being processed. Please retry shortly.', 'maktomine-restaurant-core' ),
			409
		);
	}

	/**
	 * Handle an idempotency record in 'failed' status with strict concurrency protection.
	 *
	 * Re-reads current state before attempting deletion.
	 * Atomically deletes ONLY records in 'failed' status via delete( $key, STATUS_FAILED ).
	 * Never deletes a completed row or an active processing row.
	 * Re-claims the key authoritatively and evaluates the claim result.
	 *
	 * @param string                  $idempotency_key     Client idempotency key.
	 * @param string                  $request_hash        Canonical SHA-256 request hash.
	 * @param OrderIdempotencyService $idempotency_service Idempotency service instance.
	 * @return WP_REST_Response|WP_Error|true True if new claim established, or response/error to return.
	 */
	private function handle_failed_state(
		string $idempotency_key,
		string $request_hash,
		OrderIdempotencyService $idempotency_service
	): WP_REST_Response|WP_Error|true {
		// 1. Re-read current state before attempting deletion.
		$current = $idempotency_service->get( $idempotency_key );

		if ( null !== $current ) {
			if ( OrderIdempotencyService::STATUS_COMPLETED === $current['status'] ) {
				return $this->replay_cached_response( $current );
			}

			if ( OrderIdempotencyService::STATUS_PROCESSING === $current['status'] ) {
				return $this->handle_processing_state( $idempotency_key, $idempotency_service );
			}

			if ( OrderIdempotencyService::STATUS_FAILED === $current['status'] ) {
				Logger::warning(
					'OrderRestController: Removing prior failed idempotency record to permit clean retry.',
					[
						'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $idempotency_key ),
					]
				);

				// Atomically delete ONLY if still in 'failed' status.
				$delete_res = $idempotency_service->delete_failed( $idempotency_key );
				if ( is_wp_error( $delete_res ) ) {
					// If delete failed due to invalid status transition (concurrent claim changed status), re-read.
					if ( OrderIdempotencyService::ERROR_INVALID_STATUS_TRANSITION === $delete_res->get_error_code() ) {
						$concur = $idempotency_service->get( $idempotency_key );
						if ( null !== $concur ) {
							if ( OrderIdempotencyService::STATUS_COMPLETED === $concur['status'] ) {
								return $this->replay_cached_response( $concur );
							}
							if ( OrderIdempotencyService::STATUS_PROCESSING === $concur['status'] ) {
								return $this->handle_processing_state( $idempotency_key, $idempotency_service );
							}
						}
					}
					return $this->handle_service_error( $delete_res );
				}
			}
		}

		// 2. Re-claim authoritatively using the same canonical request_hash.
		$reclaim = $idempotency_service->claim( $idempotency_key, $request_hash );
		if ( is_wp_error( $reclaim ) ) {
			return $this->handle_service_error( $reclaim );
		}

		$reclaim_status = (string) ( $reclaim['status'] ?? '' );

		// 3. Inspect authoritative claim result:
		// - 'claimed' -> submit exactly once
		if ( 'claimed' === $reclaim_status ) {
			return true;
		}

		// - 'completed' -> replay
		if ( OrderIdempotencyService::STATUS_COMPLETED === $reclaim_status ) {
			return $this->replay_cached_response( (array) ( $reclaim['record'] ?? [] ) );
		}

		// - 'processing' -> reconcile or safe 409
		if ( OrderIdempotencyService::STATUS_PROCESSING === $reclaim_status ) {
			return $this->handle_processing_state( $idempotency_key, $idempotency_service );
		}

		// - 'mismatch' -> 400
		if ( (bool) ( $reclaim['has_hash_mismatch'] ?? false ) || OrderIdempotencyService::STATUS_MISMATCH === $reclaim_status ) {
			return $this->respond_error(
				self::ERROR_IDEMPOTENCY_HASH_MISMATCH,
				__( 'The provided idempotency key was previously used with a different request payload.', 'maktomine-restaurant-core' ),
				400
			);
		}

		return $this->respond_error(
			self::ERROR_IDEMPOTENCY_PROCESSING,
			__( 'Unable to process request with this idempotency key. Please retry shortly.', 'maktomine-restaurant-core' ),
			409
		);
	}

	/**
	 * Resolve and validate the optional client idempotency key from request header and body.
	 *
	 * Rules:
	 * - Reads 'Idempotency-Key' HTTP header.
	 * - Reads optional 'idempotency_key' request body parameter.
	 * - If both are provided and differ, returns deterministic WP_Error (400).
	 * - If neither is provided, returns null (preserving non-idempotent behavior).
	 * - If provided, validates key format (16-64 chars, [A-Za-z0-9_-]).
	 *
	 * @param WP_REST_Request $request Request instance.
	 * @return string|null|WP_Error Resolved key string, null if omitted, or WP_Error on format/mismatch error.
	 */
	private function resolve_idempotency_key( WP_REST_Request $request ): string|null|WP_Error {
		$raw_header = $request->get_header( 'idempotency-key' );
		$raw_body   = $request->get_param( 'idempotency_key' );

		// If neither was provided at all:
		if ( null === $raw_header && null === $raw_body ) {
			return null;
		}

		$header_key = null;
		if ( null !== $raw_header ) {
			$header_trimmed = trim( (string) $raw_header );
			if ( '' === $header_trimmed ) {
				return $this->respond_error(
					OrderIdempotencyService::ERROR_INVALID_KEY,
					__( 'The provided idempotency key is malformed or invalid.', 'maktomine-restaurant-core' ),
					400
				);
			}
			$header_key = $header_trimmed;
		}

		$body_key = null;
		if ( null !== $raw_body ) {
			if ( ! is_string( $raw_body ) ) {
				return $this->respond_error(
					OrderIdempotencyService::ERROR_INVALID_KEY,
					__( 'The provided idempotency key must be a string.', 'maktomine-restaurant-core' ),
					400
				);
			}
			$body_trimmed = trim( $raw_body );
			if ( '' === $body_trimmed ) {
				return $this->respond_error(
					OrderIdempotencyService::ERROR_INVALID_KEY,
					__( 'The provided idempotency key is malformed or invalid.', 'maktomine-restaurant-core' ),
					400
				);
			}
			$body_key = $body_trimmed;
		}

		if ( null !== $header_key && null !== $body_key && $header_key !== $body_key ) {
			return $this->respond_error(
				self::ERROR_IDEMPOTENCY_KEY_MISMATCH,
				__( 'The Idempotency-Key header and idempotency_key body parameter do not match.', 'maktomine-restaurant-core' ),
				400
			);
		}

		$key = $header_key ?? $body_key;

		if ( null !== $key && ! OrderIdempotencyService::is_valid_key( $key ) ) {
			return $this->respond_error(
				OrderIdempotencyService::ERROR_INVALID_KEY,
				__( 'The provided idempotency key is malformed or invalid.', 'maktomine-restaurant-core' ),
				400
			);
		}

		return $key;
	}

	/**
	 * Compute canonical SHA-256 request digest for idempotency verification.
	 *
	 * Strictly deterministic:
	 * - Extracts validated cart lines and sorts them by line_id.
	 * - Sorts transformed customer data keys.
	 * - Excludes ephemeral data, timestamps, transient headers, and the idempotency key itself.
	 * - Returns a 64-character lowercase hexadecimal hash.
	 *
	 * @param Cart                 $cart          Validated hydrated Cart entity.
	 * @param array<string, mixed> $customer_data Transformed canonical customer data.
	 * @return string 64-character lowercase hexadecimal SHA-256 digest.
	 */
	private function compute_request_hash( Cart $cart, array $customer_data ): string {
		$cart_lines = [];
		foreach ( $cart->get_lines() as $line ) {
			$cart_lines[] = [
				'line_id'   => $line->get_line_id(),
				'food_id'   => $line->get_food_id(),
				'selection' => $line->get_selection(),
				'addons'    => $line->get_addons(),
				'quantity'  => $line->get_quantity(),
			];
		}

		usort(
			$cart_lines,
			static fn( array $a, array $b ): int => strcmp( (string) $a['line_id'], (string) $b['line_id'] )
		);

		$canonical_customer = $customer_data;
		ksort( $canonical_customer );

		$canonical_payload = [
			'cart'     => $cart_lines,
			'customer' => $canonical_customer,
		];

		$canonical_json = wp_json_encode( $canonical_payload );

		return hash( 'sha256', (string) $canonical_json );
	}

	/**
	 * Replay a previously cached successful response for a completed idempotency claim.
	 *
	 * Preserves original HTTP status and serialized response body without executing
	 * catalog validation, order transactions, or downstream messaging.
	 *
	 * Strict Phase 4P/4Q Invariant:
	 * If the cached response body is absent, corrupt, or missing required envelope fields
	 * ('data' with 'order' and 'whatsapp'), returns a safe 500 storage error rather than
	 * emitting an incomplete 201 or fabricating downstream state.
	 *
	 * @param array<string, mixed> $record Stored idempotency record.
	 * @return WP_REST_Response|WP_Error
	 */
	private function replay_cached_response( array $record ): WP_REST_Response|WP_Error {
		$cached_code     = (int) ( $record['response_code'] ?? 201 );
		$cached_body     = $record['response_body'] ?? null;
		$idempotency_key = isset( $record['idempotency_key'] ) ? (string) $record['idempotency_key'] : '';

		// Strict Phase 4Q Invariant: Completed claim must correspond to a committed order row.
		// If the committed order does not exist, fail closed with a safe storage error (500).
		$idempotency_service = $this->order_idempotency_service ?? OrderIdempotencyService::instance();
		$committed_order     = ( '' !== $idempotency_key ) ? $idempotency_service->find_order_by_idempotency_key( $idempotency_key ) : null;

		if ( null === $committed_order ) {
			Logger::error(
				'OrderRestController: Database integrity inconsistency detected: completed idempotency claim has no committed order row.',
				[
					'idempotency_correlation' => '' !== $idempotency_key ? OrderIdempotencyService::safe_key_for_log( $idempotency_key ) : '***',
					'order_id'                => $record['order_id'] ?? null,
					'order_reference'         => $record['order_reference'] ?? null,
					'operation'               => 'completed_replay_integrity_check',
				]
			);

			return $this->respond_error(
				OrderIdempotencyService::ERROR_STORAGE_FAILED,
				__( 'A database error occurred while retrieving the completed order response. Please contact support.', 'maktomine-restaurant-core' ),
				500
			);
		}

		if ( is_string( $cached_body ) && '' !== trim( $cached_body ) ) {
			$decoded = json_decode( $cached_body, true );
			if ( is_array( $decoded ) && isset( $decoded['data'] ) && is_array( $decoded['data'] ) ) {
				$data = $decoded['data'];
				// Verify presence of order and whatsapp blocks to guarantee contract conformance.
				if ( isset( $data['order'], $data['whatsapp'] ) && is_array( $data['order'] ) && is_array( $data['whatsapp'] ) ) {
					return new WP_REST_Response( $decoded, $cached_code );
				}
			}
		}

		Logger::error(
			'OrderRestController: Cached response body is corrupt, incomplete, or structurally invalid for completed record.',
			[
				'idempotency_correlation' => '' !== $idempotency_key ? OrderIdempotencyService::safe_key_for_log( $idempotency_key ) : '***',
				'order_id'                => $record['order_id'] ?? null,
			]
		);

		return $this->respond_error(
			OrderIdempotencyService::ERROR_STORAGE_FAILED,
			__( 'A database error occurred while retrieving the completed order response. Please contact support.', 'maktomine-restaurant-core' ),
			500
		);
	}

	/**
	 * Basic schema validation callback for the cart parameter.
	 *
	 * @param mixed           $value   Raw parameter value.
	 * @param WP_REST_Request $request Request instance.
	 * @param string          $param   Parameter key.
	 * @return bool|WP_Error
	 */
	public function validate_cart_param( mixed $value, WP_REST_Request $request, string $param ): bool|WP_Error {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return new WP_Error(
				self::ERROR_INVALID_CART,
				__( 'Cart must be a non-empty object containing version and lines.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		return true;
	}

	/**
	 * Basic schema validation callback for the customer parameter.
	 *
	 * @param mixed           $value   Raw parameter value.
	 * @param WP_REST_Request $request Request instance.
	 * @param string          $param   Parameter key.
	 * @return bool|WP_Error
	 */
	public function validate_customer_param( mixed $value, WP_REST_Request $request, string $param ): bool|WP_Error {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return new WP_Error(
				self::ERROR_INVALID_CUSTOMER,
				__( 'Customer must be a non-empty object containing contact and fulfillment details.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		return true;
	}

	/**
	 * Basic schema validation callback for the optional idempotency_key parameter.
	 *
	 * @param mixed           $value   Raw parameter value.
	 * @param WP_REST_Request $request Request instance.
	 * @param string          $param   Parameter key.
	 * @return bool|WP_Error
	 */
	public function validate_idempotency_key_param( mixed $value, WP_REST_Request $request, string $param ): bool|WP_Error {
		if ( null === $value || '' === $value ) {
			return true;
		}

		if ( ! is_string( $value ) || ! OrderIdempotencyService::is_valid_key( trim( $value ) ) ) {
			return new WP_Error(
				OrderIdempotencyService::ERROR_INVALID_KEY,
				__( 'The provided idempotency key is malformed or invalid.', 'maktomine-restaurant-core' ),
				[ 'status' => 400 ]
			);
		}

		return true;
	}

	/**
	 * Transform external REST customer payload into canonical Core customer schema.
	 *
	 * Preserves optionality and field presence without performing domain validation.
	 * Authoritative validation and sanitization remain the exclusive responsibility of OrderService.
	 *
	 * Mapping:
	 * - name              -> customer_name
	 * - phone             -> customer_phone
	 * - whatsapp          -> customer_whatsapp
	 * - order_type        -> order_type
	 * - delivery_address  -> delivery_address
	 * - delivery_area     -> delivery_area
	 * - delivery_landmark -> delivery_landmark
	 * - order_note        -> order_note
	 *
	 * @param array<string, mixed> $raw_customer Raw customer array from REST request.
	 * @return array<string, mixed> Transformed array conforming to Core customer contract.
	 */
	private function transform_customer_payload( array $raw_customer ): array {
		$customer_data = [];

		// Required or core identity fields.
		if ( array_key_exists( 'name', $raw_customer ) ) {
			$customer_data['customer_name'] = $raw_customer['name'];
		} elseif ( array_key_exists( 'customer_name', $raw_customer ) ) {
			// Backwards compatibility if internal key was directly provided.
			$customer_data['customer_name'] = $raw_customer['customer_name'];
		}

		if ( array_key_exists( 'phone', $raw_customer ) ) {
			$customer_data['customer_phone'] = $raw_customer['phone'];
		} elseif ( array_key_exists( 'customer_phone', $raw_customer ) ) {
			$customer_data['customer_phone'] = $raw_customer['customer_phone'];
		}

		// Optional WhatsApp field.
		if ( array_key_exists( 'whatsapp', $raw_customer ) ) {
			$customer_data['customer_whatsapp'] = $raw_customer['whatsapp'];
		} elseif ( array_key_exists( 'customer_whatsapp', $raw_customer ) ) {
			$customer_data['customer_whatsapp'] = $raw_customer['customer_whatsapp'];
		}

		// Fulfillment & delivery fields.
		if ( array_key_exists( 'order_type', $raw_customer ) ) {
			$customer_data['order_type'] = $raw_customer['order_type'];
		}

		if ( array_key_exists( 'delivery_address', $raw_customer ) ) {
			$customer_data['delivery_address'] = $raw_customer['delivery_address'];
		}

		if ( array_key_exists( 'delivery_area', $raw_customer ) ) {
			$customer_data['delivery_area'] = $raw_customer['delivery_area'];
		}

		if ( array_key_exists( 'delivery_landmark', $raw_customer ) ) {
			$customer_data['delivery_landmark'] = $raw_customer['delivery_landmark'];
		}

		if ( array_key_exists( 'order_note', $raw_customer ) ) {
			$customer_data['order_note'] = $raw_customer['order_note'];
		}

		return $customer_data;
	}

	/**
	 * Map lower-level domain, validator, and persistence errors to standard REST HTTP status codes.
	 *
	 * @param WP_Error $error Domain or service error instance.
	 * @return WP_Error
	 */
	private function handle_service_error( WP_Error $error ): WP_Error {
		$code    = $error->get_error_code();
		$message = $error->get_error_message();

		$status = match ( $code ) {
			// 400 Bad Request: Malformed request, cart structure, version, limits, empty cart, invalid customer inputs, invalid idempotency.
			self::ERROR_INVALID_REQUEST_BODY,
			self::ERROR_INVALID_CART,
			self::ERROR_INVALID_CUSTOMER,
			self::ERROR_IDEMPOTENCY_KEY_MISMATCH,
			self::ERROR_IDEMPOTENCY_HASH_MISMATCH,
			OrderIdempotencyService::ERROR_INVALID_KEY,
			OrderIdempotencyService::ERROR_INVALID_REQUEST_HASH,
			OrderIdempotencyService::ERROR_INVALID_PARAMS,
			OrderService::ERROR_INVALID_IDEMPOTENCY_KEY,
			Cart::ERROR_INVALID_VERSION,
			Cart::ERROR_MALFORMED_CART,
			Cart::ERROR_CART_LINE_LIMIT_EXCEEDED,
			Cart::ERROR_QUANTITY_LIMIT_EXCEEDED,
			CartLine::ERROR_INVALID_FOOD_ID,
			CartLine::ERROR_INVALID_SELECTION,
			CartLine::ERROR_INVALID_ADDONS,
			CartLine::ERROR_INVALID_QUANTITY,
			CartValidatorService::ERROR_INVALID_CART,
			CartValidatorService::ERROR_INVALID_FOOD_ITEM,
			CartValidatorService::ERROR_INVALID_VARIATION_SELECTION,
			CartValidatorService::ERROR_INVALID_ADDON,
			CartValidatorService::ERROR_ADDON_QUANTITY_EXCEEDED,
			CartValidatorService::ERROR_INVALID_QUANTITY,
			OrderCreationService::ERROR_EMPTY_CART,
			OrderService::ERROR_INVALID_VALIDATED_CART,
			OrderService::ERROR_INVALID_CUSTOMER_NAME,
			OrderService::ERROR_INVALID_CUSTOMER_PHONE,
			OrderService::ERROR_INVALID_CUSTOMER_WHATSAPP,
			OrderService::ERROR_INVALID_ORDER_TYPE,
			OrderService::ERROR_INVALID_DELIVERY_ADDRESS,
			OrderService::ERROR_INVALID_ORDER_NOTE,
			OrderService::ERROR_INVALID_STATUS_TRANSITION => 400,

			// 403 Forbidden: Unauthorized management actions.
			OrderService::ERROR_UNAUTHORIZED => 403,

			// 404 Not Found: Missing order.
			OrderService::ERROR_ORDER_NOT_FOUND => 404,

			// 409 Conflict: Catalog state conflicts, in-flight processing, key collisions.
			self::ERROR_IDEMPOTENCY_PROCESSING,
			OrderService::ERROR_IDEMPOTENCY_COLLISION,
			CartValidatorService::ERROR_FOOD_ITEM_UNAVAILABLE,
			CartValidatorService::ERROR_VARIATION_UNAVAILABLE,
			CartValidatorService::ERROR_ADDON_UNAVAILABLE,
			CartValidatorService::ERROR_REQUIRED_ADDON_MISSING => 409,

			// 500 Internal Server Error: System/pricing validation failures, idempotency storage failure, or database persistence errors.
			OrderIdempotencyService::ERROR_STORAGE_FAILED,
			CartValidatorService::ERROR_INVALID_PRICE,
			CartValidatorService::ERROR_CART_VALIDATION_FAILED,
			OrderService::ERROR_ORDER_CREATION_FAILED => 500,

			default => 400,
		};

		return new WP_Error( $code, $message, [ 'status' => $status ] );
	}
}
