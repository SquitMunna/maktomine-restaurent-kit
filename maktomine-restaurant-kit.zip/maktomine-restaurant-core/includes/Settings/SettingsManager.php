<?php
/**
 * Settings Manager Module.
 *
 * @package Maktomine\RestaurantCore\Settings
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Settings;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Contracts\ModuleInterface;

final class SettingsManager implements ModuleInterface {

	public function get_id(): string {
		return 'settings';
	}

	public function register(): void {
		// Register setting with WordPress Settings API for sanitization and security.
		add_action( 'admin_init', [ $this, 'register_settings' ] );
	}

	public function boot(): void {
		// Settings ready.
	}

	/**
	 * Register settings schema with WordPress options API.
	 *
	 * @return void
	 */
	public function register_settings(): void {
		register_setting(
			'maktomine_restaurant_core_settings',
			BusinessInfoRepository::OPTION_KEY,
			[
				'type'              => 'array',
				'description'       => 'Restaurant Business Information and Global Configuration',
				'sanitize_callback' => [ $this, 'sanitize_settings' ],
				'show_in_rest'      => false,
				'default'           => [],
			]
		);
	}

	/**
	 * Sanitization callback for business info.
	 *
	 * @param mixed $input Raw input data.
	 * @return array<string, mixed>
	 */
	public function sanitize_settings( mixed $input ): array {
		if ( ! is_array( $input ) ) {
			return [];
		}

		$clean = [];

		$clean['restaurant_name'] = isset( $input['restaurant_name'] ) ? sanitize_text_field( (string) $input['restaurant_name'] ) : '';
		$clean['tagline']         = isset( $input['tagline'] ) ? sanitize_text_field( (string) $input['tagline'] ) : '';
		$clean['logo_id']         = isset( $input['logo_id'] ) ? absint( $input['logo_id'] ) : 0;
		$clean['address']         = isset( $input['address'] ) ? sanitize_textarea_field( (string) $input['address'] ) : '';
		$clean['city']            = isset( $input['city'] ) ? sanitize_text_field( (string) $input['city'] ) : '';
		$clean['postal_code']     = isset( $input['postal_code'] ) ? sanitize_text_field( (string) $input['postal_code'] ) : '';
		$clean['google_maps_url'] = isset( $input['google_maps_url'] ) ? esc_url_raw( (string) $input['google_maps_url'] ) : '';
		$clean['phone']           = isset( $input['phone'] ) ? sanitize_text_field( (string) $input['phone'] ) : '';
		$clean['whatsapp']        = isset( $input['whatsapp'] ) ? preg_replace( '/[^0-9+]/', '', (string) $input['whatsapp'] ) : '';
		$clean['whatsapp_secondary']= isset( $input['whatsapp_secondary'] ) ? preg_replace( '/[^0-9+]/', '', (string) $input['whatsapp_secondary'] ) : '';
		$clean['email']           = isset( $input['email'] ) ? sanitize_email( (string) $input['email'] ) : '';
		$clean['currency']        = isset( $input['currency'] ) ? sanitize_text_field( (string) $input['currency'] ) : 'USD';
		$clean['currency_symbol'] = isset( $input['currency_symbol'] ) ? sanitize_text_field( (string) $input['currency_symbol'] ) : '$';
		$clean['currency_position'] = isset( $input['currency_position'] ) && in_array( $input['currency_position'], [ 'left', 'right', 'left_space', 'right_space' ], true ) ? $input['currency_position'] : 'left';

		return $clean;
	}
}
