<?php
/**
 * Restaurant Business Information Repository.
 * Authoritative storage and retrieval for core restaurant domain data.
 *
 * @package Maktomine\RestaurantCore\Settings
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Settings;

defined( 'ABSPATH' ) || exit;

final class BusinessInfoRepository {

	public const OPTION_KEY = 'mkt_business_info';

	/**
	 * Default fallback configuration.
	 *
	 * @var array<string, mixed>
	 */
	private static array $defaults = [
		'restaurant_name'   => '',
		'tagline'           => '',
		'logo_id'           => 0,
		'address'           => '',
		'city'              => '',
		'postal_code'       => '',
		'google_maps_url'   => '',
		'phone'             => '',
		'whatsapp'          => '',
		'whatsapp_secondary'=> '',
		'email'             => '',
		'opening_hours'     => [
			'monday'    => [ 'open' => '09:00', 'close' => '22:00', 'closed' => false ],
			'tuesday'   => [ 'open' => '09:00', 'close' => '22:00', 'closed' => false ],
			'wednesday' => [ 'open' => '09:00', 'close' => '22:00', 'closed' => false ],
			'thursday'  => [ 'open' => '09:00', 'close' => '22:00', 'closed' => false ],
			'friday'    => [ 'open' => '09:00', 'close' => '23:00', 'closed' => false ],
			'saturday'  => [ 'open' => '10:00', 'close' => '23:00', 'closed' => false ],
			'sunday'    => [ 'open' => '10:00', 'close' => '21:00', 'closed' => false ],
		],
		'currency'          => 'USD',
		'currency_symbol'   => '$',
		'currency_position' => 'left', // left, right, left_space, right_space
		'social_profiles'   => [
			'facebook'  => '',
			'instagram' => '',
			'tiktok'    => '',
			'youtube'   => '',
			'twitter'   => '',
			'snapchat'  => '',
		],
		'delivery_enabled'  => true,
		'pickup_enabled'    => true,
		'min_order_amount'  => 0.0,
		'free_delivery_threshold' => 0.0,
		'flat_delivery_charge'    => 0.0,
	];

	/**
	 * In-memory cache for fast lookups during request execution.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $cached_data = null;

	/**
	 * Retrieve all business information or a single key.
	 *
	 * @param string|null $key     Specific setting key.
	 * @param mixed       $default Optional default if not found.
	 * @return mixed
	 */
	public static function get( ?string $key = null, mixed $default = null ): mixed {
		if ( null === self::$cached_data ) {
			$stored = get_option( self::OPTION_KEY, [] );
			self::$cached_data = is_array( $stored ) ? wp_parse_args( $stored, self::$defaults ) : self::$defaults;
		}

		if ( null === $key ) {
			return self::$cached_data;
		}

		return self::$cached_data[ $key ] ?? $default;
	}

	/**
	 * Update business information.
	 *
	 * @param array<string, mixed> $data New data array to merge.
	 * @return bool True if saved successfully.
	 */
	public static function update( array $data ): bool {
		$current = self::get();
		$updated = wp_parse_args( $data, $current );

		// Clear memory cache.
		self::$cached_data = $updated;

		return update_option( self::OPTION_KEY, $updated, true );
	}

	/**
	 * Reset to factory defaults.
	 *
	 * @return bool
	 */
	public static function reset_defaults(): bool {
		self::$cached_data = self::$defaults;
		return update_option( self::OPTION_KEY, self::$defaults, true );
	}
}
