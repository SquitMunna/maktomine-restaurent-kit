<?php
/**
 * Food Item Admin Metabox Interface.
 * Server-rendered administration UI for food item metadata, attributes, variations, and add-ons.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Capabilities\CapabilityManager;
use WP_Post;

final class FoodItemAdmin {

	public const NONCE_ACTION = 'maktomine_save_food_item_meta';
	public const NONCE_NAME   = 'mkt_food_item_nonce';

	/**
	 * Register hooks for food item admin metabox and asset handling.
	 *
	 * @return void
	 */
	public static function init(): void {
		add_action( 'add_meta_boxes', [ self::class, 'register_metaboxes' ] );
		add_action( 'save_post_' . PostTypes::FOOD_ITEM_CPT, [ self::class, 'save_metadata' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
		add_action( 'admin_notices', [ self::class, 'display_save_notices' ] );
	}

	/**
	 * Enqueue WordPress Media Library and food item admin script on edit screens only.
	 *
	 * @param string $hook_suffix Current admin screen hook.
	 * @return void
	 */
	public static function enqueue_assets( string $hook_suffix ): void {
		if ( ! in_array( $hook_suffix, [ 'post.php', 'post-new.php' ], true ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || PostTypes::FOOD_ITEM_CPT !== $screen->post_type ) {
			return;
		}

		// Enqueue standard WordPress media manager.
		wp_enqueue_media();

		// Enqueue dedicated vanilla media & schema integration script.
		wp_enqueue_script(
			'maktomine-food-item-admin',
			MAKTOMINE_CORE_URL . 'assets/js/admin-food-item.js',
			[ 'media-editor' ],
			MAKTOMINE_CORE_VERSION,
			true
		);

		// Localize configuration parameters and translation strings.
		wp_localize_script(
			'maktomine-food-item-admin',
			'mktFoodItemConfig',
			[
				'maxAttributes' => FoodSchemaValidator::MAX_ATTRIBUTES,
				'maxVariations' => FoodSchemaValidator::MAX_VARIATIONS,
				'currency'      => function_exists( 'maktomine_get_currency_symbol' ) ? maktomine_get_currency_symbol() : '$',
				'i18n'          => [
					'maxAttributesReached' => __( 'Maximum 3 attributes reached.', 'maktomine-restaurant-core' ),
					'maxVariationsReached' => __( 'Maximum 60 variations reached.', 'maktomine-restaurant-core' ),
					'confirmRemoveAttr'    => __( 'Are you sure you want to remove this attribute and its options?', 'maktomine-restaurant-core' ),
					'noAttributesNotice'   => __( 'Please define attributes with at least one option before adding variations.', 'maktomine-restaurant-core' ),
					'selectOptionPrompt'   => __( '-- Select Option --', 'maktomine-restaurant-core' ),
				],
			]
		);
	}

	/**
	 * Display transient feedback notices following post save (e.g. schema cap warnings).
	 *
	 * @return void
	 */
	public static function display_save_notices(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || PostTypes::FOOD_ITEM_CPT !== $screen->post_type ) {
			return;
		}

		global $post;
		if ( ! $post || ! isset( $post->ID ) ) {
			return;
		}

		$transient_key = 'mkt_food_item_notice_' . (int) $post->ID;
		$notice        = get_transient( $transient_key );
		if ( $notice && is_array( $notice ) ) {
			delete_transient( $transient_key );
			$type    = esc_attr( $notice['type'] ?? 'error' );
			$message = $notice['message'] ?? '';
			printf(
				'<div class="notice notice-%s is-dismissible" style="padding-top:8px;padding-bottom:8px;"><p style="margin:0;line-height:1.6;"><strong>%s</strong></p></div>',
				$type,
				wp_kses_post( $message )
			);
		}
	}

	/**
	 * Register Food Item Details metabox.
	 *
	 * @return void
	 */
	public static function register_metaboxes(): void {
		add_meta_box(
			'mkt_food_item_details',
			__( 'Food Item Settings & Pricing', 'maktomine-restaurant-core' ),
			[ self::class, 'render_metabox' ],
			PostTypes::FOOD_ITEM_CPT,
			'normal',
			'high'
		);
	}

	/**
	 * Render Food Item Details metabox form.
	 *
	 * @param WP_Post $post Current post object.
	 * @return void
	 */
	public static function render_metabox( WP_Post $post ): void {
		// Output security nonce.
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME );

		$currency = function_exists( 'maktomine_get_currency_symbol' ) ? maktomine_get_currency_symbol() : '$';

		// Fetch existing canonical scalar meta values.
		$base_price    = get_post_meta( $post->ID, FoodItemMeta::META_BASE_PRICE, true );
		$base_price    = '' !== $base_price && false !== $base_price ? (float) $base_price : 0.0;

		$sale_price    = get_post_meta( $post->ID, FoodItemMeta::META_SALE_PRICE, true );
		$sale_price    = '' !== $sale_price && false !== $sale_price ? (float) $sale_price : 0.0;

		$availability  = get_post_meta( $post->ID, FoodItemMeta::META_AVAILABILITY_STATUS, true );
		$availability  = ! empty( $availability ) ? (string) $availability : FoodItemMeta::STATUS_IN_STOCK;

		$is_featured   = (int) get_post_meta( $post->ID, FoodItemMeta::META_IS_FEATURED, true );
		$is_popular    = (int) get_post_meta( $post->ID, FoodItemMeta::META_IS_POPULAR, true );

		$prep_time     = (int) get_post_meta( $post->ID, FoodItemMeta::META_PREP_TIME, true );
		$calories      = (int) get_post_meta( $post->ID, FoodItemMeta::META_CALORIES, true );

		$image_id      = (int) get_post_meta( $post->ID, FoodItemMeta::META_IMAGE_ID, true );
		$image_preview = '';
		if ( $image_id > 0 && function_exists( 'wp_get_attachment_image' ) ) {
			$image_preview = wp_get_attachment_image(
				$image_id,
				'thumbnail',
				false,
				[
					'style' => 'max-width:140px;max-height:140px;height:auto;border-radius:4px;border:1px solid #dcdcde;display:block;',
				]
			);
		}

		// Fetch existing structured schemas.
		$raw_attr_schema = get_post_meta( $post->ID, FoodItemMeta::META_ATTRIBUTES_SCHEMA, true );
		$attributes_data = FoodSchemaValidator::parse_attributes_schema( $raw_attr_schema );
		$attributes_list = $attributes_data['attributes'];

		$raw_var_schema  = get_post_meta( $post->ID, FoodItemMeta::META_VARIATIONS_SCHEMA, true );
		$variations_data = FoodSchemaValidator::parse_variations_schema( $raw_var_schema, $raw_attr_schema );
		$variations_list = $variations_data['variations'];

		$raw_addon_schema = get_post_meta( $post->ID, FoodItemMeta::META_ADDONS_SCHEMA, true );
		$addons_data      = FoodSchemaValidator::parse_addons_schema( $raw_addon_schema );
		$addons_list      = $addons_data['addons'];
		?>
		<div class="mkt-food-item-meta-wrap">
			<!-- Hidden marker ensuring schema updates are only processed when the full metabox is submitted -->
			<input type="hidden" name="mkt_food_item_schema_submitted" value="1" />

			<table class="form-table" role="presentation">
				<tbody>
					<!-- SECTION A: PRICING -->
					<tr>
						<th scope="row">
							<label for="mkt_base_price">
								<?php esc_html_e( 'Base Price', 'maktomine-restaurant-core' ); ?> (<?php echo esc_html( $currency ); ?>)
							</label>
						</th>
						<td>
							<input
								type="number"
								name="<?php echo esc_attr( FoodItemMeta::META_BASE_PRICE ); ?>"
								id="mkt_base_price"
								value="<?php echo esc_attr( number_format( $base_price, 2, '.', '' ) ); ?>"
								step="0.01"
								min="0"
								class="regular-text"
							/>
							<p class="description">
								<?php esc_html_e( 'Standard menu price for this item. Must be a non-negative number.', 'maktomine-restaurant-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="mkt_sale_price">
								<?php esc_html_e( 'Sale Price', 'maktomine-restaurant-core' ); ?> (<?php echo esc_html( $currency ); ?>)
							</label>
						</th>
						<td>
							<input
								type="number"
								name="<?php echo esc_attr( FoodItemMeta::META_SALE_PRICE ); ?>"
								id="mkt_sale_price"
								value="<?php echo esc_attr( number_format( $sale_price, 2, '.', '' ) ); ?>"
								step="0.01"
								min="0"
								class="regular-text"
							/>
							<p class="description">
								<?php esc_html_e( 'Promotional discounted price. Enter 0.00 or leave empty if no sale promotion is active.', 'maktomine-restaurant-core' ); ?>
							</p>
						</td>
					</tr>

					<!-- SECTION B: AVAILABILITY -->
					<tr>
						<th scope="row">
							<label for="mkt_availability_status">
								<?php esc_html_e( 'Availability Status', 'maktomine-restaurant-core' ); ?>
							</label>
						</th>
						<td>
							<select
								name="<?php echo esc_attr( FoodItemMeta::META_AVAILABILITY_STATUS ); ?>"
								id="mkt_availability_status"
								class="regular-text"
							>
								<option value="<?php echo esc_attr( FoodItemMeta::STATUS_IN_STOCK ); ?>" <?php selected( $availability, FoodItemMeta::STATUS_IN_STOCK ); ?>>
									<?php esc_html_e( 'In Stock', 'maktomine-restaurant-core' ); ?>
								</option>
								<option value="<?php echo esc_attr( FoodItemMeta::STATUS_OUT_OF_STOCK ); ?>" <?php selected( $availability, FoodItemMeta::STATUS_OUT_OF_STOCK ); ?>>
									<?php esc_html_e( 'Out of Stock', 'maktomine-restaurant-core' ); ?>
								</option>
								<option value="<?php echo esc_attr( FoodItemMeta::STATUS_PRE_ORDER_ONLY ); ?>" <?php selected( $availability, FoodItemMeta::STATUS_PRE_ORDER_ONLY ); ?>>
									<?php esc_html_e( 'Pre-order Only', 'maktomine-restaurant-core' ); ?>
								</option>
							</select>
							<p class="description">
								<?php esc_html_e( 'Controls availability for ordering and menu display.', 'maktomine-restaurant-core' ); ?>
							</p>
						</td>
					</tr>

					<!-- SECTION C: CATALOG FLAGS -->
					<tr>
						<th scope="row">
							<?php esc_html_e( 'Catalog Highlights', 'maktomine-restaurant-core' ); ?>
						</th>
						<td>
							<fieldset>
								<legend class="screen-reader-text">
									<span><?php esc_html_e( 'Catalog Highlights', 'maktomine-restaurant-core' ); ?></span>
								</legend>

								<label for="mkt_is_featured" style="margin-right:20px;">
									<input
										type="checkbox"
										name="<?php echo esc_attr( FoodItemMeta::META_IS_FEATURED ); ?>"
										id="mkt_is_featured"
										value="1"
										<?php checked( 1 === $is_featured ); ?>
									/>
									<?php esc_html_e( 'Featured Item', 'maktomine-restaurant-core' ); ?>
								</label>

								<label for="mkt_is_popular">
									<input
										type="checkbox"
										name="<?php echo esc_attr( FoodItemMeta::META_IS_POPULAR ); ?>"
										id="mkt_is_popular"
										value="1"
										<?php checked( 1 === $is_popular ); ?>
									/>
									<?php esc_html_e( 'Popular / Chef Recommendation', 'maktomine-restaurant-core' ); ?>
								</label>
							</fieldset>
							<p class="description">
								<?php esc_html_e( 'Badges and promotional visibility tags displayed on menu layouts.', 'maktomine-restaurant-core' ); ?>
							</p>
						</td>
					</tr>

					<!-- SECTION D: PREPARATION & NUTRITION -->
					<tr>
						<th scope="row">
							<label for="mkt_prep_time">
								<?php esc_html_e( 'Preparation Time', 'maktomine-restaurant-core' ); ?> (<?php esc_html_e( 'mins', 'maktomine-restaurant-core' ); ?>)
							</label>
						</th>
						<td>
							<input
								type="number"
								name="<?php echo esc_attr( FoodItemMeta::META_PREP_TIME ); ?>"
								id="mkt_prep_time"
								value="<?php echo esc_attr( (string) $prep_time ); ?>"
								step="1"
								min="0"
								class="small-text"
							/>
							<span class="description"><?php esc_html_e( 'Estimated preparation time in minutes.', 'maktomine-restaurant-core' ); ?></span>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="mkt_calories">
								<?php esc_html_e( 'Calories', 'maktomine-restaurant-core' ); ?> (<?php esc_html_e( 'kcal', 'maktomine-restaurant-core' ); ?>)
							</label>
						</th>
						<td>
							<input
								type="number"
								name="<?php echo esc_attr( FoodItemMeta::META_CALORIES ); ?>"
								id="mkt_calories"
								value="<?php echo esc_attr( (string) $calories ); ?>"
								step="1"
								min="0"
								class="small-text"
							/>
							<span class="description"><?php esc_html_e( 'Nutritional calorie count per serving.', 'maktomine-restaurant-core' ); ?></span>
						</td>
					</tr>

					<!-- SECTION E: DEDICATED CATALOG IMAGE -->
					<tr>
						<th scope="row">
							<label for="mkt_image_id">
								<?php esc_html_e( 'Catalog Image', 'maktomine-restaurant-core' ); ?>
							</label>
						</th>
						<td>
							<input
								type="hidden"
								name="<?php echo esc_attr( FoodItemMeta::META_IMAGE_ID ); ?>"
								id="mkt_image_id"
								value="<?php echo esc_attr( (string) $image_id ); ?>"
							/>
							<div id="mkt_image_preview" style="margin-bottom:10px;">
								<?php if ( ! empty( $image_preview ) ) : ?>
									<?php echo $image_preview; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<?php else : ?>
									<span class="description" style="font-style:italic;">
										<?php esc_html_e( 'No catalog image selected.', 'maktomine-restaurant-core' ); ?>
									</span>
								<?php endif; ?>
							</div>

							<button
								type="button"
								class="button button-secondary"
								id="mkt_select_image_btn"
								data-uploader-title="<?php echo esc_attr__( 'Select Food Item Catalog Image', 'maktomine-restaurant-core' ); ?>"
								data-uploader-button-text="<?php echo esc_attr__( 'Set Catalog Image', 'maktomine-restaurant-core' ); ?>"
								data-select-text="<?php echo esc_attr__( 'Select Image', 'maktomine-restaurant-core' ); ?>"
								data-replace-text="<?php echo esc_attr__( 'Replace Image', 'maktomine-restaurant-core' ); ?>"
							>
								<?php
								if ( $image_id > 0 ) {
									esc_html_e( 'Replace Image', 'maktomine-restaurant-core' );
								} else {
									esc_html_e( 'Select Image', 'maktomine-restaurant-core' );
								}
								?>
							</button>

							<button
								type="button"
								class="button button-link-delete"
								id="mkt_remove_image_btn"
								data-empty-text="<?php echo esc_attr__( 'No catalog image selected.', 'maktomine-restaurant-core' ); ?>"
								style="<?php echo $image_id > 0 ? 'display:inline-block;margin-left:8px;' : 'display:none;margin-left:8px;'; ?>"
							>
								<?php esc_html_e( 'Remove Image', 'maktomine-restaurant-core' ); ?>
							</button>

							<p class="description" style="margin-top:6px;">
								<?php esc_html_e( 'Dedicated high-resolution food image for menu cards and digital catalog displays.', 'maktomine-restaurant-core' ); ?>
							</p>
						</td>
					</tr>

					<!-- SECTION F1: ATTRIBUTES SCHEMA -->
					<tr>
						<th scope="row">
							<span style="font-weight:600;display:block;"><?php esc_html_e( 'Attributes & Options', 'maktomine-restaurant-core' ); ?></span>
							<span class="description" style="font-weight:normal;display:block;margin-top:4px;">
								<?php esc_html_e( 'Selectable customer dimensions (e.g. Size, Crust, Spice Level). Capped at 3 attributes.', 'maktomine-restaurant-core' ); ?>
							</span>
							<span style="display:inline-block;margin-top:6px;background:#e0e0e0;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">
								<span id="mkt_attr_count"><?php echo esc_html( (string) count( $attributes_list ) ); ?></span> / <?php echo esc_html( (string) FoodSchemaValidator::MAX_ATTRIBUTES ); ?> <?php esc_html_e( 'max', 'maktomine-restaurant-core' ); ?>
							</span>
						</th>
						<td>
							<div id="mkt_attributes_container">
								<?php foreach ( $attributes_list as $attr_idx => $attr_item ) : ?>
									<div class="mkt-attr-card" data-index="<?php echo esc_attr( (string) $attr_idx ); ?>" style="background:#f8f9fa;border:1px solid #ccd0d4;border-radius:6px;padding:12px;margin-bottom:12px;">
										<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
											<strong class="mkt-attr-card-title" style="font-size:13px;"><?php echo esc_html( $attr_item['name'] ); ?></strong>
											<button type="button" class="button button-link-delete mkt-remove-attr-btn">
												<?php esc_html_e( 'Remove Attribute', 'maktomine-restaurant-core' ); ?>
											</button>
										</div>
										<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:10px;">
											<div style="flex:1;min-width:140px;">
												<label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px;"><?php esc_html_e( 'Name', 'maktomine-restaurant-core' ); ?></label>
												<input type="text" name="mkt_attributes[<?php echo esc_attr( (string) $attr_idx ); ?>][name]" value="<?php echo esc_attr( $attr_item['name'] ); ?>" class="regular-text mkt-attr-name-input" placeholder="e.g. Size" style="width:100%;" required />
											</div>
											<div style="flex:1;min-width:140px;">
												<label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px;"><?php esc_html_e( 'Slug ID', 'maktomine-restaurant-core' ); ?></label>
												<input type="text" name="mkt_attributes[<?php echo esc_attr( (string) $attr_idx ); ?>][id]" value="<?php echo esc_attr( $attr_item['id'] ); ?>" class="regular-text mkt-attr-id-input" placeholder="e.g. size" style="width:100%;" />
											</div>
											<div style="width:140px;">
												<label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px;"><?php esc_html_e( 'Type', 'maktomine-restaurant-core' ); ?></label>
												<select name="mkt_attributes[<?php echo esc_attr( (string) $attr_idx ); ?>][type]" style="width:100%;">
													<option value="select" <?php selected( $attr_item['type'], 'select' ); ?>><?php esc_html_e( 'Select (Dropdown)', 'maktomine-restaurant-core' ); ?></option>
												</select>
											</div>
											<div style="display:flex;align-items:center;padding-top:20px;">
												<label><input type="checkbox" name="mkt_attributes[<?php echo esc_attr( (string) $attr_idx ); ?>][required]" value="1" <?php checked( $attr_item['required'] ); ?> /> <?php esc_html_e( 'Required', 'maktomine-restaurant-core' ); ?></label>
											</div>
										</div>

										<div style="margin-top:10px;">
											<strong style="font-size:12px;display:block;margin-bottom:4px;"><?php esc_html_e( 'Options:', 'maktomine-restaurant-core' ); ?></strong>
											<table class="widefat fixed striped mkt-options-table" style="max-width:650px;margin-bottom:6px;">
												<thead>
													<tr>
														<th><?php esc_html_e( 'Option Label', 'maktomine-restaurant-core' ); ?></th>
														<th><?php esc_html_e( 'Option Slug ID', 'maktomine-restaurant-core' ); ?></th>
														<th style="width:70px;"><?php esc_html_e( 'Action', 'maktomine-restaurant-core' ); ?></th>
													</tr>
												</thead>
												<tbody class="mkt-options-tbody">
													<?php foreach ( $attr_item['options'] as $opt_idx => $opt ) : ?>
														<tr class="mkt-opt-row" data-opt-index="<?php echo esc_attr( (string) $opt_idx ); ?>">
															<td><input type="text" name="mkt_attributes[<?php echo esc_attr( (string) $attr_idx ); ?>][options][<?php echo esc_attr( (string) $opt_idx ); ?>][label]" value="<?php echo esc_attr( $opt['label'] ); ?>" class="mkt-opt-label-input" placeholder="e.g. Small" style="width:100%;" required /></td>
															<td><input type="text" name="mkt_attributes[<?php echo esc_attr( (string) $attr_idx ); ?>][options][<?php echo esc_attr( (string) $opt_idx ); ?>][id]" value="<?php echo esc_attr( $opt['id'] ); ?>" class="mkt-opt-id-input" placeholder="e.g. small" style="width:100%;" /></td>
															<td><button type="button" class="button button-link-delete mkt-remove-opt-btn"><?php esc_html_e( 'Remove', 'maktomine-restaurant-core' ); ?></button></td>
														</tr>
													<?php endforeach; ?>
												</tbody>
											</table>
											<button type="button" class="button button-secondary mkt-add-opt-btn">+ <?php esc_html_e( 'Add Option', 'maktomine-restaurant-core' ); ?></button>
										</div>
									</div>
								<?php endforeach; ?>
							</div>

							<button
								type="button"
								class="button button-secondary"
								id="mkt_add_attribute_btn"
								<?php echo count( $attributes_list ) >= FoodSchemaValidator::MAX_ATTRIBUTES ? 'disabled' : ''; ?>
							>
								+ <?php esc_html_e( 'Add Attribute', 'maktomine-restaurant-core' ); ?>
							</button>
						</td>
					</tr>

					<!-- SECTION F2: VARIATIONS MATRIX -->
					<tr>
						<th scope="row">
							<span style="font-weight:600;display:block;"><?php esc_html_e( 'Variations Matrix', 'maktomine-restaurant-core' ); ?></span>
							<span class="description" style="font-weight:normal;display:block;margin-top:4px;">
								<?php esc_html_e( 'Price-bearing combinations and stock status. Capped at 60 variations.', 'maktomine-restaurant-core' ); ?>
							</span>
							<span style="display:inline-block;margin-top:6px;background:#e0e0e0;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">
								<span id="mkt_var_count"><?php echo esc_html( (string) count( $variations_list ) ); ?></span> / <?php echo esc_html( (string) FoodSchemaValidator::MAX_VARIATIONS ); ?> <?php esc_html_e( 'max', 'maktomine-restaurant-core' ); ?>
							</span>
						</th>
						<td>
							<table class="widefat fixed striped" id="mkt_variations_table" style="margin-bottom:10px;">
								<thead>
									<tr>
										<th style="width:180px;"><?php esc_html_e( 'Variation Slug ID', 'maktomine-restaurant-core' ); ?></th>
										<th><?php esc_html_e( 'Attribute Combination', 'maktomine-restaurant-core' ); ?></th>
										<th style="width:105px;"><?php esc_html_e( 'Price', 'maktomine-restaurant-core' ); ?> (<?php echo esc_html( $currency ); ?>)</th>
										<th style="width:130px;"><?php esc_html_e( 'Availability', 'maktomine-restaurant-core' ); ?></th>
										<th style="width:70px;"><?php esc_html_e( 'Action', 'maktomine-restaurant-core' ); ?></th>
									</tr>
								</thead>
								<tbody id="mkt_variations_tbody">
									<?php if ( empty( $variations_list ) ) : ?>
										<tr class="mkt-no-vars-row">
											<td colspan="5" style="text-align:center;padding:12px;color:#646970;">
												<?php esc_html_e( 'No variations configured. Base price applies.', 'maktomine-restaurant-core' ); ?>
											</td>
										</tr>
									<?php else : ?>
										<?php foreach ( $variations_list as $var_idx => $var_item ) : ?>
											<tr class="mkt-var-row" data-index="<?php echo esc_attr( (string) $var_idx ); ?>">
												<td>
													<input type="text" name="mkt_variations[<?php echo esc_attr( (string) $var_idx ); ?>][id]" value="<?php echo esc_attr( $var_item['id'] ); ?>" class="mkt-var-id-input" placeholder="e.g. size-small" style="width:100%;" />
												</td>
												<td>
													<div class="mkt-var-attrs-wrap" style="display:flex;gap:8px;flex-wrap:wrap;">
														<?php foreach ( $attributes_list as $attr_item ) : ?>
															<?php
															$attr_id      = (string) $attr_item['id'];
															$selected_opt = isset( $var_item['attributes'][ $attr_id ] ) ? (string) $var_item['attributes'][ $attr_id ] : '';
															?>
															<div class="mkt-var-attr-pair" data-attr-id="<?php echo esc_attr( $attr_id ); ?>" style="font-size:11px;">
																<span style="font-weight:600;display:block;"><?php echo esc_html( $attr_item['name'] ); ?>:</span>
																<select name="mkt_variations[<?php echo esc_attr( (string) $var_idx ); ?>][attributes][<?php echo esc_attr( $attr_id ); ?>]" class="mkt-var-attr-select">
																	<?php foreach ( $attr_item['options'] as $opt ) : ?>
																		<option value="<?php echo esc_attr( $opt['id'] ); ?>" <?php selected( $selected_opt, $opt['id'] ); ?>>
																			<?php echo esc_html( $opt['label'] ); ?>
																		</option>
																	<?php endforeach; ?>
																</select>
															</div>
														<?php endforeach; ?>
													</div>
												</td>
												<td>
													<input type="number" step="0.01" min="0" name="mkt_variations[<?php echo esc_attr( (string) $var_idx ); ?>][price]" value="<?php echo esc_attr( number_format( (float) $var_item['price'], 2, '.', '' ) ); ?>" style="width:100%;" />
												</td>
												<td>
													<select name="mkt_variations[<?php echo esc_attr( (string) $var_idx ); ?>][availability]" style="width:100%;">
														<option value="<?php echo esc_attr( FoodItemMeta::STATUS_IN_STOCK ); ?>" <?php selected( $var_item['availability'], FoodItemMeta::STATUS_IN_STOCK ); ?>>
															<?php esc_html_e( 'In Stock', 'maktomine-restaurant-core' ); ?>
														</option>
														<option value="<?php echo esc_attr( FoodItemMeta::STATUS_OUT_OF_STOCK ); ?>" <?php selected( $var_item['availability'], FoodItemMeta::STATUS_OUT_OF_STOCK ); ?>>
															<?php esc_html_e( 'Out of Stock', 'maktomine-restaurant-core' ); ?>
														</option>
														<option value="<?php echo esc_attr( FoodItemMeta::STATUS_PRE_ORDER_ONLY ); ?>" <?php selected( $var_item['availability'], FoodItemMeta::STATUS_PRE_ORDER_ONLY ); ?>>
															<?php esc_html_e( 'Pre-order Only', 'maktomine-restaurant-core' ); ?>
														</option>
													</select>
												</td>
												<td>
													<button type="button" class="button button-link-delete mkt-remove-var-btn">
														<?php esc_html_e( 'Remove', 'maktomine-restaurant-core' ); ?>
													</button>
												</td>
											</tr>
										<?php endforeach; ?>
									<?php endif; ?>
								</tbody>
							</table>

							<button
								type="button"
								class="button button-secondary"
								id="mkt_add_variation_btn"
								<?php echo count( $variations_list ) >= FoodSchemaValidator::MAX_VARIATIONS ? 'disabled' : ''; ?>
							>
								+ <?php esc_html_e( 'Add Variation Row', 'maktomine-restaurant-core' ); ?>
							</button>
						</td>
					</tr>

					<!-- SECTION F3: CUSTOM ADD-ONS -->
					<tr>
						<th scope="row">
							<span style="font-weight:600;display:block;"><?php esc_html_e( 'Custom Add-ons', 'maktomine-restaurant-core' ); ?></span>
							<span class="description" style="font-weight:normal;display:block;margin-top:4px;">
								<?php esc_html_e( 'Optional extras, toppings, or sides selectable by customers.', 'maktomine-restaurant-core' ); ?>
							</span>
						</th>
						<td>
							<table class="widefat fixed striped" id="mkt_addons_table" style="margin-bottom:10px;">
								<thead>
									<tr>
										<th><?php esc_html_e( 'Add-on Name', 'maktomine-restaurant-core' ); ?></th>
										<th><?php esc_html_e( 'Slug ID', 'maktomine-restaurant-core' ); ?></th>
										<th style="width:105px;"><?php esc_html_e( 'Price', 'maktomine-restaurant-core' ); ?> (<?php echo esc_html( $currency ); ?>)</th>
										<th style="width:75px;"><?php esc_html_e( 'Max Qty', 'maktomine-restaurant-core' ); ?></th>
										<th style="width:70px;text-align:center;"><?php esc_html_e( 'Required', 'maktomine-restaurant-core' ); ?></th>
										<th style="width:130px;"><?php esc_html_e( 'Availability', 'maktomine-restaurant-core' ); ?></th>
										<th style="width:70px;"><?php esc_html_e( 'Action', 'maktomine-restaurant-core' ); ?></th>
									</tr>
								</thead>
								<tbody id="mkt_addons_tbody">
									<?php if ( empty( $addons_list ) ) : ?>
										<tr class="mkt-no-addons-row">
											<td colspan="7" style="text-align:center;padding:12px;color:#646970;">
												<?php esc_html_e( 'No add-ons configured.', 'maktomine-restaurant-core' ); ?>
											</td>
										</tr>
									<?php else : ?>
										<?php foreach ( $addons_list as $addon_idx => $addon_item ) : ?>
											<tr class="mkt-addon-row" data-index="<?php echo esc_attr( (string) $addon_idx ); ?>">
												<td>
													<input type="text" name="mkt_addons[<?php echo esc_attr( (string) $addon_idx ); ?>][name]" value="<?php echo esc_attr( $addon_item['name'] ); ?>" class="mkt-addon-name-input" placeholder="e.g. Extra Cheese" style="width:100%;" required />
												</td>
												<td>
													<input type="text" name="mkt_addons[<?php echo esc_attr( (string) $addon_idx ); ?>][id]" value="<?php echo esc_attr( $addon_item['id'] ); ?>" class="mkt-addon-id-input" placeholder="e.g. extra-cheese" style="width:100%;" />
												</td>
												<td>
													<input type="number" step="0.01" min="0" name="mkt_addons[<?php echo esc_attr( (string) $addon_idx ); ?>][price]" value="<?php echo esc_attr( number_format( (float) $addon_item['price'], 2, '.', '' ) ); ?>" style="width:100%;" />
												</td>
												<td>
													<input type="number" step="1" min="1" name="mkt_addons[<?php echo esc_attr( (string) $addon_idx ); ?>][max_quantity]" value="<?php echo esc_attr( (string) $addon_item['max_quantity'] ); ?>" style="width:100%;" />
												</td>
												<td style="text-align:center;">
													<input type="checkbox" name="mkt_addons[<?php echo esc_attr( (string) $addon_idx ); ?>][required]" value="1" <?php checked( $addon_item['required'] ); ?> />
												</td>
												<td>
													<select name="mkt_addons[<?php echo esc_attr( (string) $addon_idx ); ?>][availability]" style="width:100%;">
														<option value="<?php echo esc_attr( FoodItemMeta::STATUS_IN_STOCK ); ?>" <?php selected( $addon_item['availability'], FoodItemMeta::STATUS_IN_STOCK ); ?>>
															<?php esc_html_e( 'In Stock', 'maktomine-restaurant-core' ); ?>
														</option>
														<option value="<?php echo esc_attr( FoodItemMeta::STATUS_OUT_OF_STOCK ); ?>" <?php selected( $addon_item['availability'], FoodItemMeta::STATUS_OUT_OF_STOCK ); ?>>
															<?php esc_html_e( 'Out of Stock', 'maktomine-restaurant-core' ); ?>
														</option>
														<option value="<?php echo esc_attr( FoodItemMeta::STATUS_PRE_ORDER_ONLY ); ?>" <?php selected( $addon_item['availability'], FoodItemMeta::STATUS_PRE_ORDER_ONLY ); ?>>
															<?php esc_html_e( 'Pre-order Only', 'maktomine-restaurant-core' ); ?>
														</option>
													</select>
												</td>
												<td>
													<button type="button" class="button button-link-delete mkt-remove-addon-btn">
														<?php esc_html_e( 'Remove', 'maktomine-restaurant-core' ); ?>
													</button>
												</td>
											</tr>
										<?php endforeach; ?>
									<?php endif; ?>
								</tbody>
							</table>

							<button type="button" class="button button-secondary" id="mkt_add_addon_btn">
								+ <?php esc_html_e( 'Add Add-on', 'maktomine-restaurant-core' ); ?>
							</button>
						</td>
					</tr>
				</tbody>
			</table>

			<!-- TEMPLATES FOR DYNAMIC ROW CREATION (VANILLA JS) -->
			<template id="mkt_tmpl_attribute">
				<div class="mkt-attr-card" data-index="__ATTR_INDEX__" style="background:#f8f9fa;border:1px solid #ccd0d4;border-radius:6px;padding:12px;margin-bottom:12px;">
					<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
						<strong class="mkt-attr-card-title" style="font-size:13px;"><?php esc_html_e( 'New Attribute', 'maktomine-restaurant-core' ); ?></strong>
						<button type="button" class="button button-link-delete mkt-remove-attr-btn">
							<?php esc_html_e( 'Remove Attribute', 'maktomine-restaurant-core' ); ?>
						</button>
					</div>
					<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:10px;">
						<div style="flex:1;min-width:140px;">
							<label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px;"><?php esc_html_e( 'Name', 'maktomine-restaurant-core' ); ?></label>
							<input type="text" name="mkt_attributes[__ATTR_INDEX__][name]" value="" class="regular-text mkt-attr-name-input" placeholder="e.g. Size" style="width:100%;" required />
						</div>
						<div style="flex:1;min-width:140px;">
							<label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px;"><?php esc_html_e( 'Slug ID', 'maktomine-restaurant-core' ); ?></label>
							<input type="text" name="mkt_attributes[__ATTR_INDEX__][id]" value="" class="regular-text mkt-attr-id-input" placeholder="e.g. size" style="width:100%;" />
						</div>
						<div style="width:140px;">
							<label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px;"><?php esc_html_e( 'Type', 'maktomine-restaurant-core' ); ?></label>
							<select name="mkt_attributes[__ATTR_INDEX__][type]" style="width:100%;">
								<option value="select"><?php esc_html_e( 'Select (Dropdown)', 'maktomine-restaurant-core' ); ?></option>
							</select>
						</div>
						<div style="display:flex;align-items:center;padding-top:20px;">
							<label><input type="checkbox" name="mkt_attributes[__ATTR_INDEX__][required]" value="1" /> <?php esc_html_e( 'Required', 'maktomine-restaurant-core' ); ?></label>
						</div>
					</div>

					<div style="margin-top:10px;">
						<strong style="font-size:12px;display:block;margin-bottom:4px;"><?php esc_html_e( 'Options:', 'maktomine-restaurant-core' ); ?></strong>
						<table class="widefat fixed striped mkt-options-table" style="max-width:650px;margin-bottom:6px;">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Option Label', 'maktomine-restaurant-core' ); ?></th>
									<th><?php esc_html_e( 'Option Slug ID', 'maktomine-restaurant-core' ); ?></th>
									<th style="width:70px;"><?php esc_html_e( 'Action', 'maktomine-restaurant-core' ); ?></th>
								</tr>
							</thead>
							<tbody class="mkt-options-tbody">
								<tr class="mkt-opt-row" data-opt-index="0">
									<td><input type="text" name="mkt_attributes[__ATTR_INDEX__][options][0][label]" value="" class="mkt-opt-label-input" placeholder="e.g. Regular" style="width:100%;" required /></td>
									<td><input type="text" name="mkt_attributes[__ATTR_INDEX__][options][0][id]" value="" class="mkt-opt-id-input" placeholder="e.g. regular" style="width:100%;" /></td>
									<td><button type="button" class="button button-link-delete mkt-remove-opt-btn"><?php esc_html_e( 'Remove', 'maktomine-restaurant-core' ); ?></button></td>
								</tr>
							</tbody>
						</table>
						<button type="button" class="button button-secondary mkt-add-opt-btn">+ <?php esc_html_e( 'Add Option', 'maktomine-restaurant-core' ); ?></button>
					</div>
				</div>
			</template>

			<template id="mkt_tmpl_option">
				<tr class="mkt-opt-row" data-opt-index="__OPT_INDEX__">
					<td><input type="text" name="mkt_attributes[__ATTR_INDEX__][options][__OPT_INDEX__][label]" value="" class="mkt-opt-label-input" placeholder="e.g. Medium" style="width:100%;" required /></td>
					<td><input type="text" name="mkt_attributes[__ATTR_INDEX__][options][__OPT_INDEX__][id]" value="" class="mkt-opt-id-input" placeholder="e.g. medium" style="width:100%;" /></td>
					<td><button type="button" class="button button-link-delete mkt-remove-opt-btn"><?php esc_html_e( 'Remove', 'maktomine-restaurant-core' ); ?></button></td>
				</tr>
			</template>

			<template id="mkt_tmpl_variation">
				<tr class="mkt-var-row" data-index="__VAR_INDEX__">
					<td>
						<input type="text" name="mkt_variations[__VAR_INDEX__][id]" value="" class="mkt-var-id-input" placeholder="e.g. size-medium" style="width:100%;" />
					</td>
					<td>
						<div class="mkt-var-attrs-wrap" style="display:flex;gap:8px;flex-wrap:wrap;">
							<!-- Dynamically populated attribute options -->
						</div>
					</td>
					<td>
						<input type="number" step="0.01" min="0" name="mkt_variations[__VAR_INDEX__][price]" value="0.00" style="width:100%;" />
					</td>
					<td>
						<select name="mkt_variations[__VAR_INDEX__][availability]" style="width:100%;">
							<option value="<?php echo esc_attr( FoodItemMeta::STATUS_IN_STOCK ); ?>"><?php esc_html_e( 'In Stock', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( FoodItemMeta::STATUS_OUT_OF_STOCK ); ?>"><?php esc_html_e( 'Out of Stock', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( FoodItemMeta::STATUS_PRE_ORDER_ONLY ); ?>"><?php esc_html_e( 'Pre-order Only', 'maktomine-restaurant-core' ); ?></option>
						</select>
					</td>
					<td>
						<button type="button" class="button button-link-delete mkt-remove-var-btn">
							<?php esc_html_e( 'Remove', 'maktomine-restaurant-core' ); ?>
						</button>
					</td>
				</tr>
			</template>

			<template id="mkt_tmpl_addon">
				<tr class="mkt-addon-row" data-index="__ADDON_INDEX__">
					<td>
						<input type="text" name="mkt_addons[__ADDON_INDEX__][name]" value="" class="mkt-addon-name-input" placeholder="e.g. Extra Sauce" style="width:100%;" required />
					</td>
					<td>
						<input type="text" name="mkt_addons[__ADDON_INDEX__][id]" value="" class="mkt-addon-id-input" placeholder="e.g. extra-sauce" style="width:100%;" />
					</td>
					<td>
						<input type="number" step="0.01" min="0" name="mkt_addons[__ADDON_INDEX__][price]" value="0.00" style="width:100%;" />
					</td>
					<td>
						<input type="number" step="1" min="1" name="mkt_addons[__ADDON_INDEX__][max_quantity]" value="1" style="width:100%;" />
					</td>
					<td style="text-align:center;">
						<input type="checkbox" name="mkt_addons[__ADDON_INDEX__][required]" value="1" />
					</td>
					<td>
						<select name="mkt_addons[__ADDON_INDEX__][availability]" style="width:100%;">
							<option value="<?php echo esc_attr( FoodItemMeta::STATUS_IN_STOCK ); ?>"><?php esc_html_e( 'In Stock', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( FoodItemMeta::STATUS_OUT_OF_STOCK ); ?>"><?php esc_html_e( 'Out of Stock', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( FoodItemMeta::STATUS_PRE_ORDER_ONLY ); ?>"><?php esc_html_e( 'Pre-order Only', 'maktomine-restaurant-core' ); ?></option>
						</select>
					</td>
					<td>
						<button type="button" class="button button-link-delete mkt-remove-addon-btn">
							<?php esc_html_e( 'Remove', 'maktomine-restaurant-core' ); ?>
						</button>
					</td>
				</tr>
			</template>
		</div>
		<?php
	}

	/**
	 * Secure save post handler for food item metadata, attributes, variations, and add-ons.
	 *
	 * @param int     $post_id Post ID being saved.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public static function save_metadata( int $post_id, WP_Post $post ): void {
		// 1. Verify post type.
		if ( PostTypes::FOOD_ITEM_CPT !== $post->post_type ) {
			return;
		}

		// 2. Prevent autosave or revision corruption.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( function_exists( 'wp_is_post_autosave' ) && wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( function_exists( 'wp_is_post_revision' ) && wp_is_post_revision( $post_id ) ) {
			return;
		}

		// 3. Verify security nonce.
		if ( ! isset( $_POST[ self::NONCE_NAME ] ) ) {
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST[ self::NONCE_NAME ] ) );
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return;
		}

		// 4. Verify user capability.
		if ( ! current_user_can( CapabilityManager::EDIT_FOOD_ITEM, $post_id ) && ! current_user_can( CapabilityManager::MANAGE_MENU ) ) {
			return;
		}

		// 5. Sanitize, normalize, and persist scalar fields using canonical FoodItemMeta methods.
		// Base Price.
		$raw_base_price = isset( $_POST[ FoodItemMeta::META_BASE_PRICE ] )
			? wp_unslash( $_POST[ FoodItemMeta::META_BASE_PRICE ] )
			: 0.0;
		$base_price = FoodItemMeta::sanitize_price( $raw_base_price );
		update_post_meta( $post_id, FoodItemMeta::META_BASE_PRICE, $base_price );

		// Sale Price.
		$raw_sale_price = isset( $_POST[ FoodItemMeta::META_SALE_PRICE ] )
			? wp_unslash( $_POST[ FoodItemMeta::META_SALE_PRICE ] )
			: 0.0;
		$sale_price = FoodItemMeta::sanitize_optional_price( $raw_sale_price );
		update_post_meta( $post_id, FoodItemMeta::META_SALE_PRICE, $sale_price );

		// Availability Status.
		$raw_availability = isset( $_POST[ FoodItemMeta::META_AVAILABILITY_STATUS ] )
			? wp_unslash( $_POST[ FoodItemMeta::META_AVAILABILITY_STATUS ] )
			: FoodItemMeta::STATUS_IN_STOCK;
		$availability = FoodItemMeta::sanitize_availability( $raw_availability );
		update_post_meta( $post_id, FoodItemMeta::META_AVAILABILITY_STATUS, $availability );

		// Featured Flag.
		$raw_featured = isset( $_POST[ FoodItemMeta::META_IS_FEATURED ] )
			? wp_unslash( $_POST[ FoodItemMeta::META_IS_FEATURED ] )
			: 0;
		$is_featured  = FoodItemMeta::sanitize_boolean_int( $raw_featured );
		update_post_meta( $post_id, FoodItemMeta::META_IS_FEATURED, $is_featured );

		// Popular Flag.
		$raw_popular = isset( $_POST[ FoodItemMeta::META_IS_POPULAR ] )
			? wp_unslash( $_POST[ FoodItemMeta::META_IS_POPULAR ] )
			: 0;
		$is_popular  = FoodItemMeta::sanitize_boolean_int( $raw_popular );
		update_post_meta( $post_id, FoodItemMeta::META_IS_POPULAR, $is_popular );

		// Preparation Time.
		$raw_prep_time = isset( $_POST[ FoodItemMeta::META_PREP_TIME ] )
			? wp_unslash( $_POST[ FoodItemMeta::META_PREP_TIME ] )
			: 0;
		$prep_time = FoodItemMeta::sanitize_non_negative_int( $raw_prep_time );
		update_post_meta( $post_id, FoodItemMeta::META_PREP_TIME, $prep_time );

		// Calories.
		$raw_calories = isset( $_POST[ FoodItemMeta::META_CALORIES ] )
			? wp_unslash( $_POST[ FoodItemMeta::META_CALORIES ] )
			: 0;
		$calories = FoodItemMeta::sanitize_non_negative_int( $raw_calories );
		update_post_meta( $post_id, FoodItemMeta::META_CALORIES, $calories );

		// Dedicated Catalog Image Attachment ID.
		$raw_image_id = isset( $_POST[ FoodItemMeta::META_IMAGE_ID ] )
			? wp_unslash( $_POST[ FoodItemMeta::META_IMAGE_ID ] )
			: 0;
		$image_id = FoodItemMeta::sanitize_image_id( $raw_image_id );
		update_post_meta( $post_id, FoodItemMeta::META_IMAGE_ID, $image_id );

		// 6. Sanitize, normalize, and persist structured schema fields.
		// Only mutate schemas when the food item schema editor form was actually submitted.
		if ( isset( $_POST['mkt_food_item_schema_submitted'] ) ) {
			$raw_attributes = isset( $_POST['mkt_attributes'] ) && is_array( $_POST['mkt_attributes'] )
				? wp_unslash( $_POST['mkt_attributes'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				: [];

			$raw_variations = isset( $_POST['mkt_variations'] ) && is_array( $_POST['mkt_variations'] )
				? wp_unslash( $_POST['mkt_variations'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				: [];

			$raw_addons = isset( $_POST['mkt_addons'] ) && is_array( $_POST['mkt_addons'] )
				? wp_unslash( $_POST['mkt_addons'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				: [];

			// Pre-persistence validation across all components.
			$validation = FoodSchemaValidator::validate_submission( $raw_attributes, $raw_variations, $raw_addons );

			if ( ! $validation['valid'] ) {
				// Rejection: do NOT update any schema postmeta! Existing postmeta is strictly preserved.
				set_transient(
					'mkt_food_item_notice_' . $post_id,
					[
						'type'    => 'error',
						'message' => implode( '<br />', array_map( 'esc_html', $validation['errors'] ) ),
					],
					45
				);
			} else {
				// Atomic persistence: ALL components validated, save all 3 schemas together.
				update_post_meta( $post_id, FoodItemMeta::META_ATTRIBUTES_SCHEMA, $validation['attributes_json'] );
				update_post_meta( $post_id, FoodItemMeta::META_VARIATIONS_SCHEMA, $validation['variations_json'] );
				update_post_meta( $post_id, FoodItemMeta::META_ADDONS_SCHEMA, $validation['addons_json'] );
			}
		}
	}
}
