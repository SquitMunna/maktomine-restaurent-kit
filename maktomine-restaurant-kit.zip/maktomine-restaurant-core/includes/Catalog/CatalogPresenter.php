<?php
/**
 * Catalog Presentation Adapter.
 * Lightweight, stateless presentation-data adapter between CatalogService and rendering layers.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

final class CatalogPresenter {

	/**
	 * Transform a normalized food item domain representation into a presentation-safe array.
	 *
	 * Returns data only; NEVER generates HTML markup.
	 *
	 * @param array<string, mixed> $food_item Normalized food item array from CatalogService.
	 * @return array<string, mixed> Presentation-ready food item data structure.
	 */
	public static function present_item( array $food_item ): array {
		$id                  = (int) ( $food_item['id'] ?? 0 );
		$title               = (string) ( $food_item['title'] ?? '' );
		$slug                = (string) ( $food_item['slug'] ?? '' );
		$description         = (string) ( $food_item['description'] ?? '' );
		$short_description   = (string) ( $food_item['short_description'] ?? '' );
		$permalink           = (string) ( $food_item['permalink'] ?? '' );
		$status              = (string) ( $food_item['status'] ?? '' );
		$base_price          = (float) ( $food_item['base_price'] ?? 0.0 );
		$sale_price          = (float) ( $food_item['sale_price'] ?? 0.0 );
		$availability_status = (string) ( $food_item['availability_status'] ?? FoodItemMeta::STATUS_IN_STOCK );
		$is_featured         = (bool) ( $food_item['is_featured'] ?? false );
		$is_popular          = (bool) ( $food_item['is_popular'] ?? false );
		$prep_time           = max( 0, (int) ( $food_item['prep_time'] ?? 0 ) );
		$calories            = max( 0, (int) ( $food_item['calories'] ?? 0 ) );
		$image_id            = max( 0, (int) ( $food_item['image_id'] ?? 0 ) );

		$attributes = isset( $food_item['attributes'] ) && is_array( $food_item['attributes'] ) ? $food_item['attributes'] : [];
		$variations = isset( $food_item['variations'] ) && is_array( $food_item['variations'] ) ? $food_item['variations'] : [];
		$raw_addons = isset( $food_item['addons'] ) && is_array( $food_item['addons'] ) ? $food_item['addons'] : [];
		$categories = isset( $food_item['categories'] ) && is_array( $food_item['categories'] ) ? $food_item['categories'] : [];
		$tags       = isset( $food_item['tags'] ) && is_array( $food_item['tags'] ) ? $food_item['tags'] : [];

		// Presentation-derived flags.
		$has_sale_price = ( $sale_price > 0.0 && $sale_price < $base_price );
		$is_variable    = ! empty( $variations );

		// Price formatting.
		$formatted_base_price = function_exists( 'maktomine_format_price' )
			? maktomine_format_price( $base_price )
			: number_format( $base_price, 2 );

		$formatted_sale_price = $has_sale_price
			? ( function_exists( 'maktomine_format_price' ) ? maktomine_format_price( $sale_price ) : number_format( $sale_price, 2 ) )
			: null;

		// Availability formatting.
		$availability = self::format_availability( $availability_status );

		// Metric formatting.
		$formatted_prep_time = $prep_time > 0
			? sprintf(
				/* translators: %d: Preparation time in minutes */
				__( '%d mins', 'maktomine-restaurant-core' ),
				$prep_time
			)
			: null;

		$formatted_calories = $calories > 0
			? sprintf(
				/* translators: %d: Calorie count */
				__( '%d kcal', 'maktomine-restaurant-core' ),
				$calories
			)
			: null;

		// Image presentation data resolution.
		$image = self::resolve_image_data( $image_id, $title );

		// Add-on presentation formatting (preserves authoritative schema while adding formatted display prices).
		$addons = self::format_addons( $raw_addons );

		return [
			// Direct passthrough from CatalogService.
			'id'                  => $id,
			'title'               => $title,
			'slug'                => $slug,
			'description'         => $description,
			'short_description'   => $short_description,
			'permalink'           => $permalink,
			'status'              => $status,
			'base_price'          => $base_price,
			'sale_price'          => $sale_price,
			'availability_status' => $availability_status,
			'is_featured'         => $is_featured,
			'is_popular'          => $is_popular,
			'prep_time'           => $prep_time,
			'calories'            => $calories,
			'image_id'            => $image_id,
			'attributes'          => $attributes,
			'variations'          => $variations,
			'addons'              => $addons,
			'categories'          => $categories,
			'tags'                => $tags,

			// Formatted / Presentation data.
			'formatted_base_price'=> $formatted_base_price,
			'formatted_sale_price'=> $formatted_sale_price,
			'availability_label'  => $availability['label'],
			'availability_token'  => $availability['token'],
			'formatted_prep_time' => $formatted_prep_time,
			'formatted_calories'  => $formatted_calories,
			'image'               => $image,

			// Presentation-derived convenience.
			'has_sale_price'      => $has_sale_price,
			'is_variable'         => $is_variable,
		];
	}

	/**
	 * Transform a normalized food items collection for presentation.
	 *
	 * Preserves collection structure and pagination metadata while formatting each item.
	 *
	 * @param array<string, mixed> $collection Collection array from CatalogService::get_food_items().
	 * @return array{
	 *     items: array<int, array<string, mixed>>,
	 *     pagination: array<string, mixed>
	 * } Presentation-ready collection structure.
	 */
	public static function present_collection( array $collection ): array {
		$raw_items = isset( $collection['items'] ) && is_array( $collection['items'] ) ? $collection['items'] : [];
		$items     = [];

		foreach ( $raw_items as $item ) {
			if ( is_array( $item ) ) {
				$items[] = self::present_item( $item );
			}
		}

		return [
			'items'      => $items,
			'pagination' => isset( $collection['pagination'] ) && is_array( $collection['pagination'] ) ? $collection['pagination'] : [],
		];
	}

	/**
	 * Format availability status into translated display label and UI token.
	 *
	 * Does NOT evaluate orderability, store hours, cart state, or checkout eligibility.
	 *
	 * @param string $status Raw availability status token.
	 * @return array{
	 *     label: string,
	 *     token: string
	 * }
	 */
	private static function format_availability( string $status ): array {
		return match ( $status ) {
			FoodItemMeta::STATUS_OUT_OF_STOCK => [
				'label' => __( 'Out of Stock', 'maktomine-restaurant-core' ),
				'token' => 'out-of-stock',
			],
			FoodItemMeta::STATUS_PRE_ORDER_ONLY => [
				'label' => __( 'Pre-Order Only', 'maktomine-restaurant-core' ),
				'token' => 'pre-order',
			],
			default => [
				'label' => __( 'In Stock', 'maktomine-restaurant-core' ),
				'token' => 'in-stock',
			],
		};
	}

	/**
	 * Resolve WordPress attachment metadata into structured image presentation data.
	 *
	 * Returns data only; NEVER generates <img> HTML.
	 *
	 * @param int    $image_id WordPress attachment post ID.
	 * @param string $title    Fallback title for image alt attribute.
	 * @return array{
	 *     id: int,
	 *     url: string,
	 *     alt: string,
	 *     width: int|null,
	 *     height: int|null
	 * }
	 */
	private static function resolve_image_data( int $image_id, string $title ): array {
		if ( $image_id <= 0 || ! function_exists( 'wp_get_attachment_image_src' ) ) {
			return [
				'id'     => 0,
				'url'    => '',
				'alt'    => '',
				'width'  => null,
				'height' => null,
			];
		}

		$src = wp_get_attachment_image_src( $image_id, 'full' );
		if ( ! is_array( $src ) || empty( $src[0] ) ) {
			return [
				'id'     => $image_id,
				'url'    => '',
				'alt'    => '',
				'width'  => null,
				'height' => null,
			];
		}

		$alt = function_exists( 'get_post_meta' ) ? (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) : '';
		if ( '' === $alt && '' !== $title ) {
			$alt = $title;
		}

		return [
			'id'     => $image_id,
			'url'    => (string) $src[0],
			'alt'    => $alt,
			'width'  => isset( $src[1] ) && is_numeric( $src[1] ) ? (int) $src[1] : null,
			'height' => isset( $src[2] ) && is_numeric( $src[2] ) ? (int) $src[2] : null,
		];
	}

	/**
	 * Format add-on options for presentation by enriching with localized price display strings.
	 *
	 * Preserves all authoritative schema keys without mutation.
	 *
	 * @param array<int, array<string, mixed>> $addons Normalized add-ons schema array.
	 * @return array<int, array<string, mixed>>
	 */
	private static function format_addons( array $addons ): array {
		$presented_addons = [];

		foreach ( $addons as $addon ) {
			if ( ! is_array( $addon ) ) {
				continue;
			}

			$raw_price       = (float) ( $addon['price'] ?? 0.0 );
			$formatted_price = function_exists( 'maktomine_format_price' )
				? maktomine_format_price( $raw_price )
				: number_format( $raw_price, 2 );

			$presented_addon                    = $addon;
			$presented_addon['formatted_price'] = $formatted_price;

			$presented_addons[] = $presented_addon;
		}

		return $presented_addons;
	}
}
