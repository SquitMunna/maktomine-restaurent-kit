<?php
/**
 * Cart Item Presentation Resolver.
 * Resolves raw BrowserCart line state against canonical Core catalog services into safe presentation data
 * with authoritative server-side pricing.
 *
 * Domain service that coordinates between CatalogService, VariationMatrixResolver, PriceCalculator,
 * and CatalogPresenter to evaluate presentation and pricing snapshots for cart lines without mutating
 * or persisting state.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Cart\CartLine;
use Maktomine\RestaurantCore\Settings\BusinessInfoRepository;
use Maktomine\RestaurantCore\Support\Sanitizer;
use WP_Error;

/**
 * Class CartItemPresentationResolver
 *
 * Coordinates between CatalogService, VariationMatrixResolver, PriceCalculator, and CatalogPresenter
 * to translate BrowserCart lines into rich, safe display structures with authoritative server-side pricing.
 */
final class CartItemPresentationResolver {

	/**
	 * Canonical status constants.
	 */
	public const STATUS_VALID             = 'valid';
	public const STATUS_MISSING           = 'missing';
	public const STATUS_UNPUBLISHED       = 'unpublished';
	public const STATUS_UNAVAILABLE       = 'unavailable';
	public const STATUS_INVALID_VARIATION = 'invalid_variation';
	public const STATUS_INVALID_ADDON     = 'invalid_addon';
	public const STATUS_MALFORMED         = 'malformed';

	/**
	 * Catalog domain service instance.
	 *
	 * @var CatalogService
	 */
	private CatalogService $catalog_service;

	/**
	 * Constructor.
	 *
	 * @param CatalogService|null $catalog_service Optional injected service instance.
	 */
	public function __construct( ?CatalogService $catalog_service = null ) {
		$this->catalog_service = $catalog_service ?? CatalogService::instance();
	}

	/**
	 * Resolve an array of cart lines into a complete authoritative cart snapshot with subtotal and pricing.
	 *
	 * @param array<int, mixed> $lines Array of untrusted cart line arrays from client.
	 * @return array{
	 *     lines: array<int, array<string, mixed>>,
	 *     item_count: int,
	 *     subtotal: float,
	 *     subtotal_formatted: string,
	 *     currency: string,
	 *     currency_symbol: string,
	 *     currency_position: string
	 * }
	 */
	public function resolve_cart_snapshot( array $lines ): array {
		$currency          = (string) BusinessInfoRepository::get( 'currency', 'USD' );
		$currency_symbol   = (string) BusinessInfoRepository::get( 'currency_symbol', '$' );
		$currency_position = (string) BusinessInfoRepository::get( 'currency_position', 'left' );

		if ( '' === trim( $currency ) ) {
			$currency = 'USD';
		}
		if ( '' === trim( $currency_symbol ) ) {
			$currency_symbol = '$';
		}
		if ( ! in_array( $currency_position, [ 'left', 'right', 'left_space', 'right_space' ], true ) ) {
			$currency_position = 'left';
		}

		$resolved_lines   = [];
		$total_item_count = 0;
		$subtotal         = 0.0;

		foreach ( $lines as $line ) {
			if ( ! is_array( $line ) ) {
				$resolved_lines[] = $this->build_malformed_line( '', 0, 0 );
				continue;
			}

			$resolved         = $this->resolve_line( $line );
			$resolved_lines[] = $resolved;

			// Subtotal strictly aggregates valid and available lines with authoritative pricing.
			if ( self::STATUS_VALID === $resolved['status'] && true === $resolved['is_available'] && isset( $resolved['pricing'] ) && is_array( $resolved['pricing'] ) ) {
				$total_item_count += (int) $resolved['quantity'];
				$subtotal          = round( $subtotal + (float) $resolved['pricing']['line_total'], 2 );
			}
		}

		return [
			'lines'              => $resolved_lines,
			'item_count'         => $total_item_count,
			'subtotal'           => $subtotal,
			'subtotal_formatted' => $this->format_money( $subtotal, $currency_symbol, $currency_position ),
			'currency'           => $currency,
			'currency_symbol'    => $currency_symbol,
			'currency_position'  => $currency_position,
		];
	}

	/**
	 * Resolve an array of cart lines into presentation-safe objects.
	 * Preserves backwards compatibility with Phase 4N by returning an array of resolved lines.
	 *
	 * @param array<int, mixed> $lines Array of cart line arrays.
	 * @return array<int, array<string, mixed>> Array of resolved presentation structures.
	 */
	public function resolve_lines( array $lines ): array {
		$snapshot = $this->resolve_cart_snapshot( $lines );
		return $snapshot['lines'];
	}

	/**
	 * Resolve a single cart line into a presentation-safe object with authoritative pricing.
	 *
	 * @param array<string, mixed> $line Untrusted cart line array.
	 * @return array<string, mixed> Resolved presentation structure.
	 */
	public function resolve_line( array $line ): array {
		$line_id  = isset( $line['line_id'] ) && is_string( $line['line_id'] ) ? sanitize_text_field( $line['line_id'] ) : '';
		$food_id  = isset( $line['food_id'] ) && is_numeric( $line['food_id'] ) ? (int) $line['food_id'] : 0;
		$quantity = isset( $line['quantity'] ) && is_numeric( $line['quantity'] ) ? (int) $line['quantity'] : 0;

		// 1. Check for malformed line state or boundary violations.
		if ( '' === $line_id || $food_id <= 0 || $quantity < 1 || $quantity > CartLine::MAX_LINE_QUANTITY ) {
			return $this->build_malformed_line( $line_id, $food_id, max( 0, $quantity ) );
		}

		$raw_selection = isset( $line['selection'] ) && is_array( $line['selection'] ) ? $line['selection'] : [];
		$raw_addons    = isset( $line['addons'] ) && is_array( $line['addons'] ) ? $line['addons'] : [];

		// Authoritative currency resolution.
		$currency          = (string) BusinessInfoRepository::get( 'currency', 'USD' );
		$currency_symbol   = (string) BusinessInfoRepository::get( 'currency_symbol', '$' );
		$currency_position = (string) BusinessInfoRepository::get( 'currency_position', 'left' );

		if ( '' === trim( $currency ) ) {
			$currency = 'USD';
		}
		if ( '' === trim( $currency_symbol ) ) {
			$currency_symbol = '$';
		}
		if ( ! in_array( $currency_position, [ 'left', 'right', 'left_space', 'right_space' ], true ) ) {
			$currency_position = 'left';
		}

		// 2. Query canonical CatalogService.
		$food_item = $this->catalog_service->get_food_item( $food_id );
		if ( is_wp_error( $food_item ) ) {
			return $this->build_missing_line( $line_id, $food_id, $quantity );
		}

		// 3. Check published status (never expose draft or private items to public callers).
		if ( 'publish' !== ( $food_item['status'] ?? '' ) ) {
			return $this->build_unpublished_line( $line_id, $food_id, $quantity );
		}

		// 4. Transform baseline presentation attributes via canonical CatalogPresenter.
		$presented = CatalogPresenter::present_item( $food_item );

		// 5. Check food item stock availability.
		$availability_status = (string) ( $food_item['availability_status'] ?? FoodItemMeta::STATUS_IN_STOCK );
		$is_in_stock         = ( FoodItemMeta::STATUS_IN_STOCK === $availability_status );

		// 6. Resolve variation selections and authoritative variation unit price.
		$item_has_variations = ! empty( $food_item['variations'] );
		$resolved_variations = [];
		$resolved_variation  = null;

		if ( $item_has_variations ) {
			if ( empty( $raw_selection ) ) {
				return $this->build_invalid_variation_line(
					$line_id,
					$food_id,
					$quantity,
					(string) $food_item['title'],
					$presented['image'] ?? null,
					[],
					__( 'Variation selection is required for this item.', 'maktomine-restaurant-core' )
				);
			}

			// Validate and resolve selection through canonical CatalogService and VariationMatrixResolver.
			$variation_resolution = $this->catalog_service->resolve_food_item_selection( $food_id, $raw_selection );
			if ( is_wp_error( $variation_resolution ) || empty( $variation_resolution['matched'] ) ) {
				return $this->build_invalid_variation_line(
					$line_id,
					$food_id,
					$quantity,
					(string) $food_item['title'],
					$presented['image'] ?? null,
					$raw_selection,
					is_wp_error( $variation_resolution ) ? $variation_resolution->get_error_message() : __( 'Selected variation is no longer available.', 'maktomine-restaurant-core' )
				);
			}

			$resolved_variation = $variation_resolution['variation'];

			// Check variation-level availability.
			$var_availability = (string) ( $resolved_variation['availability'] ?? FoodItemMeta::STATUS_IN_STOCK );
			$resolved_variations = $this->resolve_variation_labels( $food_item['attributes'] ?? [], $raw_selection );

			if ( FoodItemMeta::STATUS_IN_STOCK !== $var_availability ) {
				return $this->build_unavailable_line(
					$line_id,
					$food_id,
					$quantity,
					(string) $food_item['title'],
					$presented['image'] ?? null,
					$resolved_variations,
					[],
					__( 'The selected variation is currently out of stock.', 'maktomine-restaurant-core' )
				);
			}

			// Calculate unit price using canonical PriceCalculator (Variation price takes complete precedence).
			$price_calc = PriceCalculator::calculate( $food_item['base_price'], $food_item['sale_price'], $resolved_variation );
		} else {
			// Simple food item: variation selection must be empty.
			if ( ! empty( $raw_selection ) ) {
				return $this->build_invalid_variation_line(
					$line_id,
					$food_id,
					$quantity,
					(string) $food_item['title'],
					$presented['image'] ?? null,
					$raw_selection,
					__( 'This item is not a variable item.', 'maktomine-restaurant-core' )
				);
			}

			// Calculate unit price using canonical PriceCalculator (Sale Price > Base Price).
			$price_calc = PriceCalculator::calculate( $food_item['base_price'], $food_item['sale_price'], null );
		}

		if ( ! $price_calc['success'] ) {
			$err_msg = isset( $price_calc['error']['message'] ) ? (string) $price_calc['error']['message'] : __( 'Failed to determine item price.', 'maktomine-restaurant-core' );
			return $this->build_malformed_line( $line_id, $food_id, $quantity, $err_msg );
		}

		$item_unit_price = (float) $price_calc['price'];

		// 7. Authoritative add-on validation & pricing.
		$catalog_addons_map    = [];
		$required_addon_lookup = [];
		if ( isset( $food_item['addons'] ) && is_array( $food_item['addons'] ) ) {
			foreach ( $food_item['addons'] as $schema_addon ) {
				if ( is_array( $schema_addon ) && isset( $schema_addon['id'] ) ) {
					$aid                       = (string) $schema_addon['id'];
					$catalog_addons_map[ $aid ] = $schema_addon;
					if ( ! empty( $schema_addon['required'] ) ) {
						$required_addon_lookup[ $aid ] = $schema_addon;
					}
				}
			}
		}

		$resolved_addons  = [];
		$addons_unit_cost = 0.0;
		$seen_addon_ids   = [];

		if ( ! empty( $raw_addons ) ) {
			foreach ( $raw_addons as $addon_req ) {
				if (
					! is_array( $addon_req ) ||
					! isset( $addon_req['id'], $addon_req['quantity'] ) ||
					! is_scalar( $addon_req['id'] ) ||
					! is_numeric( $addon_req['quantity'] )
				) {
					return $this->build_invalid_addon_line(
						$line_id,
						$food_id,
						$quantity,
						(string) $food_item['title'],
						$presented['image'] ?? null,
						__( 'Malformed add-on specification.', 'maktomine-restaurant-core' )
					);
				}

				$addon_id  = sanitize_text_field( (string) $addon_req['id'] );
				$addon_qty = (int) $addon_req['quantity'];

				if ( $addon_qty < 1 ) {
					return $this->build_invalid_addon_line(
						$line_id,
						$food_id,
						$quantity,
						(string) $food_item['title'],
						$presented['image'] ?? null,
						__( 'Add-on quantity must be at least 1.', 'maktomine-restaurant-core' )
					);
				}

				// Defensive duplicate protection.
				if ( isset( $seen_addon_ids[ $addon_id ] ) ) {
					return $this->build_invalid_addon_line(
						$line_id,
						$food_id,
						$quantity,
						(string) $food_item['title'],
						$presented['image'] ?? null,
						sprintf(
							/* translators: %s: add-on identifier */
							__( 'Duplicate add-on "%s" in selection.', 'maktomine-restaurant-core' ),
							$addon_id
						)
					);
				}
				$seen_addon_ids[ $addon_id ] = true;

				// Verify existence in authoritative catalog schema.
				if ( ! isset( $catalog_addons_map[ $addon_id ] ) ) {
					return $this->build_invalid_addon_line(
						$line_id,
						$food_id,
						$quantity,
						(string) $food_item['title'],
						$presented['image'] ?? null,
						sprintf(
							/* translators: %s: Addon ID */
							__( 'Add-on "%s" is no longer available.', 'maktomine-restaurant-core' ),
							$addon_id
						)
					);
				}

				$schema_addon = $catalog_addons_map[ $addon_id ];

				// Verify add-on availability.
				$addon_avail = (string) ( $schema_addon['availability'] ?? FoodItemMeta::STATUS_IN_STOCK );
				if ( FoodItemMeta::STATUS_IN_STOCK !== $addon_avail ) {
					return $this->build_invalid_addon_line(
						$line_id,
						$food_id,
						$quantity,
						(string) $food_item['title'],
						$presented['image'] ?? null,
						sprintf(
							/* translators: %s: Addon display name */
							__( 'Add-on "%s" is currently out of stock.', 'maktomine-restaurant-core' ),
							$schema_addon['name'] ?? $addon_id
						)
					);
				}

				// Verify requested quantity against allowable maximum.
				$max_qty = max( 1, (int) ( $schema_addon['max_quantity'] ?? 1 ) );
				if ( $addon_qty > $max_qty ) {
					return $this->build_invalid_addon_line(
						$line_id,
						$food_id,
						$quantity,
						(string) $food_item['title'],
						$presented['image'] ?? null,
						sprintf(
							/* translators: 1: add-on name, 2: requested quantity, 3: maximum quantity */
							__( 'Add-on "%1$s" quantity (%2$d) exceeds allowable maximum of %3$d.', 'maktomine-restaurant-core' ),
							$schema_addon['name'] ?? $addon_id,
							$addon_qty,
							$max_qty
						)
					);
				}

				// Extract authoritative price exclusively from schema.
				$addon_unit_price = Sanitizer::price( $schema_addon['price'] ?? 0.0 );
				$addon_line_total = round( $addon_unit_price * $addon_qty, 2 );
				$addons_unit_cost = round( $addons_unit_cost + $addon_line_total, 2 );

				$resolved_addons[] = [
					'id'                   => $addon_id,
					'name'                 => (string) ( $schema_addon['name'] ?? $addon_id ),
					'quantity'             => $addon_qty,
					'unit_price'           => $addon_unit_price,
					'unit_price_formatted' => $this->format_money( $addon_unit_price, $currency_symbol, $currency_position ),
					'line_total'           => $addon_line_total,
					'line_total_formatted' => $this->format_money( $addon_line_total, $currency_symbol, $currency_position ),
				];
			}
		}

		// Verify all required add-ons are present.
		foreach ( $required_addon_lookup as $req_id => $req_addon ) {
			if ( ! isset( $seen_addon_ids[ $req_id ] ) ) {
				return $this->build_invalid_addon_line(
					$line_id,
					$food_id,
					$quantity,
					(string) $food_item['title'],
					$presented['image'] ?? null,
					sprintf(
						/* translators: %s: add-on name */
						__( 'Required add-on "%s" is missing from selection.', 'maktomine-restaurant-core' ),
						$req_addon['name'] ?? $req_id
					)
				);
			}
		}

		// 8. Handle food item out-of-stock.
		if ( ! $is_in_stock ) {
			return $this->build_unavailable_line(
				$line_id,
				$food_id,
				$quantity,
				(string) $food_item['title'],
				$presented['image'] ?? null,
				$resolved_variations,
				$resolved_addons,
				__( 'This item is currently out of stock.', 'maktomine-restaurant-core' )
			);
		}

		// 9. Authoritative monetary calculations (deterministic 2-decimal arithmetic).
		$effective_line_unit_price = round( $item_unit_price + $addons_unit_cost, 2 );
		$line_total                = round( $effective_line_unit_price * $quantity, 2 );

		return [
			'line_id'            => $line_id,
			'food_id'            => $food_id,
			'title'              => (string) $food_item['title'],
			'image'              => $presented['image'] ?? null,
			'quantity'           => $quantity,
			'status'             => self::STATUS_VALID,
			'is_available'       => true,
			'availability_token' => $presented['availability_token'] ?? 'in-stock',
			'availability_label' => $presented['availability_label'] ?? __( 'In Stock', 'maktomine-restaurant-core' ),
			'variations'         => $resolved_variations,
			'addons'             => $resolved_addons,
			'pricing'            => [
				'currency'                       => $currency,
				'currency_symbol'                => $currency_symbol,
				'currency_position'              => $currency_position,
				'unit_price'                     => $item_unit_price,
				'unit_price_formatted'           => $this->format_money( $item_unit_price, $currency_symbol, $currency_position ),
				'addons_total'                   => $addons_unit_cost,
				'addons_total_formatted'         => $this->format_money( $addons_unit_cost, $currency_symbol, $currency_position ),
				'effective_unit_price'           => $effective_line_unit_price,
				'effective_unit_price_formatted' => $this->format_money( $effective_line_unit_price, $currency_symbol, $currency_position ),
				'line_total'                     => $line_total,
				'line_total_formatted'           => $this->format_money( $line_total, $currency_symbol, $currency_position ),
			],
			'error_message'      => null,
		];
	}

	/**
	 * Format numerical amount into localized currency display string using authoritative settings.
	 *
	 * @param float  $amount   Numeric monetary value.
	 * @param string $symbol   Currency symbol.
	 * @param string $position Currency position.
	 * @return string Formatted localized price string.
	 */
	private function format_money( float $amount, string $symbol, string $position ): string {
		if ( function_exists( 'maktomine_format_price' ) ) {
			return maktomine_format_price( $amount );
		}

		$formatted_number = number_format( $amount, 2, '.', ',' );
		return match ( $position ) {
			'right'       => $formatted_number . $symbol,
			'right_space' => $formatted_number . ' ' . $symbol,
			'left_space'  => $symbol . ' ' . $formatted_number,
			default       => $symbol . $formatted_number,
		};
	}

	/**
	 * Map raw customer selection keys/values to canonical schema attribute and option labels.
	 *
	 * @param array<int, array<string, mixed>> $attributes_schema Catalog attributes schema.
	 * @param array<string, string>            $selection         Raw customer selections.
	 * @return array<int, array<string, string>> Array of resolved variation presentation records.
	 */
	private function resolve_variation_labels( array $attributes_schema, array $selection ): array {
		$resolved = [];

		$schema_map = [];
		foreach ( $attributes_schema as $attr ) {
			if ( ! is_array( $attr ) || ! isset( $attr['id'] ) ) {
				continue;
			}
			$attr_id                = (string) $attr['id'];
			$options_map            = [];
			$raw_options            = isset( $attr['options'] ) && is_array( $attr['options'] ) ? $attr['options'] : [];
			foreach ( $raw_options as $opt ) {
				if ( is_array( $opt ) && isset( $opt['id'] ) ) {
					$options_map[ (string) $opt['id'] ] = (string) ( $opt['name'] ?? $opt['id'] );
				}
			}

			$schema_map[ $attr_id ] = [
				'name'    => (string) ( $attr['name'] ?? $attr_id ),
				'options' => $options_map,
			];
		}

		foreach ( $selection as $attr_id => $opt_id ) {
			if ( ! is_scalar( $attr_id ) || ! is_scalar( $opt_id ) ) {
				continue;
			}

			$attr_id_str = (string) $attr_id;
			$opt_id_str  = (string) $opt_id;

			$attr_name = $schema_map[ $attr_id_str ]['name'] ?? $attr_id_str;
			$opt_name  = $schema_map[ $attr_id_str ]['options'][ $opt_id_str ] ?? $opt_id_str;

			$resolved[] = [
				'attribute_id'    => $attr_id_str,
				'attribute_label' => $attr_name,
				'option_id'       => $opt_id_str,
				'option_label'    => $opt_name,
			];
		}

		return $resolved;
	}

	/**
	 * Construct a presentation record for an unavailable food item or variation.
	 *
	 * @param string                    $line_id
	 * @param int                       $food_id
	 * @param int                       $quantity
	 * @param string                    $title
	 * @param array<string, mixed>|null $image
	 * @param array<int, mixed>         $variations
	 * @param array<int, mixed>         $addons
	 * @param string                    $error_message
	 * @return array<string, mixed>
	 */
	private function build_unavailable_line(
		string $line_id,
		int $food_id,
		int $quantity,
		string $title,
		?array $image,
		array $variations,
		array $addons,
		string $error_message
	): array {
		return [
			'line_id'            => $line_id,
			'food_id'            => $food_id,
			'title'              => $title,
			'image'              => $image,
			'quantity'           => $quantity,
			'status'             => self::STATUS_UNAVAILABLE,
			'is_available'       => false,
			'availability_token' => 'out-of-stock',
			'availability_label' => __( 'Out of Stock', 'maktomine-restaurant-core' ),
			'variations'         => $variations,
			'addons'             => $addons,
			'pricing'            => null,
			'error_message'      => $error_message,
		];
	}

	/**
	 * Construct a presentation record for a malformed cart line.
	 *
	 * @param string      $line_id
	 * @param int         $food_id
	 * @param int         $quantity
	 * @param string|null $error_message Optional custom error message.
	 * @return array<string, mixed>
	 */
	private function build_malformed_line( string $line_id, int $food_id, int $quantity, ?string $error_message = null ): array {
		return [
			'line_id'            => $line_id,
			'food_id'            => $food_id,
			'title'              => __( 'Invalid Cart Line', 'maktomine-restaurant-core' ),
			'image'              => null,
			'quantity'           => $quantity,
			'status'             => self::STATUS_MALFORMED,
			'is_available'       => false,
			'availability_token' => 'malformed',
			'availability_label' => __( 'Invalid Line', 'maktomine-restaurant-core' ),
			'variations'         => [],
			'addons'             => [],
			'pricing'            => null,
			'error_message'      => $error_message ?? __( 'Cart line specification is malformed.', 'maktomine-restaurant-core' ),
		];
	}

	/**
	 * Construct a presentation record for a missing/non-existent food item.
	 *
	 * @param string $line_id
	 * @param int    $food_id
	 * @param int    $quantity
	 * @return array<string, mixed>
	 */
	private function build_missing_line( string $line_id, int $food_id, int $quantity ): array {
		return [
			'line_id'            => $line_id,
			'food_id'            => $food_id,
			'title'              => sprintf(
				/* translators: %d: Food Item ID */
				__( 'Food Item #%d', 'maktomine-restaurant-core' ),
				$food_id
			),
			'image'              => null,
			'quantity'           => $quantity,
			'status'             => self::STATUS_MISSING,
			'is_available'       => false,
			'availability_token' => 'missing',
			'availability_label' => __( 'Item Not Found', 'maktomine-restaurant-core' ),
			'variations'         => [],
			'addons'             => [],
			'pricing'            => null,
			'error_message'      => __( 'This item no longer exists in the catalog.', 'maktomine-restaurant-core' ),
		];
	}

	/**
	 * Construct a presentation record for an unpublished/draft/private food item.
	 * Never exposes private or draft titles to public queries.
	 *
	 * @param string $line_id
	 * @param int    $food_id
	 * @param int    $quantity
	 * @return array<string, mixed>
	 */
	private function build_unpublished_line( string $line_id, int $food_id, int $quantity ): array {
		return [
			'line_id'            => $line_id,
			'food_id'            => $food_id,
			'title'              => sprintf(
				/* translators: %d: Food Item ID */
				__( 'Food Item #%d', 'maktomine-restaurant-core' ),
				$food_id
			),
			'image'              => null,
			'quantity'           => $quantity,
			'status'             => self::STATUS_UNPUBLISHED,
			'is_available'       => false,
			'availability_token' => 'unpublished',
			'availability_label' => __( 'Unavailable', 'maktomine-restaurant-core' ),
			'variations'         => [],
			'addons'             => [],
			'pricing'            => null,
			'error_message'      => __( 'This item is currently unpublished.', 'maktomine-restaurant-core' ),
		];
	}

	/**
	 * Construct a presentation record for an invalid variation selection.
	 *
	 * @param string                    $line_id
	 * @param int                       $food_id
	 * @param int                       $quantity
	 * @param string                    $title
	 * @param array<string, mixed>|null $image
	 * @param array<string, string>     $selection
	 * @param string                    $error_message
	 * @return array<string, mixed>
	 */
	private function build_invalid_variation_line(
		string $line_id,
		int $food_id,
		int $quantity,
		string $title,
		?array $image,
		array $selection,
		string $error_message
	): array {
		// Fallback variation objects with raw keys/values for customer transparency.
		$raw_variations = [];
		foreach ( $selection as $attr_id => $opt_id ) {
			$attr_str = is_scalar( $attr_id ) ? (string) $attr_id : '';
			$opt_str  = is_scalar( $opt_id ) ? (string) $opt_id : '';
			$raw_variations[] = [
				'attribute_id'    => $attr_str,
				'attribute_label' => $attr_str,
				'option_id'       => $opt_str,
				'option_label'    => $opt_str,
			];
		}

		return [
			'line_id'            => $line_id,
			'food_id'            => $food_id,
			'title'              => $title,
			'image'              => $image,
			'quantity'           => $quantity,
			'status'             => self::STATUS_INVALID_VARIATION,
			'is_available'       => false,
			'availability_token' => 'invalid-variation',
			'availability_label' => __( 'Invalid Variation', 'maktomine-restaurant-core' ),
			'variations'         => $raw_variations,
			'addons'             => [],
			'pricing'            => null,
			'error_message'      => $error_message,
		];
	}

	/**
	 * Construct a presentation record for an invalid add-on selection.
	 *
	 * @param string                    $line_id
	 * @param int                       $food_id
	 * @param int                       $quantity
	 * @param string                    $title
	 * @param array<string, mixed>|null $image
	 * @param string                    $error_message
	 * @return array<string, mixed>
	 */
	private function build_invalid_addon_line(
		string $line_id,
		int $food_id,
		int $quantity,
		string $title,
		?array $image,
		string $error_message
	): array {
		return [
			'line_id'            => $line_id,
			'food_id'            => $food_id,
			'title'              => $title,
			'image'              => $image,
			'quantity'           => $quantity,
			'status'             => self::STATUS_INVALID_ADDON,
			'is_available'       => false,
			'availability_token' => 'invalid-addon',
			'availability_label' => __( 'Invalid Add-on', 'maktomine-restaurant-core' ),
			'variations'         => [],
			'addons'             => [],
			'pricing'            => null,
			'error_message'      => $error_message,
		];
	}
}

