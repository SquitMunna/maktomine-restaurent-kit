<?php
/**
 * Custom Post Types Registration Foundation.
 * Registers food items, blocks, reviews, and galleries with explicit capability mapping.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Capabilities\CapabilityManager;
use Maktomine\RestaurantCore\Compatibility\IntegrationDetector;

final class PostTypes {

	public const FOOD_ITEM_CPT = 'mkt_food_item';
	public const BLOCK_CPT     = 'mkt_block';
	public const REVIEW_CPT    = 'mkt_review';
	public const GALLERY_CPT   = 'mkt_gallery';

	/**
	 * Register all custom post types and compatibility hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		self::register_food_item();
		self::register_block();
		self::register_review();
		self::register_gallery();
		self::register_compatibility_hooks();
	}

	/**
	 * Register Food Item CPT (mkt_food_item).
	 * Publicly queryable for frontend menus and consumer catalog routes.
	 */
	private static function register_food_item(): void {
		$labels = [
			'name'               => _x( 'Food Items', 'post type general name', 'maktomine-restaurant-core' ),
			'singular_name'      => _x( 'Food Item', 'post type singular name', 'maktomine-restaurant-core' ),
			'menu_name'          => _x( 'Food Menu', 'admin menu', 'maktomine-restaurant-core' ),
			'name_admin_bar'     => _x( 'Food Item', 'add new on admin bar', 'maktomine-restaurant-core' ),
			'add_new'            => _x( 'Add New Item', 'food item', 'maktomine-restaurant-core' ),
			'add_new_item'       => __( 'Add New Food Item', 'maktomine-restaurant-core' ),
			'new_item'           => __( 'New Food Item', 'maktomine-restaurant-core' ),
			'edit_item'          => __( 'Edit Food Item', 'maktomine-restaurant-core' ),
			'view_item'          => __( 'View Food Item', 'maktomine-restaurant-core' ),
			'all_items'          => __( 'All Food Items', 'maktomine-restaurant-core' ),
			'search_items'       => __( 'Search Food Items', 'maktomine-restaurant-core' ),
			'parent_item_colon'  => __( 'Parent Food Items:', 'maktomine-restaurant-core' ),
			'not_found'          => __( 'No food items found.', 'maktomine-restaurant-core' ),
			'not_found_in_trash' => __( 'No food items found in Trash.', 'maktomine-restaurant-core' ),
		];

		$capabilities = [
			'edit_post'              => CapabilityManager::EDIT_FOOD_ITEM,
			'read_post'              => CapabilityManager::READ_FOOD_ITEM,
			'delete_post'            => CapabilityManager::DELETE_FOOD_ITEM,
			'edit_posts'             => CapabilityManager::EDIT_FOOD_ITEMS,
			'edit_others_posts'      => CapabilityManager::EDIT_OTHERS_FOOD_ITEMS,
			'publish_posts'          => CapabilityManager::PUBLISH_FOOD_ITEMS,
			'read_private_posts'     => CapabilityManager::READ_PRIVATE_FOOD_ITEMS,
			'delete_posts'           => CapabilityManager::DELETE_FOOD_ITEMS,
			'delete_private_posts'   => CapabilityManager::DELETE_PRIVATE_FOOD_ITEMS,
			'delete_published_posts' => CapabilityManager::DELETE_PUBLISHED_FOOD_ITEMS,
			'delete_others_posts'    => CapabilityManager::DELETE_OTHERS_FOOD_ITEMS,
			'edit_private_posts'     => CapabilityManager::EDIT_PRIVATE_FOOD_ITEMS,
			'edit_published_posts'   => CapabilityManager::EDIT_PUBLISHED_FOOD_ITEMS,
		];

		$args = [
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => 'mkt_food_menu',
			'query_var'          => true,
			'rewrite'            => [ 'slug' => 'food-item', 'with_front' => false ],
			'capabilities'       => $capabilities,
			'map_meta_cap'       => true,
			'has_archive'        => 'food-menu',
			'hierarchical'       => false,
			'menu_position'      => 26,
			'menu_icon'          => 'dashicons-food',
			'show_in_rest'       => true,
			'rest_base'          => 'food-items',
			'supports'           => [ 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ],
		];

		register_post_type( self::FOOD_ITEM_CPT, $args );
	}

	/**
	 * Register Maktomine Block CPT (mkt_block).
	 * Non-public foundation entity for custom templates/sections.
	 */
	private static function register_block(): void {
		$labels = [
			'name'               => _x( 'Maktomine Blocks', 'post type general name', 'maktomine-restaurant-core' ),
			'singular_name'      => _x( 'Maktomine Block', 'post type singular name', 'maktomine-restaurant-core' ),
			'menu_name'          => _x( 'Maktomine Blocks', 'admin menu', 'maktomine-restaurant-core' ),
			'add_new'            => _x( 'Add New Block', 'block', 'maktomine-restaurant-core' ),
			'add_new_item'       => __( 'Add New Block', 'maktomine-restaurant-core' ),
			'edit_item'          => __( 'Edit Block', 'maktomine-restaurant-core' ),
			'all_items'          => __( 'Maktomine Blocks', 'maktomine-restaurant-core' ),
			'search_items'       => __( 'Search Blocks', 'maktomine-restaurant-core' ),
			'not_found'          => __( 'No blocks found.', 'maktomine-restaurant-core' ),
		];

		$supports = [ 'title', 'editor' ];
		if ( IntegrationDetector::is_elementor_active() ) {
			$supports[] = 'elementor';
		}

		$args = [
			'labels'             => $labels,
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => 'maktomine_theme_kit',
			'show_in_rest'       => true,
			'rest_base'          => 'blocks',
			'supports'           => $supports,
			'capability_type'    => 'post',
			'map_meta_cap'       => true,
		];

		register_post_type( self::BLOCK_CPT, $args );
	}

	/**
	 * Register Customer Review CPT (mkt_review).
	 * Non-public foundation entity for customer feedback/testimonials.
	 */
	private static function register_review(): void {
		$labels = [
			'name'               => _x( 'Customer Reviews', 'post type general name', 'maktomine-restaurant-core' ),
			'singular_name'      => _x( 'Customer Review', 'post type singular name', 'maktomine-restaurant-core' ),
			'menu_name'          => _x( 'Customer Reviews', 'admin menu', 'maktomine-restaurant-core' ),
			'add_new'            => _x( 'Add New Review', 'review', 'maktomine-restaurant-core' ),
			'add_new_item'       => __( 'Add New Review', 'maktomine-restaurant-core' ),
			'edit_item'          => __( 'Edit Review', 'maktomine-restaurant-core' ),
			'all_items'          => __( 'All Reviews', 'maktomine-restaurant-core' ),
			'search_items'       => __( 'Search Reviews', 'maktomine-restaurant-core' ),
		];

		$args = [
			'labels'             => $labels,
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'menu_icon'          => 'dashicons-star-filled',
			'show_in_rest'       => true,
			'rest_base'          => 'reviews',
			'supports'           => [ 'title', 'editor', 'thumbnail' ],
			'capability_type'    => 'post',
			'map_meta_cap'       => true,
		];

		register_post_type( self::REVIEW_CPT, $args );
	}

	/**
	 * Register Restaurant Gallery CPT (mkt_gallery).
	 * Non-public foundation entity for restaurant photo galleries.
	 */
	private static function register_gallery(): void {
		$labels = [
			'name'               => _x( 'Restaurant Gallery', 'post type general name', 'maktomine-restaurant-core' ),
			'singular_name'      => _x( 'Gallery Item', 'post type singular name', 'maktomine-restaurant-core' ),
			'menu_name'          => _x( 'Restaurant Gallery', 'admin menu', 'maktomine-restaurant-core' ),
			'add_new'            => _x( 'Add New Gallery', 'gallery', 'maktomine-restaurant-core' ),
			'add_new_item'       => __( 'Add New Gallery', 'maktomine-restaurant-core' ),
			'edit_item'          => __( 'Edit Gallery', 'maktomine-restaurant-core' ),
			'all_items'          => __( 'All Galleries', 'maktomine-restaurant-core' ),
		];

		$args = [
			'labels'             => $labels,
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'menu_icon'          => 'dashicons-format-gallery',
			'show_in_rest'       => true,
			'rest_base'          => 'galleries',
			'supports'           => [ 'title', 'thumbnail' ],
			'capability_type'    => 'post',
			'map_meta_cap'       => true,
		];

		register_post_type( self::GALLERY_CPT, $args );
	}

	/**
	 * Defensively attach compatibility hooks for optional page builders.
	 */
	private static function register_compatibility_hooks(): void {
		// If Elementor initializes later in the bootstrap process, attach block support safely.
		add_action( 'elementor/init', static function(): void {
			add_post_type_support( self::BLOCK_CPT, 'elementor' );
		} );
	}
}
