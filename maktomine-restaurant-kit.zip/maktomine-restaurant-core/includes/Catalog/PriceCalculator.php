<?php
/**
 * Price Calculator.
 * Canonical service for determining the effective catalog unit price of a food item.
 * Pure catalog-domain service with no database side-effects, cart logic, or tax calculations.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Class PriceCalculator
 *
 * Evaluates food item base pricing, promotional sale pricing, and resolved variation pricing
 * to compute a deterministic effective unit price according to strict precedence rules:
 *
 * Precedence:
 *  1. Valid explicit variation price (takes complete precedence; does NOT stack discounts).
 *  2. Otherwise valid food-level promotional sale price (if present, > 0, and <= base price).
 *  3. Otherwise food item base price.
 *
 * Responsibility Boundary:
 *  - Owns: Monetary normalization, pricing validation, precedence evaluation, unit price calculation.
 *  - Excludes: Database loading/persistence, cart state, quantity multipliers, add-on totals,
 *              discounts/coupons, taxes, delivery fees, order creation.
 */
final class PriceCalculator {

	/**
	 * Error codes.
	 */
	public const ERROR_INVALID_BASE_PRICE      = 'invalid_base_price';
	public const ERROR_INVALID_SALE_PRICE      = 'invalid_sale_price';
	public const ERROR_INVALID_VARIATION_PRICE = 'invalid_variation_price';

	/**
	 * Price source identifiers.
	 */
	public const SOURCE_BASE      = 'base';
	public const SOURCE_SALE      = 'sale';
	public const SOURCE_VARIATION = 'variation';

	/**
	 * Calculate the effective unit price for a food item.
	 *
	 * @param float|int|string      $base_price Raw base price.
	 * @param float|int|string|null $sale_price Optional raw promotional sale price.
	 * @param array|null            $variation  Optional resolved variation data array containing 'price'.
	 * @return array{
	 *     success: bool,
	 *     price: float|null,
	 *     source: string|null,
	 *     base_price: float|null,
	 *     sale_price: float|null,
	 *     variation_price: float|null,
	 *     variation_id: string|null,
	 *     error: array{code: string, message: string}|null
	 * }
	 */
	public static function calculate(
		float|int|string $base_price,
		float|int|string|null $sale_price = null,
		?array $variation = null
	): array {
		// ---------------------------------------------------------------------
		// 1. Validate and Normalize Base Price
		// ---------------------------------------------------------------------
		if ( ! self::is_valid_numeric( $base_price ) ) {
			return self::failure(
				self::ERROR_INVALID_BASE_PRICE,
				__( 'The base price is invalid.', 'maktomine-restaurant-core' )
			);
		}

		$raw_base_float = (float) $base_price;
		if ( $raw_base_float < 0.0 ) {
			return self::failure(
				self::ERROR_INVALID_BASE_PRICE,
				__( 'The base price cannot be negative.', 'maktomine-restaurant-core' )
			);
		}

		$normalized_base = round( $raw_base_float, 2 );

		// ---------------------------------------------------------------------
		// 2. Validate and Normalize Sale Price
		// ---------------------------------------------------------------------
		$normalized_sale = 0.0;

		if ( null !== $sale_price && '' !== $sale_price && false !== $sale_price ) {
			if ( ! self::is_valid_numeric( $sale_price ) ) {
				return self::failure(
					self::ERROR_INVALID_SALE_PRICE,
					__( 'The sale price is invalid.', 'maktomine-restaurant-core' )
				);
			}

			$raw_sale_float = (float) $sale_price;
			if ( $raw_sale_float < 0.0 ) {
				return self::failure(
					self::ERROR_INVALID_SALE_PRICE,
					__( 'The sale price cannot be negative.', 'maktomine-restaurant-core' )
				);
			}

			$normalized_sale = round( $raw_sale_float, 2 );
		}

		// ---------------------------------------------------------------------
		// 3. Validate Variation Price (if variation supplied)
		// ---------------------------------------------------------------------
		$has_variation            = false;
		$normalized_var_price     = null;
		$variation_id             = null;

		if ( null !== $variation && ! empty( $variation ) ) {
			$has_variation = true;

			if ( ! array_key_exists( 'price', $variation ) || ! self::is_valid_numeric( $variation['price'] ) ) {
				return self::failure(
					self::ERROR_INVALID_VARIATION_PRICE,
					__( 'The variation price is invalid.', 'maktomine-restaurant-core' )
				);
			}

			$raw_var_float = (float) $variation['price'];
			if ( $raw_var_float < 0.0 ) {
				return self::failure(
					self::ERROR_INVALID_VARIATION_PRICE,
					__( 'The variation price cannot be negative.', 'maktomine-restaurant-core' )
				);
			}

			$normalized_var_price = round( $raw_var_float, 2 );
			$variation_id         = isset( $variation['id'] ) ? (string) $variation['id'] : null;
		}

		// ---------------------------------------------------------------------
		// 4. Determine Effective Price & Source According to Precedence
		// ---------------------------------------------------------------------
		// Rule 1: Resolved variation price takes complete precedence.
		if ( $has_variation && null !== $normalized_var_price ) {
			return [
				'success'         => true,
				'price'           => $normalized_var_price,
				'source'          => self::SOURCE_VARIATION,
				'base_price'      => $normalized_base,
				'sale_price'      => $normalized_sale,
				'variation_price' => $normalized_var_price,
				'variation_id'    => $variation_id,
				'error'           => null,
			];
		}

		// Rule 2: Active promotional sale price (must be positive and <= base price).
		if ( $normalized_sale > 0.0 && $normalized_sale <= $normalized_base ) {
			return [
				'success'         => true,
				'price'           => $normalized_sale,
				'source'          => self::SOURCE_SALE,
				'base_price'      => $normalized_base,
				'sale_price'      => $normalized_sale,
				'variation_price' => null,
				'variation_id'    => null,
				'error'           => null,
			];
		}

		// Rule 3: Default to base price.
		return [
			'success'         => true,
			'price'           => $normalized_base,
			'source'          => self::SOURCE_BASE,
			'base_price'      => $normalized_base,
			'sale_price'      => $normalized_sale,
			'variation_price' => null,
			'variation_id'    => null,
			'error'           => null,
		];
	}

	/**
	 * Validate whether an input is a finite, well-formed numeric value.
	 *
	 * Accepts integers, finite floats, and valid numeric strings (e.g. "10", "10.50", "0").
	 * Strictly rejects booleans, arrays, objects, non-numeric strings, INF, -INF, and NAN.
	 *
	 * @param mixed $value Raw input value.
	 * @return bool True if value is strictly numeric and finite.
	 */
	public static function is_valid_numeric( mixed $value ): bool {
		if ( null === $value || is_array( $value ) || is_object( $value ) || is_bool( $value ) ) {
			return false;
		}

		if ( is_int( $value ) ) {
			return true;
		}

		if ( is_float( $value ) ) {
			return is_finite( $value ) && ! is_nan( $value );
		}

		if ( is_string( $value ) ) {
			$trimmed = trim( $value );
			if ( '' === $trimmed ) {
				return false;
			}

			if ( ! is_numeric( $trimmed ) ) {
				return false;
			}

			$float_val = (float) $trimmed;
			return is_finite( $float_val ) && ! is_nan( $float_val );
		}

		return false;
	}

	/**
	 * Helper to construct a structured failure response.
	 *
	 * @param string $code    Stable error code.
	 * @param string $message Localized error description.
	 * @return array{
	 *     success: false,
	 *     price: null,
	 *     source: null,
	 *     base_price: null,
	 *     sale_price: null,
	 *     variation_price: null,
	 *     variation_id: null,
	 *     error: array{code: string, message: string}
	 * }
	 */
	private static function failure( string $code, string $message ): array {
		return [
			'success'         => false,
			'price'           => null,
			'source'          => null,
			'base_price'      => null,
			'sale_price'      => null,
			'variation_price' => null,
			'variation_id'    => null,
			'error'           => [
				'code'    => $code,
				'message' => $message,
			],
		];
	}
}
