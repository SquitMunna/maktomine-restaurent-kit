<?php
/**
 * Food Schema Validator.
 * Canonical validator and normalizer for food item attributes, variations, and add-ons schemas.
 * Enforces strict validation, reference integrity, limit controls, and atomic submission checks.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Support\Sanitizer;

final class FoodSchemaValidator {

	/**
	 * Maximum allowed attribute axes per food item.
	 */
	public const MAX_ATTRIBUTES = 3;

	/**
	 * Maximum allowed variation combinations per food item.
	 */
	public const MAX_VARIATIONS = 60;

	/**
	 * Maximum payload character length for JSON schema strings (100KB ceiling).
	 */
	public const MAX_SCHEMA_SIZE = 100000;

	/**
	 * Supported attribute selection types in v1.
	 */
	public const ALLOWED_ATTRIBUTE_TYPES = [
		'select',
	];

	/**
	 * Canonical fallback representation for empty attributes schema.
	 */
	public const EMPTY_ATTRIBUTES_SCHEMA = '{"attributes":[]}';

	/**
	 * Canonical fallback representation for empty variations schema.
	 */
	public const EMPTY_VARIATIONS_SCHEMA = '{"variations":[]}';

	/**
	 * Canonical fallback representation for empty add-ons schema.
	 */
	public const EMPTY_ADDONS_SCHEMA = '{"addons":[]}';

	// =========================================================================
	// 1. ID Normalization
	// =========================================================================

	/**
	 * Normalize an identifier into a deterministic machine-safe slug.
	 * Format: lowercase ASCII alphanumeric characters and hyphens only.
	 *
	 * @param mixed  $raw            Raw identifier or string.
	 * @param string $fallback_label Optional label to derive ID from if raw ID is empty.
	 * @return string Clean machine-safe slug, or empty string if unresolvable.
	 */
	public static function normalize_id( mixed $raw, string $fallback_label = '' ): string {
		$str = is_string( $raw ) ? $raw : '';
		$str = trim( $str );

		if ( '' === $str && '' !== $fallback_label ) {
			$str = trim( $fallback_label );
		}

		if ( '' === $str ) {
			return '';
		}

		// Convert to lowercase.
		$slug = strtolower( $str );

		// Replace spaces, underscores, and forward slashes with hyphens.
		$slug = preg_replace( '/[\s_\/]+/', '-', $slug ) ?? '';

		// Retain only ASCII alphanumeric characters and hyphens.
		$slug = preg_replace( '/[^a-z0-9\-]/', '', $slug ) ?? '';

		// Collapse multiple consecutive hyphens into a single hyphen.
		$slug = preg_replace( '/-+/', '-', $slug ) ?? '';

		// Trim leading and trailing hyphens.
		return trim( $slug, '-' );
	}

	// =========================================================================
	// 2. Comprehensive Pre-Persistence Submission Validation
	// =========================================================================

	/**
	 * Perform strict pre-persistence validation for submitted schemas.
	 * Enforces the conceptual sequence:
	 *  1. Validate submitted attributes.
	 *  2. Build authoritative attribute/option lookup from SUBMITTED attributes.
	 *  3. Validate submitted variations against the newly validated lookup.
	 *  4. Validate submitted add-ons.
	 *
	 * Rejects invalid submissions with detailed error messages without partially saving.
	 *
	 * @param array $raw_attributes Submitted attributes array.
	 * @param array $raw_variations Submitted variations array.
	 * @param array $raw_addons     Submitted add-ons array.
	 * @return array{
	 *     valid: bool,
	 *     errors: string[],
	 *     attributes_data: array,
	 *     variations_data: array,
	 *     addons_data: array,
	 *     attributes_json: string,
	 *     variations_json: string,
	 *     addons_json: string
	 * }
	 */
	public static function validate_submission( array $raw_attributes, array $raw_variations, array $raw_addons ): array {
		$errors = [];

		// Filter out entirely empty submission rows (e.g. empty templates or blank clicks).
		$clean_raw_attributes = self::filter_empty_rows( $raw_attributes, [ 'name', 'id' ] );
		$clean_raw_variations = self::filter_empty_rows( $raw_variations, [ 'id', 'attributes' ] );
		$clean_raw_addons     = self::filter_empty_rows( $raw_addons, [ 'name', 'id' ] );

		// ---------------------------------------------------------------------
		// Step 1: Validate Attributes
		// ---------------------------------------------------------------------
		$attr_count = count( $clean_raw_attributes );
		if ( $attr_count > self::MAX_ATTRIBUTES ) {
			$errors[] = sprintf(
				/* translators: %d: maximum allowed attributes */
				__( 'Food items support a maximum of %d attributes. Submission rejected.', 'maktomine-restaurant-core' ),
				self::MAX_ATTRIBUTES
			);
		}

		$normalized_attributes = [];
		$seen_attr_ids         = [];
		$declared_lookup_map   = [];

		foreach ( $clean_raw_attributes as $attr_idx => $attr_data ) {
			if ( ! is_array( $attr_data ) ) {
				$errors[] = sprintf(
					/* translators: %d: attribute row number */
					__( 'Attribute #%d: Invalid data format.', 'maktomine-restaurant-core' ),
					(int) $attr_idx + 1
				);
				continue;
			}

			$raw_name = isset( $attr_data['name'] ) ? trim( (string) $attr_data['name'] ) : '';
			$name     = sanitize_text_field( $raw_name );
			if ( '' === $name ) {
				$errors[] = sprintf(
					/* translators: %d: attribute row number */
					__( 'Attribute #%d: Name cannot be empty.', 'maktomine-restaurant-core' ),
					(int) $attr_idx + 1
				);
			}

			$raw_id = isset( $attr_data['id'] ) ? trim( (string) $attr_data['id'] ) : '';
			$id     = self::normalize_id( $raw_id, $name );
			if ( '' === $id ) {
				$errors[] = sprintf(
					/* translators: %d: attribute row number */
					__( 'Attribute #%d: Unable to generate a valid slug ID.', 'maktomine-restaurant-core' ),
					(int) $attr_idx + 1
				);
			} elseif ( isset( $seen_attr_ids[ $id ] ) ) {
				$errors[] = sprintf(
					/* translators: %s: attribute slug ID */
					__( "Attribute ID '%s' is duplicated.", 'maktomine-restaurant-core' ),
					$id
				);
			} else {
				$seen_attr_ids[ $id ] = true;
			}

			$raw_type = isset( $attr_data['type'] ) ? (string) $attr_data['type'] : 'select';
			$type     = in_array( $raw_type, self::ALLOWED_ATTRIBUTE_TYPES, true ) ? $raw_type : 'select';
			$required = ! empty( $attr_data['required'] );
			$sort     = isset( $attr_data['sort_order'] ) ? (int) $attr_data['sort_order'] : ( ( (int) $attr_idx + 1 ) * 10 );

			// Process and validate options within this attribute.
			$raw_options = isset( $attr_data['options'] ) && is_array( $attr_data['options'] ) ? $attr_data['options'] : [];
			$clean_raw_options = self::filter_empty_rows( $raw_options, [ 'label', 'id' ] );

			if ( empty( $clean_raw_options ) ) {
				$errors[] = sprintf(
					/* translators: %s: attribute name */
					__( "Attribute '%s' must contain at least one option.", 'maktomine-restaurant-core' ),
					'' !== $name ? $name : (string) ( (int) $attr_idx + 1 )
				);
			}

			$normalized_options = [];
			$seen_option_ids    = [];

			foreach ( $clean_raw_options as $opt_idx => $opt_data ) {
				if ( ! is_array( $opt_data ) ) {
					continue;
				}

				$raw_opt_label = isset( $opt_data['label'] ) ? trim( (string) $opt_data['label'] ) : '';
				$opt_label     = sanitize_text_field( $raw_opt_label );
				if ( '' === $opt_label ) {
					$errors[] = sprintf(
						/* translators: 1: option number, 2: attribute name */
						__( "Option #%1$d in attribute '%2$s': Label cannot be empty.", 'maktomine-restaurant-core' ),
						(int) $opt_idx + 1,
						$name
					);
				}

				$raw_opt_id = isset( $opt_data['id'] ) ? trim( (string) $opt_data['id'] ) : '';
				$opt_id     = self::normalize_id( $raw_opt_id, $opt_label );
				if ( '' === $opt_id ) {
					$errors[] = sprintf(
						/* translators: 1: option label, 2: attribute name */
						__( "Option '%1$s' in attribute '%2$s': Unable to generate a valid slug ID.", 'maktomine-restaurant-core' ),
						$opt_label,
						$name
					);
				} elseif ( isset( $seen_option_ids[ $opt_id ] ) ) {
					$errors[] = sprintf(
						/* translators: 1: option slug ID, 2: attribute slug ID */
						__( "Option ID '%1$s' is duplicated within attribute '%2$s'.", 'maktomine-restaurant-core' ),
						$opt_id,
						$id
					);
				} else {
					$seen_option_ids[ $opt_id ] = true;
				}

				$normalized_options[] = [
					'id'    => $opt_id,
					'label' => $opt_label,
				];

				if ( '' !== $id && '' !== $opt_id ) {
					$declared_lookup_map[ $id ][ $opt_id ] = true;
				}
			}

			$normalized_attributes[] = [
				'id'         => $id,
				'name'       => $name,
				'type'       => $type,
				'required'   => $required,
				'options'    => $normalized_options,
				'sort_order' => $sort,
			];
		}

		// ---------------------------------------------------------------------
		// Step 2: Validate Variations Against Newly Validated Attributes Map
		// ---------------------------------------------------------------------
		$var_count = count( $clean_raw_variations );
		if ( $var_count > self::MAX_VARIATIONS ) {
			$errors[] = sprintf(
				/* translators: %d: maximum allowed variations */
				__( 'Food items support a maximum of %d variations. Submission rejected.', 'maktomine-restaurant-core' ),
				self::MAX_VARIATIONS
			);
		}

		if ( $var_count > 0 && empty( $clean_raw_attributes ) ) {
			$errors[] = __( 'Variations cannot be defined without declared attributes. Submission rejected.', 'maktomine-restaurant-core' );
		}

		$normalized_variations = [];
		$seen_variation_ids    = [];
		$seen_combinations     = [];

		foreach ( $clean_raw_variations as $var_idx => $var_data ) {
			if ( ! is_array( $var_data ) ) {
				$errors[] = sprintf(
					/* translators: %d: variation row number */
					__( 'Variation #%d: Invalid data format.', 'maktomine-restaurant-core' ),
					(int) $var_idx + 1
				);
				continue;
			}

			// Validate assigned attribute options.
			$raw_assigned = isset( $var_data['attributes'] ) && is_array( $var_data['attributes'] )
				? $var_data['attributes']
				: [];

			if ( empty( $raw_assigned ) ) {
				$errors[] = sprintf(
					/* translators: %d: variation row number */
					__( 'Variation #%d: Attribute combinations must be specified.', 'maktomine-restaurant-core' ),
					(int) $var_idx + 1
				);
				continue;
			}

			$normalized_attr_map = [];
			$combo_parts         = [];

			foreach ( $raw_assigned as $attr_key => $opt_val ) {
				$attr_id = self::normalize_id( (string) $attr_key );
				$opt_id  = self::normalize_id( (string) $opt_val );

				if ( '' === $attr_id || '' === $opt_id ) {
					continue;
				}

				// Strict reference integrity check against submitted attributes lookup.
				if ( ! isset( $declared_lookup_map[ $attr_id ] ) ) {
					$errors[] = sprintf(
						/* translators: 1: variation row number, 2: attribute slug ID */
						__( "Variation #%1$d references an unknown attribute '%2$s'.", 'maktomine-restaurant-core' ),
						(int) $var_idx + 1,
						$attr_id
					);
				} elseif ( ! isset( $declared_lookup_map[ $attr_id ][ $opt_id ] ) ) {
					$errors[] = sprintf(
						/* translators: 1: variation row number, 2: option slug ID, 3: attribute slug ID */
						__( "Variation #%1$d references an unknown option '%2$s' for attribute '%3$s'.", 'maktomine-restaurant-core' ),
						(int) $var_idx + 1,
						$opt_id,
						$attr_id
					);
				}

				$normalized_attr_map[ $attr_id ] = $opt_id;
			}

			// Ensure unique variation combination signature.
			ksort( $normalized_attr_map );
			foreach ( $normalized_attr_map as $k => $v ) {
				$combo_parts[] = $k . '=' . $v;
			}
			$combination_signature = implode( '|', $combo_parts );

			if ( '' !== $combination_signature ) {
				if ( isset( $seen_combinations[ $combination_signature ] ) ) {
					$errors[] = sprintf(
						/* translators: %s: attribute combination string */
						__( "Variation combination '%s' is duplicated.", 'maktomine-restaurant-core' ),
						$combination_signature
					);
				} else {
					$seen_combinations[ $combination_signature ] = true;
				}
			}

			// Validate or derive variation ID.
			$raw_var_id = isset( $var_data['id'] ) ? trim( (string) $var_data['id'] ) : '';
			$var_id     = self::normalize_id( $raw_var_id );

			if ( '' === $var_id ) {
				// Deterministically derive slug from sorted combination: e.g. size-small-crust-thin.
				$auto_slug_parts = [];
				foreach ( $normalized_attr_map as $k => $v ) {
					$auto_slug_parts[] = $k . '-' . $v;
				}
				$var_id = self::normalize_id( implode( '-', $auto_slug_parts ) );
			}

			if ( '' === $var_id ) {
				$errors[] = sprintf(
					/* translators: %d: variation row number */
					__( 'Variation #%d: Unable to generate a valid slug ID.', 'maktomine-restaurant-core' ),
					(int) $var_idx + 1
				);
			} elseif ( isset( $seen_variation_ids[ $var_id ] ) ) {
				$errors[] = sprintf(
					/* translators: %s: variation slug ID */
					__( "Variation ID '%s' is duplicated.", 'maktomine-restaurant-core' ),
					$var_id
				);
			} else {
				$seen_variation_ids[ $var_id ] = true;
			}

			$price        = Sanitizer::price( $var_data['price'] ?? 0.0 );
			$availability = FoodItemMeta::sanitize_availability( (string) ( $var_data['availability'] ?? FoodItemMeta::STATUS_IN_STOCK ) );
			$sort         = isset( $var_data['sort_order'] ) ? (int) $var_data['sort_order'] : ( ( (int) $var_idx + 1 ) * 10 );

			$normalized_variations[] = [
				'id'           => $var_id,
				'attributes'   => $normalized_attr_map,
				'price'        => $price,
				'availability' => $availability,
				'sort_order'   => $sort,
			];
		}

		// ---------------------------------------------------------------------
		// Step 3: Validate Add-ons
		// ---------------------------------------------------------------------
		$normalized_addons = [];
		$seen_addon_ids    = [];

		foreach ( $clean_raw_addons as $addon_idx => $addon_data ) {
			if ( ! is_array( $addon_data ) ) {
				$errors[] = sprintf(
					/* translators: %d: add-on row number */
					__( 'Add-on #%d: Invalid data format.', 'maktomine-restaurant-core' ),
					(int) $addon_idx + 1
				);
				continue;
			}

			$raw_name = isset( $addon_data['name'] ) ? trim( (string) $addon_data['name'] ) : '';
			$name     = sanitize_text_field( $raw_name );
			if ( '' === $name ) {
				$errors[] = sprintf(
					/* translators: %d: add-on row number */
					__( 'Add-on #%d: Name cannot be empty.', 'maktomine-restaurant-core' ),
					(int) $addon_idx + 1
				);
			}

			$raw_id = isset( $addon_data['id'] ) ? trim( (string) $addon_data['id'] ) : '';
			$id     = self::normalize_id( $raw_id, $name );
			if ( '' === $id ) {
				$errors[] = sprintf(
					/* translators: %d: add-on row number */
					__( 'Add-on #%d: Unable to generate a valid slug ID.', 'maktomine-restaurant-core' ),
					(int) $addon_idx + 1
				);
			} elseif ( isset( $seen_addon_ids[ $id ] ) ) {
				$errors[] = sprintf(
					/* translators: %s: add-on slug ID */
					__( "Add-on ID '%s' is duplicated.", 'maktomine-restaurant-core' ),
					$id
				);
			} else {
				$seen_addon_ids[ $id ] = true;
			}

			$price        = Sanitizer::price( $addon_data['price'] ?? 0.0 );
			$required     = ! empty( $addon_data['required'] );
			$max_qty      = max( 1, (int) ( $addon_data['max_quantity'] ?? 1 ) );
			$availability = FoodItemMeta::sanitize_availability( (string) ( $addon_data['availability'] ?? FoodItemMeta::STATUS_IN_STOCK ) );
			$sort         = isset( $addon_data['sort_order'] ) ? (int) $addon_data['sort_order'] : ( ( (int) $addon_idx + 1 ) * 10 );

			$normalized_addons[] = [
				'id'           => $id,
				'name'         => $name,
				'price'        => $price,
				'required'     => $required,
				'max_quantity' => $max_qty,
				'availability' => $availability,
				'sort_order'   => $sort,
			];
		}

		// ---------------------------------------------------------------------
		// Step 4: Verification Verdict & Canonical Serialization
		// ---------------------------------------------------------------------
		$is_valid = empty( $errors );

		$attributes_json = self::EMPTY_ATTRIBUTES_SCHEMA;
		$variations_json = self::EMPTY_VARIATIONS_SCHEMA;
		$addons_json     = self::EMPTY_ADDONS_SCHEMA;

		if ( $is_valid ) {
			if ( ! empty( $normalized_attributes ) ) {
				$encoded_attr = wp_json_encode( [ 'attributes' => $normalized_attributes ] );
				if ( false !== $encoded_attr && strlen( $encoded_attr ) <= self::MAX_SCHEMA_SIZE ) {
					$attributes_json = $encoded_attr;
				} else {
					$errors[] = __( 'Attributes schema exceeds payload limits.', 'maktomine-restaurant-core' );
					$is_valid = false;
				}
			}

			if ( ! empty( $normalized_variations ) ) {
				$encoded_var = wp_json_encode( [ 'variations' => $normalized_variations ] );
				if ( false !== $encoded_var && strlen( $encoded_var ) <= self::MAX_SCHEMA_SIZE ) {
					$variations_json = $encoded_var;
				} else {
					$errors[] = __( 'Variations schema exceeds payload limits.', 'maktomine-restaurant-core' );
					$is_valid = false;
				}
			}

			if ( ! empty( $normalized_addons ) ) {
				$encoded_addon = wp_json_encode( [ 'addons' => $normalized_addons ] );
				if ( false !== $encoded_addon && strlen( $encoded_addon ) <= self::MAX_SCHEMA_SIZE ) {
					$addons_json = $encoded_addon;
				} else {
					$errors[] = __( 'Add-ons schema exceeds payload limits.', 'maktomine-restaurant-core' );
					$is_valid = false;
				}
			}
		}

		return [
			'valid'           => $is_valid,
			'errors'          => $errors,
			'attributes_data' => $normalized_attributes,
			'variations_data' => $normalized_variations,
			'addons_data'     => $normalized_addons,
			'attributes_json' => $attributes_json,
			'variations_json' => $variations_json,
			'addons_json'     => $addons_json,
		];
	}

	// =========================================================================
	// 3. Schema Sanitization & Encoding (Defensive API Methods)
	// =========================================================================

	/**
	 * Sanitize and validate attributes schema into canonical JSON.
	 * Enforces max 3 attributes, unique IDs, unique option IDs, and valid options.
	 *
	 * @param mixed $input Raw JSON string or array of attributes.
	 * @return string Canonical JSON string containing {"attributes":[...]}.
	 */
	public static function sanitize_attributes_schema( mixed $input ): string {
		$raw_list = self::extract_list_from_input( $input, 'attributes' );
		if ( empty( $raw_list ) ) {
			return self::EMPTY_ATTRIBUTES_SCHEMA;
		}

		$validation = self::validate_submission( $raw_list, [], [] );
		if ( $validation['valid'] ) {
			return $validation['attributes_json'];
		}

		return self::EMPTY_ATTRIBUTES_SCHEMA;
	}

	/**
	 * Sanitize and validate variations schema into canonical JSON.
	 *
	 * @param mixed $input             Raw JSON string or array of variations.
	 * @param mixed $attributes_schema Optional attributes schema (JSON string or array) for reference integrity.
	 * @return string Canonical JSON string containing {"variations":[...]}.
	 */
	public static function sanitize_variations_schema( mixed $input, mixed $attributes_schema = null ): string {
		$raw_vars = self::extract_list_from_input( $input, 'variations' );
		if ( empty( $raw_vars ) ) {
			return self::EMPTY_VARIATIONS_SCHEMA;
		}

		$raw_attrs  = self::extract_list_from_input( $attributes_schema, 'attributes' );
		$validation = self::validate_submission( $raw_attrs, $raw_vars, [] );
		if ( $validation['valid'] ) {
			return $validation['variations_json'];
		}

		return self::EMPTY_VARIATIONS_SCHEMA;
	}

	/**
	 * Sanitize and validate add-ons schema into canonical JSON.
	 *
	 * @param mixed $input Raw JSON string or array of add-ons.
	 * @return string Canonical JSON string containing {"addons":[...]}.
	 */
	public static function sanitize_addons_schema( mixed $input ): string {
		$raw_addons = self::extract_list_from_input( $input, 'addons' );
		if ( empty( $raw_addons ) ) {
			return self::EMPTY_ADDONS_SCHEMA;
		}

		$validation = self::validate_submission( [], [], $raw_addons );
		if ( $validation['valid'] ) {
			return $validation['addons_json'];
		}

		return self::EMPTY_ADDONS_SCHEMA;
	}

	// =========================================================================
	// 4. Schema Parsers (For UI and Consumers)
	// =========================================================================

	/**
	 * Parse attributes schema JSON or array into a normalized array structure.
	 *
	 * @param mixed $value Schema JSON string or array.
	 * @return array{attributes: array<int, array<string, mixed>>}
	 */
	public static function parse_attributes_schema( mixed $value ): array {
		$raw_list = self::extract_list_from_input( $value, 'attributes' );
		if ( empty( $raw_list ) ) {
			return [ 'attributes' => [] ];
		}

		$validation = self::validate_submission( $raw_list, [], [] );
		if ( $validation['valid'] ) {
			return [ 'attributes' => $validation['attributes_data'] ];
		}

		// Fallback decode if pre-stored JSON is valid
		if ( is_string( $value ) ) {
			$decoded = json_decode( $value, true );
			if ( is_array( $decoded ) && isset( $decoded['attributes'] ) && is_array( $decoded['attributes'] ) ) {
				return [ 'attributes' => $decoded['attributes'] ];
			}
		}

		return [ 'attributes' => [] ];
	}

	/**
	 * Parse variations schema JSON or array into a normalized array structure.
	 *
	 * @param mixed $value             Schema JSON string or array.
	 * @param mixed $attributes_schema Optional attributes schema for reference integrity.
	 * @return array{variations: array<int, array<string, mixed>>}
	 */
	public static function parse_variations_schema( mixed $value, mixed $attributes_schema = null ): array {
		$raw_vars = self::extract_list_from_input( $value, 'variations' );
		if ( empty( $raw_vars ) ) {
			return [ 'variations' => [] ];
		}

		$raw_attrs  = self::extract_list_from_input( $attributes_schema, 'attributes' );
		$validation = self::validate_submission( $raw_attrs, $raw_vars, [] );
		if ( $validation['valid'] ) {
			return [ 'variations' => $validation['variations_data'] ];
		}

		if ( is_string( $value ) ) {
			$decoded = json_decode( $value, true );
			if ( is_array( $decoded ) && isset( $decoded['variations'] ) && is_array( $decoded['variations'] ) ) {
				return [ 'variations' => $decoded['variations'] ];
			}
		}

		return [ 'variations' => [] ];
	}

	/**
	 * Parse add-ons schema JSON or array into a normalized array structure.
	 *
	 * @param mixed $value Schema JSON string or array.
	 * @return array{addons: array<int, array<string, mixed>>}
	 */
	public static function parse_addons_schema( mixed $value ): array {
		$raw_addons = self::extract_list_from_input( $value, 'addons' );
		if ( empty( $raw_addons ) ) {
			return [ 'addons' => [] ];
		}

		$validation = self::validate_submission( [], [], $raw_addons );
		if ( $validation['valid'] ) {
			return [ 'addons' => $validation['addons_data'] ];
		}

		if ( is_string( $value ) ) {
			$decoded = json_decode( $value, true );
			if ( is_array( $decoded ) && isset( $decoded['addons'] ) && is_array( $decoded['addons'] ) ) {
				return [ 'addons' => $decoded['addons'] ];
			}
		}

		return [ 'addons' => [] ];
	}

	// =========================================================================
	// 5. Internal Helper Utilities
	// =========================================================================

	/**
	 * Filter out empty submission rows from a list of rows.
	 * A row is considered empty if all checked keys are empty.
	 *
	 * @param array    $list        Raw list of rows.
	 * @param string[] $check_keys  Key names to test.
	 * @return array
	 */
	private static function filter_empty_rows( array $list, array $check_keys ): array {
		$result = [];
		foreach ( $list as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$has_value = false;
			foreach ( $check_keys as $key ) {
				if ( isset( $item[ $key ] ) ) {
					if ( is_array( $item[ $key ] ) ) {
						if ( ! empty( $item[ $key ] ) ) {
							$has_value = true;
							break;
						}
					} elseif ( '' !== trim( (string) $item[ $key ] ) ) {
						$has_value = true;
						break;
					}
				}
			}
			if ( $has_value ) {
				$result[] = $item;
			}
		}
		return $result;
	}

	/**
	 * Extract a flat list of records from either a JSON string, a top-level array, or a keyed object.
	 *
	 * @param mixed  $input Raw input.
	 * @param string $key   Expected key (e.g. 'attributes', 'variations', 'addons').
	 * @return array<int, mixed>
	 */
	private static function extract_list_from_input( mixed $input, string $key ): array {
		if ( empty( $input ) ) {
			return [];
		}

		if ( is_string( $input ) ) {
			$trimmed = trim( $input );
			if ( '' === $trimmed || 'null' === $trimmed || strlen( $trimmed ) > self::MAX_SCHEMA_SIZE ) {
				return [];
			}
			$decoded = json_decode( $trimmed, true );
			if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $decoded ) ) {
				return [];
			}
			$input = $decoded;
		}

		if ( ! is_array( $input ) ) {
			return [];
		}

		if ( isset( $input[ $key ] ) && is_array( $input[ $key ] ) ) {
			return array_values( $input[ $key ] );
		}

		// If input is an indexed list of items directly.
		$is_list = function_exists( 'array_is_list' )
			? array_is_list( $input )
			: ( empty( $input ) || array_keys( $input ) === range( 0, count( $input ) - 1 ) );

		if ( $is_list ) {
			return $input;
		}

		// Or if input is an associative array of item records keyed by index/slug.
		return array_values( $input );
	}

	/**
	 * Build a lookup map of declared attributes and their allowed option IDs.
	 * Format: [ 'attr_id' => [ 'opt_id' => true, ... ], ... ]
	 *
	 * @param mixed $attributes_schema Attributes schema input.
	 * @return array<string, array<string, bool>>
	 */
	public static function build_attribute_lookup_map( mixed $attributes_schema ): array {
		if ( empty( $attributes_schema ) ) {
			return [];
		}

		$parsed = self::parse_attributes_schema( $attributes_schema );
		$map    = [];

		foreach ( $parsed['attributes'] as $attr ) {
			$attr_id = (string) $attr['id'];
			$map[ $attr_id ] = [];

			if ( isset( $attr['options'] ) && is_array( $attr['options'] ) ) {
				foreach ( $attr['options'] as $opt ) {
					$opt_id = (string) $opt['id'];
					$map[ $attr_id ][ $opt_id ] = true;
				}
			}
		}

		return $map;
	}
}
