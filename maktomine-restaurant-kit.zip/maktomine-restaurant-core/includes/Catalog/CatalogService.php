<?php
/**
 * Food Catalog Service.
 * Application orchestration service bridging WordPress storage and pure catalog domain services.
 * Composes FoodItemMeta, FoodSchemaValidator, VariationMatrixResolver, and PriceCalculator.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

use WP_Post;
use WP_Error;
use WP_Term;
use WP_Query;

/**
 * Class CatalogService
 *
 * Primary application service for the food catalog.
 *
 * Responsibilities:
 *  - Loads food item records from WordPress storage.
 *  - Decodes and validates stored JSON schemas via FoodSchemaValidator without silent mutation.
 *  - Provides normalized catalog item representations.
 *  - Orchestrates variation resolution by delegating to VariationMatrixResolver.
 *  - Orchestrates effective unit price calculation by delegating to PriceCalculator.
 *
 * Architectural Boundaries:
 *  - Does NOT create database tables or execute raw SQL.
 *  - Does NOT register or handle REST endpoints (reserved for Phase 3N).
 *  - Does NOT manage cart state, quantities, or order creation.
 *  - Does NOT calculate add-on totals, delivery fees, taxes, or tips.
 *  - Does NOT modify postmeta during catalog read operations.
 *  - Does NOT duplicate variation matching or pricing precedence logic.
 */
final class CatalogService {

	/**
	 * Service-level error codes.
	 */
	public const ERROR_INVALID_FOOD_ID      = 'invalid_food_id';
	public const ERROR_INVALID_SLUG         = 'invalid_slug';
	public const ERROR_INVALID_ARGUMENT     = 'invalid_argument';
	public const ERROR_FOOD_NOT_FOUND       = 'food_item_not_found';
	public const ERROR_INVALID_TYPE         = 'invalid_food_item_type';
	public const ERROR_INVALID_CATALOG_DATA = 'invalid_catalog_data';
	public const ERROR_INVALID_SCHEMA       = 'invalid_catalog_schema';

	/**
	 * Canonical allowed collection sorting modes and their WP_Query mappings.
	 *
	 * @var array<string, array{orderby: string, order: string}>
	 */
	public const ALLOWED_ORDERBY = [
		'date_desc'  => [ 'orderby' => 'date', 'order' => 'DESC' ],
		'date_asc'   => [ 'orderby' => 'date', 'order' => 'ASC' ],
		'title_asc'  => [ 'orderby' => 'title', 'order' => 'ASC' ],
		'title_desc' => [ 'orderby' => 'title', 'order' => 'DESC' ],
		'menu_order' => [ 'orderby' => 'menu_order title', 'order' => 'ASC' ],
	];

	/**
	 * Singleton instance for shared service consumption.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * In-memory per-request item cache.
	 * Format: [ food_id => normalized_item_array ]
	 *
	 * @var array<int, array<string, mixed>>
	 */
	private array $item_cache = [];

	/**
	 * In-memory per-request slug to ID cache.
	 * Format: [ slug => food_id ]
	 *
	 * @var array<string, int>
	 */
	private array $slug_cache = [];

	/**
	 * Retrieve shared service instance.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Reset in-memory per-request caches.
	 *
	 * @return void
	 */
	public function clear_cache(): void {
		$this->item_cache = [];
		$this->slug_cache = [];
	}

	// =========================================================================
	// 1. Get Food Item by ID
	// =========================================================================

	/**
	 * Retrieve a normalized food item representation by WordPress post ID.
	 *
	 * @param int $food_id WordPress post ID.
	 * @return array<string, mixed>|WP_Error Normalized catalog item array on success, WP_Error on failure.
	 */
	public function get_food_item( int $food_id ): array|WP_Error {
		// 1. Validate positive integer ID.
		if ( $food_id <= 0 ) {
			return new WP_Error(
				self::ERROR_INVALID_FOOD_ID,
				__( 'Invalid food item ID. ID must be a positive integer.', 'maktomine-restaurant-core' )
			);
		}

		// Check in-memory cache.
		if ( isset( $this->item_cache[ $food_id ] ) ) {
			return $this->item_cache[ $food_id ];
		}

		// 2. Load post.
		$post = get_post( $food_id );
		if ( ! $post instanceof WP_Post ) {
			return new WP_Error(
				self::ERROR_FOOD_NOT_FOUND,
				__( 'Food item not found.', 'maktomine-restaurant-core' )
			);
		}

		// 3. Confirm post is not trashed.
		if ( 'trash' === $post->post_status ) {
			return new WP_Error(
				self::ERROR_FOOD_NOT_FOUND,
				__( 'Food item has been trashed.', 'maktomine-restaurant-core' )
			);
		}

		// 4. Confirm post type is mkt_food_item.
		if ( PostTypes::FOOD_ITEM_CPT !== $post->post_type ) {
			return new WP_Error(
				self::ERROR_INVALID_TYPE,
				__( 'Specified post is not a valid food item.', 'maktomine-restaurant-core' )
			);
		}

		// 5. Load and validate authoritative metadata.
		$base_price_raw  = get_post_meta( $food_id, FoodItemMeta::META_BASE_PRICE, true );
		$sale_price_raw  = get_post_meta( $food_id, FoodItemMeta::META_SALE_PRICE, true );
		$availability    = (string) get_post_meta( $food_id, FoodItemMeta::META_AVAILABILITY_STATUS, true );
		$is_featured_raw = get_post_meta( $food_id, FoodItemMeta::META_IS_FEATURED, true );
		$is_popular_raw  = get_post_meta( $food_id, FoodItemMeta::META_IS_POPULAR, true );
		$prep_time_raw   = get_post_meta( $food_id, FoodItemMeta::META_PREP_TIME, true );
		$calories_raw    = get_post_meta( $food_id, FoodItemMeta::META_CALORIES, true );
		$image_id_raw    = get_post_meta( $food_id, FoodItemMeta::META_IMAGE_ID, true );
		$attr_json_raw   = get_post_meta( $food_id, FoodItemMeta::META_ATTRIBUTES_SCHEMA, true );
		$var_json_raw    = get_post_meta( $food_id, FoodItemMeta::META_VARIATIONS_SCHEMA, true );
		$addon_json_raw  = get_post_meta( $food_id, FoodItemMeta::META_ADDONS_SCHEMA, true );

		// Base price validation.
		$base_price_check = ( '' === $base_price_raw || false === $base_price_raw ) ? 0.0 : $base_price_raw;
		if ( ! PriceCalculator::is_valid_numeric( $base_price_check ) || (float) $base_price_check < 0.0 ) {
			return new WP_Error(
				self::ERROR_INVALID_CATALOG_DATA,
				__( 'Food item has an invalid base price in storage.', 'maktomine-restaurant-core' ),
				[ 'code' => PriceCalculator::ERROR_INVALID_BASE_PRICE ]
			);
		}
		$base_price = round( (float) $base_price_check, 2 );

		// Sale price validation.
		$sale_price_check = ( '' === $sale_price_raw || false === $sale_price_raw ) ? 0.0 : $sale_price_raw;
		if ( ! PriceCalculator::is_valid_numeric( $sale_price_check ) || (float) $sale_price_check < 0.0 ) {
			return new WP_Error(
				self::ERROR_INVALID_CATALOG_DATA,
				__( 'Food item has an invalid sale price in storage.', 'maktomine-restaurant-core' ),
				[ 'code' => PriceCalculator::ERROR_INVALID_SALE_PRICE ]
			);
		}
		$sale_price = round( (float) $sale_price_check, 2 );

		// Availability normalization.
		if ( empty( $availability ) || ! in_array( $availability, FoodItemMeta::ALLOWED_AVAILABILITY, true ) ) {
			$availability = FoodItemMeta::STATUS_IN_STOCK;
		}

		$is_featured = (bool) ( (int) $is_featured_raw );
		$is_popular  = (bool) ( (int) $is_popular_raw );
		$prep_time   = max( 0, (int) $prep_time_raw );
		$calories    = max( 0, (int) $calories_raw );
		$image_id    = max( 0, (int) $image_id_raw );

		// 6. Decode and strictly validate schemas via FoodSchemaValidator.
		$schemas = $this->decode_and_validate_schemas( $attr_json_raw, $var_json_raw, $addon_json_raw );
		if ( is_wp_error( $schemas ) ) {
			return $schemas;
		}

		// 7. Extract taxonomy terms.
		$categories = $this->normalize_taxonomy_terms( $food_id, Taxonomies::FOOD_CATEGORY_TAX );
		$tags       = $this->normalize_taxonomy_terms( $food_id, Taxonomies::FOOD_TAG_TAX );

		// 8. Construct normalized catalog item contract.
		$normalized = [
			'id'                  => (int) $post->ID,
			'title'               => (string) $post->post_title,
			'slug'                => (string) $post->post_name,
			'description'         => (string) ( $post->post_content ?? '' ),
			'short_description'   => (string) ( $post->post_excerpt ?? '' ),
			'status'              => (string) $post->post_status,
			'permalink'           => (string) ( get_permalink( $post ) ?: '' ),
			'base_price'          => $base_price,
			'sale_price'          => $sale_price,
			'availability_status' => $availability,
			'is_featured'         => $is_featured,
			'is_popular'          => $is_popular,
			'prep_time'           => $prep_time,
			'calories'            => $calories,
			'image_id'            => $image_id,
			'attributes'          => $schemas['attributes'],
			'variations'          => $schemas['variations'],
			'addons'              => $schemas['addons'],
			'categories'          => $categories,
			'tags'                => $tags,
		];

		// Cache normalized item.
		$this->item_cache[ $food_id ] = $normalized;
		if ( '' !== $normalized['slug'] ) {
			$this->slug_cache[ $normalized['slug'] ] = $food_id;
		}

		return $normalized;
	}

	// =========================================================================
	// 2. Get Food Item by Slug
	// =========================================================================

	/**
	 * Retrieve a normalized food item representation by slug.
	 *
	 * @param string $slug Food item slug.
	 * @return array<string, mixed>|WP_Error Normalized catalog item array on success, WP_Error on failure.
	 */
	public function get_food_item_by_slug( string $slug ): array|WP_Error {
		$clean_slug = sanitize_title( trim( $slug ) );
		if ( '' === $clean_slug ) {
			return new WP_Error(
				self::ERROR_INVALID_SLUG,
				__( 'Food item slug cannot be empty.', 'maktomine-restaurant-core' )
			);
		}

		if ( isset( $this->slug_cache[ $clean_slug ] ) ) {
			return $this->get_food_item( $this->slug_cache[ $clean_slug ] );
		}

		$posts = get_posts( [
			'name'           => $clean_slug,
			'post_type'      => PostTypes::FOOD_ITEM_CPT,
			'post_status'    => [ 'publish', 'draft', 'pending', 'private', 'future' ],
			'posts_per_page' => 1,
			'no_found_rows'  => true,
		] );

		if ( empty( $posts ) ) {
			return new WP_Error(
				self::ERROR_FOOD_NOT_FOUND,
				sprintf(
					/* translators: %s: food item slug */
					__( "Food item with slug '%s' was not found.", 'maktomine-restaurant-core' ),
					$clean_slug
				)
			);
		}

		$post_id = (int) $posts[0]->ID;
		$this->slug_cache[ $clean_slug ] = $post_id;

		return $this->get_food_item( $post_id );
	}

	// =========================================================================
	// 3. Get Food Items Collection
	// =========================================================================

	/**
	 * Retrieve a bounded, paginated collection of normalized food items with controlled filtering and sorting.
	 *
	 * Supported arguments:
	 *  - per_page: integer, 1 to 50 (default: 20)
	 *  - page: integer, >= 1 (default: 1)
	 *  - status: string (default: 'publish', only 'publish' allowed for public catalog)
	 *  - category: string, menu category term slug
	 *  - tag: string, dietary tag term slug
	 *  - featured: bool|int|string, boolean filter for featured items
	 *  - popular: bool|int|string, boolean filter for popular items
	 *  - availability_status: string ('in_stock', 'out_of_stock', 'pre_order_only')
	 *  - orderby: string ('date_desc', 'date_asc', 'title_asc', 'title_desc', 'menu_order', default: 'date_desc')
	 *
	 * @param array<string, mixed> $args Query arguments.
	 * @return array{
	 *     items: array<int, array<string, mixed>>,
	 *     pagination: array{
	 *         page: int,
	 *         per_page: int,
	 *         total_items: int,
	 *         total_pages: int
	 *     }
	 * }|WP_Error Normalized collection structure on success, WP_Error on validation or corrupt data failure.
	 */
	public function get_food_items( array $args = [] ): array|WP_Error {
		// 1. Reject unapproved arbitrary query arguments.
		$allowed_keys = [
			'per_page',
			'page',
			'status',
			'category',
			'tag',
			'featured',
			'popular',
			'availability_status',
			'orderby',
		];
		$extra_keys   = array_diff( array_keys( $args ), $allowed_keys );
		if ( ! empty( $extra_keys ) ) {
			return new WP_Error(
				self::ERROR_INVALID_ARGUMENT,
				sprintf(
					/* translators: %s: Comma-separated list of unsupported argument names */
					__( 'Unsupported query arguments provided: %s.', 'maktomine-restaurant-core' ),
					implode( ', ', $extra_keys )
				)
			);
		}

		// 2. Validate per_page argument (min: 1, max: 50, default: 20).
		$per_page = 20;
		if ( isset( $args['per_page'] ) ) {
			if ( ! is_numeric( $args['per_page'] ) || (int) $args['per_page'] < 1 || (int) $args['per_page'] > 50 ) {
				return new WP_Error(
					self::ERROR_INVALID_ARGUMENT,
					__( 'The per_page parameter must be an integer between 1 and 50.', 'maktomine-restaurant-core' )
				);
			}
			$per_page = (int) $args['per_page'];
		}

		// 3. Validate page argument (min: 1, default: 1).
		$page = 1;
		if ( isset( $args['page'] ) ) {
			if ( ! is_numeric( $args['page'] ) || (int) $args['page'] < 1 ) {
				return new WP_Error(
					self::ERROR_INVALID_ARGUMENT,
					__( 'The page parameter must be a positive integer greater than or equal to 1.', 'maktomine-restaurant-core' )
				);
			}
			$page = (int) $args['page'];
		}

		// 4. Validate status argument (default: 'publish', only 'publish' allowed for public collection).
		$status = 'publish';
		if ( isset( $args['status'] ) ) {
			if ( ! is_string( $args['status'] ) || 'publish' !== $args['status'] ) {
				return new WP_Error(
					self::ERROR_INVALID_ARGUMENT,
					__( 'Unsupported post status for public catalog collection. Only "publish" is supported.', 'maktomine-restaurant-core' )
				);
			}
			$status = $args['status'];
		}

		// 5. Validate taxonomy filters (category and tag slugs).
		$tax_query = [];

		if ( isset( $args['category'] ) ) {
			$category_slug = $this->validate_taxonomy_slug_filter(
				$args['category'],
				Taxonomies::FOOD_CATEGORY_TAX,
				'category'
			);
			if ( is_wp_error( $category_slug ) ) {
				return $category_slug;
			}

			$tax_query[] = [
				'taxonomy' => Taxonomies::FOOD_CATEGORY_TAX,
				'field'    => 'slug',
				'terms'    => $category_slug,
			];
		}

		if ( isset( $args['tag'] ) ) {
			$tag_slug = $this->validate_taxonomy_slug_filter(
				$args['tag'],
				Taxonomies::FOOD_TAG_TAX,
				'tag'
			);
			if ( is_wp_error( $tag_slug ) ) {
				return $tag_slug;
			}

			$tax_query[] = [
				'taxonomy' => Taxonomies::FOOD_TAG_TAX,
				'field'    => 'slug',
				'terms'    => $tag_slug,
			];
		}

		if ( count( $tax_query ) > 1 ) {
			$tax_query['relation'] = 'AND';
		}

		// 6. Validate metadata filters (featured, popular, availability).
		$meta_query = [];

		if ( isset( $args['featured'] ) ) {
			$featured_val = $this->validate_boolean_filter( $args['featured'], 'featured' );
			if ( is_wp_error( $featured_val ) ) {
				return $featured_val;
			}

			if ( true === $featured_val ) {
				$meta_query[] = [
					'key'     => FoodItemMeta::META_IS_FEATURED,
					'value'   => 1,
					'compare' => '=',
					'type'    => 'NUMERIC',
				];
			} else {
				$meta_query[] = [
					'relation' => 'OR',
					[
						'key'     => FoodItemMeta::META_IS_FEATURED,
						'value'   => 0,
						'compare' => '=',
						'type'    => 'NUMERIC',
					],
					[
						'key'     => FoodItemMeta::META_IS_FEATURED,
						'compare' => 'NOT EXISTS',
					],
				];
			}
		}

		if ( isset( $args['popular'] ) ) {
			$popular_val = $this->validate_boolean_filter( $args['popular'], 'popular' );
			if ( is_wp_error( $popular_val ) ) {
				return $popular_val;
			}

			if ( true === $popular_val ) {
				$meta_query[] = [
					'key'     => FoodItemMeta::META_IS_POPULAR,
					'value'   => 1,
					'compare' => '=',
					'type'    => 'NUMERIC',
				];
			} else {
				$meta_query[] = [
					'relation' => 'OR',
					[
						'key'     => FoodItemMeta::META_IS_POPULAR,
						'value'   => 0,
						'compare' => '=',
						'type'    => 'NUMERIC',
					],
					[
						'key'     => FoodItemMeta::META_IS_POPULAR,
						'compare' => 'NOT EXISTS',
					],
				];
			}
		}

		if ( isset( $args['availability_status'] ) ) {
			if ( ! is_string( $args['availability_status'] ) || ! in_array( $args['availability_status'], FoodItemMeta::ALLOWED_AVAILABILITY, true ) ) {
				return new WP_Error(
					self::ERROR_INVALID_ARGUMENT,
					sprintf(
						/* translators: 1: Provided status, 2: Allowed statuses */
						__( 'Invalid availability_status "%1$s". Allowed values: %2$s.', 'maktomine-restaurant-core' ),
						is_scalar( $args['availability_status'] ) ? (string) $args['availability_status'] : gettype( $args['availability_status'] ),
						implode( ', ', FoodItemMeta::ALLOWED_AVAILABILITY )
					)
				);
			}
			$availability = $args['availability_status'];

			if ( FoodItemMeta::STATUS_IN_STOCK === $availability ) {
				$meta_query[] = [
					'relation' => 'OR',
					[
						'key'     => FoodItemMeta::META_AVAILABILITY_STATUS,
						'value'   => FoodItemMeta::STATUS_IN_STOCK,
						'compare' => '=',
					],
					[
						'key'     => FoodItemMeta::META_AVAILABILITY_STATUS,
						'compare' => 'NOT EXISTS',
					],
				];
			} else {
				$meta_query[] = [
					'key'     => FoodItemMeta::META_AVAILABILITY_STATUS,
					'value'   => $availability,
					'compare' => '=',
				];
			}
		}

		if ( count( $meta_query ) > 1 ) {
			$meta_query['relation'] = 'AND';
		}

		// 7. Validate and map sorting orderby mode.
		$orderby_mode = 'date_desc';
		if ( isset( $args['orderby'] ) ) {
			if ( ! is_string( $args['orderby'] ) || ! isset( self::ALLOWED_ORDERBY[ $args['orderby'] ] ) ) {
				return new WP_Error(
					self::ERROR_INVALID_ARGUMENT,
					sprintf(
						/* translators: 1: Provided mode, 2: Allowed modes */
						__( 'Invalid orderby mode "%1$s". Allowed modes: %2$s.', 'maktomine-restaurant-core' ),
						is_scalar( $args['orderby'] ) ? (string) $args['orderby'] : gettype( $args['orderby'] ),
						implode( ', ', array_keys( self::ALLOWED_ORDERBY ) )
					)
				);
			}
			$orderby_mode = $args['orderby'];
		}

		$sort_config = self::ALLOWED_ORDERBY[ $orderby_mode ];

		// 8. Execute bounded WordPress query returning IDs only with deterministic ordering.
		$query_args = [
			'post_type'              => PostTypes::FOOD_ITEM_CPT,
			'post_status'            => $status,
			'posts_per_page'         => $per_page,
			'paged'                  => $page,
			'orderby'                => $sort_config['orderby'],
			'order'                  => $sort_config['order'],
			'fields'                 => 'ids',
			'no_found_rows'          => false,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		];

		if ( ! empty( $tax_query ) ) {
			$query_args['tax_query'] = $tax_query;
		}

		if ( ! empty( $meta_query ) ) {
			$query_args['meta_query'] = $meta_query;
		}

		$query       = new WP_Query( $query_args );
		$total_items = (int) $query->found_posts;
		$total_pages = (int) $query->max_num_pages;
		$post_ids    = (array) $query->posts;

		// 9. Normalization delegation: delegate each post ID to get_food_item().
		$items = [];
		foreach ( $post_ids as $post_id ) {
			$item = $this->get_food_item( (int) $post_id );
			if ( is_wp_error( $item ) ) {
				// Strict integrity: never hide corrupt catalog records.
				return $item;
			}
			$items[] = $item;
		}

		return [
			'items'      => $items,
			'pagination' => [
				'page'        => $page,
				'per_page'    => $per_page,
				'total_items' => $total_items,
				'total_pages' => $total_pages,
			],
		];
	}

	// =========================================================================
	// 4. Resolve Food Item Selection
	// =========================================================================

	/**
	 * Resolve customer attribute selections against the food item's variation matrix.
	 * Delegated strictly to VariationMatrixResolver without duplicating matching rules.
	 *
	 * @param int   $food_id   Food item post ID.
	 * @param array $selection Customer attribute selections [ 'attribute_id' => 'option_id' ].
	 * @return array{
	 *     matched: bool,
	 *     food_id: int,
	 *     variation: array<string, mixed>,
	 *     selection: array<string, string>
	 * }|WP_Error Resolved variation structure on success, WP_Error on failure.
	 */
	public function resolve_food_item_selection( int $food_id, array $selection ): array|WP_Error {
		// 1. Load validated food item.
		$food_item = $this->get_food_item( $food_id );
		if ( is_wp_error( $food_item ) ) {
			return $food_item;
		}

		// 2. Delegate directly to authoritative VariationMatrixResolver.
		$attributes_schema = [ 'attributes' => $food_item['attributes'] ];
		$variations_schema = [ 'variations' => $food_item['variations'] ];

		$resolution = VariationMatrixResolver::resolve( $attributes_schema, $variations_schema, $selection );

		// 3. Handle resolver errors.
		if ( ! $resolution['success'] ) {
			$err = $resolution['error'];
			return new WP_Error(
				$err['code'],
				$err['message'],
				$err
			);
		}

		if ( ! $resolution['matched'] ) {
			$err  = $resolution['error'];
			$code = $err['code'] ?? VariationMatrixResolver::ERROR_VARIATION_NOT_FOUND;
			$msg  = $err['message'] ?? __( 'No variation matches the selected options.', 'maktomine-restaurant-core' );
			return new WP_Error(
				$code,
				$msg,
				$err ?? []
			);
		}

		return [
			'matched'   => true,
			'food_id'   => $food_id,
			'variation' => $resolution['variation'],
			'selection' => $resolution['selection'],
		];
	}

	// =========================================================================
	// 4. Calculate Food Item Price
	// =========================================================================

	/**
	 * Calculate the effective unit price for a food item and optional attribute selection.
	 * Resolves variations when required, then delegates directly to PriceCalculator.
	 *
	 * @param int   $food_id   Food item post ID.
	 * @param array $selection Optional customer attribute selections.
	 * @return array{
	 *     success: bool,
	 *     food_id: int,
	 *     price: float,
	 *     source: string,
	 *     base_price: float,
	 *     sale_price: float,
	 *     variation_price: float|null,
	 *     variation_id: string|null,
	 *     selection: array<string, string>
	 * }|WP_Error Structured pricing result on success, WP_Error on failure.
	 */
	public function calculate_food_item_price( int $food_id, array $selection = [] ): array|WP_Error {
		// 1. Load validated food item.
		$food_item = $this->get_food_item( $food_id );
		if ( is_wp_error( $food_item ) ) {
			return $food_item;
		}

		$has_variations = ! empty( $food_item['variations'] );

		// Case A: Food item has no variations (simple food item).
		if ( ! $has_variations ) {
			// If selection was provided for an item without attributes, delegate to resolver to catch invalid selection.
			if ( ! empty( $selection ) ) {
				$resolution = $this->resolve_food_item_selection( $food_id, $selection );
				if ( is_wp_error( $resolution ) ) {
					return $resolution;
				}
			}

			$calc = PriceCalculator::calculate( $food_item['base_price'], $food_item['sale_price'], null );
			if ( ! $calc['success'] ) {
				$err = $calc['error'];
				return new WP_Error( $err['code'], $err['message'], $err );
			}

			return [
				'success'         => true,
				'food_id'         => $food_id,
				'price'           => $calc['price'],
				'source'          => $calc['source'],
				'base_price'      => $calc['base_price'],
				'sale_price'      => $calc['sale_price'],
				'variation_price' => null,
				'variation_id'    => null,
				'selection'       => [],
			];
		}

		// Case B: Food item has variations (variation selection is required).
		$resolution = $this->resolve_food_item_selection( $food_id, $selection );
		if ( is_wp_error( $resolution ) ) {
			return $resolution;
		}

		$variation = $resolution['variation'];

		// Calculate unit price using authoritative PriceCalculator.
		$calc = PriceCalculator::calculate( $food_item['base_price'], $food_item['sale_price'], $variation );
		if ( ! $calc['success'] ) {
			$err = $calc['error'];
			return new WP_Error( $err['code'], $err['message'], $err );
		}

		return [
			'success'         => true,
			'food_id'         => $food_id,
			'price'           => $calc['price'],
			'source'          => $calc['source'],
			'base_price'      => $calc['base_price'],
			'sale_price'      => $calc['sale_price'],
			'variation_price' => $calc['variation_price'],
			'variation_id'    => $calc['variation_id'],
			'selection'       => $resolution['selection'],
		];
	}

	// =========================================================================
	// 5. Internal Schema Decoding & Strict Validation Helpers
	// =========================================================================

	/**
	 * Decode and strictly validate raw JSON schema fields from storage.
	 * Never silently repairs corrupt schemas; rejects any invalid data with WP_Error.
	 *
	 * @param mixed $raw_attr_json  Stored attributes schema JSON.
	 * @param mixed $raw_var_json   Stored variations schema JSON.
	 * @param mixed $raw_addon_json Stored add-ons schema JSON.
	 * @return array{
	 *     attributes: array<int, array<string, mixed>>,
	 *     variations: array<int, array<string, mixed>>,
	 *     addons: array<int, array<string, mixed>>
	 * }|WP_Error
	 */
	private function decode_and_validate_schemas(
		mixed $raw_attr_json,
		mixed $raw_var_json,
		mixed $raw_addon_json
	): array|WP_Error {
		// 1. Safely decode attributes schema JSON.
		$raw_attributes = $this->decode_raw_schema_json( $raw_attr_json, 'attributes' );
		if ( is_wp_error( $raw_attributes ) ) {
			return $raw_attributes;
		}

		// 2. Safely decode variations schema JSON.
		$raw_variations = $this->decode_raw_schema_json( $raw_var_json, 'variations' );
		if ( is_wp_error( $raw_variations ) ) {
			return $raw_variations;
		}

		// 3. Safely decode add-ons schema JSON.
		$raw_addons = $this->decode_raw_schema_json( $raw_addon_json, 'addons' );
		if ( is_wp_error( $raw_addons ) ) {
			return $raw_addons;
		}

		// 4. Verify no empty rows are present in stored data (strict integrity check).
		foreach ( $raw_attributes as $idx => $row ) {
			if ( ! is_array( $row ) || empty( $row ) ) {
				return new WP_Error(
					self::ERROR_INVALID_SCHEMA,
					sprintf(
						/* translators: %d: attribute index number */
						__( 'Attribute #%d in storage is empty or malformed.', 'maktomine-restaurant-core' ),
						(int) $idx + 1
					)
				);
			}
		}

		foreach ( $raw_variations as $idx => $row ) {
			if ( ! is_array( $row ) || empty( $row ) ) {
				return new WP_Error(
					self::ERROR_INVALID_SCHEMA,
					sprintf(
						/* translators: %d: variation index number */
						__( 'Variation #%d in storage is empty or malformed.', 'maktomine-restaurant-core' ),
						(int) $idx + 1
					)
				);
			}
		}

		foreach ( $raw_addons as $idx => $row ) {
			if ( ! is_array( $row ) || empty( $row ) ) {
				return new WP_Error(
					self::ERROR_INVALID_SCHEMA,
					sprintf(
						/* translators: %d: add-on index number */
						__( 'Add-on #%d in storage is empty or malformed.', 'maktomine-restaurant-core' ),
						(int) $idx + 1
					)
				);
			}
		}

		// 5. Authoritative validation via FoodSchemaValidator.
		$validation = FoodSchemaValidator::validate_submission( $raw_attributes, $raw_variations, $raw_addons );

		if ( ! $validation['valid'] ) {
			return new WP_Error(
				self::ERROR_INVALID_SCHEMA,
				implode( ' ', $validation['errors'] ),
				[ 'errors' => $validation['errors'] ]
			);
		}

		return [
			'attributes' => $validation['attributes_data'],
			'variations' => $validation['variations_data'],
			'addons'     => $validation['addons_data'],
		];
	}

	/**
	 * Decode a stored schema JSON value safely into an array of records.
	 *
	 * @param mixed  $raw_json Raw string or array from postmeta.
	 * @param string $root_key Expected root key ('attributes', 'variations', 'addons').
	 * @return array<int, mixed>|WP_Error List of records on success, WP_Error on malformed JSON or invalid format.
	 */
	private function decode_raw_schema_json( mixed $raw_json, string $root_key ): array|WP_Error {
		if ( null === $raw_json || '' === $raw_json || false === $raw_json ) {
			return [];
		}

		if ( is_array( $raw_json ) ) {
			if ( isset( $raw_json[ $root_key ] ) && is_array( $raw_json[ $root_key ] ) ) {
				return array_values( $raw_json[ $root_key ] );
			}
			return array_values( $raw_json );
		}

		if ( ! is_string( $raw_json ) ) {
			return new WP_Error(
				self::ERROR_INVALID_SCHEMA,
				sprintf(
					/* translators: %s: schema name */
					__( '%s schema must be a valid JSON string.', 'maktomine-restaurant-core' ),
					ucfirst( $root_key )
				)
			);
		}

		$trimmed = trim( $raw_json );
		if ( '' === $trimmed || '[]' === $trimmed || 'null' === $trimmed ) {
			return [];
		}

		if ( strlen( $trimmed ) > FoodSchemaValidator::MAX_SCHEMA_SIZE ) {
			return new WP_Error(
				self::ERROR_INVALID_SCHEMA,
				sprintf(
					/* translators: %s: schema name */
					__( '%s schema exceeds maximum payload limits.', 'maktomine-restaurant-core' ),
					ucfirst( $root_key )
				)
			);
		}

		$decoded = json_decode( $trimmed, true );
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return new WP_Error(
				self::ERROR_INVALID_SCHEMA,
				sprintf(
					/* translators: %s: schema name */
					__( '%s schema contains malformed JSON.', 'maktomine-restaurant-core' ),
					ucfirst( $root_key )
				),
				[ 'json_error' => json_last_error_msg() ]
			);
		}

		if ( ! is_array( $decoded ) ) {
			return new WP_Error(
				self::ERROR_INVALID_SCHEMA,
				sprintf(
					/* translators: %s: schema name */
					__( '%s schema must decode to an array or object.', 'maktomine-restaurant-core' ),
					ucfirst( $root_key )
				)
			);
		}

		// Structure: {"attributes": [...]}
		if ( isset( $decoded[ $root_key ] ) ) {
			if ( ! is_array( $decoded[ $root_key ] ) ) {
				return new WP_Error(
					self::ERROR_INVALID_SCHEMA,
					sprintf(
						/* translators: %s: schema name */
						__( '%s key in schema must be an array.', 'maktomine-restaurant-core' ),
						$root_key
					)
				);
			}
			return array_values( $decoded[ $root_key ] );
		}

		// If decoded is directly an indexed list.
		$is_list = function_exists( 'array_is_list' )
			? array_is_list( $decoded )
			: ( empty( $decoded ) || array_keys( $decoded ) === range( 0, count( $decoded ) - 1 ) );

		if ( $is_list ) {
			return $decoded;
		}

		// If empty object {}
		if ( empty( $decoded ) ) {
			return [];
		}

		return new WP_Error(
			self::ERROR_INVALID_SCHEMA,
			sprintf(
				/* translators: %s: schema name */
				__( '%s schema has an invalid structure.', 'maktomine-restaurant-core' ),
				ucfirst( $root_key )
			)
		);
	}

	/**
	 * Normalize WordPress taxonomy terms into clean associative arrays.
	 *
	 * @param int    $food_id  Food item post ID.
	 * @param string $taxonomy Taxonomy slug.
	 * @return array<int, array{id: int, name: string, slug: string}>
	 */
	private function normalize_taxonomy_terms( int $food_id, string $taxonomy ): array {
		$terms = get_the_terms( $food_id, $taxonomy );
		if ( ! is_array( $terms ) || is_wp_error( $terms ) ) {
			return [];
		}

		$normalized = [];
		foreach ( $terms as $term ) {
			if ( $term instanceof WP_Term ) {
				$normalized[] = [
					'id'   => (int) $term->term_id,
					'name' => (string) $term->name,
					'slug' => (string) $term->slug,
				];
			}
		}

		return $normalized;
	}

	/**
	 * Validate a boolean query argument.
	 *
	 * Accepts boolean true/false, integer 1/0, or string 'true'/'false'/'1'/'0'.
	 * Rejects all arbitrary or ambiguous truthiness strings.
	 *
	 * @param mixed  $value      Raw input value.
	 * @param string $param_name Name of the parameter for error reporting.
	 * @return bool|WP_Error Validated boolean value on success, WP_Error on invalid input.
	 */
	private function validate_boolean_filter( mixed $value, string $param_name ): bool|WP_Error {
		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( 1 === $value || '1' === $value || 'true' === $value ) {
			return true;
		}

		if ( 0 === $value || '0' === $value || 'false' === $value ) {
			return false;
		}

		return new WP_Error(
			self::ERROR_INVALID_ARGUMENT,
			sprintf(
				/* translators: %s: Parameter name */
				__( 'The %s parameter must be a boolean value (true/false or 1/0).', 'maktomine-restaurant-core' ),
				$param_name
			)
		);
	}

	/**
	 * Validate a taxonomy term slug query argument against canonical slug rules and term existence.
	 *
	 * Enforces VALIDATE -> LOOK UP rather than SANITIZE/MUTATE -> LOOK UP:
	 * 1. Requires a scalar string.
	 * 2. Trims surrounding whitespace and rejects empty strings.
	 * 3. Confirms the supplied string is already in canonical WordPress slug syntax without mutation.
	 * 4. Verifies the canonical slug exists in the specified taxonomy.
	 *
	 * @param mixed  $value      Raw input value.
	 * @param string $taxonomy   Target taxonomy name (e.g. Taxonomies::FOOD_CATEGORY_TAX).
	 * @param string $param_name Name of the parameter for error reporting ('category' or 'tag').
	 * @return string|WP_Error Validated canonical term slug on success, WP_Error on failure.
	 */
	private function validate_taxonomy_slug_filter( mixed $value, string $taxonomy, string $param_name ): string|WP_Error {
		// 1. Must be a scalar string.
		if ( ! is_string( $value ) ) {
			return new WP_Error(
				self::ERROR_INVALID_ARGUMENT,
				sprintf(
					/* translators: %s: Parameter name */
					__( 'The %s parameter must be a string slug.', 'maktomine-restaurant-core' ),
					$param_name
				)
			);
		}

		// 2. Trim surrounding whitespace only and verify non-empty.
		$slug = trim( $value );
		if ( '' === $slug ) {
			return new WP_Error(
				self::ERROR_INVALID_ARGUMENT,
				sprintf(
					/* translators: %s: Parameter name */
					__( 'The %s parameter must be a non-empty string slug.', 'maktomine-restaurant-core' ),
					$param_name
				)
			);
		}

		// 3. Strict canonical slug syntax check (VALIDATE, DO NOT MUTATE).
		// If sanitize_title() differs from the trimmed input, the input was not already a canonical slug.
		if ( function_exists( 'sanitize_title' ) && $slug !== sanitize_title( $slug ) ) {
			return new WP_Error(
				self::ERROR_INVALID_ARGUMENT,
				sprintf(
					/* translators: 1: Parameter name, 2: Provided value */
					__( 'The %1$s parameter "%2$s" is not a valid canonical term slug.', 'maktomine-restaurant-core' ),
					$param_name,
					$value
				)
			);
		}

		// 4. Verify term existence in taxonomy (LOOK UP).
		if ( function_exists( 'get_term_by' ) ) {
			$term = get_term_by( 'slug', $slug, $taxonomy );
			if ( ! $term instanceof WP_Term ) {
				return new WP_Error(
					self::ERROR_INVALID_ARGUMENT,
					sprintf(
						/* translators: 1: Parameter name (capitalized), 2: Term slug */
						__( '%1$s term "%2$s" does not exist.', 'maktomine-restaurant-core' ),
						ucfirst( $param_name ),
						$slug
					)
				);
			}
		}

		return $slug;
	}
}
