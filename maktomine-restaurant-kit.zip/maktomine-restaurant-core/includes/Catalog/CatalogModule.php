<?php
/**
 * Catalog Module.
 * Initializes food catalog CPTs and Taxonomies.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Contracts\ModuleInterface;

final class CatalogModule implements ModuleInterface {

	public function get_id(): string {
		return 'catalog';
	}

	public function register(): void {
		add_action( 'init', [ PostTypes::class, 'register' ], 5 );
		add_action( 'init', [ Taxonomies::class, 'register' ], 5 );
		add_action( 'init', [ FoodItemMeta::class, 'register' ], 10 );

		if ( is_admin() ) {
			FoodItemAdmin::init();
		}
	}

	public function boot(): void {
		// Ready for Phase 3 variations and pricing extensions.
	}
}
