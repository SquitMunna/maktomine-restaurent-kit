<?php
/**
 * Taxonomies Registration Foundation.
 * Registers food categories, dietary tags, and gallery categories.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Capabilities\CapabilityManager;

final class Taxonomies {

	public const FOOD_CATEGORY_TAX = 'mkt_food_category';
	public const FOOD_TAG_TAX      = 'mkt_food_tag';
	public const GALLERY_CAT_TAX   = 'mkt_gallery_category';

	/**
	 * Register all custom taxonomies.
	 *
	 * @return void
	 */
	public static function register(): void {
		self::register_food_category();
		self::register_food_tag();
		self::register_gallery_category();
	}

	/**
	 * Register Menu Category Taxonomy (mkt_food_category).
	 * Hierarchical taxonomy for grouping food items.
	 */
	private static function register_food_category(): void {
		$labels = [
			'name'              => _x( 'Menu Categories', 'taxonomy general name', 'maktomine-restaurant-core' ),
			'singular_name'     => _x( 'Menu Category', 'taxonomy singular name', 'maktomine-restaurant-core' ),
			'search_items'      => __( 'Search Menu Categories', 'maktomine-restaurant-core' ),
			'all_items'         => __( 'All Categories', 'maktomine-restaurant-core' ),
			'parent_item'       => __( 'Parent Category', 'maktomine-restaurant-core' ),
			'parent_item_colon' => __( 'Parent Category:', 'maktomine-restaurant-core' ),
			'edit_item'         => __( 'Edit Category', 'maktomine-restaurant-core' ),
			'update_item'       => __( 'Update Category', 'maktomine-restaurant-core' ),
			'add_new_item'      => __( 'Add New Menu Category', 'maktomine-restaurant-core' ),
			'new_item_name'     => __( 'New Category Name', 'maktomine-restaurant-core' ),
			'menu_name'         => __( 'Categories', 'maktomine-restaurant-core' ),
		];

		$args = [
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => 'food-category', 'with_front' => false ],
			'show_in_rest'      => true,
			'rest_base'         => 'food-categories',
			'capabilities'      => [
				'manage_terms' => CapabilityManager::MANAGE_MENU,
				'edit_terms'   => CapabilityManager::MANAGE_MENU,
				'delete_terms' => CapabilityManager::MANAGE_MENU,
				'assign_terms' => CapabilityManager::EDIT_FOOD_ITEMS,
			],
		];

		register_taxonomy( self::FOOD_CATEGORY_TAX, [ PostTypes::FOOD_ITEM_CPT ], $args );
	}

	/**
	 * Register Dietary Tag Taxonomy (mkt_food_tag).
	 * Non-hierarchical taxonomy for dietary preferences (Vegan, Gluten-Free, Halal, Spicy, etc.).
	 */
	private static function register_food_tag(): void {
		$labels = [
			'name'          => _x( 'Dietary Tags', 'taxonomy general name', 'maktomine-restaurant-core' ),
			'singular_name' => _x( 'Dietary Tag', 'taxonomy singular name', 'maktomine-restaurant-core' ),
			'search_items'  => __( 'Search Dietary Tags', 'maktomine-restaurant-core' ),
			'all_items'     => __( 'All Dietary Tags', 'maktomine-restaurant-core' ),
			'edit_item'     => __( 'Edit Tag', 'maktomine-restaurant-core' ),
			'update_item'   => __( 'Update Tag', 'maktomine-restaurant-core' ),
			'add_new_item'  => __( 'Add New Dietary Tag', 'maktomine-restaurant-core' ),
			'new_item_name' => __( 'New Dietary Tag Name', 'maktomine-restaurant-core' ),
			'menu_name'     => __( 'Dietary Tags', 'maktomine-restaurant-core' ),
		];

		$args = [
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => 'dietary-tag', 'with_front' => false ],
			'show_in_rest'      => true,
			'rest_base'         => 'food-tags',
			'capabilities'      => [
				'manage_terms' => CapabilityManager::MANAGE_MENU,
				'edit_terms'   => CapabilityManager::MANAGE_MENU,
				'delete_terms' => CapabilityManager::MANAGE_MENU,
				'assign_terms' => CapabilityManager::EDIT_FOOD_ITEMS,
			],
		];

		register_taxonomy( self::FOOD_TAG_TAX, [ PostTypes::FOOD_ITEM_CPT ], $args );
	}

	/**
	 * Register Gallery Category Taxonomy (mkt_gallery_category).
	 * Hierarchical taxonomy for restaurant gallery collections.
	 */
	private static function register_gallery_category(): void {
		$labels = [
			'name'          => _x( 'Gallery Categories', 'taxonomy general name', 'maktomine-restaurant-core' ),
			'singular_name' => _x( 'Gallery Category', 'taxonomy singular name', 'maktomine-restaurant-core' ),
			'menu_name'     => __( 'Gallery Categories', 'maktomine-restaurant-core' ),
		];

		$args = [
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => 'gallery-category', 'with_front' => false ],
			'show_in_rest'      => true,
			'capabilities'      => [
				'manage_terms' => CapabilityManager::MANAGE_GALLERY,
				'edit_terms'   => CapabilityManager::MANAGE_GALLERY,
				'delete_terms' => CapabilityManager::MANAGE_GALLERY,
				'assign_terms' => CapabilityManager::MANAGE_GALLERY,
			],
		];

		register_taxonomy( self::GALLERY_CAT_TAX, [ PostTypes::GALLERY_CPT ], $args );
	}
}
