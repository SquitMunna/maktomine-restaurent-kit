<?php
/**
 * Variation Matrix Resolver.
 * Resolves requested customer attribute selections against a food item's variation matrix.
 * Pure catalog-domain service with no database side-effects or price calculations.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Class VariationMatrixResolver
 *
 * Evaluates customer attribute selections against a validated food item's attribute
 * and variation schemas to locate the exact matching variation record.
 */
final class VariationMatrixResolver {

	/**
	 * Error codes.
	 */
	public const ERROR_INVALID_SCHEMA                   = 'invalid_schema';
	public const ERROR_INVALID_SELECTION                = 'invalid_selection';
	public const ERROR_UNKNOWN_ATTRIBUTE                = 'unknown_attribute';
	public const ERROR_UNKNOWN_OPTION                   = 'unknown_option';
	public const ERROR_MISSING_REQUIRED_ATTRIBUTE       = 'missing_required_attribute';
	public const ERROR_DUPLICATE_VARIATION_COMBINATION  = 'duplicate_variation_combination';
	public const ERROR_VARIATION_NOT_FOUND              = 'variation_not_found';

	/**
	 * Resolve a set of attribute selections against the provided schemas.
	 *
	 * Note: This service is stateless and does not query or mutate the database,
	 * does not evaluate or calculate prices, and does not enforce cart or order policy.
	 *
	 * @param array $attributes_schema Attribute schema array (or ['attributes' => [...]]).
	 * @param array $variations_schema Variation schema array (or ['variations' => [...]]).
	 * @param array $selection         Customer attribute selections [ 'attribute_id' => 'option_id' ].
	 * @return array{
	 *     success: bool,
	 *     matched: bool,
	 *     variation: array<string, mixed>|null,
	 *     selection: array<string, string>,
	 *     error: array{code: string, message: string, attribute_id?: string, option_id?: string, combination?: string}|null
	 * }
	 */
	public static function resolve(
		array $attributes_schema,
		array $variations_schema,
		array $selection
	): array {
		// ---------------------------------------------------------------------
		// 1. Extract and Validate Attribute Definitions
		// ---------------------------------------------------------------------
		$raw_attributes = isset( $attributes_schema['attributes'] ) && is_array( $attributes_schema['attributes'] )
			? $attributes_schema['attributes']
			: $attributes_schema;

		$declared_attributes = [];

		foreach ( $raw_attributes as $attr_idx => $attr_data ) {
			if ( ! is_array( $attr_data ) ) {
				return self::failure(
					self::ERROR_INVALID_SCHEMA,
					__( 'Malformed attribute schema definition.', 'maktomine-restaurant-core' ),
					[]
				);
			}

			$raw_id = isset( $attr_data['id'] ) ? (string) $attr_data['id'] : '';
			$attr_id = FoodSchemaValidator::normalize_id( $raw_id );

			if ( '' === $attr_id ) {
				return self::failure(
					self::ERROR_INVALID_SCHEMA,
					__( 'Attribute definition is missing a valid identifier.', 'maktomine-restaurant-core' ),
					[]
				);
			}

			$required = isset( $attr_data['required'] ) ? (bool) $attr_data['required'] : true;
			$raw_options = isset( $attr_data['options'] ) && is_array( $attr_data['options'] )
				? $attr_data['options']
				: [];

			$options_map = [];
			foreach ( $raw_options as $opt_data ) {
				if ( is_array( $opt_data ) && isset( $opt_data['id'] ) ) {
					$opt_id = FoodSchemaValidator::normalize_id( (string) $opt_data['id'] );
					if ( '' !== $opt_id ) {
						$options_map[ $opt_id ] = true;
					}
				}
			}

			$declared_attributes[ $attr_id ] = [
				'id'       => $attr_id,
				'name'     => isset( $attr_data['name'] ) ? (string) $attr_data['name'] : $attr_id,
				'required' => $required,
				'options'  => $options_map,
			];
		}

		// ---------------------------------------------------------------------
		// 2. Normalize and Validate Incoming Selection
		// ---------------------------------------------------------------------
		$normalized_selection = [];

		foreach ( $selection as $attr_key => $opt_val ) {
			if ( ! is_scalar( $attr_key ) || ! is_scalar( $opt_val ) ) {
				return self::failure(
					self::ERROR_INVALID_SELECTION,
					__( 'Attribute selection must contain scalar values.', 'maktomine-restaurant-core' ),
					[]
				);
			}

			$norm_attr = FoodSchemaValidator::normalize_id( (string) $attr_key );
			$norm_opt  = FoodSchemaValidator::normalize_id( (string) $opt_val );

			if ( '' === $norm_attr || '' === $norm_opt ) {
				return self::failure(
					self::ERROR_INVALID_SELECTION,
					__( 'Attribute and option identifiers cannot be empty.', 'maktomine-restaurant-core' ),
					[]
				);
			}

			if ( isset( $normalized_selection[ $norm_attr ] ) && $normalized_selection[ $norm_attr ] !== $norm_opt ) {
				return self::failure(
					self::ERROR_INVALID_SELECTION,
					sprintf(
						/* translators: %s: attribute identifier */
						__( "Conflicting values provided for attribute '%s'.", 'maktomine-restaurant-core' ),
						$norm_attr
					),
					$normalized_selection,
					[ 'attribute_id' => $norm_attr ]
				);
			}

			$normalized_selection[ $norm_attr ] = $norm_opt;
		}

		// ---------------------------------------------------------------------
		// 3. Verify Selection Against Declared Attributes & Options
		// ---------------------------------------------------------------------
		foreach ( $normalized_selection as $selected_attr => $selected_opt ) {
			if ( ! isset( $declared_attributes[ $selected_attr ] ) ) {
				return self::failure(
					self::ERROR_UNKNOWN_ATTRIBUTE,
					sprintf(
						/* translators: %s: attribute identifier */
						__( "Attribute '%s' is not recognized.", 'maktomine-restaurant-core' ),
						$selected_attr
					),
					$normalized_selection,
					[ 'attribute_id' => $selected_attr ]
				);
			}

			if ( ! isset( $declared_attributes[ $selected_attr ]['options'][ $selected_opt ] ) ) {
				return self::failure(
					self::ERROR_UNKNOWN_OPTION,
					sprintf(
						/* translators: 1: option identifier, 2: attribute identifier */
						__( "Option '%1$s' is not recognized for attribute '%2$s'.", 'maktomine-restaurant-core' ),
						$selected_opt,
						$selected_attr
					),
					$normalized_selection,
					[
						'attribute_id' => $selected_attr,
						'option_id'    => $selected_opt,
					]
				);
			}
		}

		// ---------------------------------------------------------------------
		// 4. Verify All Required Attributes Are Present
		// ---------------------------------------------------------------------
		foreach ( $declared_attributes as $attr_id => $attr_meta ) {
			if ( $attr_meta['required'] && ! isset( $normalized_selection[ $attr_id ] ) ) {
				return self::failure(
					self::ERROR_MISSING_REQUIRED_ATTRIBUTE,
					sprintf(
						/* translators: %s: attribute identifier */
						__( "Required attribute '%s' is missing from selection.", 'maktomine-restaurant-core' ),
						$attr_id
					),
					$normalized_selection,
					[ 'attribute_id' => $attr_id ]
				);
			}
		}

		// ---------------------------------------------------------------------
		// 5. Extract and Validate Variations Matrix
		// ---------------------------------------------------------------------
		$raw_variations = isset( $variations_schema['variations'] ) && is_array( $variations_schema['variations'] )
			? $variations_schema['variations']
			: $variations_schema;

		// Deterministic comparison signature for requested selection.
		$selection_signature = self::build_combination_signature( $normalized_selection );

		$seen_combinations  = [];
		$matched_variation  = null;

		foreach ( $raw_variations as $var_idx => $var_data ) {
			if ( ! is_array( $var_data ) ) {
				return self::failure(
					self::ERROR_INVALID_SCHEMA,
					__( 'Malformed variation schema definition.', 'maktomine-restaurant-core' ),
					$normalized_selection
				);
			}

			$var_attributes = isset( $var_data['attributes'] ) && is_array( $var_data['attributes'] )
				? $var_data['attributes']
				: [];

			if ( empty( $var_attributes ) ) {
				return self::failure(
					self::ERROR_INVALID_SCHEMA,
					__( 'Variation record is missing attribute combinations.', 'maktomine-restaurant-core' ),
					$normalized_selection
				);
			}

			// Normalize variation attribute map.
			$var_attr_map = [];
			foreach ( $var_attributes as $v_attr => $v_opt ) {
				if ( ! is_scalar( $v_attr ) || ! is_scalar( $v_opt ) ) {
					continue;
				}
				$norm_v_attr = FoodSchemaValidator::normalize_id( (string) $v_attr );
				$norm_v_opt  = FoodSchemaValidator::normalize_id( (string) $v_opt );
				if ( '' !== $norm_v_attr && '' !== $norm_v_opt ) {
					$var_attr_map[ $norm_v_attr ] = $norm_v_opt;
				}
			}

			$var_signature = self::build_combination_signature( $var_attr_map );

			// Duplicate combination protection.
			if ( isset( $seen_combinations[ $var_signature ] ) ) {
				return self::failure(
					self::ERROR_DUPLICATE_VARIATION_COMBINATION,
					sprintf(
						/* translators: %s: variation combination signature */
						__( "Duplicate variation combination detected: '%s'.", 'maktomine-restaurant-core' ),
						$var_signature
					),
					$normalized_selection,
					[ 'combination' => $var_signature ]
				);
			}

			$seen_combinations[ $var_signature ] = true;

			// Exact match comparison.
			if ( $var_signature === $selection_signature && null === $matched_variation ) {
				$matched_variation = [
					'id'           => isset( $var_data['id'] ) ? (string) $var_data['id'] : '',
					'attributes'   => $var_attr_map,
					'price'        => isset( $var_data['price'] ) ? (float) $var_data['price'] : 0.0,
					'availability' => isset( $var_data['availability'] ) ? (string) $var_data['availability'] : FoodItemMeta::STATUS_IN_STOCK,
					'sort_order'   => isset( $var_data['sort_order'] ) ? (int) $var_data['sort_order'] : 0,
				];
			}
		}

		// ---------------------------------------------------------------------
		// 6. Match Result Construction
		// ---------------------------------------------------------------------
		if ( null !== $matched_variation ) {
			return [
				'success'   => true,
				'matched'   => true,
				'variation' => $matched_variation,
				'selection' => $normalized_selection,
				'error'     => null,
			];
		}

		// Valid selection, but no matching variation exists in matrix.
		return [
			'success'   => true,
			'matched'   => false,
			'variation' => null,
			'selection' => $normalized_selection,
			'error'     => [
				'code'    => self::ERROR_VARIATION_NOT_FOUND,
				'message' => __( 'No variation matches the selected options.', 'maktomine-restaurant-core' ),
			],
		];
	}

	/**
	 * Build a deterministic combination signature string for comparison.
	 * Sorts keys alphabetically so key order never affects matching.
	 *
	 * @param array<string, string> $map Associative map of attribute_id => option_id.
	 * @return string Canonical signature e.g. "crust=thin|size=large".
	 */
	public static function build_combination_signature( array $map ): string {
		if ( empty( $map ) ) {
			return '';
		}

		ksort( $map );
		$parts = [];
		foreach ( $map as $k => $v ) {
			$parts[] = (string) $k . '=' . (string) $v;
		}

		return implode( '|', $parts );
	}

	/**
	 * Helper to build a structured failure response.
	 *
	 * @param string                $code      Stable error code.
	 * @param string                $message   Human-readable message.
	 * @param array<string, string> $selection Normalized selection so far.
	 * @param array<string, string> $context   Additional error context.
	 * @return array{
	 *     success: false,
	 *     matched: false,
	 *     variation: null,
	 *     selection: array<string, string>,
	 *     error: array{code: string, message: string, attribute_id?: string, option_id?: string, combination?: string}
	 * }
	 */
	private static function failure( string $code, string $message, array $selection, array $context = [] ): array {
		$error = array_merge(
			[
				'code'    => $code,
				'message' => $message,
			],
			$context
		);

		return [
			'success'   => false,
			'matched'   => false,
			'variation' => null,
			'selection' => $selection,
			'error'     => $error,
		];
	}
}
