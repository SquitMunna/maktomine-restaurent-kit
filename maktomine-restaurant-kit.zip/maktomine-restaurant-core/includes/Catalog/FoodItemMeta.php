<?php
/**
 * Food Item Meta Registry and Schema Definition.
 * Registers protected post meta fields, REST schemas, and sanitization/auth callbacks.
 *
 * @package Maktomine\RestaurantCore\Catalog
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Catalog;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Capabilities\CapabilityManager;
use Maktomine\RestaurantCore\Support\Sanitizer;

final class FoodItemMeta {

	// Canonical Post Meta Keys (Exact _mkt_ naming convention).
	public const META_BASE_PRICE          = '_mkt_base_price';
	public const META_SALE_PRICE          = '_mkt_sale_price';
	public const META_AVAILABILITY_STATUS = '_mkt_availability_status';
	public const META_IS_FEATURED         = '_mkt_is_featured';
	public const META_IS_POPULAR          = '_mkt_is_popular';
	public const META_PREP_TIME           = '_mkt_prep_time';
	public const META_CALORIES            = '_mkt_calories';
	public const META_IMAGE_ID            = '_mkt_image_id';
	public const META_ATTRIBUTES_SCHEMA   = '_mkt_attributes_schema';
	public const META_VARIATIONS_SCHEMA   = '_mkt_variations_schema';
	public const META_ADDONS_SCHEMA       = '_mkt_addons_schema';

	// Allowed Availability Status Enum.
	public const STATUS_IN_STOCK         = 'in_stock';
	public const STATUS_OUT_OF_STOCK     = 'out_of_stock';
	public const STATUS_PRE_ORDER_ONLY   = 'pre_order_only';

	public const ALLOWED_AVAILABILITY = [
		self::STATUS_IN_STOCK,
		self::STATUS_OUT_OF_STOCK,
		self::STATUS_PRE_ORDER_ONLY,
	];

	/**
	 * Register all food item meta keys with WordPress.
	 *
	 * @return void
	 */
	public static function register(): void {
		// 1. Base Price (number).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_BASE_PRICE,
			[
				'type'              => 'number',
				'description'       => __( 'Standard base price for the food item.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => 0.0,
				'sanitize_callback' => [ self::class, 'sanitize_price' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => [
					'schema' => [
						'type'        => 'number',
						'minimum'     => 0,
						'default'     => 0.0,
						'description' => 'Base price in standard currency format.',
					],
				],
			]
		);

		// 2. Sale Price (number, optional/promotional, 0.0 when none).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_SALE_PRICE,
			[
				'type'              => 'number',
				'description'       => __( 'Discounted sale price for the food item.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => 0.0,
				'sanitize_callback' => [ self::class, 'sanitize_optional_price' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => [
					'schema' => [
						'type'        => 'number',
						'minimum'     => 0,
						'default'     => 0.0,
						'description' => 'Sale price if on promotion (0 if none).',
					],
				],
			]
		);

		// 3. Availability Status (enum string).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_AVAILABILITY_STATUS,
			[
				'type'              => 'string',
				'description'       => __( 'Stock and availability status.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => self::STATUS_IN_STOCK,
				'sanitize_callback' => [ self::class, 'sanitize_availability' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => [
					'schema' => [
						'type' => 'string',
						'enum' => self::ALLOWED_AVAILABILITY,
					],
				],
			]
		);

		// 4. Featured Status (boolean 0/1 integer in DB).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_IS_FEATURED,
			[
				'type'              => 'integer',
				'description'       => __( 'Whether item is featured on menus.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => 0,
				'sanitize_callback' => [ self::class, 'sanitize_boolean_int' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => [
					'schema' => [
						'type' => 'boolean',
					],
				],
			]
		);

		// 5. Popular Status (boolean 0/1 integer in DB).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_IS_POPULAR,
			[
				'type'              => 'integer',
				'description'       => __( 'Whether item is marked as popular or chef recommendation.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => 0,
				'sanitize_callback' => [ self::class, 'sanitize_boolean_int' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => [
					'schema' => [
						'type' => 'boolean',
					],
				],
			]
		);

		// 6. Preparation Time in minutes (non-negative integer).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_PREP_TIME,
			[
				'type'              => 'integer',
				'description'       => __( 'Average preparation time in minutes.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => 0,
				'sanitize_callback' => [ self::class, 'sanitize_non_negative_int' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'integer',
						'minimum' => 0,
					],
				],
			]
		);

		// 7. Calories in kcal (non-negative integer).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_CALORIES,
			[
				'type'              => 'integer',
				'description'       => __( 'Calorie content in kcal.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => 0,
				'sanitize_callback' => [ self::class, 'sanitize_non_negative_int' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'integer',
						'minimum' => 0,
					],
				],
			]
		);

		// 8. Image ID (valid attachment ID).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_IMAGE_ID,
			[
				'type'              => 'integer',
				'description'       => __( 'Dedicated catalog image attachment ID.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => 0,
				'sanitize_callback' => [ self::class, 'sanitize_image_id' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'integer',
						'minimum' => 0,
					],
				],
			]
		);

		// 9. Attributes Schema (JSON string).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_ATTRIBUTES_SCHEMA,
			[
				'type'              => 'string',
				'description'       => __( 'JSON representation of item attributes and selections.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => '[]',
				'sanitize_callback' => [ self::class, 'sanitize_json_schema' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => false, // Handled through dedicated normalized catalog layer.
			]
		);

		// 10. Variations Schema (JSON string).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_VARIATIONS_SCHEMA,
			[
				'type'              => 'string',
				'description'       => __( 'JSON representation of price-bearing variations matrix.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => '[]',
				'sanitize_callback' => [ self::class, 'sanitize_json_schema' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => false,
			]
		);

		// 11. Add-ons Schema (JSON string).
		register_post_meta(
			PostTypes::FOOD_ITEM_CPT,
			self::META_ADDONS_SCHEMA,
			[
				'type'              => 'string',
				'description'       => __( 'JSON representation of optional add-ons and price adjustments.', 'maktomine-restaurant-core' ),
				'single'            => true,
				'default'           => '[]',
				'sanitize_callback' => [ self::class, 'sanitize_json_schema' ],
				'auth_callback'     => [ self::class, 'auth_edit_food_item' ],
				'show_in_rest'      => false,
			]
		);
	}

	// =========================================================================
	// Sanitization & Normalization Callbacks
	// =========================================================================

	/**
	 * Sanitize base price into a normalized non-negative float.
	 *
	 * @param mixed $value Raw price input.
	 * @return float
	 */
	public static function sanitize_price( mixed $value ): float {
		return Sanitizer::price( $value );
	}

	/**
	 * Sanitize optional sale price. Returns 0.0 if empty/unset.
	 *
	 * @param mixed $value Raw sale price input.
	 * @return float
	 */
	public static function sanitize_optional_price( mixed $value ): float {
		if ( null === $value || '' === $value || false === $value ) {
			return 0.0;
		}

		$price = Sanitizer::price( $value );
		return $price > 0.0 ? $price : 0.0;
	}

	/**
	 * Validate availability status against allowed enum.
	 *
	 * @param mixed $value Raw status string.
	 * @return string
	 */
	public static function sanitize_availability( mixed $value ): string {
		$status = is_string( $value ) ? sanitize_key( $value ) : '';
		if ( in_array( $status, self::ALLOWED_AVAILABILITY, true ) ) {
			return $status;
		}

		return self::STATUS_IN_STOCK;
	}

	/**
	 * Normalize boolean to 0 or 1 integer.
	 *
	 * @param mixed $value Raw input.
	 * @return int 0 or 1.
	 */
	public static function sanitize_boolean_int( mixed $value ): int {
		if ( is_bool( $value ) ) {
			return $value ? 1 : 0;
		}

		if ( '1' === $value || 1 === $value || 'true' === $value || 'yes' === $value || 'on' === $value ) {
			return 1;
		}

		return 0;
	}

	/**
	 * Normalize non-negative integer (e.g. prep time, calories).
	 *
	 * @param mixed $value Raw input.
	 * @return int
	 */
	public static function sanitize_non_negative_int( mixed $value ): int {
		if ( ! is_numeric( $value ) ) {
			return 0;
		}

		return max( 0, (int) $value );
	}

	/**
	 * Sanitize image attachment ID. Must be a valid non-negative integer.
	 *
	 * @param mixed $value Raw attachment ID.
	 * @return int Valid attachment ID or 0.
	 */
	public static function sanitize_image_id( mixed $value ): int {
		if ( ! is_numeric( $value ) ) {
			return 0;
		}

		$attachment_id = (int) $value;
		if ( $attachment_id <= 0 ) {
			return 0;
		}

		// Verify attachment existence where WordPress functions are available.
		if ( function_exists( 'get_post_type' ) && 'attachment' !== get_post_type( $attachment_id ) ) {
			return 0;
		}

		return $attachment_id;
	}

	/**
	 * Defensively sanitize structured JSON string for attributes, variations, and add-ons.
	 * Re-encodes valid JSON to guarantee well-formed syntax; falls back to '[]' if corrupted.
	 * Enforces defensive maximum size limit (100KB) to guard against unbounded input.
	 *
	 * @param mixed $value Raw JSON string or array.
	 * @return string Clean, validated JSON string.
	 */
	public static function sanitize_json_schema( mixed $value ): string {
		if ( empty( $value ) ) {
			return '[]';
		}

		if ( is_array( $value ) ) {
			$encoded = wp_json_encode( $value );
			return false !== $encoded ? $encoded : '[]';
		}

		if ( is_string( $value ) ) {
			$trimmed = trim( $value );
			if ( '' === $trimmed || 'null' === $trimmed ) {
				return '[]';
			}

			// Defensive upper bound: 100,000 characters.
			if ( strlen( $trimmed ) > 100000 ) {
				return '[]';
			}

			// Validate JSON structure safely.
			$decoded = json_decode( $trimmed, true );
			if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded ) ) {
				$encoded = wp_json_encode( $decoded );
				return false !== $encoded ? $encoded : '[]';
			}
		}

		return '[]';
	}

	// =========================================================================
	// Authorization Callbacks
	// =========================================================================

	/**
	 * Capability check for editing food item meta fields.
	 *
	 * @param bool   $allowed  Whether the user is currently allowed.
	 * @param string $meta_key Meta key being updated.
	 * @param int    $post_id  Post ID.
	 * @return bool
	 */
	public static function auth_edit_food_item( bool $allowed, string $meta_key, int $post_id ): bool {
		if ( ! current_user_can( CapabilityManager::EDIT_FOOD_ITEM, $post_id ) && ! current_user_can( CapabilityManager::MANAGE_MENU ) ) {
			return false;
		}

		return true;
	}
}
