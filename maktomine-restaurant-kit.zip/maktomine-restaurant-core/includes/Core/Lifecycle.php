<?php
/**
 * Plugin Lifecycle Controller.
 * Handles activation, deactivation, rewrite rule flushes, and capability assignment.
 *
 * @package Maktomine\RestaurantCore\Core
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Core;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Database\DatabaseManager;
use Maktomine\RestaurantCore\Capabilities\CapabilityManager;
use Maktomine\RestaurantCore\Catalog\PostTypes;
use Maktomine\RestaurantCore\Catalog\Taxonomies;
use Maktomine\RestaurantCore\Orders\IdempotencyMaintenanceService;

final class Lifecycle {

	/**
	 * Run tasks during plugin activation.
	 *
	 * @return void
	 */
	public static function activate(): void {
		// 1. Assign role capabilities.
		CapabilityManager::register_capabilities();

		// 2. Register CPTs and Taxonomies so rewrites can be registered.
		PostTypes::register();
		Taxonomies::register();

		// 3. Execute database migrations.
		$db_manager = new DatabaseManager();
		$db_manager->migrate();

		// 4. Safe flush rewrite rules.
		flush_rewrite_rules();

		// 5. Schedule idempotency maintenance cron job.
		IdempotencyMaintenanceService::schedule_maintenance();

		Logger::info( 'Maktomine Restaurant Core activated successfully.' );
	}

	/**
	 * Run tasks during plugin deactivation.
	 * Note: Deactivation NEVER drops tables, deletes posts, or erases settings.
	 *
	 * @return void
	 */
	public static function deactivate(): void {
		// 1. Unschedule idempotency maintenance cron job.
		IdempotencyMaintenanceService::unschedule_maintenance();

		// 2. Flush rewrites to remove food-item and food-category rules.
		flush_rewrite_rules();

		Logger::info( 'Maktomine Restaurant Core deactivated safely. All restaurant domain data preserved.' );
	}
}
