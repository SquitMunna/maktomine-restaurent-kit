<?php
/**
 * Internal Security and Error Logger.
 * Provides structured, privacy-hardened event logging with automatic pattern-based redaction.
 *
 * @package Maktomine\RestaurantCore\Core
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Core;

defined( 'ABSPATH' ) || exit;

final class Logger {

	public const LEVEL_DEBUG   = 'DEBUG';
	public const LEVEL_INFO    = 'INFO';
	public const LEVEL_WARNING = 'WARNING';
	public const LEVEL_ERROR   = 'ERROR';

	/**
	 * Log a structured message with privacy filters applied to message and context.
	 *
	 * @param string               $level   One of the LEVEL_* constants.
	 * @param string               $message Informational message.
	 * @param array<string, mixed> $context Additional structured data (sensitive keys stripped).
	 * @return void
	 */
	public static function log( string $level, string $message, array $context = [] ): void {
		$sanitized_message = self::sanitize_message( $message );
		$sanitized_context = self::strip_sensitive_data( $context );

		$entry = sprintf(
			'[%s] [Maktomine Restaurant Core] [%s]: %s %s',
			gmdate( 'Y-m-d H:i:s' ),
			$level,
			$sanitized_message,
			! empty( $sanitized_context ) ? (string) wp_json_encode( $sanitized_context ) : ''
		);

		// Trigger standard WordPress debug log if active.
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			error_log( $entry ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}

		/**
		 * Hook to allow custom logging handlers (e.g., admin log viewer).
		 *
		 * @param string               $level             Log level.
		 * @param string               $sanitized_message Filtered log message.
		 * @param array<string, mixed> $sanitized_context Filtered context data.
		 */
		do_action( 'maktomine/core/log_entry', $level, $sanitized_message, $sanitized_context );
	}

	public static function debug( string $message, array $context = [] ): void {
		self::log( self::LEVEL_DEBUG, $message, $context );
	}

	public static function info( string $message, array $context = [] ): void {
		self::log( self::LEVEL_INFO, $message, $context );
	}

	public static function warning( string $message, array $context = [] ): void {
		self::log( self::LEVEL_WARNING, $message, $context );
	}

	public static function error( string $message, array $context = [] ): void {
		self::log( self::LEVEL_ERROR, $message, $context );
	}

	/**
	 * Check if a normalized context key contains any privacy-sensitive patterns.
	 * Matches variations such as customer_whatsapp, delivery_address, api_key, verification_hash, etc.
	 *
	 * Note: Explicitly exempts the pre-masked correlation field 'idempotency_correlation'
	 * (or 'idempotency_masked') so that diagnostic correlation survives sanitization,
	 * while ensuring any raw key/secret/token remains strictly redacted.
	 *
	 * @param string $key Raw array key name.
	 * @return bool
	 */
	private static function is_sensitive_key( string $key ): bool {
		$normalized = strtolower( preg_replace( '/[^a-z0-9]/', '', $key ) ?? '' );

		if ( empty( $normalized ) ) {
			return false;
		}

		// Pre-masked correlation identifiers are specifically permitted to survive context sanitization.
		// Note: The value MUST be pre-masked (e.g., via OrderIdempotencyService::safe_key_for_log).
		if ( 'idempotencycorrelation' === $normalized || 'idempotencymasked' === $normalized ) {
			return false;
		}

		$sensitive_patterns = [
			'pass',
			'pwd',
			'secret',
			'token',
			'auth',
			'bearer',
			'credential',
			'key',
			'phone',
			'mobile',
			'tel',
			'whatsapp',
			'email',
			'mail',
			'address',
			'street',
			'zip',
			'postal',
			'location',
			'card',
			'cvv',
			'cvc',
			'expir',
			'iban',
			'bank',
			'cookie',
			'session',
			'nonce',
			'hash',
			'salt',
			'signature',
		];

		foreach ( $sensitive_patterns as $pattern ) {
			if ( str_contains( $normalized, $pattern ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Redact high-risk patterns (emails, tokens, credit card sequences) from log message strings.
	 *
	 * @param string $message Raw message.
	 * @return string Sanitized message.
	 */
	private static function sanitize_message( string $message ): string {
		// Redact email addresses.
		$sanitized = preg_replace( '/[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+/', '[REDACTED_EMAIL]', $message ) ?? $message;

		// Redact Bearer / API token values.
		$sanitized = preg_replace( '/((?:Bearer|Token|key=)\s*)[A-Za-z0-9_\-\.]{8,}/i', '$1[REDACTED_TOKEN]', $sanitized ) ?? $sanitized;

		// Redact 13-19 digit card numbers.
		$sanitized = preg_replace( '/\b(?:\d[ -]*?){13,19}\b/', '[REDACTED_CARD]', $sanitized ) ?? $sanitized;

		return $sanitized;
	}

	/**
	 * Recursively remove sensitive customer and system details from context data.
	 *
	 * @param array<string, mixed> $context Raw context data.
	 * @return array<string, mixed>
	 */
	private static function strip_sensitive_data( array $context ): array {
		$clean = [];

		foreach ( $context as $key => $value ) {
			$string_key = (string) $key;

			if ( self::is_sensitive_key( $string_key ) ) {
				$clean[ $key ] = '[REDACTED]';
			} elseif ( is_array( $value ) ) {
				$clean[ $key ] = self::strip_sensitive_data( $value );
			} elseif ( is_string( $value ) ) {
				$clean[ $key ] = self::sanitize_message( $value );
			} else {
				$clean[ $key ] = $value;
			}
		}

		return $clean;
	}
}
