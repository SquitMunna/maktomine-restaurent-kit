<?php
/**
 * Lightweight Service Container / Dependency Locator.
 *
 * @package Maktomine\RestaurantCore\Core
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Core;

defined( 'ABSPATH' ) || exit;

final class Container {

	/**
	 * Service definitions (closures or existing instances).
	 *
	 * @var array<string, mixed>
	 */
	private array $bindings = [];

	/**
	 * Resolved singleton instances.
	 *
	 * @var array<string, object>
	 */
	private array $instances = [];

	/**
	 * Register a binding or instance.
	 *
	 * @param string $id       Service identifier.
	 * @param mixed  $concrete Instance or factory closure.
	 * @return void
	 */
	public function bind( string $id, mixed $concrete ): void {
		$this->bindings[ $id ] = $concrete;
		unset( $this->instances[ $id ] );
	}

	/**
	 * Register a shared singleton service.
	 *
	 * @param string $id       Service identifier.
	 * @param mixed  $concrete Instance or factory closure.
	 * @return void
	 */
	public function singleton( string $id, mixed $concrete ): void {
		$this->bind( $id, $concrete );
	}

	/**
	 * Resolve and retrieve a service by identifier.
	 *
	 * @param string $id Service identifier.
	 * @return mixed
	 */
	public function get( string $id ): mixed {
		if ( isset( $this->instances[ $id ] ) ) {
			return $this->instances[ $id ];
		}

		if ( ! isset( $this->bindings[ $id ] ) ) {
			return null;
		}

		$target = $this->bindings[ $id ];

		if ( is_callable( $target ) ) {
			$instance = $target( $this );
			$this->instances[ $id ] = $instance;
			return $instance;
		}

		if ( is_object( $target ) ) {
			$this->instances[ $id ] = $target;
			return $target;
		}

		return $target;
	}

	/**
	 * Check if a service binding exists.
	 *
	 * @param string $id Service identifier.
	 * @return bool
	 */
	public function has( string $id ): bool {
		return isset( $this->bindings[ $id ] ) || isset( $this->instances[ $id ] );
	}
}
