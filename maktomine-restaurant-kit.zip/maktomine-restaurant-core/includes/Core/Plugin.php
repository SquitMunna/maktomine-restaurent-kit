<?php
/**
 * Main Plugin Orchestrator Kernel.
 * Initializes container, registers core modules, and dispatches boot events.
 *
 * @package Maktomine\RestaurantCore\Core
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Core;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Contracts\ModuleInterface;
use Maktomine\RestaurantCore\Catalog\CatalogModule;
use Maktomine\RestaurantCore\Settings\SettingsManager;
use Maktomine\RestaurantCore\Admin\AdminModule;
use Maktomine\RestaurantCore\REST\RestModule;
use Maktomine\RestaurantCore\Database\DatabaseManager;
use Maktomine\RestaurantCore\Orders\IdempotencyMaintenanceService;

final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Flag indicating whether all core modules have completed registration and boot.
	 *
	 * @var bool
	 */
	private bool $is_booted = false;

	/**
	 * Service and dependency container.
	 *
	 * @var Container
	 */
	private Container $container;

	/**
	 * Registered module instances.
	 *
	 * @var array<string, ModuleInterface>
	 */
	private array $modules = [];

	/**
	 * Prevent direct instantiation.
	 */
	private function __construct() {
		$this->container = new Container();
	}

	/**
	 * Retrieve singleton instance.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Static check to verify if the plugin kernel exists and is fully booted.
	 *
	 * @return bool
	 */
	public static function is_active(): bool {
		return null !== self::$instance && self::$instance->is_booted();
	}

	/**
	 * Check if all modules have booted.
	 *
	 * @return bool
	 */
	public function is_booted(): bool {
		return $this->is_booted;
	}

	/**
	 * Boot all plugin modules and subsystems in sequential phases.
	 *
	 * @return void
	 */
	public function boot(): void {
		if ( $this->is_booted ) {
			return;
		}

		// Load text domain for internationalization.
		load_plugin_textdomain(
			'maktomine-restaurant-core',
			false,
			dirname( plugin_basename( MAKTOMINE_CORE_FILE ) ) . '/languages/'
		);

		// Register core modules into the container.
		$this->register_default_modules();

		// Phase 1: Register phase (hooks, CPTs, taxonomies, settings).
		foreach ( $this->modules as $module ) {
			$module->register();
		}

		// Check for database schema updates on boot (covers plugin updates without re-activation).
		$db_manager = new DatabaseManager();
		$db_manager->maybe_migrate();

		// Phase 2: Boot phase (cross-module listeners, runtime initialization).
		foreach ( $this->modules as $module ) {
			$module->boot();
		}

		// Register idempotency maintenance cron listener.
		( new IdempotencyMaintenanceService() )->register();

		// Ensure scheduler is registered when migrations run during an update without re-activation.
		add_action( 'maktomine/database/migrated', [ IdempotencyMaintenanceService::class, 'maybe_schedule_on_update' ] );

		// Mark kernel as fully active and ready for consumption.
		$this->is_booted = true;

		/**
		 * Action triggered when Maktomine Restaurant Core has completely booted.
		 * Available for Theme and third-party extensions to hook into.
		 *
		 * @param Plugin $this Plugin kernel instance.
		 */
		do_action( 'maktomine/core/loaded', $this );
	}

	/**
	 * Register default modules for Phase 1.
	 *
	 * @return void
	 */
	private function register_default_modules(): void {
		$core_modules = [
			new SettingsManager(),
			new CatalogModule(),
			new AdminModule(),
			new RestModule(),
		];

		foreach ( $core_modules as $module ) {
			$this->register_module( $module );
		}
	}

	/**
	 * Register an individual module.
	 *
	 * @param ModuleInterface $module Module instance.
	 * @return void
	 */
	public function register_module( ModuleInterface $module ): void {
		$id = $module->get_id();
		$this->modules[ $id ] = $module;
		$this->container->singleton( "module.{$id}", $module );
	}

	/**
	 * Get module by ID.
	 *
	 * @param string $id Module ID.
	 * @return ModuleInterface|null
	 */
	public function get_module( string $id ): ?ModuleInterface {
		return $this->modules[ $id ] ?? null;
	}

	/**
	 * Retrieve container instance.
	 *
	 * @return Container
	 */
	public function get_container(): Container {
		return $this->container;
	}
}
