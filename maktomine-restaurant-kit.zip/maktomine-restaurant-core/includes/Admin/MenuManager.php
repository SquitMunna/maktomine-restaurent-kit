<?php
/**
 * Admin Menu Manager.
 * Defines the commercial WordPress admin menu structure with capability verification.
 *
 * @package Maktomine\RestaurantCore\Admin
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Admin;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Capabilities\CapabilityManager;
use Maktomine\RestaurantCore\Catalog\PostTypes;
use Maktomine\RestaurantCore\Catalog\Taxonomies;
use Maktomine\RestaurantCore\Compatibility\IntegrationDetector;

final class MenuManager {

	/**
	 * Register top-level and sub-level admin menus.
	 *
	 * @return void
	 */
	public static function register(): void {
		// 1. Food Menu (Top-level).
		add_menu_page(
			__( 'Food Menu', 'maktomine-restaurant-core' ),
			__( 'Food Menu', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_MENU,
			'mkt_food_menu',
			[ self::class, 'render_food_menu_page' ],
			'dashicons-food',
			26
		);

		// Submenus under Food Menu.
		add_submenu_page(
			'mkt_food_menu',
			__( 'All Food Items', 'maktomine-restaurant-core' ),
			__( 'All Food Items', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_MENU,
			'edit.php?post_type=' . PostTypes::FOOD_ITEM_CPT
		);

		add_submenu_page(
			'mkt_food_menu',
			__( 'Add New Item', 'maktomine-restaurant-core' ),
			__( 'Add New Item', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_MENU,
			'post-new.php?post_type=' . PostTypes::FOOD_ITEM_CPT
		);

		add_submenu_page(
			'mkt_food_menu',
			__( 'Menu Categories', 'maktomine-restaurant-core' ),
			__( 'Categories', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_MENU,
			'edit-tags.php?taxonomy=' . Taxonomies::FOOD_CATEGORY_TAX . '&post_type=' . PostTypes::FOOD_ITEM_CPT
		);

		add_submenu_page(
			'mkt_food_menu',
			__( 'Dietary Tags', 'maktomine-restaurant-core' ),
			__( 'Dietary Tags', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_MENU,
			'edit-tags.php?taxonomy=' . Taxonomies::FOOD_TAG_TAX . '&post_type=' . PostTypes::FOOD_ITEM_CPT
		);

		add_submenu_page(
			'mkt_food_menu',
			__( 'Attributes & Add-ons Library', 'maktomine-restaurant-core' ),
			__( 'Attributes & Add-ons', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_MENU,
			'mkt_attributes_addons',
			[ self::class, 'render_attributes_addons_page' ]
		);

		// 2. Inquiries & Bookings (Top-level).
		add_menu_page(
			__( 'Inquiries & Bookings', 'maktomine-restaurant-core' ),
			__( 'Inquiries & Bookings', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_BOOKINGS,
			'mkt_bookings',
			[ self::class, 'render_bookings_page' ],
			'dashicons-calendar-alt',
			27
		);

		add_submenu_page(
			'mkt_bookings',
			__( 'All Reservations', 'maktomine-restaurant-core' ),
			__( 'All Reservations', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_BOOKINGS,
			'mkt_bookings',
			[ self::class, 'render_bookings_page' ]
		);

		add_submenu_page(
			'mkt_bookings',
			__( 'Calendar Overview', 'maktomine-restaurant-core' ),
			__( 'Calendar Overview', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_BOOKINGS,
			'mkt_bookings_calendar',
			[ self::class, 'render_bookings_calendar_page' ]
		);

		add_submenu_page(
			'mkt_bookings',
			__( 'Booking Settings', 'maktomine-restaurant-core' ),
			__( 'Booking Settings', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_BOOKINGS,
			'mkt_bookings_settings',
			[ self::class, 'render_bookings_settings_page' ]
		);

		// 3. Orders Log (Top-level).
		add_menu_page(
			__( 'Orders Log', 'maktomine-restaurant-core' ),
			__( 'Orders Log', 'maktomine-restaurant-core' ),
			CapabilityManager::VIEW_ORDERS,
			'mkt_orders',
			[ self::class, 'render_orders_page' ],
			'dashicons-clipboard',
			28
		);

		// 4. Maktomine Theme Kit (Top-level Hub).
		add_menu_page(
			__( 'Maktomine Theme Kit', 'maktomine-restaurant-core' ),
			__( 'Maktomine Theme Kit', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_SETTINGS,
			'maktomine_theme_kit',
			[ self::class, 'render_theme_kit_dashboard' ],
			'dashicons-store',
			59
		);

		add_submenu_page(
			'maktomine_theme_kit',
			__( 'Setup Wizard', 'maktomine-restaurant-core' ),
			__( 'Setup Wizard', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_SETTINGS,
			'mkt_wizard',
			[ self::class, 'render_wizard_page' ]
		);

		add_submenu_page(
			'maktomine_theme_kit',
			__( 'Restaurant Business Settings', 'maktomine-restaurant-core' ),
			__( 'Business Settings', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_SETTINGS,
			'mkt_business_settings',
			[ self::class, 'render_business_settings_page' ]
		);

		add_submenu_page(
			'maktomine_theme_kit',
			__( 'Delivery & WhatsApp', 'maktomine-restaurant-core' ),
			__( 'Delivery & WhatsApp', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_SETTINGS,
			'mkt_delivery_whatsapp',
			[ self::class, 'render_delivery_whatsapp_page' ]
		);

		add_submenu_page(
			'maktomine_theme_kit',
			__( 'Maktomine Blocks', 'maktomine-restaurant-core' ),
			__( 'Maktomine Blocks', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_BLOCKS,
			'edit.php?post_type=' . PostTypes::BLOCK_CPT
		);

		add_submenu_page(
			'maktomine_theme_kit',
			__( 'System Status', 'maktomine-restaurant-core' ),
			__( 'System Status', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_SETTINGS,
			'mkt_system_status',
			[ self::class, 'render_system_status_page' ]
		);

		add_submenu_page(
			'maktomine_theme_kit',
			__( 'Documentation', 'maktomine-restaurant-core' ),
			__( 'Documentation', 'maktomine-restaurant-core' ),
			CapabilityManager::MANAGE_SETTINGS,
			'mkt_documentation',
			[ self::class, 'render_documentation_page' ]
		);
	}

	// =========================================================================
	// Foundational Page Renderers with Strict Permission Verification
	// =========================================================================

	public static function render_food_menu_page(): void {
		self::check_permission( CapabilityManager::MANAGE_MENU );
		self::render_phase_notice( __( 'Food Menu Overview', 'maktomine-restaurant-core' ), 'Phase 3' );
	}

	public static function render_attributes_addons_page(): void {
		self::check_permission( CapabilityManager::MANAGE_MENU );
		self::render_phase_notice( __( 'Attributes & Add-ons Library', 'maktomine-restaurant-core' ), 'Phase 3' );
	}

	public static function render_bookings_page(): void {
		self::check_permission( CapabilityManager::MANAGE_BOOKINGS );
		self::render_phase_notice( __( 'Reservations & Table Bookings', 'maktomine-restaurant-core' ), 'Phase 5' );
	}

	public static function render_bookings_calendar_page(): void {
		self::check_permission( CapabilityManager::MANAGE_BOOKINGS );
		self::render_phase_notice( __( 'Booking Calendar Overview', 'maktomine-restaurant-core' ), 'Phase 5' );
	}

	public static function render_bookings_settings_page(): void {
		self::check_permission( CapabilityManager::MANAGE_BOOKINGS );
		self::render_phase_notice( __( 'Reservation Capacity Settings', 'maktomine-restaurant-core' ), 'Phase 5' );
	}

	public static function render_orders_page(): void {
		self::check_permission( CapabilityManager::VIEW_ORDERS );
		OrdersAdminPage::render();
	}

	public static function render_theme_kit_dashboard(): void {
		self::check_permission( CapabilityManager::MANAGE_SETTINGS );
		self::render_phase_notice( __( 'Maktomine Theme Kit Hub', 'maktomine-restaurant-core' ), 'Phase 2 & Phase 11' );
	}

	public static function render_wizard_page(): void {
		self::check_permission( CapabilityManager::MANAGE_SETTINGS );
		self::render_phase_notice( __( 'One-Click Setup Wizard', 'maktomine-restaurant-core' ), 'Phase 11' );
	}

	public static function render_business_settings_page(): void {
		self::check_permission( CapabilityManager::MANAGE_SETTINGS );
		self::render_phase_notice( __( 'Restaurant Business Information', 'maktomine-restaurant-core' ), 'Phase 1 Foundation Ready — Settings Form in Phase 3' );
	}

	public static function render_delivery_whatsapp_page(): void {
		self::check_permission( CapabilityManager::MANAGE_SETTINGS );
		self::render_phase_notice( __( 'Delivery Matrix & WhatsApp Dispatch', 'maktomine-restaurant-core' ), 'Phase 4 & Phase 5' );
	}

	public static function render_system_status_page(): void {
		self::check_permission( CapabilityManager::MANAGE_SETTINGS );
		?>
		<div class="wrap mkt-admin-wrap">
			<h1><?php esc_html_e( 'Maktomine Restaurant Kit — System Status', 'maktomine-restaurant-core' ); ?></h1>
			<div class="card" style="max-width: 800px; margin-top: 20px;">
				<h2><?php esc_html_e( 'Environment Diagnostics', 'maktomine-restaurant-core' ); ?></h2>
				<table class="widefat striped">
					<tbody>
						<tr>
							<td><strong><?php esc_html_e( 'Core Plugin Version', 'maktomine-restaurant-core' ); ?></strong></td>
							<td><?php echo esc_html( MAKTOMINE_CORE_VERSION ); ?></td>
						</tr>
						<tr>
							<td><strong><?php esc_html_e( 'Database Schema Version', 'maktomine-restaurant-core' ); ?></strong></td>
							<td><?php echo esc_html( (string) get_option( 'mkt_db_version', 'Not installed' ) ); ?></td>
						</tr>
						<tr>
							<td><strong><?php esc_html_e( 'PHP Version', 'maktomine-restaurant-core' ); ?></strong></td>
							<td><?php echo esc_html( PHP_VERSION ); ?></td>
						</tr>
						<tr>
							<td><strong><?php esc_html_e( 'WordPress Version', 'maktomine-restaurant-core' ); ?></strong></td>
							<td><?php echo esc_html( get_bloginfo( 'version' ) ); ?></td>
						</tr>
						<tr>
							<td><strong><?php esc_html_e( 'Theme Status', 'maktomine-restaurant-core' ); ?></strong></td>
							<td>
								<?php
								if ( function_exists( 'wp_get_theme' ) ) {
									$theme = wp_get_theme();
									echo esc_html( $theme->get( 'Name' ) . ' (v' . $theme->get( 'Version' ) . ')' );
								} else {
									esc_html_e( 'Unknown', 'maktomine-restaurant-core' );
								}
								?>
							</td>
						</tr>
						<tr>
							<td><strong><?php esc_html_e( 'Elementor Status', 'maktomine-restaurant-core' ); ?></strong></td>
							<td>
								<?php
								if ( IntegrationDetector::is_elementor_active() ) {
									esc_html_e( 'Active & Detected', 'maktomine-restaurant-core' );
								} else {
									esc_html_e( 'Not Detected (Optional — Plugin runs independently)', 'maktomine-restaurant-core' );
								}
								?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	public static function render_documentation_page(): void {
		self::check_permission( CapabilityManager::MANAGE_SETTINGS );
		?>
		<div class="wrap mkt-admin-wrap">
			<h1><?php esc_html_e( 'Maktomine Restaurant Kit — Documentation', 'maktomine-restaurant-core' ); ?></h1>
			<p><?php esc_html_e( 'Welcome to the Maktomine Restaurant Kit commercial WordPress ecosystem. Full documentation is available in the product release package.', 'maktomine-restaurant-core' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Verify current user capability before executing page rendering.
	 *
	 * @param string $capability WordPress capability.
	 * @return void
	 */
	private static function check_permission( string $capability ): void {
		if ( ! current_user_can( $capability ) ) {
			wp_die(
				esc_html__( 'Sorry, you are not allowed to access this page.', 'maktomine-restaurant-core' ),
				403
			);
		}
	}

	/**
	 * Render standard phase notice box.
	 */
	private static function render_phase_notice( string $title, string $phase ): void {
		?>
		<div class="wrap mkt-admin-wrap">
			<h1><?php echo esc_html( $title ); ?></h1>
			<div class="notice notice-info" style="margin-top: 20px; padding: 15px 20px;">
				<p>
					<strong><?php esc_html_e( 'Maktomine Restaurant Kit Architecture Notice', 'maktomine-restaurant-core' ); ?>:</strong>
					<?php
					printf(
						/* translators: 1: Feature title, 2: Target phase */
						esc_html__( '%1$s menu and controller foundations are registered in Phase 1. Full interactive interfaces and business workflows are scheduled for %2$s.', 'maktomine-restaurant-core' ),
						esc_html( $title ),
						'<strong>' . esc_html( $phase ) . '</strong>'
					);
					?>
				</p>
			</div>
		</div>
		<?php
	}
}
