<?php
/**
 * Admin Module.
 * Initializes WordPress admin menus, assets, and notices.
 *
 * @package Maktomine\RestaurantCore\Admin
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Admin;

defined( 'ABSPATH' ) || exit;

use Maktomine\RestaurantCore\Contracts\ModuleInterface;
use Maktomine\RestaurantCore\Orders\IdempotencyMaintenanceService;

final class AdminModule implements ModuleInterface {

	public function get_id(): string {
		return 'admin';
	}

	public function register(): void {
		if ( ! is_admin() ) {
			return;
		}

		add_action( 'admin_menu', [ MenuManager::class, 'register' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );

		// Ensure scheduler is registered on existing active installations during administrative visits.
		add_action( 'admin_init', [ IdempotencyMaintenanceService::class, 'maybe_schedule_on_update' ] );
	}

	public function boot(): void {
		// Admin boot complete.
	}

	/**
	 * Enqueue minimal admin styles for Maktomine admin wrappers.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public function enqueue_assets( string $hook_suffix ): void {
		// Only enqueue on maktomine specific admin screens.
		if ( false === strpos( $hook_suffix, 'mkt_' ) && false === strpos( $hook_suffix, 'maktomine' ) ) {
			return;
		}

		wp_enqueue_style(
			'maktomine-admin-foundation',
			MAKTOMINE_CORE_URL . 'assets/css/admin-foundation.css',
			[],
			MAKTOMINE_CORE_VERSION
		);

		// Enqueue dedicated order list presentation assets on orders admin page.
		if ( false !== strpos( $hook_suffix, 'mkt_orders' ) ) {
			OrdersAdminPage::enqueue_assets();
		}
	}
}
