<?php
/**
 * Orders Admin Page Presentation Controller.
 *
 * Renders the administrative order list presentation shell for the
 * Maktomine Restaurant Core system. Strictly consumes the authoritative
 * REST endpoint GET /maktomine/v1/admin/orders via client-side JavaScript.
 *
 * Direct database access ($wpdb), domain calculation, or order mutations
 * are strictly prohibited in this presentation layer.
 *
 * @package Maktomine\RestaurantCore\Admin
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Admin;

use Maktomine\RestaurantCore\Capabilities\CapabilityManager;
use Maktomine\RestaurantCore\Orders\Order;
use Maktomine\RestaurantCore\Settings\BusinessInfoRepository;

defined( 'ABSPATH' ) || exit;

/**
 * Class OrdersAdminPage
 */
final class OrdersAdminPage {

	/**
	 * Render the administrative orders management shell.
	 *
	 * Guarded by CapabilityManager::VIEW_ORDERS ('view_restaurant_orders').
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( CapabilityManager::VIEW_ORDERS ) ) {
			wp_die(
				esc_html__( 'Sorry, you are not allowed to view restaurant orders.', 'maktomine-restaurant-core' ),
				403
			);
		}

		$currency_symbol = (string) BusinessInfoRepository::get( 'currency_symbol', '$' );
		?>
		<div class="wrap mkt-admin-wrap mkt-orders-page-wrap">
			<!-- Screen Reader Live Announcements -->
			<div id="mkt-orders-announcements" class="screen-reader-text" aria-live="polite" aria-atomic="true"></div>

			<!-- 1. Orders Collection List View -->
			<div id="mkt-orders-list-view" class="mkt-view-container">
				<h1 class="wp-heading-inline">
					<?php esc_html_e( 'Restaurant Orders', 'maktomine-restaurant-core' ); ?>
				</h1>
				<hr class="wp-header-end" />

				<!-- Filter & Search Toolbar -->
				<form id="mkt-orders-filter-form" class="mkt-orders-filter-bar" role="search" aria-label="<?php esc_attr_e( 'Filter orders', 'maktomine-restaurant-core' ); ?>">
					<div class="mkt-filter-group">
						<label for="mkt-filter-status" class="screen-reader-text">
							<?php esc_html_e( 'Order Status', 'maktomine-restaurant-core' ); ?>
						</label>
						<select id="mkt-filter-status" name="status" class="mkt-filter-select">
							<option value=""><?php esc_html_e( 'All Statuses', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( Order::STATUS_PENDING_WHATSAPP ); ?>"><?php esc_html_e( 'Pending WhatsApp', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( Order::STATUS_CONFIRMED ); ?>"><?php esc_html_e( 'Confirmed', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( Order::STATUS_PREPARING ); ?>"><?php esc_html_e( 'Preparing', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( Order::STATUS_READY ); ?>"><?php esc_html_e( 'Ready', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( Order::STATUS_COMPLETED ); ?>"><?php esc_html_e( 'Completed', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( Order::STATUS_CANCELLED ); ?>"><?php esc_html_e( 'Cancelled', 'maktomine-restaurant-core' ); ?></option>
						</select>
					</div>

					<div class="mkt-filter-group">
						<label for="mkt-filter-type" class="screen-reader-text">
							<?php esc_html_e( 'Order Type', 'maktomine-restaurant-core' ); ?>
						</label>
						<select id="mkt-filter-type" name="type" class="mkt-filter-select">
							<option value=""><?php esc_html_e( 'All Types', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( Order::TYPE_DELIVERY ); ?>"><?php esc_html_e( 'Delivery', 'maktomine-restaurant-core' ); ?></option>
							<option value="<?php echo esc_attr( Order::TYPE_PICKUP ); ?>"><?php esc_html_e( 'Pickup', 'maktomine-restaurant-core' ); ?></option>
						</select>
					</div>

					<div class="mkt-filter-group">
						<label for="mkt-filter-date-from" class="mkt-filter-label">
							<?php esc_html_e( 'From:', 'maktomine-restaurant-core' ); ?>
						</label>
						<input
							type="date"
							id="mkt-filter-date-from"
							name="date_from"
							class="mkt-filter-date"
							aria-label="<?php esc_attr_e( 'Filter orders created on or after date', 'maktomine-restaurant-core' ); ?>"
						/>
					</div>

					<div class="mkt-filter-group">
						<label for="mkt-filter-date-to" class="mkt-filter-label">
							<?php esc_html_e( 'To:', 'maktomine-restaurant-core' ); ?>
						</label>
						<input
							type="date"
							id="mkt-filter-date-to"
							name="date_to"
							class="mkt-filter-date"
							aria-label="<?php esc_attr_e( 'Filter orders created on or before date', 'maktomine-restaurant-core' ); ?>"
						/>
					</div>

					<div class="mkt-filter-group mkt-search-group">
						<label for="mkt-filter-search" class="screen-reader-text">
							<?php esc_html_e( 'Search Orders', 'maktomine-restaurant-core' ); ?>
						</label>
						<input
							type="search"
							id="mkt-filter-search"
							name="search"
							class="mkt-filter-search-input"
							placeholder="<?php esc_attr_e( 'Search ref, phone, name...', 'maktomine-restaurant-core' ); ?>"
							aria-label="<?php esc_attr_e( 'Search by order reference, customer phone, or customer name', 'maktomine-restaurant-core' ); ?>"
						/>
					</div>

					<div class="mkt-filter-actions">
						<button type="submit" id="mkt-filter-submit" class="button button-primary">
							<?php esc_html_e( 'Apply Filters', 'maktomine-restaurant-core' ); ?>
						</button>
						<button type="button" id="mkt-filter-clear" class="button button-secondary">
							<?php esc_html_e( 'Clear Filters', 'maktomine-restaurant-core' ); ?>
						</button>
					</div>
				</form>

				<!-- Feedback Notice Container -->
				<div id="mkt-orders-notice-container" class="mkt-orders-notice-wrap" role="alert" style="display: none;"></div>

				<!-- Meta & Summary Header -->
				<div class="mkt-orders-top-meta">
					<div id="mkt-orders-count-indicator" class="mkt-orders-count-indicator" aria-live="polite">
						<span class="mkt-count-text"><?php esc_html_e( 'Loading orders...', 'maktomine-restaurant-core' ); ?></span>
					</div>
					<div class="mkt-orders-per-page-wrap">
						<label for="mkt-per-page-select">
							<?php esc_html_e( 'Orders per page:', 'maktomine-restaurant-core' ); ?>
						</label>
						<select id="mkt-per-page-select" class="mkt-per-page-select">
							<option value="20" selected>20</option>
							<option value="50">50</option>
							<option value="100">100</option>
						</select>
					</div>
				</div>

				<!-- Responsive Orders Table -->
				<div
					id="mkt-orders-table-container"
					class="mkt-orders-table-container"
					tabindex="0"
					role="region"
					aria-label="<?php esc_attr_e( 'Restaurant orders table. Use arrow keys or scroll horizontally to view details.', 'maktomine-restaurant-core' ); ?>"
				>
					<table class="wp-list-table widefat fixed striped table-view-list mkt-orders-table" id="mkt-orders-table">
						<caption class="screen-reader-text">
							<?php esc_html_e( 'Restaurant Orders Management Table', 'maktomine-restaurant-core' ); ?>
						</caption>
						<thead>
							<tr>
								<th scope="col" id="col-order" class="manage-column column-order column-sortable" aria-sort="none">
									<button type="button" class="mkt-sort-button" data-sort="order_reference" aria-label="<?php esc_attr_e( 'Sort by Order Reference', 'maktomine-restaurant-core' ); ?>">
										<span><?php esc_html_e( 'Order', 'maktomine-restaurant-core' ); ?></span>
										<span class="mkt-sort-indicator" aria-hidden="true"></span>
									</button>
								</th>
								<th scope="col" id="col-customer" class="manage-column column-customer">
									<?php esc_html_e( 'Customer', 'maktomine-restaurant-core' ); ?>
								</th>
								<th scope="col" id="col-type" class="manage-column column-type">
									<?php esc_html_e( 'Type', 'maktomine-restaurant-core' ); ?>
								</th>
								<th scope="col" id="col-status" class="manage-column column-status column-sortable" aria-sort="none">
									<button type="button" class="mkt-sort-button" data-sort="order_status" aria-label="<?php esc_attr_e( 'Sort by Order Status', 'maktomine-restaurant-core' ); ?>">
										<span><?php esc_html_e( 'Status', 'maktomine-restaurant-core' ); ?></span>
										<span class="mkt-sort-indicator" aria-hidden="true"></span>
									</button>
								</th>
								<th scope="col" id="col-total" class="manage-column column-total column-sortable" aria-sort="none">
									<button type="button" class="mkt-sort-button" data-sort="total_amount" aria-label="<?php esc_attr_e( 'Sort by Total Amount', 'maktomine-restaurant-core' ); ?>">
										<span><?php esc_html_e( 'Total', 'maktomine-restaurant-core' ); ?></span>
										<span class="mkt-sort-indicator" aria-hidden="true"></span>
									</button>
								</th>
								<th scope="col" id="col-created" class="manage-column column-created column-sortable sorted-desc" aria-sort="descending">
									<button type="button" class="mkt-sort-button" data-sort="created_at" aria-label="<?php esc_attr_e( 'Sort by Creation Date (Currently Descending)', 'maktomine-restaurant-core' ); ?>">
										<span><?php esc_html_e( 'Created', 'maktomine-restaurant-core' ); ?></span>
										<span class="mkt-sort-indicator" aria-hidden="true"></span>
									</button>
								</th>
								<th scope="col" id="col-updated" class="manage-column column-updated">
									<?php esc_html_e( 'Updated', 'maktomine-restaurant-core' ); ?>
								</th>
								<th scope="col" id="col-action" class="manage-column column-action">
									<?php esc_html_e( 'Action', 'maktomine-restaurant-core' ); ?>
								</th>
							</tr>
						</thead>
						<tbody id="mkt-orders-tbody">
							<tr class="mkt-loading-row">
								<td colspan="8" class="mkt-loading-cell">
									<div class="mkt-loading-spinner" aria-hidden="true"></div>
									<span><?php esc_html_e( 'Loading orders from server...', 'maktomine-restaurant-core' ); ?></span>
								</td>
							</tr>
						</tbody>
						<tfoot>
							<tr>
								<th scope="col" class="manage-column column-order"><?php esc_html_e( 'Order', 'maktomine-restaurant-core' ); ?></th>
								<th scope="col" class="manage-column column-customer"><?php esc_html_e( 'Customer', 'maktomine-restaurant-core' ); ?></th>
								<th scope="col" class="manage-column column-type"><?php esc_html_e( 'Type', 'maktomine-restaurant-core' ); ?></th>
								<th scope="col" class="manage-column column-status"><?php esc_html_e( 'Status', 'maktomine-restaurant-core' ); ?></th>
								<th scope="col" class="manage-column column-total"><?php esc_html_e( 'Total', 'maktomine-restaurant-core' ); ?></th>
								<th scope="col" class="manage-column column-created"><?php esc_html_e( 'Created', 'maktomine-restaurant-core' ); ?></th>
								<th scope="col" class="manage-column column-updated"><?php esc_html_e( 'Updated', 'maktomine-restaurant-core' ); ?></th>
								<th scope="col" class="manage-column column-action"><?php esc_html_e( 'Action', 'maktomine-restaurant-core' ); ?></th>
							</tr>
						</tfoot>
					</table>
				</div>

				<!-- Pagination Toolbar -->
				<div id="mkt-orders-pagination" class="mkt-orders-pagination tablenav bottom" role="navigation" aria-label="<?php esc_attr_e( 'Orders pagination', 'maktomine-restaurant-core' ); ?>">
					<div class="tablenav-pages">
						<span class="displaying-num" id="mkt-pagination-total-items">0 items</span>
						<span class="pagination-links">
							<button type="button" id="mkt-page-first" class="tablenav-pages-navspan button" disabled aria-label="<?php esc_attr_e( 'First page', 'maktomine-restaurant-core' ); ?>">
								<span aria-hidden="true">&laquo;</span>
							</button>
							<button type="button" id="mkt-page-prev" class="tablenav-pages-navspan button" disabled aria-label="<?php esc_attr_e( 'Previous page', 'maktomine-restaurant-core' ); ?>">
								<span aria-hidden="true">&lsaquo;</span>
							</button>
							<span class="paging-input">
								<span class="screen-reader-text"><?php esc_html_e( 'Current Page', 'maktomine-restaurant-core' ); ?></span>
								<span id="mkt-current-page-num" class="current-page">1</span>
								<span class="tablenav-paging-text">
									<?php esc_html_e( 'of', 'maktomine-restaurant-core' ); ?>
									<span id="mkt-total-pages-num" class="total-pages">1</span>
								</span>
							</span>
							<button type="button" id="mkt-page-next" class="tablenav-pages-navspan button" disabled aria-label="<?php esc_attr_e( 'Next page', 'maktomine-restaurant-core' ); ?>">
								<span aria-hidden="true">&rsaquo;</span>
							</button>
							<button type="button" id="mkt-page-last" class="tablenav-pages-navspan button" disabled aria-label="<?php esc_attr_e( 'Last page', 'maktomine-restaurant-core' ); ?>">
								<span aria-hidden="true">&raquo;</span>
							</button>
						</span>
					</div>
				</div>
			</div>

			<!-- 2. Single Order Detail View (Read-Only Presentation Shell) -->
			<div id="mkt-orders-detail-view" class="mkt-view-container mkt-orders-detail-wrap" style="display: none;" aria-label="<?php esc_attr_e( 'Order Details', 'maktomine-restaurant-core' ); ?>">
				<div class="mkt-detail-header-bar">
					<div class="mkt-detail-header-left">
						<button type="button" id="mkt-back-to-list-btn" class="button button-secondary mkt-back-btn" aria-label="<?php esc_attr_e( 'Return to restaurant orders list', 'maktomine-restaurant-core' ); ?>">
							&larr; <?php esc_html_e( 'Back to Orders', 'maktomine-restaurant-core' ); ?>
						</button>
						<h1 id="mkt-detail-title" class="mkt-detail-heading" tabindex="-1">
							<?php esc_html_e( 'Order Details', 'maktomine-restaurant-core' ); ?>
						</h1>
					</div>
					<div class="mkt-detail-header-badges">
						<span id="mkt-detail-status-badge" class="mkt-badge-status"></span>
						<span id="mkt-detail-type-badge" class="mkt-badge-type"></span>
					</div>
				</div>
				<hr class="wp-header-end" />

				<!-- Detail Notice Container -->
				<div id="mkt-detail-notice-wrap" class="mkt-orders-notice-wrap" role="alert" style="display: none;"></div>

				<!-- Detail Loading State Box -->
				<div id="mkt-detail-loading" class="mkt-detail-loading-box" style="display: none;">
					<div class="mkt-loading-spinner" aria-hidden="true"></div>
					<span><?php esc_html_e( 'Loading order details from server...', 'maktomine-restaurant-core' ); ?></span>
				</div>

				<!-- Detail Content Grid -->
				<div id="mkt-detail-content" class="mkt-detail-content-grid" style="display: none;">
					<!-- Left Main Column: Items & Totals & Notes -->
					<div class="mkt-detail-main-col">
						<!-- Items Card -->
						<div class="card mkt-card">
							<h2><?php esc_html_e( 'Order Items', 'maktomine-restaurant-core' ); ?></h2>
							<div class="mkt-detail-items-table-wrap">
								<table class="wp-list-table widefat fixed striped mkt-detail-items-table" id="mkt-detail-items-table">
									<thead>
										<tr>
											<th scope="col"><?php esc_html_e( 'Item Description', 'maktomine-restaurant-core' ); ?></th>
											<th scope="col" class="mkt-col-qty"><?php esc_html_e( 'Qty', 'maktomine-restaurant-core' ); ?></th>
											<th scope="col" class="mkt-col-price"><?php esc_html_e( 'Unit Price', 'maktomine-restaurant-core' ); ?></th>
											<th scope="col" class="mkt-col-total"><?php esc_html_e( 'Line Total', 'maktomine-restaurant-core' ); ?></th>
										</tr>
									</thead>
									<tbody id="mkt-detail-items-tbody">
										<!-- Rendered via JavaScript -->
									</tbody>
								</table>
							</div>

							<!-- Financial Summary Box -->
							<div class="mkt-detail-totals-box">
								<div class="mkt-totals-row">
									<span class="mkt-totals-label"><?php esc_html_e( 'Subtotal:', 'maktomine-restaurant-core' ); ?></span>
									<span class="mkt-totals-val" id="mkt-detail-subtotal">-</span>
								</div>
								<div class="mkt-totals-row">
									<span class="mkt-totals-label"><?php esc_html_e( 'Delivery Charge:', 'maktomine-restaurant-core' ); ?></span>
									<span class="mkt-totals-val" id="mkt-detail-delivery-charge">-</span>
								</div>
								<div class="mkt-totals-row mkt-totals-grand">
									<span class="mkt-totals-label"><?php esc_html_e( 'Total Amount:', 'maktomine-restaurant-core' ); ?></span>
									<span class="mkt-totals-val" id="mkt-detail-total">-</span>
								</div>
							</div>
						</div>

						<!-- Order Note Card (Rendered only when present) -->
						<div class="card mkt-card" id="mkt-detail-note-card" style="display: none;">
							<h2><?php esc_html_e( 'Customer Order Note', 'maktomine-restaurant-core' ); ?></h2>
							<p id="mkt-detail-order-note" class="mkt-order-note-text"></p>
						</div>
					</div>

					<!-- Right Sidebar Column: Overview, Customer, Fulfillment -->
					<div class="mkt-detail-sidebar-col">
						<!-- Status Management Card -->
						<div class="card mkt-card" id="mkt-detail-status-card">
							<h2><?php esc_html_e( 'Order Status', 'maktomine-restaurant-core' ); ?></h2>
							<div class="mkt-status-control-wrap">
								<div class="mkt-status-current-row">
									<span class="mkt-status-current-label"><?php esc_html_e( 'Current Status:', 'maktomine-restaurant-core' ); ?></span>
									<span id="mkt-detail-card-status-badge" class="mkt-badge-status"></span>
								</div>
								<div class="mkt-status-form-group">
									<label for="mkt-detail-status-select" class="mkt-status-select-label">
										<?php esc_html_e( 'Change Status:', 'maktomine-restaurant-core' ); ?>
									</label>
									<div class="mkt-status-action-row">
										<select id="mkt-detail-status-select" class="mkt-detail-status-select" aria-label="<?php esc_attr_e( 'Change order status', 'maktomine-restaurant-core' ); ?>">
										</select>
										<button type="button" id="mkt-update-status-btn" class="button button-primary mkt-update-status-btn">
											<?php esc_html_e( 'Update Status', 'maktomine-restaurant-core' ); ?>
										</button>
									</div>
								</div>
								<div id="mkt-detail-status-feedback" class="mkt-detail-status-feedback" role="status" aria-live="polite" style="display: none;"></div>
							</div>
						</div>

						<!-- Overview Card -->
						<div class="card mkt-card">
							<h2><?php esc_html_e( 'Order Overview', 'maktomine-restaurant-core' ); ?></h2>
							<dl class="mkt-meta-dl">
								<dt><?php esc_html_e( 'Reference:', 'maktomine-restaurant-core' ); ?></dt>
								<dd id="mkt-detail-ref" class="mkt-order-ref">-</dd>

								<dt><?php esc_html_e( 'Fulfillment:', 'maktomine-restaurant-core' ); ?></dt>
								<dd id="mkt-detail-fulfillment">-</dd>

								<dt><?php esc_html_e( 'Created Date:', 'maktomine-restaurant-core' ); ?></dt>
								<dd id="mkt-detail-created" class="mkt-date-cell">-</dd>

								<dt><?php esc_html_e( 'Last Updated:', 'maktomine-restaurant-core' ); ?></dt>
								<dd id="mkt-detail-updated" class="mkt-date-cell">-</dd>
							</dl>
						</div>

						<!-- Customer Card -->
						<div class="card mkt-card">
							<h2><?php esc_html_e( 'Customer Information', 'maktomine-restaurant-core' ); ?></h2>
							<dl class="mkt-meta-dl">
								<dt><?php esc_html_e( 'Name:', 'maktomine-restaurant-core' ); ?></dt>
								<dd id="mkt-detail-customer-name" class="mkt-customer-name">-</dd>

								<dt><?php esc_html_e( 'Phone:', 'maktomine-restaurant-core' ); ?></dt>
								<dd id="mkt-detail-customer-phone">-</dd>
							</dl>
						</div>

						<!-- Fulfillment Card -->
						<div class="card mkt-card" id="mkt-detail-fulfillment-card">
							<h2><?php esc_html_e( 'Fulfillment Details', 'maktomine-restaurant-core' ); ?></h2>
							<div id="mkt-detail-delivery-info">
								<dl class="mkt-meta-dl">
									<dt><?php esc_html_e( 'Delivery Address:', 'maktomine-restaurant-core' ); ?></dt>
									<dd id="mkt-detail-address">-</dd>

									<dt id="mkt-detail-area-dt"><?php esc_html_e( 'Area:', 'maktomine-restaurant-core' ); ?></dt>
									<dd id="mkt-detail-area">-</dd>

									<dt id="mkt-detail-landmark-dt"><?php esc_html_e( 'Landmark:', 'maktomine-restaurant-core' ); ?></dt>
									<dd id="mkt-detail-landmark">-</dd>
								</dl>
							</div>
							<div id="mkt-detail-pickup-info" style="display: none;">
								<p class="mkt-pickup-notice">
									<span class="dashicons dashicons-store" aria-hidden="true"></span>
									<?php esc_html_e( 'Customer will pick up this order directly at the restaurant.', 'maktomine-restaurant-core' ); ?>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue dedicated assets for the Orders admin screen.
	 *
	 * @return void
	 */
	public static function enqueue_assets(): void {
		$initial_order_id = isset( $_GET['order_id'] ) ? sanitize_text_field( (string) $_GET['order_id'] ) : '';

		wp_enqueue_style(
			'maktomine-admin-orders',
			MAKTOMINE_CORE_URL . 'assets/css/admin-orders.css',
			[ 'maktomine-admin-foundation' ],
			MAKTOMINE_CORE_VERSION
		);

		wp_enqueue_script(
			'maktomine-admin-orders',
			MAKTOMINE_CORE_URL . 'assets/js/admin-orders.js',
			[],
			MAKTOMINE_CORE_VERSION,
			true
		);

		wp_localize_script(
			'maktomine-admin-orders',
			'mktAdminOrdersConfig',
			[
				'restUrl'          => esc_url_raw( rest_url( 'maktomine/v1/admin/orders' ) ),
				'nonce'            => wp_create_nonce( 'wp_rest' ),
				'initialOrderId'   => $initial_order_id,
				'defaultPerPage'   => 20,
				'maxPerPage'       => 100,
				'currencySymbol'   => (string) BusinessInfoRepository::get( 'currency_symbol', '$' ),
				'currencyPosition' => (string) BusinessInfoRepository::get( 'currency_position', 'left' ),
				'statuses'         => [
					Order::STATUS_PENDING_WHATSAPP => __( 'Pending WhatsApp', 'maktomine-restaurant-core' ),
					Order::STATUS_CONFIRMED        => __( 'Confirmed', 'maktomine-restaurant-core' ),
					Order::STATUS_PREPARING        => __( 'Preparing', 'maktomine-restaurant-core' ),
					Order::STATUS_READY            => __( 'Ready', 'maktomine-restaurant-core' ),
					Order::STATUS_COMPLETED        => __( 'Completed', 'maktomine-restaurant-core' ),
					Order::STATUS_CANCELLED        => __( 'Cancelled', 'maktomine-restaurant-core' ),
				],
				'types'            => [
					Order::TYPE_DELIVERY           => __( 'Delivery', 'maktomine-restaurant-core' ),
					Order::TYPE_PICKUP             => __( 'Pickup', 'maktomine-restaurant-core' ),
				],
				'i18n'             => [
					'loading'            => __( 'Loading orders...', 'maktomine-restaurant-core' ),
					'loadingDetail'      => __( 'Loading order details...', 'maktomine-restaurant-core' ),
					'noOrders'           => __( 'No orders found in the system yet.', 'maktomine-restaurant-core' ),
					'noFilteredOrders'   => __( 'No orders match the current filter criteria.', 'maktomine-restaurant-core' ),
					'errorUnauthorized'  => __( 'You do not have permission to view restaurant orders. Please log in with an authorized account.', 'maktomine-restaurant-core' ),
					'errorInvalidParams' => __( 'Invalid request parameters. Please verify your filter values.', 'maktomine-restaurant-core' ),
					'errorServer'        => __( 'A server error occurred while retrieving orders. Please try again.', 'maktomine-restaurant-core' ),
					'errorNetwork'       => __( 'Unable to connect to the restaurant API. Please check your network connection.', 'maktomine-restaurant-core' ),
					'errorMalformed'     => __( 'Unexpected response structure received from server.', 'maktomine-restaurant-core' ),
					'orderNotFound'      => __( 'Order not found. Please verify the order ID or return to the orders list.', 'maktomine-restaurant-core' ),
					'orderTitle'         => __( 'Order #%s', 'maktomine-restaurant-core' ),
					'retry'              => __( 'Retry', 'maktomine-restaurant-core' ),
					'clearFilters'       => __( 'Clear Filters', 'maktomine-restaurant-core' ),
					'viewDetailNotice'   => __( 'View full historical order details and item snapshot.', 'maktomine-restaurant-core' ),
					'viewOrderAria'      => __( 'View details for order %s', 'maktomine-restaurant-core' ),
					'itemsCount'         => __( '%s items', 'maktomine-restaurant-core' ),
					'showingCount'       => __( 'Showing %1$d–%2$d of %3$d orders', 'maktomine-restaurant-core' ),
					'view'               => __( 'View', 'maktomine-restaurant-core' ),
					'na'                 => __( 'N/A', 'maktomine-restaurant-core' ),
					'backToOrders'       => __( 'Back to Orders', 'maktomine-restaurant-core' ),
					'noItems'            => __( 'No items recorded for this order.', 'maktomine-restaurant-core' ),
					'statusLabel'        => __( 'Status: %s', 'maktomine-restaurant-core' ),
					'typeLabel'          => __( 'Fulfillment: %s', 'maktomine-restaurant-core' ),
					'updateStatus'       => __( 'Update Status', 'maktomine-restaurant-core' ),
					'updatingStatus'     => __( 'Updating status...', 'maktomine-restaurant-core' ),
					'statusUpdated'      => __( 'Order status updated successfully to %s.', 'maktomine-restaurant-core' ),
					'statusUpdateFailed' => __( 'Unable to update the order status. Please choose a valid status.', 'maktomine-restaurant-core' ),
					'statusForbidden'    => __( 'You do not have permission to update order status.', 'maktomine-restaurant-core' ),
					'statusConflict'     => __( 'The order status could not be updated because the order changed. Refresh the order and try again.', 'maktomine-restaurant-core' ),
					'statusSelectLabel'  => __( 'Change order status', 'maktomine-restaurant-core' ),
				],
			]
		);
	}
}
