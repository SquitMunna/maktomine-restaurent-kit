<?php
/**
 * Capability and Permission Manager.
 * Defines granular role capabilities for restaurant management operations and Food Item CPT.
 *
 * @package Maktomine\RestaurantCore\Capabilities
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Capabilities;

defined( 'ABSPATH' ) || exit;

final class CapabilityManager {

	// ==========================================
	// 1. Food Item CPT Primitive Capabilities
	// ==========================================
	public const EDIT_FOOD_ITEMS             = 'edit_restaurant_food_items';
	public const EDIT_OTHERS_FOOD_ITEMS      = 'edit_others_restaurant_food_items';
	public const PUBLISH_FOOD_ITEMS          = 'publish_restaurant_food_items';
	public const READ_PRIVATE_FOOD_ITEMS     = 'read_private_restaurant_food_items';
	public const DELETE_FOOD_ITEMS           = 'delete_restaurant_food_items';
	public const DELETE_PRIVATE_FOOD_ITEMS   = 'delete_private_restaurant_food_items';
	public const DELETE_PUBLISHED_FOOD_ITEMS = 'delete_published_restaurant_food_items';
	public const DELETE_OTHERS_FOOD_ITEMS    = 'delete_others_restaurant_food_items';
	public const EDIT_PRIVATE_FOOD_ITEMS     = 'edit_private_restaurant_food_items';
	public const EDIT_PUBLISHED_FOOD_ITEMS   = 'edit_published_restaurant_food_items';

	// ==========================================
	// 2. Food Item CPT Meta Capabilities
	// ==========================================
	public const EDIT_FOOD_ITEM              = 'edit_restaurant_food_item';
	public const READ_FOOD_ITEM              = 'read_restaurant_food_item';
	public const DELETE_FOOD_ITEM            = 'delete_restaurant_food_item';

	// ==========================================
	// 3. Domain / Business Capabilities
	// ==========================================
	public const MANAGE_MENU                 = 'manage_restaurant_menu';
	public const MANAGE_ORDERS               = 'manage_restaurant_orders';
	public const VIEW_ORDERS                 = 'view_restaurant_orders';
	public const MANAGE_BOOKINGS             = 'manage_restaurant_bookings';
	public const MANAGE_REVIEWS              = 'manage_restaurant_reviews';
	public const MANAGE_GALLERY              = 'manage_restaurant_gallery';
	public const MANAGE_BLOCKS               = 'manage_restaurant_blocks';
	public const MANAGE_SETTINGS             = 'manage_restaurant_settings';

	/**
	 * Retrieve list of all Food Item CPT primitive capabilities.
	 *
	 * @return array<string>
	 */
	public static function get_food_item_primitive_capabilities(): array {
		return [
			self::EDIT_FOOD_ITEMS,
			self::EDIT_OTHERS_FOOD_ITEMS,
			self::PUBLISH_FOOD_ITEMS,
			self::READ_PRIVATE_FOOD_ITEMS,
			self::DELETE_FOOD_ITEMS,
			self::DELETE_PRIVATE_FOOD_ITEMS,
			self::DELETE_PUBLISHED_FOOD_ITEMS,
			self::DELETE_OTHERS_FOOD_ITEMS,
			self::EDIT_PRIVATE_FOOD_ITEMS,
			self::EDIT_PUBLISHED_FOOD_ITEMS,
		];
	}

	/**
	 * Retrieve list of all custom domain business capabilities.
	 *
	 * @return array<string>
	 */
	public static function get_business_capabilities(): array {
		return [
			self::MANAGE_MENU,
			self::MANAGE_ORDERS,
			self::VIEW_ORDERS,
			self::MANAGE_BOOKINGS,
			self::MANAGE_REVIEWS,
			self::MANAGE_GALLERY,
			self::MANAGE_BLOCKS,
			self::MANAGE_SETTINGS,
		];
	}

	/**
	 * Retrieve complete list of all capabilities owned by this plugin.
	 *
	 * @return array<string>
	 */
	public static function get_all_capabilities(): array {
		return array_values( array_unique( array_merge(
			self::get_food_item_primitive_capabilities(),
			self::get_business_capabilities()
		) ) );
	}

	/**
	 * Retrieve capabilities for Administrator role.
	 *
	 * @return array<string>
	 */
	public static function get_administrator_capabilities(): array {
		$caps = self::get_all_capabilities();

		/**
		 * Filter capabilities granted to Administrator.
		 *
		 * @param array<string> $caps List of capability names.
		 */
		return (array) apply_filters( 'maktomine/capabilities/admin_caps', $caps );
	}

	/**
	 * Retrieve capabilities for Editor role.
	 *
	 * @return array<string>
	 */
	public static function get_editor_capabilities(): array {
		$caps = [
			// Food Item CPT permissions.
			self::EDIT_FOOD_ITEMS,
			self::EDIT_OTHERS_FOOD_ITEMS,
			self::PUBLISH_FOOD_ITEMS,
			self::READ_PRIVATE_FOOD_ITEMS,
			self::DELETE_FOOD_ITEMS,
			self::DELETE_PUBLISHED_FOOD_ITEMS,
			self::DELETE_OTHERS_FOOD_ITEMS,
			self::EDIT_PUBLISHED_FOOD_ITEMS,
			// Restaurant domain operational permissions.
			self::MANAGE_MENU,
			self::VIEW_ORDERS,
			self::MANAGE_BOOKINGS,
			self::MANAGE_REVIEWS,
			self::MANAGE_GALLERY,
		];

		/**
		 * Filter capabilities granted to Editor.
		 *
		 * @param array<string> $caps List of capability names.
		 */
		return (array) apply_filters( 'maktomine/capabilities/editor_caps', $caps );
	}

	/**
	 * Register capabilities with WordPress roles during activation.
	 * Idempotent: checks role existence and adds capabilities safely without duplicates.
	 *
	 * @return void
	 */
	public static function register_capabilities(): void {
		$admin_role = get_role( 'administrator' );
		if ( $admin_role ) {
			foreach ( self::get_administrator_capabilities() as $cap ) {
				$admin_role->add_cap( $cap, true );
			}
		}

		$editor_role = get_role( 'editor' );
		if ( $editor_role ) {
			foreach ( self::get_editor_capabilities() as $cap ) {
				$editor_role->add_cap( $cap, true );
			}
		}

		/**
		 * Action triggered after Maktomine capabilities are registered.
		 * Allows custom restaurant extensions to grant capabilities to custom roles.
		 */
		do_action( 'maktomine/capabilities/registered' );
	}

	/**
	 * Remove capabilities upon plugin uninstallation only.
	 * Safely iterates registered roles and strips only plugin-owned capabilities.
	 *
	 * @return void
	 */
	public static function remove_capabilities(): void {
		$roles_to_clean = [ 'administrator', 'editor' ];

		/**
		 * Filter roles to clean upon uninstallation.
		 *
		 * @param array<string> $roles_to_clean Role slugs.
		 */
		$roles_to_clean = (array) apply_filters( 'maktomine/capabilities/roles_to_clean', $roles_to_clean );

		$all_caps = self::get_all_capabilities();

		foreach ( $roles_to_clean as $role_slug ) {
			$role = get_role( $role_slug );
			if ( ! $role ) {
				continue;
			}
			foreach ( $all_caps as $cap ) {
				$role->remove_cap( $cap );
			}
		}

		/**
		 * Action triggered after Maktomine capabilities are removed on uninstall.
		 */
		do_action( 'maktomine/capabilities/removed' );
	}
}
