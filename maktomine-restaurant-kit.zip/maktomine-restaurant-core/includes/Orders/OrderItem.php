<?php
/**
 * Order Item Domain Model Snapshot Entity.
 *
 * Represents an immutable, historical snapshot of a single line item
 * belonging to a persisted order.
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

defined( 'ABSPATH' ) || exit;

/**
 * Class OrderItem
 *
 * Captures historical product name, variation summary, add-on summary,
 * unit price, quantity, and line total at the exact moment of order placement.
 */
final class OrderItem {

	/**
	 * Primary key in wp_maktomine_order_items.
	 *
	 * @var int|null
	 */
	private ?int $id;

	/**
	 * Foreign key referencing wp_maktomine_orders.id.
	 *
	 * @var int|null
	 */
	private ?int $order_id;

	/**
	 * Original food item post ID.
	 *
	 * @var int
	 */
	private int $food_id;

	/**
	 * Snapshot of the food item title at time of order.
	 *
	 * @var string
	 */
	private string $item_name;

	/**
	 * Variation identifier (if variable item).
	 *
	 * @var string|null
	 */
	private ?string $variation_id;

	/**
	 * Human-readable variation attribute summary (e.g. "Size: Large, Crust: Thin").
	 *
	 * @var string|null
	 */
	private ?string $variation_summary;

	/**
	 * Human-readable add-on choices summary (e.g. "Extra Cheese (x2), Garlic Dip").
	 *
	 * @var string|null
	 */
	private ?string $addons_summary;

	/**
	 * Authoritative line unit price (effective unit price including add-ons).
	 *
	 * @var float
	 */
	private float $unit_price;

	/**
	 * Item quantity ordered.
	 *
	 * @var int
	 */
	private int $quantity;

	/**
	 * Authoritative line total (unit_price * quantity).
	 *
	 * @var float
	 */
	private float $line_total;

	/**
	 * Constructor.
	 *
	 * @param int|null    $id                Record ID.
	 * @param int|null    $order_id          Order ID.
	 * @param int         $food_id           Food item ID.
	 * @param string      $item_name         Item name snapshot.
	 * @param string|null $variation_id      Variation ID snapshot.
	 * @param string|null $variation_summary Variation summary snapshot.
	 * @param string|null $addons_summary    Add-ons summary snapshot.
	 * @param float       $unit_price        Effective unit price.
	 * @param int         $quantity          Quantity.
	 * @param float       $line_total        Line total.
	 */
	public function __construct(
		?int $id,
		?int $order_id,
		int $food_id,
		string $item_name,
		?string $variation_id,
		?string $variation_summary,
		?string $addons_summary,
		float $unit_price,
		int $quantity,
		float $line_total
	) {
		$this->id                = $id;
		$this->order_id          = $order_id;
		$this->food_id           = $food_id;
		$this->item_name         = $item_name;
		$this->variation_id      = $variation_id;
		$this->variation_summary = $variation_summary;
		$this->addons_summary    = $addons_summary;
		$this->unit_price        = round( $unit_price, 2 );
		$this->quantity          = max( 1, $quantity );
		$this->line_total        = round( $line_total, 2 );
	}

	// ==========================================
	// Getters
	// ==========================================

	public function get_id(): ?int {
		return $this->id;
	}

	public function get_order_id(): ?int {
		return $this->order_id;
	}

	public function get_food_id(): int {
		return $this->food_id;
	}

	public function get_item_name(): string {
		return $this->item_name;
	}

	public function get_variation_id(): ?string {
		return $this->variation_id;
	}

	public function get_variation_summary(): ?string {
		return $this->variation_summary;
	}

	public function get_addons_summary(): ?string {
		return $this->addons_summary;
	}

	public function get_unit_price(): float {
		return $this->unit_price;
	}

	public function get_quantity(): int {
		return $this->quantity;
	}

	public function get_line_total(): float {
		return $this->line_total;
	}

	// ==========================================
	// Factory & Serialization
	// ==========================================

	/**
	 * Construct an OrderItem snapshot entity from a validated cart line structure.
	 *
	 * Sourced exclusively from the validated output of CartValidatorService.
	 *
	 * @param array<string, mixed> $line     Validated cart line array.
	 * @param int|null            $order_id Optional associated order ID.
	 * @return self
	 */
	public static function from_validated_line( array $line, ?int $order_id = null ): self {
		$food_id = (int) ( $line['food_id'] ?? 0 );
		$title   = (string) ( $line['title'] ?? '' );

		$variation_id      = null;
		$variation_summary = null;
		if ( isset( $line['variation'] ) && is_array( $line['variation'] ) ) {
			$vid = (string) ( $line['variation']['id'] ?? '' );
			if ( '' !== $vid ) {
				$variation_id = $vid;
			}
			$vsum = (string) ( $line['variation']['summary'] ?? '' );
			if ( '' !== $vsum ) {
				$variation_summary = $vsum;
			}
		}

		$addons_summary = null;
		if ( isset( $line['addons'] ) && is_array( $line['addons'] ) ) {
			$addons_summary = self::build_addons_summary( $line['addons'] );
		}

		$unit_price = isset( $line['effective_unit_price'] )
			? (float) $line['effective_unit_price']
			: (float) ( $line['unit_price'] ?? 0.0 );

		$quantity   = max( 1, (int) ( $line['quantity'] ?? 1 ) );
		$line_total = isset( $line['line_total'] )
			? (float) $line['line_total']
			: round( $unit_price * $quantity, 2 );

		return new self(
			null,
			$order_id,
			$food_id,
			$title,
			$variation_id,
			$variation_summary,
			$addons_summary,
			$unit_price,
			$quantity,
			$line_total
		);
	}

	/**
	 * Construct an OrderItem snapshot entity from a database record.
	 *
	 * @param object|array<string, mixed> $record Database row from wp_maktomine_order_items.
	 * @return self
	 */
	public static function from_record( object|array $record ): self {
		$data = (array) $record;

		return new self(
			isset( $data['id'] ) ? (int) $data['id'] : null,
			isset( $data['order_id'] ) ? (int) $data['order_id'] : null,
			(int) ( $data['food_id'] ?? 0 ),
			(string) ( $data['item_name'] ?? '' ),
			isset( $data['variation_id'] ) && '' !== $data['variation_id'] ? (string) $data['variation_id'] : null,
			isset( $data['variation_summary'] ) && '' !== $data['variation_summary'] ? (string) $data['variation_summary'] : null,
			isset( $data['addons_summary'] ) && '' !== $data['addons_summary'] ? (string) $data['addons_summary'] : null,
			isset( $data['unit_price'] ) ? (float) $data['unit_price'] : 0.0,
			isset( $data['quantity'] ) ? (int) $data['quantity'] : 1,
			isset( $data['line_total'] ) ? (float) $data['line_total'] : 0.0
		);
	}

	/**
	 * Export the order item snapshot to an array.
	 *
	 * @return array<string, mixed>
	 */
	public function to_array(): array {
		return [
			'id'                => $this->id,
			'order_id'          => $this->order_id,
			'food_id'           => $this->food_id,
			'item_name'         => $this->item_name,
			'variation_id'      => $this->variation_id,
			'variation_summary' => $this->variation_summary,
			'addons_summary'    => $this->addons_summary,
			'unit_price'        => $this->unit_price,
			'quantity'          => $this->quantity,
			'line_total'        => $this->line_total,
		];
	}

	/**
	 * Build a human-readable add-on summary string from a validated add-ons array.
	 *
	 * Format: "Extra Cheese (x2), Garlic Dip" or "Cheese x 2, Bacon".
	 *
	 * @param array<int, mixed> $addons Validated add-on records.
	 * @return string|null
	 */
	public static function build_addons_summary( array $addons ): ?string {
		if ( empty( $addons ) ) {
			return null;
		}

		$parts = [];
		foreach ( $addons as $addon ) {
			if ( ! is_array( $addon ) ) {
				continue;
			}

			$name = trim( (string) ( $addon['name'] ?? $addon['id'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}

			$qty = isset( $addon['quantity'] ) ? (int) $addon['quantity'] : 1;
			$parts[] = $qty > 1 ? sprintf( '%s (x%d)', $name, $qty ) : $name;
		}

		return ! empty( $parts ) ? implode( ', ', $parts ) : null;
	}
}
