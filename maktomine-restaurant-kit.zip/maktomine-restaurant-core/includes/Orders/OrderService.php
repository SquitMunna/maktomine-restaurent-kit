<?php
/**
 * Order Domain Service & Persistence Manager.
 *
 * Coordinates atomic order creation, status transitions, and authoritative
 * order snapshot persistence from validated cart data.
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

defined( 'ABSPATH' ) || exit;

use WP_Error;
use wpdb;
use Maktomine\RestaurantCore\Capabilities\CapabilityManager;
use Maktomine\RestaurantCore\Core\Logger;
use Maktomine\RestaurantCore\Support\Sanitizer;
use Maktomine\RestaurantCore\Support\Validator;

/**
 * Class OrderService
 *
 * Manages the transition from an authoritative validated cart and customer
 * input into a permanently persisted, immutable order record.
 */
final class OrderService {

	/**
	 * Error codes.
	 */
	public const ERROR_INVALID_VALIDATED_CART    = 'invalid_validated_cart';
	public const ERROR_INVALID_CUSTOMER_NAME     = 'invalid_customer_name';
	public const ERROR_INVALID_CUSTOMER_PHONE    = 'invalid_customer_phone';
	public const ERROR_INVALID_CUSTOMER_WHATSAPP = 'invalid_customer_whatsapp';
	public const ERROR_INVALID_ORDER_TYPE        = 'invalid_order_type';
	public const ERROR_INVALID_DELIVERY_ADDRESS  = 'invalid_delivery_address';
	public const ERROR_INVALID_ORDER_NOTE        = 'invalid_order_note';
	public const ERROR_ORDER_CREATION_FAILED     = 'order_creation_failed';
	public const ERROR_ORDER_NOT_FOUND           = 'order_not_found';
	public const ERROR_INVALID_STATUS_TRANSITION = 'invalid_status_transition';
	public const ERROR_UNAUTHORIZED              = 'unauthorized';
	public const ERROR_INVALID_IDEMPOTENCY_KEY   = 'invalid_idempotency_key';
	public const ERROR_IDEMPOTENCY_COLLISION     = 'idempotency_key_collision';

	/**
	 * WordPress database abstraction.
	 *
	 * @var wpdb
	 */
	private wpdb $wpdb;

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Constructor.
	 *
	 * @param wpdb|null $wpdb Optional custom database instance for testing.
	 */
	public function __construct( ?wpdb $wpdb = null ) {
		/** @var wpdb $db */
		$db = $wpdb ?? $GLOBALS['wpdb'];
		$this->wpdb = $db;
	}

	/**
	 * Retrieve singleton instance.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Create and persist an order from a validated cart result and customer data.
	 *
	 * Executes an atomic transaction:
	 * 1. Validates optional client idempotency key if supplied.
	 * 2. Validates structure of validated cart (produced by CartValidatorService).
	 * 3. Validates and sanitizes customer inputs.
	 * 4. Enforces authoritative pricing from validated cart (delivery_charge = 0.00).
	 * 5. Generates unique order reference (MKT-YYYYMMDD-XXXX).
	 * 6. Generates cryptographically secure verification hash.
	 * 7. Atomically inserts order header with optional idempotency_key and all order item snapshots.
	 * 8. On success, commits transaction and returns the Order entity.
	 * 9. On failure, rolls back transaction and returns WP_Error.
	 *
	 * @param array<string, mixed> $validated_cart Output from CartValidatorService::validate().
	 * @param array<string, mixed> $customer_data  Raw customer input array.
	 * @param string|null          $idempotency_key Optional client idempotency key for deduplication.
	 * @return Order|WP_Error
	 */
	public function create_order(
		array $validated_cart,
		array $customer_data,
		?string $idempotency_key = null
	): Order|WP_Error {
		// 0. Validate optional client idempotency key if supplied.
		$validated_idempotency_key = null;
		if ( null !== $idempotency_key ) {
			$trimmed_key = trim( $idempotency_key );
			if ( ! OrderIdempotencyService::is_valid_key( $trimmed_key ) ) {
				return new WP_Error(
					self::ERROR_INVALID_IDEMPOTENCY_KEY,
					__( 'The provided idempotency key is malformed or invalid.', 'maktomine-restaurant-core' )
				);
			}
			$validated_idempotency_key = $trimmed_key;
		}

		// 1. Validate the structure of the validated cart.
		$cart_check = $this->validate_validated_cart_structure( $validated_cart );
		if ( is_wp_error( $cart_check ) ) {
			return $cart_check;
		}

		// 2. Validate and sanitize customer information.
		$validated_customer = $this->validate_customer_data( $customer_data );
		if ( is_wp_error( $validated_customer ) ) {
			return $validated_customer;
		}

		// 3. Authoritative monetary amounts strictly sourced from validated cart.
		$subtotal        = round( (float) $validated_cart['subtotal'], 2 );
		$delivery_charge = 0.00; // Phase 4D invariant: delivery calculation deferred to delivery phase.
		$total_amount    = round( $subtotal + $delivery_charge, 2 );
		$currency        = strtoupper( trim( (string) $validated_cart['currency'] ) );

		// 4. Generate unique server-side reference.
		$order_reference = $this->generate_unique_reference();

		// 5. Generate secure verification hash.
		$verification_hash = $this->generate_verification_hash( $order_reference );

		// Database table names with dynamic prefix.
		$orders_table      = $this->wpdb->prefix . 'maktomine_orders';
		$order_items_table = $this->wpdb->prefix . 'maktomine_order_items';

		$now = current_time( 'mysql', true );

		// 6. Execute atomic persistence transaction.
		$this->wpdb->query( 'START TRANSACTION' );

		try {
			$header_inserted = $this->wpdb->insert(
				$orders_table,
				[
					'order_reference'   => $order_reference,
					'idempotency_key'   => $validated_idempotency_key,
					'customer_name'     => $validated_customer['customer_name'],
					'customer_phone'    => $validated_customer['customer_phone'],
					'customer_whatsapp' => $validated_customer['customer_whatsapp'],
					'order_type'        => $validated_customer['order_type'],
					'delivery_address'  => $validated_customer['delivery_address'],
					'delivery_area'     => $validated_customer['delivery_area'],
					'delivery_landmark' => $validated_customer['delivery_landmark'],
					'order_note'        => $validated_customer['order_note'],
					'subtotal'          => $subtotal,
					'delivery_charge'   => $delivery_charge,
					'total_amount'      => $total_amount,
					'currency'          => $currency,
					'order_status'      => Order::STATUS_PENDING_WHATSAPP,
					'verification_hash' => $verification_hash,
					'created_at'        => $now,
					'updated_at'        => $now,
				],
				[
					'%s', '%s', '%s', '%s', '%s', '%s',
					'%s', '%s', '%s', '%s',
					'%f', '%f', '%f', '%s',
					'%s', '%s', '%s', '%s',
				]
			);

			if ( false === $header_inserted ) {
				$this->wpdb->query( 'ROLLBACK' );

				$last_error   = (string) $this->wpdb->last_error;
				$last_errno   = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;
				$is_duplicate = ( 1062 === $last_errno ) || ( false !== strpos( $last_error, 'Duplicate entry' ) );

				if ( null !== $validated_idempotency_key && $is_duplicate ) {
					$is_key_collision = ( false !== strpos( $last_error, 'idempotency_key' ) );

					if ( ! $is_key_collision ) {
						// Fallback check if the DB driver did not report the specific index name in the message string.
						$existing_order_id = $this->wpdb->get_var(
							$this->wpdb->prepare(
								"SELECT id FROM {$orders_table} WHERE idempotency_key = %s LIMIT 1",
								$validated_idempotency_key
							)
						);
						$is_key_collision  = ( null !== $existing_order_id );
					}

					if ( $is_key_collision ) {
						Logger::warning(
							'OrderService: Duplicate idempotency key collision on order insert.',
							[
								'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $validated_idempotency_key ),
								'operation'               => 'order_header_insert',
								'db_error_category'       => 'duplicate_key_contention',
								'last_errno'              => $last_errno,
							]
						);

						return new WP_Error(
							self::ERROR_IDEMPOTENCY_COLLISION,
							__( 'An order has already been created with this idempotency key.', 'maktomine-restaurant-core' )
						);
					}
				}

				Logger::error(
					'OrderService: Failed to insert order header.',
					[
						'operation'         => 'order_header_insert',
						'db_error_category' => OrderIdempotencyService::classify_db_error( $last_errno ),
						'last_errno'        => $last_errno,
					]
				);
				return new WP_Error(
					self::ERROR_ORDER_CREATION_FAILED,
					__( 'Failed to persist order record.', 'maktomine-restaurant-core' )
				);
			}

			$order_id = (int) $this->wpdb->insert_id;
			if ( $order_id <= 0 ) {
				$this->wpdb->query( 'ROLLBACK' );
				return new WP_Error(
					self::ERROR_ORDER_CREATION_FAILED,
					__( 'Invalid generated order identifier.', 'maktomine-restaurant-core' )
				);
			}

			// 7. Persist all line items as immutable historical snapshots.
			$persisted_items = [];
			foreach ( $validated_cart['lines'] as $line ) {
				$item = OrderItem::from_validated_line( $line, $order_id );

				$item_inserted = $this->wpdb->insert(
					$order_items_table,
					[
						'order_id'           => $order_id,
						'food_id'            => $item->get_food_id(),
						'item_name'          => $item->get_item_name(),
						'variation_id'       => $item->get_variation_id(),
						'variation_summary'  => $item->get_variation_summary(),
						'addons_summary'     => $item->get_addons_summary(),
						'unit_price'         => $item->get_unit_price(),
						'quantity'           => $item->get_quantity(),
						'line_total'         => $item->get_line_total(),
					],
					[
						'%d', '%d', '%s', '%s', '%s', '%s', '%f', '%d', '%f',
					]
				);

				if ( false === $item_inserted ) {
					$item_errno = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;
					$this->wpdb->query( 'ROLLBACK' );
					Logger::error(
						'OrderService: Failed to insert order item.',
						[
							'order_id'          => $order_id,
							'operation'         => 'order_item_insert',
							'db_error_category' => OrderIdempotencyService::classify_db_error( $item_errno ),
							'last_errno'        => $item_errno,
						]
					);
					return new WP_Error(
						self::ERROR_ORDER_CREATION_FAILED,
						__( 'Failed to persist order line items.', 'maktomine-restaurant-core' )
					);
				}

				$item_id = (int) $this->wpdb->insert_id;
				$persisted_items[] = new OrderItem(
					$item_id,
					$order_id,
					$item->get_food_id(),
					$item->get_item_name(),
					$item->get_variation_id(),
					$item->get_variation_summary(),
					$item->get_addons_summary(),
					$item->get_unit_price(),
					$item->get_quantity(),
					$item->get_line_total()
				);
			}

			// Commit atomic transaction.
			$this->wpdb->query( 'COMMIT' );

			$order = new Order(
				$order_id,
				$order_reference,
				$validated_customer['customer_name'],
				$validated_customer['customer_phone'],
				$validated_customer['customer_whatsapp'],
				$validated_customer['order_type'],
				$validated_customer['delivery_address'],
				$validated_customer['delivery_area'],
				$validated_customer['delivery_landmark'],
				$validated_customer['order_note'],
				$subtotal,
				$delivery_charge,
				$total_amount,
				$currency,
				Order::STATUS_PENDING_WHATSAPP,
				$verification_hash,
				$now,
				$now,
				$persisted_items
			);

			/**
			 * Fires immediately after an order is successfully created and committed.
			 *
			 * @param Order $order The persisted immutable Order instance.
			 */
			do_action( 'maktomine/order/created', $order );

			return $order;
		} catch ( \Throwable $e ) {
			$this->wpdb->query( 'ROLLBACK' );
			Logger::error(
				'OrderService: Unexpected exception occurred during persistence transaction.',
				[
					'operation'       => 'order_persistence_exception',
					'error_category'  => 'unexpected_persistence_exception',
					'exception_class' => get_class( $e ),
				]
			);
			return new WP_Error(
				self::ERROR_ORDER_CREATION_FAILED,
				__( 'Unexpected error occurred during order creation.', 'maktomine-restaurant-core' )
			);
		}
	}

	/**
	 * Transition an order to a new status following the approved v1 state machine.
	 *
	 * Allowed transitions:
	 * - pending_whatsapp -> confirmed, cancelled
	 * - confirmed        -> preparing, cancelled
	 * - preparing        -> ready, cancelled
	 * - ready            -> completed, cancelled
	 * - completed        -> (terminal, no transitions)
	 * - cancelled        -> (terminal, no transitions)
	 *
	 * @param int    $order_id   Database order ID.
	 * @param string $new_status Target status constant.
	 * @param bool   $check_caps Optional flag to enforce manage_restaurant_orders capability.
	 * @return bool|WP_Error True on success, WP_Error on validation or transition rejection.
	 */
	public function transition_status( int $order_id, string $new_status, bool $check_caps = false ): bool|WP_Error {
		if ( $order_id <= 0 ) {
			return new WP_Error(
				self::ERROR_ORDER_NOT_FOUND,
				__( 'Invalid order ID specified.', 'maktomine-restaurant-core' )
			);
		}

		if ( $check_caps && function_exists( 'current_user_can' ) && ! current_user_can( CapabilityManager::MANAGE_ORDERS ) ) {
			return new WP_Error(
				self::ERROR_UNAUTHORIZED,
				__( 'Insufficient permissions to update order status.', 'maktomine-restaurant-core' )
			);
		}

		$new_status = sanitize_key( $new_status );
		if ( ! in_array( $new_status, Order::ALL_STATUSES, true ) ) {
			return new WP_Error(
				self::ERROR_INVALID_STATUS_TRANSITION,
				sprintf(
					/* translators: %s: target status */
					__( 'Unrecognized order status: %s', 'maktomine-restaurant-core' ),
					$new_status
				)
			);
		}

		$orders_table = $this->wpdb->prefix . 'maktomine_orders';
		$row = $this->wpdb->get_row(
			$this->wpdb->prepare(
				"SELECT id, order_status FROM {$orders_table} WHERE id = %d LIMIT 1",
				$order_id
			)
		);

		if ( null === $row ) {
			return new WP_Error(
				self::ERROR_ORDER_NOT_FOUND,
				__( 'Order not found.', 'maktomine-restaurant-core' )
			);
		}

		$current_status = (string) $row->order_status;

		// Idempotent: same status requires no update.
		if ( $current_status === $new_status ) {
			return true;
		}

		// Enforce state machine transitions.
		$allowed = Order::ALLOWED_TRANSITIONS[ $current_status ] ?? [];
		if ( ! in_array( $new_status, $allowed, true ) ) {
			return new WP_Error(
				self::ERROR_INVALID_STATUS_TRANSITION,
				sprintf(
					/* translators: 1: current status, 2: target status */
					__( 'Cannot transition order from status "%1$s" to "%2$s".', 'maktomine-restaurant-core' ),
					$current_status,
					$new_status
				)
			);
		}

		$now     = current_time( 'mysql', true );
		$updated = $this->wpdb->query(
			$this->wpdb->prepare(
				"UPDATE {$orders_table} SET order_status = %s, updated_at = %s WHERE id = %d AND order_status = %s",
				$new_status,
				$now,
				$order_id,
				$current_status
			)
		);

		if ( false === $updated ) {
			$status_errno = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;
			Logger::error(
				'OrderService: Failed to update order status.',
				[
					'order_id'          => $order_id,
					'operation'         => 'order_status_update',
					'db_error_category' => OrderIdempotencyService::classify_db_error( $status_errno ),
					'last_errno'        => $status_errno,
				]
			);
			return new WP_Error(
				self::ERROR_ORDER_CREATION_FAILED,
				__( 'Database failure while updating order status.', 'maktomine-restaurant-core' )
			);
		}

		if ( 0 === $updated ) {
			return new WP_Error(
				self::ERROR_INVALID_STATUS_TRANSITION,
				__( 'Order status was modified concurrently by another process. Please reload.', 'maktomine-restaurant-core' )
			);
		}

		/**
		 * Fires immediately after an order status has successfully changed.
		 *
		 * @param int    $order_id       Order database ID.
		 * @param string $new_status     The newly assigned order status.
		 * @param string $current_status The previous order status.
		 */
		do_action( 'maktomine/order/status_changed', $order_id, $new_status, $current_status );

		return true;
	}

	/**
	 * Retrieve a persisted order snapshot by primary key ID.
	 *
	 * @param int $order_id Order record ID.
	 * @return Order|null
	 */
	public function get_order( int $order_id ): ?Order {
		if ( $order_id <= 0 ) {
			return null;
		}

		$orders_table = $this->wpdb->prefix . 'maktomine_orders';
		$order_row    = $this->wpdb->get_row(
			$this->wpdb->prepare(
				"SELECT * FROM {$orders_table} WHERE id = %d LIMIT 1",
				$order_id
			)
		);

		if ( null === $order_row ) {
			return null;
		}

		$items = $this->get_items_for_order( $order_id );

		return Order::from_record( $order_row, $items );
	}

	/**
	 * Retrieve a persisted order snapshot by unique public reference.
	 *
	 * @param string $reference Order reference string (e.g. MKT-YYYYMMDD-XXXX).
	 * @return Order|null
	 */
	public function get_order_by_reference( string $reference ): ?Order {
		$sanitized_ref = Sanitizer::reference( $reference );
		if ( empty( $sanitized_ref ) ) {
			return null;
		}

		$orders_table = $this->wpdb->prefix . 'maktomine_orders';
		$order_row    = $this->wpdb->get_row(
			$this->wpdb->prepare(
				"SELECT * FROM {$orders_table} WHERE order_reference = %s LIMIT 1",
				$sanitized_ref
			)
		);

		if ( null === $order_row ) {
			return null;
		}

		$order_id = (int) $order_row->id;
		$items    = $this->get_items_for_order( $order_id );

		return Order::from_record( $order_row, $items );
	}

	/**
	 * Retrieve a bounded, filtered, and paginated list of administrative order headers.
	 *
	 * Core administrative query method for Phase 6 multi-order listing:
	 * - Queries strictly wp_maktomine_orders (headers only; zero OrderItem hydration).
	 * - Enforces bounded pagination (per_page between 1 and 100).
	 * - Validates status filter against Order::ALL_STATUSES.
	 * - Validates fulfillment type filter against Order::ALL_TYPES.
	 * - Validates created_at date range inputs (YYYY-MM-DD or YYYY-MM-DD HH:MM:SS).
	 * - Supports unified multi-column search across order_reference, customer_phone, and customer_name.
	 * - Enforces deterministic ORDER BY using an internal allowlist with secondary id tie-breaker.
	 * - Runs a companion COUNT(*) query with identical WHERE predicates for accurate pagination metadata.
	 * - Emits lightweight associative list rows excluding sensitive delivery detail fields.
	 * - Strictly read-only; executes zero mutations, catalog joins, or external calls.
	 *
	 * @param array<string, mixed> $args Query arguments:
	 *     - page (int): 1-indexed page number (default 1).
	 *     - per_page (int): Items per page, bounded 1-100 (default 20).
	 *     - status (string): Optional status filter matching Order::ALL_STATUSES.
	 *     - type (string): Optional order type filter matching Order::ALL_TYPES.
	 *     - date_from (string): Optional start datetime boundary (created_at >= date_from).
	 *     - date_to (string): Optional end datetime boundary (created_at <= date_to).
	 *     - search (string): Optional search term matching reference, phone, or name.
	 *     - orderby (string): Sort field allowlist: created_at, id, order_reference, order_status, total_amount (default created_at).
	 *     - order (string): Sort direction: ASC or DESC (default DESC).
	 * @return array{
	 *     items: array<int, array<string, mixed>>,
	 *     total_items: int,
	 *     total_pages: int,
	 *     current_page: int,
	 *     per_page: int
	 * }|WP_Error
	 */
	public function get_orders( array $args = [] ): array|WP_Error {
		$orders_table = $this->wpdb->prefix . 'maktomine_orders';

		// 1. Pagination Bounds
		$page     = max( 1, isset( $args['page'] ) ? (int) $args['page'] : 1 );
		$per_page = max( 1, min( 100, isset( $args['per_page'] ) ? (int) $args['per_page'] : 20 ) );
		$offset   = ( $page - 1 ) * $per_page;

		// 2. WHERE Clause Construction & Parameter Collection
		$where_clauses = [];
		$where_params  = [];

		// Filter: Status
		if ( ! empty( $args['status'] ) ) {
			$status = sanitize_key( (string) $args['status'] );
			if ( in_array( $status, Order::ALL_STATUSES, true ) ) {
				$where_clauses[] = 'order_status = %s';
				$where_params[]  = $status;
			} else {
				return new WP_Error(
					self::ERROR_INVALID_STATUS_TRANSITION,
					sprintf(
						/* translators: %s: filter status */
						__( 'Invalid status filter value: %s', 'maktomine-restaurant-core' ),
						$status
					)
				);
			}
		}

		// Filter: Order Type
		if ( ! empty( $args['type'] ) ) {
			$type = sanitize_key( (string) $args['type'] );
			if ( in_array( $type, Order::ALL_TYPES, true ) ) {
				$where_clauses[] = 'order_type = %s';
				$where_params[]  = $type;
			} else {
				return new WP_Error(
					self::ERROR_INVALID_ORDER_TYPE,
					sprintf(
						/* translators: %s: filter order type */
						__( 'Invalid order type filter value: %s', 'maktomine-restaurant-core' ),
						$type
					)
				);
			}
		}

		// Filter: Date Range (created_at)
		if ( ! empty( $args['date_from'] ) ) {
			$date_from_raw = trim( (string) $args['date_from'] );
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}:\d{2})?$/', $date_from_raw ) ) {
				$date_from       = ( 10 === strlen( $date_from_raw ) ) ? $date_from_raw . ' 00:00:00' : $date_from_raw;
				$where_clauses[] = 'created_at >= %s';
				$where_params[]  = $date_from;
			} else {
				return new WP_Error(
					self::ERROR_INVALID_CUSTOMER_NAME,
					__( 'Invalid date_from parameter format. Expected YYYY-MM-DD or YYYY-MM-DD HH:MM:SS.', 'maktomine-restaurant-core' )
				);
			}
		}

		if ( ! empty( $args['date_to'] ) ) {
			$date_to_raw = trim( (string) $args['date_to'] );
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}:\d{2})?$/', $date_to_raw ) ) {
				$date_to         = ( 10 === strlen( $date_to_raw ) ) ? $date_to_raw . ' 23:59:59' : $date_to_raw;
				$where_clauses[] = 'created_at <= %s';
				$where_params[]  = $date_to;
			} else {
				return new WP_Error(
					self::ERROR_INVALID_CUSTOMER_NAME,
					__( 'Invalid date_to parameter format. Expected YYYY-MM-DD or YYYY-MM-DD HH:MM:SS.', 'maktomine-restaurant-core' )
				);
			}
		}

		// Search: Unified Multi-Column (order_reference, customer_phone, customer_name)
		if ( ! empty( $args['search'] ) ) {
			$search_term = trim( (string) $args['search'] );
			if ( '' !== $search_term ) {
				$escaped_like    = '%' . $this->wpdb->esc_like( $search_term ) . '%';
				$clean_ref       = Sanitizer::reference( $search_term );

				$where_clauses[] = '( order_reference = %s OR customer_phone LIKE %s OR customer_name LIKE %s )';
				$where_params[]  = '' !== $clean_ref ? $clean_ref : $search_term;
				$where_params[]  = $escaped_like;
				$where_params[]  = $escaped_like;
			}
		}

		// Assemble WHERE SQL segment
		$where_sql = '';
		if ( ! empty( $where_clauses ) ) {
			$where_sql = 'WHERE ' . implode( ' AND ', $where_clauses );
		}

		// 3. Total Count Query (for pagination metadata)
		$count_sql = "SELECT COUNT(*) FROM {$orders_table} {$where_sql}";
		if ( ! empty( $where_params ) ) {
			$prepared_count_sql = $this->wpdb->prepare( $count_sql, ...$where_params );
		} else {
			$prepared_count_sql = $count_sql;
		}

		$total_items = (int) $this->wpdb->get_var( $prepared_count_sql );

		if ( $this->wpdb->last_error ) {
			$last_errno = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;
			Logger::error(
				'OrderService: Database failure during get_orders count query.',
				[
					'operation'         => 'get_orders_count',
					'db_error_category' => OrderIdempotencyService::classify_db_error( $last_errno ),
					'last_errno'        => $last_errno,
				]
			);
			return new WP_Error(
				self::ERROR_ORDER_CREATION_FAILED,
				__( 'Database error while querying orders count.', 'maktomine-restaurant-core' )
			);
		}

		$total_pages = $total_items > 0 ? (int) ceil( $total_items / $per_page ) : 0;

		// If zero items match, return empty result structure immediately.
		if ( 0 === $total_items ) {
			return [
				'items'        => [],
				'total_items'  => 0,
				'total_pages'  => 0,
				'current_page' => $page,
				'per_page'     => $per_page,
			];
		}

		// 4. Sorting Allowlist & Deterministic Secondary Tie-Breaker
		$allowed_sort_fields = [
			'created_at'      => 'created_at',
			'id'              => 'id',
			'order_reference' => 'order_reference',
			'order_status'    => 'order_status',
			'total_amount'    => 'total_amount',
		];

		$raw_orderby = isset( $args['orderby'] ) ? sanitize_key( (string) $args['orderby'] ) : 'created_at';
		$sort_field  = $allowed_sort_fields[ $raw_orderby ] ?? 'created_at';

		$raw_order = isset( $args['order'] ) ? strtoupper( trim( (string) $args['order'] ) ) : 'DESC';
		$direction = in_array( $raw_order, [ 'ASC', 'DESC' ], true ) ? $raw_order : 'DESC';

		// Deterministic tie-breaker: always append `id` ordering if primary sort is not already `id`
		if ( 'id' === $sort_field ) {
			$order_by_sql = "ORDER BY id {$direction}";
		} else {
			$order_by_sql = "ORDER BY {$sort_field} {$direction}, id {$direction}";
		}

		// 5. Query Projection: Minimal, secure header columns
		$select_fields = 'id, order_reference, order_status, order_type, customer_name, customer_phone, subtotal, delivery_charge, total_amount, currency, created_at, updated_at';

		$query_sql = "SELECT {$select_fields} FROM {$orders_table} {$where_sql} {$order_by_sql} LIMIT %d OFFSET %d";

		$query_params   = $where_params;
		$query_params[] = $per_page;
		$query_params[] = $offset;

		$prepared_query = $this->wpdb->prepare( $query_sql, ...$query_params );
		$rows           = $this->wpdb->get_results( $prepared_query, ARRAY_A );

		if ( $this->wpdb->last_error ) {
			$last_errno = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;
			Logger::error(
				'OrderService: Database failure during get_orders list query.',
				[
					'operation'         => 'get_orders_list',
					'db_error_category' => OrderIdempotencyService::classify_db_error( $last_errno ),
					'last_errno'        => $last_errno,
				]
			);
			return new WP_Error(
				self::ERROR_ORDER_CREATION_FAILED,
				__( 'Database error while querying orders list.', 'maktomine-restaurant-core' )
			);
		}

		if ( ! is_array( $rows ) ) {
			$rows = [];
		}

		// Format output rows as lightweight associative arrays with strongly cast types
		$items = [];
		foreach ( $rows as $row ) {
			$items[] = [
				'id'              => (int) ( $row['id'] ?? 0 ),
				'order_reference' => (string) ( $row['order_reference'] ?? '' ),
				'order_status'    => (string) ( $row['order_status'] ?? '' ),
				'order_type'      => (string) ( $row['order_type'] ?? '' ),
				'customer_name'   => (string) ( $row['customer_name'] ?? '' ),
				'customer_phone'  => (string) ( $row['customer_phone'] ?? '' ),
				'subtotal'        => (float) ( $row['subtotal'] ?? 0.0 ),
				'delivery_charge' => (float) ( $row['delivery_charge'] ?? 0.0 ),
				'total_amount'    => (float) ( $row['total_amount'] ?? 0.0 ),
				'currency'        => (string) ( $row['currency'] ?? '' ),
				'created_at'      => (string) ( $row['created_at'] ?? '' ),
				'updated_at'      => (string) ( $row['updated_at'] ?? '' ),
			];
		}

		return [
			'items'        => $items,
			'total_items'  => $total_items,
			'total_pages'  => $total_pages,
			'current_page' => $page,
			'per_page'     => $per_page,
		];
	}

	// ==========================================
	// Private Helper & Validation Methods
	// ==========================================

	/**
	 * Retrieve and hydrate OrderItem snapshots for a given order ID.
	 *
	 * @param int $order_id Database order ID.
	 * @return array<OrderItem>
	 */
	private function get_items_for_order( int $order_id ): array {
		$order_items_table = $this->wpdb->prefix . 'maktomine_order_items';
		$item_rows         = $this->wpdb->get_results(
			$this->wpdb->prepare(
				"SELECT * FROM {$order_items_table} WHERE order_id = %d ORDER BY id ASC",
				$order_id
			)
		);

		if ( empty( $item_rows ) ) {
			return [];
		}

		$items = [];
		foreach ( $item_rows as $row ) {
			$items[] = OrderItem::from_record( $row );
		}

		return $items;
	}

	/**
	 * Validate that the input cart structure adheres to the Phase 4C CartValidatorService contract.
	 *
	 * Enforces mathematical and structural integrity without repeating catalog lookups:
	 * - Lines array must be non-empty.
	 * - Each line must contain positive integer food_id, bounded title, integer quantity >= 1.
	 * - Each line must contain non-negative unit_price, effective_unit_price, and line_total.
	 * - Each line must be mathematically consistent: line_total == round(effective_unit_price * quantity, 2).
	 * - If addons_total is present: effective_unit_price == round(unit_price + addons_total, 2).
	 * - The sum of all line_totals must equal subtotal.
	 * - Currency must be an authoritative 3-8 character uppercase code.
	 *
	 * @param array<string, mixed> $validated_cart Validated cart array.
	 * @return true|WP_Error
	 */
	private function validate_validated_cart_structure( array $validated_cart ): true|WP_Error {
		if ( empty( $validated_cart['lines'] ) || ! is_array( $validated_cart['lines'] ) ) {
			return new WP_Error(
				self::ERROR_INVALID_VALIDATED_CART,
				__( 'Validated cart must contain a non-empty lines array.', 'maktomine-restaurant-core' )
			);
		}

		if ( ! isset( $validated_cart['subtotal'] ) || ! is_numeric( $validated_cart['subtotal'] ) || (float) $validated_cart['subtotal'] <= 0.0 ) {
			return new WP_Error(
				self::ERROR_INVALID_VALIDATED_CART,
				__( 'Validated cart must contain a positive subtotal.', 'maktomine-restaurant-core' )
			);
		}

		if ( empty( $validated_cart['currency'] ) || ! is_string( $validated_cart['currency'] ) ) {
			return new WP_Error(
				self::ERROR_INVALID_VALIDATED_CART,
				__( 'Validated cart must contain an authoritative currency code.', 'maktomine-restaurant-core' )
			);
		}

		$currency = strtoupper( trim( $validated_cart['currency'] ) );
		if ( ! preg_match( '/^[A-Z]{3,8}$/', $currency ) ) {
			return new WP_Error(
				self::ERROR_INVALID_VALIDATED_CART,
				__( 'Validated cart contains an invalid currency code format.', 'maktomine-restaurant-core' )
			);
		}

		$calculated_subtotal   = 0.0;
		$calculated_item_count = 0;

		foreach ( $validated_cart['lines'] as $index => $line ) {
			if ( ! is_array( $line ) ) {
				return new WP_Error(
					self::ERROR_INVALID_VALIDATED_CART,
					sprintf(
						/* translators: %d: line index */
						__( 'Line %d in validated cart is malformed.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}

			$food_id = isset( $line['food_id'] ) ? (int) $line['food_id'] : 0;
			$title   = isset( $line['title'] ) ? trim( (string) $line['title'] ) : '';

			if ( $food_id <= 0 || '' === $title || mb_strlen( $title, 'UTF-8' ) > 191 ) {
				return new WP_Error(
					self::ERROR_INVALID_VALIDATED_CART,
					sprintf(
						/* translators: %d: line index */
						__( 'Line %d has invalid food item identification or title.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}

			if ( ! isset( $line['quantity'] ) || ! is_numeric( $line['quantity'] ) || (int) $line['quantity'] < 1 ) {
				return new WP_Error(
					self::ERROR_INVALID_VALIDATED_CART,
					sprintf(
						/* translators: %d: line index */
						__( 'Line %d has an invalid quantity.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}
			$quantity = (int) $line['quantity'];

			if ( ! isset( $line['unit_price'] ) || ! is_numeric( $line['unit_price'] ) || (float) $line['unit_price'] < 0.0 ) {
				return new WP_Error(
					self::ERROR_INVALID_VALIDATED_CART,
					sprintf(
						/* translators: %d: line index */
						__( 'Line %d has an invalid unit price.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}
			$unit_price = (float) $line['unit_price'];

			$effective_unit_price = isset( $line['effective_unit_price'] ) && is_numeric( $line['effective_unit_price'] )
				? (float) $line['effective_unit_price']
				: $unit_price;

			if ( $effective_unit_price < 0.0 ) {
				return new WP_Error(
					self::ERROR_INVALID_VALIDATED_CART,
					sprintf(
						/* translators: %d: line index */
						__( 'Line %d has an invalid effective unit price.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}

			if ( isset( $line['addons_total'] ) && is_numeric( $line['addons_total'] ) ) {
				$addons_total = (float) $line['addons_total'];
				if ( $addons_total < 0.0 || abs( round( $unit_price + $addons_total, 2 ) - round( $effective_unit_price, 2 ) ) > 0.01 ) {
					return new WP_Error(
						self::ERROR_INVALID_VALIDATED_CART,
						sprintf(
							/* translators: %d: line index */
							__( 'Line %d has inconsistent add-on pricing totals.', 'maktomine-restaurant-core' ),
							$index
						)
					);
				}
			}

			if ( ! isset( $line['line_total'] ) || ! is_numeric( $line['line_total'] ) || (float) $line['line_total'] < 0.0 ) {
				return new WP_Error(
					self::ERROR_INVALID_VALIDATED_CART,
					sprintf(
						/* translators: %d: line index */
						__( 'Line %d has an invalid line total.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}
			$line_total = round( (float) $line['line_total'], 2 );

			// Mathematical integrity check: line_total must equal round(effective_unit_price * quantity, 2).
			$expected_line_total = round( $effective_unit_price * $quantity, 2 );
			if ( abs( $line_total - $expected_line_total ) > 0.01 ) {
				return new WP_Error(
					self::ERROR_INVALID_VALIDATED_CART,
					sprintf(
						/* translators: %d: line index */
						__( 'Line %d line_total does not match effective_unit_price * quantity.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}

			$calculated_subtotal   = round( $calculated_subtotal + $line_total, 2 );
			$calculated_item_count += $quantity;
		}

		// Cart-level mathematical integrity check: subtotal must equal sum of line totals.
		$declared_subtotal = round( (float) $validated_cart['subtotal'], 2 );
		if ( abs( $declared_subtotal - $calculated_subtotal ) > 0.01 ) {
			return new WP_Error(
				self::ERROR_INVALID_VALIDATED_CART,
				__( 'Validated cart subtotal does not equal the sum of line totals.', 'maktomine-restaurant-core' )
			);
		}

		// Optional item_count check if present in Phase 4C payload.
		if ( isset( $validated_cart['item_count'] ) && is_numeric( $validated_cart['item_count'] ) ) {
			if ( (int) $validated_cart['item_count'] !== $calculated_item_count ) {
				return new WP_Error(
					self::ERROR_INVALID_VALIDATED_CART,
					__( 'Validated cart item_count does not match the sum of line quantities.', 'maktomine-restaurant-core' )
				);
			}
		}

		return true;
	}

	/**
	 * Validate and sanitize customer checkout input fields.
	 *
	 * @param array<string, mixed> $customer_data Raw customer data.
	 * @return array<string, mixed>|WP_Error Validated and sanitized customer fields.
	 */
	private function validate_customer_data( array $customer_data ): array|WP_Error {
		// 1. Customer Name (required, bounded 2-191 characters).
		$raw_name       = isset( $customer_data['customer_name'] ) ? (string) $customer_data['customer_name'] : '';
		$sanitized_name = sanitize_text_field( trim( $raw_name ) );
		$name_len       = mb_strlen( $sanitized_name, 'UTF-8' );

		if ( $name_len < 2 || $name_len > 191 ) {
			return new WP_Error(
				self::ERROR_INVALID_CUSTOMER_NAME,
				__( 'Customer name is required and must be between 2 and 191 characters.', 'maktomine-restaurant-core' )
			);
		}

		// 2. Customer Phone (required, validated E.164, bounded max 32).
		$raw_phone       = isset( $customer_data['customer_phone'] ) ? (string) $customer_data['customer_phone'] : '';
		$sanitized_phone = Sanitizer::phone( $raw_phone );

		if ( empty( $sanitized_phone ) || ! Validator::is_valid_phone( $raw_phone ) || strlen( $sanitized_phone ) > 32 ) {
			return new WP_Error(
				self::ERROR_INVALID_CUSTOMER_PHONE,
				__( 'A valid customer phone number is required (7 to 15 digits).', 'maktomine-restaurant-core' )
			);
		}

		// 3. Customer WhatsApp (optional; if provided, must be valid phone format, max 32).
		$raw_whatsapp       = isset( $customer_data['customer_whatsapp'] ) ? (string) $customer_data['customer_whatsapp'] : '';
		$sanitized_whatsapp = '';

		if ( '' !== trim( $raw_whatsapp ) ) {
			$sanitized_whatsapp = Sanitizer::phone( $raw_whatsapp );
			if ( empty( $sanitized_whatsapp ) || ! Validator::is_valid_phone( $raw_whatsapp ) || strlen( $sanitized_whatsapp ) > 32 ) {
				return new WP_Error(
					self::ERROR_INVALID_CUSTOMER_WHATSAPP,
					__( 'Customer WhatsApp number is invalid.', 'maktomine-restaurant-core' )
				);
			}
		}

		// 4. Order Type (required: 'delivery' or 'pickup').
		$raw_type = isset( $customer_data['order_type'] ) ? sanitize_key( (string) $customer_data['order_type'] ) : '';
		if ( ! in_array( $raw_type, Order::ALL_TYPES, true ) ) {
			return new WP_Error(
				self::ERROR_INVALID_ORDER_TYPE,
				sprintf(
					/* translators: %s: supported types list */
					__( 'Order type must be one of: %s.', 'maktomine-restaurant-core' ),
					implode( ', ', Order::ALL_TYPES )
				)
			);
		}

		// 5. Delivery Address (required for delivery orders; optional/null for pickup).
		$raw_address       = isset( $customer_data['delivery_address'] ) ? (string) $customer_data['delivery_address'] : '';
		$sanitized_address = sanitize_textarea_field( trim( $raw_address ) );

		if ( Order::TYPE_DELIVERY === $raw_type ) {
			if ( '' === $sanitized_address ) {
				return new WP_Error(
					self::ERROR_INVALID_DELIVERY_ADDRESS,
					__( 'Delivery address is required for delivery orders.', 'maktomine-restaurant-core' )
				);
			}

			if ( mb_strlen( $sanitized_address, 'UTF-8' ) > 1000 ) {
				return new WP_Error(
					self::ERROR_INVALID_DELIVERY_ADDRESS,
					__( 'Delivery address cannot exceed 1000 characters.', 'maktomine-restaurant-core' )
				);
			}
		} else {
			// For pickup orders, address is optional; if blank, record as null.
			$sanitized_address = '' !== $sanitized_address ? $sanitized_address : null;
		}

		// 6. Delivery Area (optional string, max 191).
		$raw_area       = isset( $customer_data['delivery_area'] ) ? (string) $customer_data['delivery_area'] : '';
		$sanitized_area = sanitize_text_field( trim( $raw_area ) );
		if ( mb_strlen( $sanitized_area, 'UTF-8' ) > 191 ) {
			$sanitized_area = mb_substr( $sanitized_area, 0, 191, 'UTF-8' );
		}

		// 7. Delivery Landmark (optional string, max 191).
		$raw_landmark       = isset( $customer_data['delivery_landmark'] ) ? (string) $customer_data['delivery_landmark'] : '';
		$sanitized_landmark = sanitize_text_field( trim( $raw_landmark ) );
		if ( mb_strlen( $sanitized_landmark, 'UTF-8' ) > 191 ) {
			$sanitized_landmark = mb_substr( $sanitized_landmark, 0, 191, 'UTF-8' );
		}

		// 8. Order Note (optional string, max 1000).
		$raw_note       = isset( $customer_data['order_note'] ) ? (string) $customer_data['order_note'] : '';
		$sanitized_note = sanitize_textarea_field( trim( $raw_note ) );

		if ( '' !== $sanitized_note ) {
			if ( mb_strlen( $sanitized_note, 'UTF-8' ) > 1000 ) {
				return new WP_Error(
					self::ERROR_INVALID_ORDER_NOTE,
					__( 'Order note cannot exceed 1000 characters.', 'maktomine-restaurant-core' )
				);
			}
		} else {
			$sanitized_note = null;
		}

		return [
			'customer_name'     => $sanitized_name,
			'customer_phone'    => $sanitized_phone,
			'customer_whatsapp' => $sanitized_whatsapp,
			'order_type'        => $raw_type,
			'delivery_address'  => $sanitized_address,
			'delivery_area'     => $sanitized_area,
			'delivery_landmark' => $sanitized_landmark,
			'order_note'        => $sanitized_note,
		];
	}

	/**
	 * Generate a unique public order reference conforming to MKT-YYYYMMDD-XXXX.
	 *
	 * Employs a bounded collision retry loop verifying uniqueness in the database.
	 *
	 * @return string
	 */
	private function generate_unique_reference(): string {
		$date         = gmdate( 'Ymd' );
		$orders_table = $this->wpdb->prefix . 'maktomine_orders';
		$charset      = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
		$charset_len  = strlen( $charset );

		for ( $attempt = 0; $attempt < 10; $attempt++ ) {
			$suffix = '';
			try {
				$bytes = random_bytes( 4 );
				for ( $i = 0; $i < 4; $i++ ) {
					$suffix .= $charset[ ord( $bytes[ $i ] ) % $charset_len ];
				}
			} catch ( \Throwable ) {
				$suffix = strtoupper( substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 4 ) );
			}

			$reference = sprintf( 'MKT-%s-%s', $date, $suffix );

			$exists = $this->wpdb->get_var(
				$this->wpdb->prepare(
					"SELECT id FROM {$orders_table} WHERE order_reference = %s LIMIT 1",
					$reference
				)
			);

			if ( empty( $exists ) ) {
				return $reference;
			}
		}

		// Highly improbable collision fallback: add 4-char hex timestamp suffix.
		return sprintf( 'MKT-%s-%04X', $date, (int) ( microtime( true ) * 1000 ) & 0xFFFF );
	}

	/**
	 * Generate a 64-character cryptographically secure HMAC verification hash.
	 *
	 * Fits VARCHAR(64) column without exposing internal secrets.
	 *
	 * @param string $order_reference Public order reference.
	 * @return string
	 */
	private function generate_verification_hash( string $order_reference ): string {
		$salt = function_exists( 'wp_salt' ) ? wp_salt( 'auth' ) : '';
		if ( '' === $salt ) {
			try {
				$salt = bin2hex( random_bytes( 32 ) );
			} catch ( \Throwable ) {
				$salt = hash( 'sha256', uniqid( (string) wp_rand(), true ) );
			}
		}

		try {
			$entropy = bin2hex( random_bytes( 16 ) );
		} catch ( \Throwable ) {
			$entropy = md5( uniqid( (string) wp_rand(), true ) );
		}

		return hash_hmac( 'sha256', $order_reference . '|' . $entropy, $salt );
	}
}
