<?php
/**
 * Idempotency Administrative Maintenance Service.
 *
 * Provides bounded administrative cleanup for expired failed idempotency records.
 * Integrates directly with WordPress WP-Cron and enforces strict lifecycle safety invariants:
 * - NEVER deletes processing records (in-flight or crashed).
 * - NEVER deletes completed records (authoritative cached responses).
 * - NEVER deletes or modifies orders or order line items.
 * - NEVER invokes OrderSubmissionService, OrderCreationService, or WhatsAppDispatchService.
 * - Operates in small, bounded batches using indexed queries.
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

use Maktomine\RestaurantCore\Core\Logger;
use Throwable;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Class IdempotencyMaintenanceService
 */
final class IdempotencyMaintenanceService {

	/**
	 * Unique WP-Cron hook name for scheduled maintenance.
	 */
	public const CRON_HOOK = 'maktomine_idempotency_maintenance_cron';

	/**
	 * Default batch size limit for single execution.
	 */
	public const DEFAULT_BATCH_LIMIT = 50;

	/**
	 * Hard maximum batch limit.
	 */
	public const MAX_BATCH_LIMIT = 200;

	/**
	 * WordPress option key to track whether maintenance cron has been scheduled on the installation.
	 */
	public const SCHEDULED_OPTION = 'mkt_idempotency_maintenance_scheduled';

	/**
	 * Idempotency domain service instance.
	 *
	 * @var OrderIdempotencyService
	 */
	private OrderIdempotencyService $idempotency_service;

	/**
	 * Constructor.
	 *
	 * @param OrderIdempotencyService|null $idempotency_service Idempotency service.
	 */
	public function __construct( ?OrderIdempotencyService $idempotency_service = null ) {
		$this->idempotency_service = $idempotency_service ?? OrderIdempotencyService::instance();
	}

	/**
	 * Register the WordPress WP-Cron event hook listener.
	 *
	 * Should be invoked during plugin boot.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( self::CRON_HOOK, [ $this, 'run_scheduled_maintenance' ] );
	}

	/**
	 * Schedule the recurring WP-Cron maintenance event.
	 *
	 * Safe lifecycle helper:
	 * - Only schedules if not already scheduled (wp_next_scheduled check).
	 * - Uses standard daily recurrence ('daily').
	 * - Sets the tracking option so update checks don't repeat work.
	 *
	 * @return void
	 */
	public static function schedule_maintenance(): void {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			$scheduled = wp_schedule_event( time() + 3600, 'daily', self::CRON_HOOK );
			if ( false !== $scheduled ) {
				update_option( self::SCHEDULED_OPTION, '1', true );
				Logger::info(
					'IdempotencyMaintenanceService: Recurring maintenance event scheduled successfully.',
					[
						'operation' => 'scheduler_registration',
						'hook'      => self::CRON_HOOK,
						'recurrence'=> 'daily',
					]
				);
			} else {
				Logger::warning(
					'IdempotencyMaintenanceService: Failed to schedule recurring maintenance event.',
					[
						'operation' => 'scheduler_registration_failure',
						'hook'      => self::CRON_HOOK,
					]
				);
			}
		} else {
			update_option( self::SCHEDULED_OPTION, '1', true );
		}
	}

	/**
	 * Ensure the maintenance schedule exists on existing active installations after an update.
	 *
	 * Idempotent check:
	 * - Only runs when the installation is in admin context or during upgrade hooks.
	 * - Checks the persistent tracking option first to avoid calling wp_next_scheduled on every request.
	 * - If not yet scheduled, invokes schedule_maintenance().
	 *
	 * @return void
	 */
	public static function maybe_schedule_on_update(): void {
		$already_scheduled = (string) get_option( self::SCHEDULED_OPTION, '0' );
		if ( '1' !== $already_scheduled ) {
			self::schedule_maintenance();
		}
	}

	/**
	 * Unschedule and clear the WP-Cron maintenance event.
	 *
	 * Safe lifecycle helper:
	 * - Clears all scheduled events for this plugin's hook.
	 * - Deletes the tracking option so reactivation will schedule anew.
	 * - Never affects unrelated WordPress cron jobs.
	 *
	 * @return void
	 */
	public static function unschedule_maintenance(): void {
		delete_option( self::SCHEDULED_OPTION );
		$timestamp = wp_next_scheduled( self::CRON_HOOK );
		if ( false !== $timestamp ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
			Logger::info(
				'IdempotencyMaintenanceService: Recurring maintenance event cleared successfully.',
				[
					'operation' => 'scheduler_unscheduled',
					'hook'      => self::CRON_HOOK,
				]
			);
		}
	}

	/**
	 * Safe WP-Cron action callback.
	 *
	 * Catches any unexpected Throwable to guarantee the cron request never crashes.
	 * Logs strictly bounded classification metadata; never logs raw exception text,
	 * SQL fragments, table names, or customer PII.
	 *
	 * @return void
	 */
	public function run_scheduled_maintenance(): void {
		try {
			$this->cleanup_expired_failed();
		} catch ( Throwable $e ) {
			Logger::error(
				'IdempotencyMaintenanceService: Unhandled exception during scheduled maintenance execution.',
				[
					'operation'       => 'maintenance_failure',
					'error_category'  => 'unexpected_maintenance_exception',
					'exception_class' => get_class( $e ),
				]
			);
		}
	}

	/**
	 * Execute a bounded cleanup batch of expired failed idempotency records.
	 *
	 * Workflow:
	 * 1. Queries a bounded batch of keys where status = 'failed' AND expires_at <= UTC NOW.
	 * 2. Iterates over the selected keys.
	 * 3. Invokes OrderIdempotencyService::delete_expired_failed( $key ), which independently
	 *    and atomically checks status = 'failed' and expires_at <= NOW at the database layer.
	 * 4. Logs structured, privacy-safe diagnostic metrics without customer PII or raw keys.
	 *
	 * @param int $batch_limit Maximum number of records to process.
	 * @return array{
	 *     selected_count: int,
	 *     deleted_count: int,
	 *     skipped_count: int,
	 *     batch_limit: int
	 * }
	 */
	public function cleanup_expired_failed( int $batch_limit = self::DEFAULT_BATCH_LIMIT ): array {
		$bounded_limit = max( 1, min( self::MAX_BATCH_LIMIT, $batch_limit ) );

		Logger::info(
			'IdempotencyMaintenanceService: Starting bounded expired-failed maintenance cleanup.',
			[
				'operation'   => 'maintenance_started',
				'batch_limit' => $bounded_limit,
			]
		);

		// Step 1: Select candidate keys via indexed query.
		$candidate_keys = $this->idempotency_service->get_expired_failed_keys( $bounded_limit );
		$selected_count = count( $candidate_keys );

		Logger::debug(
			'IdempotencyMaintenanceService: Candidate expired-failed keys selected.',
			[
				'operation'      => 'maintenance_batch_selected',
				'selected_count' => $selected_count,
				'batch_limit'    => $bounded_limit,
			]
		);

		$deleted_count = 0;
		$skipped_count = 0;

		// Step 2: Individually and atomically delete each key via the domain service primitive.
		foreach ( $candidate_keys as $key ) {
			// delete_expired_failed enforces status = 'failed' AND expires_at <= UTC NOW.
			$res = $this->idempotency_service->delete_expired_failed( $key );

			if ( is_wp_error( $res ) ) {
				$skipped_count++;
				Logger::warning(
					'IdempotencyMaintenanceService: Record skipped during expired-failed deletion.',
					[
						'operation'               => 'maintenance_record_skipped',
						'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $key ),
						'error_code'              => $res->get_error_code(),
					]
				);
			} else {
				$deleted_count++;
				Logger::debug(
					'IdempotencyMaintenanceService: Record successfully deleted during expired-failed maintenance.',
					[
						'operation'               => 'maintenance_record_deleted',
						'idempotency_correlation' => OrderIdempotencyService::safe_key_for_log( $key ),
					]
				);
			}
		}

		Logger::info(
			'IdempotencyMaintenanceService: Bounded expired-failed maintenance cleanup completed.',
			[
				'operation'      => 'maintenance_batch_completed',
				'selected_count' => $selected_count,
				'deleted_count'  => $deleted_count,
				'skipped_count'  => $skipped_count,
				'batch_limit'    => $bounded_limit,
			]
		);

		return [
			'selected_count' => $selected_count,
			'deleted_count'  => $deleted_count,
			'skipped_count'  => $skipped_count,
			'batch_limit'    => $bounded_limit,
		];
	}
}
