<?php
/**
 * Order Idempotency Domain Service & State Manager.
 *
 * Manages the persistence, atomic claiming, lifecycle state transitions,
 * and response caching of request idempotency keys for public order submission.
 *
 * Architectural Boundaries:
 * - Owns: Idempotency table queries and mutations, atomic concurrency claim locking,
 *   idempotency key and request hash format validation, cached response storage and retrieval,
 *   reconciliation lookups against wp_maktomine_orders.idempotency_key.
 * - Excludes: Order creation, Order domain transactions, catalog validation, price calculations,
 *   WhatsApp dispatch orchestration, BrowserCart manipulation, frontend/UI state handling.
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

use Maktomine\RestaurantCore\Core\Logger;
use WP_Error;
use wpdb;

defined( 'ABSPATH' ) || exit;

/**
 * Class OrderIdempotencyService
 */
final class OrderIdempotencyService {

	/**
	 * Idempotency status constants.
	 */
	public const STATUS_PROCESSING = 'processing';
	public const STATUS_COMPLETED  = 'completed';
	public const STATUS_FAILED     = 'failed';
	public const STATUS_MISMATCH   = 'mismatch';

	/**
	 * All recognized persistent database status values.
	 *
	 * @var array<string>
	 */
	public const ALL_STATUSES = [
		self::STATUS_PROCESSING,
		self::STATUS_COMPLETED,
		self::STATUS_FAILED,
	];

	/**
	 * Error codes.
	 */
	public const ERROR_INVALID_KEY               = 'invalid_idempotency_key';
	public const ERROR_INVALID_REQUEST_HASH      = 'invalid_request_hash';
	public const ERROR_STORAGE_FAILED            = 'idempotency_storage_failed';
	public const ERROR_RECORD_NOT_FOUND          = 'idempotency_record_not_found';
	public const ERROR_INVALID_PARAMS            = 'invalid_idempotency_params';
	public const ERROR_INVALID_STATUS_TRANSITION = 'invalid_status_transition';

	/**
	 * Default time-to-live in seconds (24 hours).
	 */
	public const DEFAULT_TTL_SECONDS = 86400;

	/**
	 * WordPress database abstraction.
	 *
	 * @var wpdb
	 */
	private wpdb $wpdb;

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Constructor.
	 *
	 * Supports dependency injection for testing.
	 *
	 * @param wpdb|null $wpdb Optional custom database instance.
	 */
	public function __construct( ?wpdb $wpdb = null ) {
		/** @var wpdb $db */
		$db = $wpdb ?? $GLOBALS['wpdb'];
		$this->wpdb = $db;
	}

	/**
	 * Retrieve singleton instance.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Reset singleton instance (useful for unit testing).
	 *
	 * @return void
	 */
	public static function reset_instance(): void {
		self::$instance = null;
	}

	/**
	 * Validate format of client-provided idempotency key.
	 *
	 * Format: 16 to 64 alphanumeric characters, underscores, or hyphens.
	 * Matches RFC 9440 recommendations and UUID/random-token patterns.
	 *
	 * @param string $key Raw idempotency key.
	 * @return bool
	 */
	public static function is_valid_key( string $key ): bool {
		return (bool) preg_match( '/^[A-Za-z0-9_-]{16,64}$/', $key );
	}

	/**
	 * Validate format of caller-provided request hash.
	 *
	 * Must be a 64-character lowercase hexadecimal SHA-256 digest.
	 *
	 * @param string $hash Request digest hash.
	 * @return bool
	 */
	public static function is_valid_request_hash( string $hash ): bool {
		return (bool) preg_match( '/^[a-f0-9]{64}$/', $hash );
	}

	/**
	 * Mask idempotency key for privacy-safe error logging.
	 *
	 * @param string $key Full idempotency key.
	 * @return string Truncated/masked representation.
	 */
	public static function safe_key_for_log( string $key ): string {
		$len = strlen( $key );
		if ( $len <= 12 ) {
			return '***';
		}
		return substr( $key, 0, 6 ) . '...' . substr( $key, -4 );
	}

	/**
	 * Attempt to atomically claim an idempotency key as 'processing'.
	 *
	 * Safely distinguishes:
	 * 1. Newly claimed key (returns status 'claimed')
	 * 2. Existing completed record (returns status 'completed' with cached response details, or 'mismatch' if hash differs)
	 * 3. Existing in-flight processing record (returns status 'processing', or 'mismatch' if hash differs)
	 * 4. Existing failed record (returns status 'failed', or 'mismatch' if hash differs)
	 * 5. Concurrent duplicate-key insertion race (detected via MySQL 1062 / Duplicate entry, then re-read)
	 * 6. Genuine database storage failure (returns WP_Error)
	 *
	 * @param string $key          Validated idempotency key.
	 * @param string $request_hash Validated 64-char lowercase hex SHA-256 request digest.
	 * @param int    $ttl_seconds  Time-to-live in seconds (defaults to 86400 / 24 hours).
	 * @return array{
	 *     status: string,
	 *     record: array<string, mixed>,
	 *     is_expired: bool,
	 *     has_hash_mismatch: bool
	 * }|WP_Error Result envelope or WP_Error on validation or database failure.
	 */
	public function claim( string $key, string $request_hash, int $ttl_seconds = self::DEFAULT_TTL_SECONDS ): array|WP_Error {
		if ( ! self::is_valid_key( $key ) ) {
			return new WP_Error(
				self::ERROR_INVALID_KEY,
				__( 'The provided idempotency key is malformed or invalid.', 'maktomine-restaurant-core' )
			);
		}

		if ( ! self::is_valid_request_hash( $request_hash ) ) {
			return new WP_Error(
				self::ERROR_INVALID_REQUEST_HASH,
				__( 'The provided request hash must be a valid 64-character lowercase SHA-256 hexadecimal string.', 'maktomine-restaurant-core' )
			);
		}

		$table = $this->wpdb->prefix . 'maktomine_idempotency_keys';

		// Step 1: Check if key already exists.
		$existing = $this->get( $key );
		if ( null !== $existing ) {
			$is_expired        = $this->is_record_expired( $existing );
			$has_hash_mismatch = ( $existing['request_hash'] !== $request_hash );
			$status            = $has_hash_mismatch ? self::STATUS_MISMATCH : $existing['status'];

			return [
				'status'            => $status,
				'record'            => $existing,
				'is_expired'        => $is_expired,
				'has_hash_mismatch' => $has_hash_mismatch,
			];
		}

		// Step 2: Key does not exist. Attempt atomic insert with status = 'processing'.
		$now_ts     = time();
		$now_mysql  = gmdate( 'Y-m-d H:i:s', $now_ts );
		$expires_at = gmdate( 'Y-m-d H:i:s', $now_ts + max( 60, $ttl_seconds ) );

		$inserted = $this->wpdb->insert(
			$table,
			[
				'idempotency_key' => $key,
				'request_hash'    => $request_hash,
				'status'          => self::STATUS_PROCESSING,
				'response_code'   => 201,
				'created_at'      => $now_mysql,
				'expires_at'      => $expires_at,
			],
			[
				'%s', '%s', '%s', '%d', '%s', '%s',
			]
		);

		if ( false !== $inserted ) {
			$record_id = (int) $this->wpdb->insert_id;
			return [
				'status'            => 'claimed',
				'record'            => [
					'id'              => $record_id,
					'idempotency_key' => $key,
					'request_hash'    => $request_hash,
					'order_id'        => null,
					'order_reference' => null,
					'status'          => self::STATUS_PROCESSING,
					'response_code'   => 201,
					'response_body'   => null,
					'created_at'      => $now_mysql,
					'expires_at'      => $expires_at,
				],
				'is_expired'        => false,
				'has_hash_mismatch' => false,
			];
		}

		// Step 3: Insert failed. Determine if it was a duplicate key collision (race condition).
		$last_error = (string) $this->wpdb->last_error;
		$last_errno = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;

		$is_duplicate = ( 1062 === $last_errno ) || ( false !== strpos( $last_error, 'Duplicate entry' ) );

		if ( $is_duplicate ) {
			// Concurrent request claimed the key first. Re-read the existing record.
			Logger::warning(
				'OrderIdempotencyService: Duplicate-key contention detected during atomic claim; evaluating existing record.',
				[
					'idempotency_correlation' => self::safe_key_for_log( $key ),
					'db_error_category'       => 'duplicate_key_contention',
					'last_errno'              => $last_errno,
				]
			);

			$concurrent_record = $this->get( $key );
			if ( null !== $concurrent_record ) {
				$is_expired        = $this->is_record_expired( $concurrent_record );
				$has_hash_mismatch = ( $concurrent_record['request_hash'] !== $request_hash );
				$status            = $has_hash_mismatch ? self::STATUS_MISMATCH : $concurrent_record['status'];

				return [
					'status'            => $status,
					'record'            => $concurrent_record,
					'is_expired'        => $is_expired,
					'has_hash_mismatch' => $has_hash_mismatch,
				];
			}
		}

		// Step 4: Genuine database failure.
		Logger::error(
			'OrderIdempotencyService: Database insert failure on idempotency claim.',
			[
				'idempotency_correlation' => self::safe_key_for_log( $key ),
				'operation'               => 'idempotency_claim_insert',
				'db_error_category'       => self::classify_db_error( $last_errno ),
				'last_errno'              => $last_errno,
			]
		);

		return new WP_Error(
			self::ERROR_STORAGE_FAILED,
			__( 'Database failure while recording idempotency claim.', 'maktomine-restaurant-core' )
		);
	}

	/**
	 * Retrieve full idempotency record by key.
	 *
	 * @param string $key Idempotency key.
	 * @return array<string, mixed>|null Record array or null if not found.
	 */
	public function get( string $key ): ?array {
		if ( ! self::is_valid_key( $key ) ) {
			return null;
		}

		$table = $this->wpdb->prefix . 'maktomine_idempotency_keys';
		$row   = $this->wpdb->get_row(
			$this->wpdb->prepare(
				"SELECT id, idempotency_key, request_hash, order_id, order_reference, status, response_code, response_body, created_at, expires_at FROM {$table} WHERE idempotency_key = %s LIMIT 1",
				$key
			),
			ARRAY_A
		);

		if ( null === $row || ! is_array( $row ) ) {
			return null;
		}

		return [
			'id'              => (int) $row['id'],
			'idempotency_key' => (string) $row['idempotency_key'],
			'request_hash'    => (string) $row['request_hash'],
			'order_id'        => null !== $row['order_id'] ? (int) $row['order_id'] : null,
			'order_reference' => null !== $row['order_reference'] ? (string) $row['order_reference'] : null,
			'status'          => (string) $row['status'],
			'response_code'   => (int) ( $row['response_code'] ?? 201 ),
			'response_body'   => $row['response_body'],
			'created_at'      => (string) $row['created_at'],
			'expires_at'      => (string) $row['expires_at'],
		];
	}

	/**
	 * Mark an idempotency claim as 'completed' and store the cached public response.
	 *
	 * Atomically enforces that the transition is ONLY permitted from:
	 * processing -> completed
	 *
	 * An already completed record or a record in another state cannot be overwritten.
	 *
	 * @param string $key             Idempotency key.
	 * @param int    $order_id        Persisted order database ID.
	 * @param string $order_reference Persisted public order reference.
	 * @param int    $response_code   HTTP status code (typically 201).
	 * @param string $response_body   Serialized sanitized JSON response payload.
	 * @return bool|WP_Error True on success, WP_Error on validation, transition rejection, or database failure.
	 */
	public function complete(
		string $key,
		int $order_id,
		string $order_reference,
		int $response_code,
		string $response_body
	): bool|WP_Error {
		if ( ! self::is_valid_key( $key ) ) {
			return new WP_Error(
				self::ERROR_INVALID_KEY,
				__( 'Invalid idempotency key for completion.', 'maktomine-restaurant-core' )
			);
		}

		if ( $order_id <= 0 || '' === trim( $order_reference ) ) {
			return new WP_Error(
				self::ERROR_INVALID_PARAMS,
				__( 'Valid order identifier and reference are required to complete idempotency record.', 'maktomine-restaurant-core' )
			);
		}

		$table = $this->wpdb->prefix . 'maktomine_idempotency_keys';

		// Atomic conditional update: strictly requires status = 'processing'.
		$updated = $this->wpdb->update(
			$table,
			[
				'status'          => self::STATUS_COMPLETED,
				'order_id'        => $order_id,
				'order_reference' => sanitize_text_field( trim( $order_reference ) ),
				'response_code'   => $response_code,
				'response_body'   => $response_body,
			],
			[
				'idempotency_key' => $key,
				'status'          => self::STATUS_PROCESSING,
			],
			[
				'%s', '%d', '%s', '%d', '%s',
			],
			[
				'%s', '%s',
			]
		);

		if ( false === $updated ) {
			$last_errno = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;
			Logger::error(
				'OrderIdempotencyService: Database failure during complete() update.',
				[
					'idempotency_correlation' => self::safe_key_for_log( $key ),
					'order_id'                => $order_id,
					'operation'               => 'idempotency_complete_update',
					'db_error_category'       => self::classify_db_error( $last_errno ),
					'last_errno'              => $last_errno,
				]
			);

			return new WP_Error(
				self::ERROR_STORAGE_FAILED,
				__( 'Database error while marking idempotency record as completed.', 'maktomine-restaurant-core' )
			);
		}

		if ( 0 === $updated ) {
			// Zero rows updated. Classify exact state for safe diagnostic return.
			$existing = $this->get( $key );
			if ( null === $existing ) {
				return new WP_Error(
					self::ERROR_RECORD_NOT_FOUND,
					__( 'Idempotency record not found for completion.', 'maktomine-restaurant-core' )
				);
			}

			if ( self::STATUS_COMPLETED === $existing['status'] ) {
				Logger::warning(
					'OrderIdempotencyService: complete() attempted on already completed record; transition prevented.',
					[
						'idempotency_correlation' => self::safe_key_for_log( $key ),
						'order_id'                => $order_id,
					]
				);

				return new WP_Error(
					self::ERROR_INVALID_STATUS_TRANSITION,
					__( 'Idempotency record is already completed and cannot be overwritten.', 'maktomine-restaurant-core' )
				);
			}

			Logger::warning(
				'OrderIdempotencyService: complete() rejected due to unexpected record status.',
				[
					'idempotency_correlation' => self::safe_key_for_log( $key ),
					'current_status'          => $existing['status'],
				]
			);

			return new WP_Error(
				self::ERROR_INVALID_STATUS_TRANSITION,
				sprintf(
					/* translators: %s: current status */
					__( 'Cannot complete idempotency record in "%s" state; only processing records may be completed.', 'maktomine-restaurant-core' ),
					$existing['status']
				)
			);
		}

		return true;
	}

	/**
	 * Mark an idempotency record as 'failed'.
	 *
	 * Atomically enforces that only in-flight 'processing' records can transition to 'failed'.
	 * An already 'completed' record is never mutated.
	 *
	 * @param string $key Idempotency key.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public function fail( string $key ): bool|WP_Error {
		if ( ! self::is_valid_key( $key ) ) {
			return new WP_Error(
				self::ERROR_INVALID_KEY,
				__( 'Invalid idempotency key.', 'maktomine-restaurant-core' )
			);
		}

		$table = $this->wpdb->prefix . 'maktomine_idempotency_keys';

		// Atomic conditional update: strictly requires status = 'processing'.
		$updated = $this->wpdb->update(
			$table,
			[
				'status' => self::STATUS_FAILED,
			],
			[
				'idempotency_key' => $key,
				'status'          => self::STATUS_PROCESSING,
			],
			[
				'%s',
			],
			[
				'%s', '%s',
			]
		);

		if ( false === $updated ) {
			$last_errno = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;
			Logger::error(
				'OrderIdempotencyService: Database failure during fail() update.',
				[
					'idempotency_correlation' => self::safe_key_for_log( $key ),
					'operation'               => 'idempotency_fail_update',
					'db_error_category'       => self::classify_db_error( $last_errno ),
					'last_errno'              => $last_errno,
				]
			);

			return new WP_Error(
				self::ERROR_STORAGE_FAILED,
				__( 'Database error while marking idempotency record as failed.', 'maktomine-restaurant-core' )
			);
		}

		if ( 0 === $updated ) {
			$existing = $this->get( $key );
			if ( null === $existing ) {
				return new WP_Error(
					self::ERROR_RECORD_NOT_FOUND,
					__( 'Idempotency record not found.', 'maktomine-restaurant-core' )
				);
			}

			if ( self::STATUS_COMPLETED === $existing['status'] ) {
				return new WP_Error(
					self::ERROR_INVALID_STATUS_TRANSITION,
					__( 'Cannot mark an already completed idempotency record as failed.', 'maktomine-restaurant-core' )
				);
			}

			if ( self::STATUS_FAILED === $existing['status'] ) {
				return true; // Idempotent no-op if already in failed state.
			}

			return new WP_Error(
				self::ERROR_INVALID_STATUS_TRANSITION,
				sprintf(
					/* translators: %s: current status */
					__( 'Cannot transition idempotency record from "%s" to failed.', 'maktomine-restaurant-core' ),
					$existing['status']
				)
			);
		}

		return true;
	}

	/**
	 * Delete an idempotency record.
	 *
	 * Fail-closed lifecycle deletion primitive:
	 * - Only records in 'failed' status may ever be deleted.
	 * - Deletion of 'processing' records is strictly prohibited under all circumstances.
	 * - Deletion of 'completed' records is strictly prohibited under all circumstances.
	 * - An optional $must_be_expired boolean enforces that deletion only succeeds if expires_at <= current server time (UTC).
	 *
	 * @param string $key              Idempotency key.
	 * @param string $expected_status  Expected status constraint (MUST be self::STATUS_FAILED).
	 * @param bool   $must_be_expired  If true, requires expires_at <= current server time. Default false.
	 * @return bool|WP_Error True on success, WP_Error on failure or disallowed status.
	 */
	public function delete(
		string $key,
		string $expected_status = self::STATUS_FAILED,
		bool $must_be_expired = false
	): bool|WP_Error {
		if ( ! self::is_valid_key( $key ) ) {
			return new WP_Error(
				self::ERROR_INVALID_KEY,
				__( 'Invalid idempotency key.', 'maktomine-restaurant-core' )
			);
		}

		// Fail-closed invariant: Under no circumstances may processing or completed records be deleted.
		if ( self::STATUS_FAILED !== $expected_status ) {
			return new WP_Error(
				self::ERROR_INVALID_STATUS_TRANSITION,
				__( 'Only failed idempotency records may be deleted.', 'maktomine-restaurant-core' )
			);
		}

		$table = $this->wpdb->prefix . 'maktomine_idempotency_keys';

		if ( $must_be_expired ) {
			$now_mysql = gmdate( 'Y-m-d H:i:s', time() );
			$deleted   = $this->wpdb->query(
				$this->wpdb->prepare(
					"DELETE FROM {$table} WHERE idempotency_key = %s AND status = %s AND expires_at <= %s",
					$key,
					self::STATUS_FAILED,
					$now_mysql
				)
			);
		} else {
			$deleted = $this->wpdb->query(
				$this->wpdb->prepare(
					"DELETE FROM {$table} WHERE idempotency_key = %s AND status = %s",
					$key,
					self::STATUS_FAILED
				)
			);
		}

		if ( false === $deleted ) {
			$last_errno = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;
			Logger::error(
				'OrderIdempotencyService: Database failure during delete().',
				[
					'idempotency_correlation' => self::safe_key_for_log( $key ),
					'operation'               => 'idempotency_delete',
					'db_error_category'       => self::classify_db_error( $last_errno ),
					'last_errno'              => $last_errno,
				]
			);

			return new WP_Error(
				self::ERROR_STORAGE_FAILED,
				__( 'Database error while deleting idempotency record.', 'maktomine-restaurant-core' )
			);
		}

		if ( 0 === $deleted ) {
			// Zero rows deleted. Inspect if the record exists to provide precise error reporting.
			$existing = $this->get( $key );
			if ( null !== $existing ) {
				if ( self::STATUS_COMPLETED === $existing['status'] ) {
					return new WP_Error(
						self::ERROR_INVALID_STATUS_TRANSITION,
						__( 'Completed idempotency records cannot be deleted.', 'maktomine-restaurant-core' )
					);
				}

				if ( self::STATUS_PROCESSING === $existing['status'] ) {
					return new WP_Error(
						self::ERROR_INVALID_STATUS_TRANSITION,
						__( 'Active or in-flight processing idempotency records cannot be deleted.', 'maktomine-restaurant-core' )
					);
				}

				if ( $must_be_expired && ! $this->is_record_expired( $existing ) ) {
					return new WP_Error(
						self::ERROR_INVALID_STATUS_TRANSITION,
						__( 'Failed idempotency record has not yet reached its expiration retention boundary.', 'maktomine-restaurant-core' )
					);
				}
			}

			// If the record does not exist, deletion is an idempotent success.
			return true;
		}

		return true;
	}

	/**
	 * Atomically delete an idempotency record ONLY if it is in 'failed' status.
	 *
	 * Safe helper for failed-state recycling. Guaranteed never to delete
	 * an active 'processing' or 'completed' record.
	 *
	 * @param string $key             Idempotency key.
	 * @param bool   $must_be_expired If true, requires expires_at <= current server time. Default false.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public function delete_failed( string $key, bool $must_be_expired = false ): bool|WP_Error {
		return $this->delete( $key, self::STATUS_FAILED, $must_be_expired );
	}

	/**
	 * Delete an expired failed idempotency record that has passed its retention window.
	 *
	 * Dedicated maintenance primitive that enforces:
	 * status = 'failed' AND expires_at <= current server time.
	 *
	 * @param string $key Idempotency key.
	 * @return bool|WP_Error True on success, WP_Error on failure or if not yet expired.
	 */
	public function delete_expired_failed( string $key ): bool|WP_Error {
		return $this->delete( $key, self::STATUS_FAILED, true );
	}

	/**
	 * Query a bounded batch of idempotency keys that are in 'failed' status and have expired.
	 *
	 * Uses the indexed `KEY status_expires (status, expires_at)` to guarantee
	 * efficient indexed access and avoid table scans.
	 *
	 * @param int $limit Maximum number of keys to select (bounded between 1 and 200). Default 50.
	 * @return array<string> List of expired failed idempotency keys.
	 */
	public function get_expired_failed_keys( int $limit = 50 ): array {
		$bounded_limit = max( 1, min( 200, $limit ) );
		$now_mysql     = gmdate( 'Y-m-d H:i:s', time() );
		$table         = $this->wpdb->prefix . 'maktomine_idempotency_keys';

		$results = $this->wpdb->get_col(
			$this->wpdb->prepare(
				"SELECT idempotency_key FROM {$table} WHERE status = %s AND expires_at <= %s ORDER BY expires_at ASC LIMIT %d",
				self::STATUS_FAILED,
				$now_mysql,
				$bounded_limit
			)
		);

		if ( ! is_array( $results ) ) {
			$last_errno = isset( $this->wpdb->dbh->errno ) ? (int) $this->wpdb->dbh->errno : 0;
			if ( $last_errno > 0 ) {
				Logger::error(
					'OrderIdempotencyService: Database failure during get_expired_failed_keys query.',
					[
						'operation'         => 'get_expired_failed_keys',
						'db_error_category' => self::classify_db_error( $last_errno ),
						'last_errno'        => $last_errno,
					]
				);
			}
			return [];
		}

		return array_filter( array_map( 'strval', $results ) );
	}

	/**
	 * Find an existing order in wp_maktomine_orders by its idempotency_key.
	 *
	 * Provides the read primitive required for later reconciliation of crashed 'processing' rows.
	 *
	 * @param string $key Idempotency key.
	 * @return object|null Database order row object or null if not found.
	 */
	public function find_order_by_idempotency_key( string $key ): ?object {
		if ( ! self::is_valid_key( $key ) ) {
			return null;
		}

		$orders_table = $this->wpdb->prefix . 'maktomine_orders';
		$row          = $this->wpdb->get_row(
			$this->wpdb->prepare(
				"SELECT * FROM {$orders_table} WHERE idempotency_key = %s LIMIT 1",
				$key
			)
		);

		return is_object( $row ) ? $row : null;
	}

	/**
	 * Reconcile an existing order into an idempotency record.
	 *
	 * Used when a recovery check discovers an order was persisted in wp_maktomine_orders
	 * while the idempotency record remained in 'processing'.
	 *
	 * Inherits the complete() transition guard: only 'processing' rows can be completed.
	 *
	 * @param string      $key             Idempotency key.
	 * @param int         $order_id        Persisted order ID.
	 * @param string      $order_reference Persisted order reference.
	 * @param int         $response_code   Response status code (default 201).
	 * @param string|null $response_body   Serialized response body.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public function reconcile_order(
		string $key,
		int $order_id,
		string $order_reference,
		int $response_code = 201,
		?string $response_body = null
	): bool|WP_Error {
		return $this->complete(
			$key,
			$order_id,
			$order_reference,
			$response_code,
			$response_body ?? ''
		);
	}

	/**
	 * Check if an idempotency record has exceeded its expiration time.
	 *
	 * Uses trusted server UTC time to determine if expires_at <= current time.
	 *
	 * @param array<string, mixed> $record Stored idempotency record.
	 * @return bool
	 */
	public static function is_record_expired( array $record ): bool {
		if ( empty( $record['expires_at'] ) ) {
			return false;
		}

		$expires_ts = strtotime( (string) $record['expires_at'] );
		return false !== $expires_ts && time() >= $expires_ts;
	}

	/**
	 * Classify a database error number into a privacy-safe, bounded category string.
	 *
	 * Prevents raw SQL error strings from leaking into logs while preserving
	 * actionable diagnostic categorization.
	 *
	 * @param int $errno MySQL error number from $wpdb->dbh->errno.
	 * @return string Safe categorization.
	 */
	public static function classify_db_error( int $errno ): string {
		return match ( $errno ) {
			1062 => 'duplicate_key_contention',
			1146 => 'table_missing',
			1045, 2002, 2003, 2006, 2013 => 'database_connection_failed',
			1205, 1213 => 'database_lock_conflict',
			1048 => 'database_null_constraint_violation',
			default => ( $errno > 0 ) ? 'database_write_failed' : 'unknown_database_error',
		};
	}
}
