<?php
/**
 * Order Submission Application Orchestration Service.
 *
 * Coordinates the multi-step boundary of creating a persisted restaurant order
 * and subsequently delegating to WhatsApp notification dispatch.
 *
 * Responsibilities & Invariants:
 * - Orchestrates OrderCreationService (order persistence) and WhatsAppDispatchService (notification).
 * - Preserves independent failure semantics: WhatsApp dispatch failure NEVER rolls back, deletes,
 *   or invalidates an already-persisted Order.
 * - Does NOT create orders directly, validate carts, or calculate prices (delegated to OrderCreationService).
 * - Does NOT build WhatsApp payloads or interact with network/transports directly (delegated to WhatsAppDispatchService).
 * - Does NOT mutate order status (order remains in its persisted state, e.g. pending_whatsapp).
 * - Does NOT clear cart state or interact with browser/client storage.
 * - Does NOT perform direct DB/SQL queries or transactions.
 * - Does NOT log or return customer PII, full payloads, or verification hashes.
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

use Maktomine\RestaurantCore\Cart\CartStateService;
use Maktomine\RestaurantCore\Core\Logger;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Class OrderSubmissionService
 */
final class OrderSubmissionService {

	/**
	 * Dispatch status constants.
	 */
	public const DISPATCH_STATUS_DISPATCHED     = 'dispatched';
	public const DISPATCH_STATUS_NOT_CONFIGURED = 'not_configured';
	public const DISPATCH_STATUS_FAILED         = 'failed';

	/**
	 * Order creation application service.
	 *
	 * @var OrderCreationService
	 */
	private OrderCreationService $order_creation_service;

	/**
	 * WhatsApp dispatch orchestration service.
	 *
	 * @var WhatsAppDispatchService
	 */
	private WhatsAppDispatchService $whatsapp_dispatch_service;

	/**
	 * Constructor.
	 *
	 * Supports dependency injection for testing and isolation, falling back to
	 * request-scoped services when parameters are omitted.
	 *
	 * If a request-scoped CartStateService is provided, it is injected into the
	 * OrderCreationService if none was explicitly passed.
	 *
	 * @param OrderCreationService|null    $order_creation_service    Optional OrderCreationService instance.
	 * @param WhatsAppDispatchService|null $whatsapp_dispatch_service Optional WhatsAppDispatchService instance.
	 * @param CartStateService|null        $cart_state                Optional request-scoped CartStateService.
	 */
	public function __construct(
		?OrderCreationService $order_creation_service = null,
		?WhatsAppDispatchService $whatsapp_dispatch_service = null,
		?CartStateService $cart_state = null
	) {
		if ( null !== $order_creation_service ) {
			$this->order_creation_service = $order_creation_service;
		} elseif ( null !== $cart_state ) {
			$this->order_creation_service = new OrderCreationService( $cart_state );
		} else {
			$this->order_creation_service = OrderCreationService::instance();
		}

		$this->whatsapp_dispatch_service = $whatsapp_dispatch_service ?? WhatsAppDispatchService::instance();
	}

	/**
	 * Submit an order from customer checkout inputs and trigger downstream WhatsApp dispatch.
	 *
	 * Execution Flow:
	 * 1. Delegates customer data to OrderCreationService::create_order().
	 * 2. If order creation fails (returns WP_Error), returns immediately without attempting dispatch.
	 * 3. Extracts the authoritative persisted order ID from the returned Order entity ($order->get_id()).
	 * 4. Invokes WhatsAppDispatchService::dispatch_order($order_id) exactly once.
	 * 5. Evaluates dispatch outcome and returns structured submission result.
	 *
	 * Failure Semantics:
	 * - If dispatch returns `whatsapp_dispatch_not_configured`: Order remains safely persisted; returns status 'not_configured'.
	 * - If dispatch returns any other `WP_Error`: Order remains safely persisted; returns status 'failed'.
	 * - Under no circumstances is the persisted Order deleted, rolled back, or mutated on dispatch failure.
	 * - Order status is never transitioned by this service.
	 *
	 * @param array<string, mixed> $customer_data   Customer contact and fulfillment inputs.
	 * @param string|null          $idempotency_key Optional client idempotency key for deduplication.
	 * @return array{
	 *     order: Order,
	 *     whatsapp: array{
	 *         attempted: bool,
	 *         dispatched: bool,
	 *         status: string,
	 *         error_code?: string
	 *     }
	 * }|WP_Error Structured submission result or WP_Error on order creation failure.
	 */
	public function submit( array $customer_data, ?string $idempotency_key = null ): array|WP_Error {
		// 1. Authoritative order creation workflow.
		// OrderCreationService handles: empty cart rejection, CartValidatorService validation,
		// and transactional OrderService persistence.
		$order = $this->order_creation_service->create_order( $customer_data, $idempotency_key );
		if ( is_wp_error( $order ) ) {
			return $order;
		}

		if ( ! ( $order instanceof Order ) ) {
			Logger::error( 'OrderSubmissionService: OrderCreationService returned an invalid result.' );

			return new WP_Error(
				OrderService::ERROR_ORDER_CREATION_FAILED,
				__( 'Unexpected error occurred during order creation.', 'maktomine-restaurant-core' )
			);
		}

		$order_id = $order->get_id();
		if ( null === $order_id || $order_id <= 0 ) {
			Logger::error(
				'OrderSubmissionService: Persisted order does not possess a valid integer ID.',
				[ 'order_reference' => $order->get_order_reference() ]
			);

			return new WP_Error(
				OrderService::ERROR_ORDER_CREATION_FAILED,
				__( 'Order was created without a valid identifier.', 'maktomine-restaurant-core' )
			);
		}

		// 2. Downstream WhatsApp dispatch boundary.
		// Dispatched exactly once using the authoritative persisted order ID.
		$dispatch_result = $this->whatsapp_dispatch_service->dispatch_order( $order_id );

		// 3. Process dispatch outcome without mutating or rolling back the persisted order.
		if ( is_wp_error( $dispatch_result ) ) {
			$error_code = $dispatch_result->get_error_code();

			if ( WhatsAppDispatchService::ERROR_DISPATCH_NOT_CONFIGURED === $error_code ) {
				// Expected default behavior in v1: Outbound network transport is deferred.
				return [
					'order'    => $order,
					'whatsapp' => [
						'attempted'  => true,
						'dispatched' => false,
						'status'     => self::DISPATCH_STATUS_NOT_CONFIGURED,
					],
				];
			}

			// Actual dispatch failure (e.g. transport failed, payload build error).
			// Order remains valid and persisted in database.
			Logger::warning(
				'OrderSubmissionService: WhatsApp dispatch failed for persisted order.',
				[
					'order_id'        => $order_id,
					'order_reference' => $order->get_order_reference(),
					'error_code'      => $error_code,
				]
			);

			return [
				'order'    => $order,
				'whatsapp' => [
					'attempted'  => true,
					'dispatched' => false,
					'status'     => self::DISPATCH_STATUS_FAILED,
					'error_code' => $error_code,
				],
			];
		}

		// Dispatch succeeded.
		return [
			'order'    => $order,
			'whatsapp' => [
				'attempted'  => true,
				'dispatched' => true,
				'status'     => self::DISPATCH_STATUS_DISPATCHED,
			],
		];
	}
}
