<?php
/**
 * Order Domain Model Entity.
 *
 * Represents an authoritative, immutable snapshot of an order in the
 * Maktomine Restaurant Core domain.
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

defined( 'ABSPATH' ) || exit;

/**
 * Class Order
 *
 * Encapsulates the domain state and life-cycle of a restaurant order.
 */
final class Order {

	/**
	 * Order status constants (approved v1 state machine).
	 */
	public const STATUS_PENDING_WHATSAPP = 'pending_whatsapp';
	public const STATUS_CONFIRMED        = 'confirmed';
	public const STATUS_PREPARING        = 'preparing';
	public const STATUS_READY            = 'ready';
	public const STATUS_COMPLETED        = 'completed';
	public const STATUS_CANCELLED        = 'cancelled';

	/**
	 * All recognized order statuses.
	 *
	 * @var array<string>
	 */
	public const ALL_STATUSES = [
		self::STATUS_PENDING_WHATSAPP,
		self::STATUS_CONFIRMED,
		self::STATUS_PREPARING,
		self::STATUS_READY,
		self::STATUS_COMPLETED,
		self::STATUS_CANCELLED,
	];

	/**
	 * Allowed status transitions map.
	 *
	 * Defines valid direct transitions between states. Terminal states have empty target arrays.
	 *
	 * @var array<string, array<string>>
	 */
	public const ALLOWED_TRANSITIONS = [
		self::STATUS_PENDING_WHATSAPP => [ self::STATUS_CONFIRMED, self::STATUS_CANCELLED ],
		self::STATUS_CONFIRMED        => [ self::STATUS_PREPARING, self::STATUS_CANCELLED ],
		self::STATUS_PREPARING        => [ self::STATUS_READY, self::STATUS_CANCELLED ],
		self::STATUS_READY            => [ self::STATUS_COMPLETED, self::STATUS_CANCELLED ],
		self::STATUS_COMPLETED        => [],
		self::STATUS_CANCELLED        => [],
	];

	/**
	 * Order type constants.
	 */
	public const TYPE_DELIVERY = 'delivery';
	public const TYPE_PICKUP   = 'pickup';

	/**
	 * All recognized order types.
	 *
	 * @var array<string>
	 */
	public const ALL_TYPES = [
		self::TYPE_DELIVERY,
		self::TYPE_PICKUP,
	];

	/**
	 * Primary key in wp_maktomine_orders.
	 *
	 * @var int|null
	 */
	private ?int $id;

	/**
	 * Public order reference (e.g. MKT-YYYYMMDD-XXXX).
	 *
	 * @var string
	 */
	private string $order_reference;

	/**
	 * Customer full name.
	 *
	 * @var string
	 */
	private string $customer_name;

	/**
	 * Customer phone number.
	 *
	 * @var string
	 */
	private string $customer_phone;

	/**
	 * Customer WhatsApp phone number.
	 *
	 * @var string
	 */
	private string $customer_whatsapp;

	/**
	 * Order fulfillment type (delivery or pickup).
	 *
	 * @var string
	 */
	private string $order_type;

	/**
	 * Delivery street address.
	 *
	 * @var string|null
	 */
	private ?string $delivery_address;

	/**
	 * Delivery area / neighborhood.
	 *
	 * @var string|null
	 */
	private ?string $delivery_area;

	/**
	 * Delivery nearby landmark.
	 *
	 * @var string|null
	 */
	private ?string $delivery_landmark;

	/**
	 * Customer instructions / order note.
	 *
	 * @var string|null
	 */
	private ?string $order_note;

	/**
	 * Authoritative item subtotal.
	 *
	 * @var float
	 */
	private float $subtotal;

	/**
	 * Delivery fee.
	 *
	 * @var float
	 */
	private float $delivery_charge;

	/**
	 * Authoritative grand total amount (subtotal + delivery_charge).
	 *
	 * @var float
	 */
	private float $total_amount;

	/**
	 * Currency ISO code (e.g. USD).
	 *
	 * @var string
	 */
	private string $currency;

	/**
	 * Current order status.
	 *
	 * @var string
	 */
	private string $order_status;

	/**
	 * Cryptographically secure server-side verification hash.
	 *
	 * @var string
	 */
	private string $verification_hash;

	/**
	 * Creation timestamp (MySQL DATETIME).
	 *
	 * @var string|null
	 */
	private ?string $created_at;

	/**
	 * Update timestamp (MySQL DATETIME).
	 *
	 * @var string|null
	 */
	private ?string $updated_at;

	/**
	 * Associated order items snapshot.
	 *
	 * @var array<OrderItem>
	 */
	private array $items;

	/**
	 * Constructor.
	 *
	 * @param int|null         $id                Database record ID.
	 * @param string           $order_reference   Unique public order reference.
	 * @param string           $customer_name     Customer name.
	 * @param string           $customer_phone    Customer phone.
	 * @param string           $customer_whatsapp Customer WhatsApp number.
	 * @param string           $order_type        Fulfillment type (delivery|pickup).
	 * @param string|null      $delivery_address  Delivery address.
	 * @param string|null      $delivery_area     Delivery area.
	 * @param string|null      $delivery_landmark Delivery landmark.
	 * @param string|null      $order_note        Order note.
	 * @param float            $subtotal          Item subtotal.
	 * @param float            $delivery_charge   Delivery charge.
	 * @param float            $total_amount      Grand total.
	 * @param string           $currency          Currency ISO code.
	 * @param string           $order_status      Current status.
	 * @param string           $verification_hash Verification hash.
	 * @param string|null      $created_at        Created datetime.
	 * @param string|null      $updated_at        Updated datetime.
	 * @param array<OrderItem> $items             Order items snapshot.
	 */
	public function __construct(
		?int $id,
		string $order_reference,
		string $customer_name,
		string $customer_phone,
		string $customer_whatsapp,
		string $order_type,
		?string $delivery_address,
		?string $delivery_area,
		?string $delivery_landmark,
		?string $order_note,
		float $subtotal,
		float $delivery_charge,
		float $total_amount,
		string $currency,
		string $order_status,
		string $verification_hash,
		?string $created_at = null,
		?string $updated_at = null,
		array $items = []
	) {
		$this->id                = $id;
		$this->order_reference   = $order_reference;
		$this->customer_name     = $customer_name;
		$this->customer_phone    = $customer_phone;
		$this->customer_whatsapp = $customer_whatsapp;
		$this->order_type        = $order_type;
		$this->delivery_address  = $delivery_address;
		$this->delivery_area     = $delivery_area;
		$this->delivery_landmark = $delivery_landmark;
		$this->order_note        = $order_note;
		$this->subtotal          = round( $subtotal, 2 );
		$this->delivery_charge   = round( $delivery_charge, 2 );
		$this->total_amount      = round( $total_amount, 2 );
		$this->currency          = strtoupper( trim( $currency ) );
		$this->order_status      = $order_status;
		$this->verification_hash = $verification_hash;
		$this->created_at        = $created_at;
		$this->updated_at        = $updated_at;
		$this->items             = array_values( $items );
	}

	// ==========================================
	// Getters
	// ==========================================

	public function get_id(): ?int {
		return $this->id;
	}

	public function get_order_reference(): string {
		return $this->order_reference;
	}

	public function get_customer_name(): string {
		return $this->customer_name;
	}

	public function get_customer_phone(): string {
		return $this->customer_phone;
	}

	public function get_customer_whatsapp(): string {
		return $this->customer_whatsapp;
	}

	public function get_order_type(): string {
		return $this->order_type;
	}

	public function get_delivery_address(): ?string {
		return $this->delivery_address;
	}

	public function get_delivery_area(): ?string {
		return $this->delivery_area;
	}

	public function get_delivery_landmark(): ?string {
		return $this->delivery_landmark;
	}

	public function get_order_note(): ?string {
		return $this->order_note;
	}

	public function get_subtotal(): float {
		return $this->subtotal;
	}

	public function get_delivery_charge(): float {
		return $this->delivery_charge;
	}

	public function get_total_amount(): float {
		return $this->total_amount;
	}

	public function get_currency(): string {
		return $this->currency;
	}

	public function get_order_status(): string {
		return $this->order_status;
	}

	public function get_verification_hash(): string {
		return $this->verification_hash;
	}

	public function get_created_at(): ?string {
		return $this->created_at;
	}

	public function get_updated_at(): ?string {
		return $this->updated_at;
	}

	/**
	 * Retrieve the items associated with this order snapshot.
	 *
	 * @return array<OrderItem>
	 */
	public function get_items(): array {
		return $this->items;
	}

	// ==========================================
	// State Machine Helpers
	// ==========================================

	/**
	 * Check if the order is in a terminal state (completed or cancelled).
	 *
	 * @return bool
	 */
	public function is_terminal(): bool {
		return in_array( $this->order_status, [ self::STATUS_COMPLETED, self::STATUS_CANCELLED ], true );
	}

	/**
	 * Check if a proposed status transition is permitted from the current status.
	 *
	 * @param string $new_status Target status to transition to.
	 * @return bool
	 */
	public function can_transition_to( string $new_status ): bool {
		$allowed = self::ALLOWED_TRANSITIONS[ $this->order_status ] ?? [];
		return in_array( $new_status, $allowed, true );
	}

	// ==========================================
	// Factory & Serialization
	// ==========================================

	/**
	 * Hydrate an Order instance from a database row object or array.
	 *
	 * @param object|array<string, mixed> $record Database row from wp_maktomine_orders.
	 * @param array<OrderItem>            $items  Associated OrderItem instances.
	 * @return self
	 */
	public static function from_record( object|array $record, array $items = [] ): self {
		$data = (array) $record;

		return new self(
			isset( $data['id'] ) ? (int) $data['id'] : null,
			(string) ( $data['order_reference'] ?? '' ),
			(string) ( $data['customer_name'] ?? '' ),
			(string) ( $data['customer_phone'] ?? '' ),
			(string) ( $data['customer_whatsapp'] ?? '' ),
			(string) ( $data['order_type'] ?? self::TYPE_DELIVERY ),
			isset( $data['delivery_address'] ) && '' !== $data['delivery_address'] ? (string) $data['delivery_address'] : null,
			isset( $data['delivery_area'] ) && '' !== $data['delivery_area'] ? (string) $data['delivery_area'] : null,
			isset( $data['delivery_landmark'] ) && '' !== $data['delivery_landmark'] ? (string) $data['delivery_landmark'] : null,
			isset( $data['order_note'] ) && '' !== $data['order_note'] ? (string) $data['order_note'] : null,
			isset( $data['subtotal'] ) ? (float) $data['subtotal'] : 0.0,
			isset( $data['delivery_charge'] ) ? (float) $data['delivery_charge'] : 0.0,
			isset( $data['total_amount'] ) ? (float) $data['total_amount'] : 0.0,
			(string) ( $data['currency'] ?? 'USD' ),
			(string) ( $data['order_status'] ?? self::STATUS_PENDING_WHATSAPP ),
			(string) ( $data['verification_hash'] ?? '' ),
			isset( $data['created_at'] ) ? (string) $data['created_at'] : null,
			isset( $data['updated_at'] ) ? (string) $data['updated_at'] : null,
			$items
		);
	}

	/**
	 * Export the order snapshot to an associative array.
	 *
	 * @return array<string, mixed>
	 */
	public function to_array(): array {
		$items_array = array_map(
			static fn( OrderItem $item ): array => $item->to_array(),
			$this->items
		);

		return [
			'id'                => $this->id,
			'order_reference'   => $this->order_reference,
			'customer_name'     => $this->customer_name,
			'customer_phone'    => $this->customer_phone,
			'customer_whatsapp' => $this->customer_whatsapp,
			'order_type'        => $this->order_type,
			'delivery_address'  => $this->delivery_address,
			'delivery_area'     => $this->delivery_area,
			'delivery_landmark' => $this->delivery_landmark,
			'order_note'        => $this->order_note,
			'subtotal'          => $this->subtotal,
			'delivery_charge'   => $this->delivery_charge,
			'total_amount'      => $this->total_amount,
			'currency'          => $this->currency,
			'order_status'      => $this->order_status,
			'verification_hash' => $this->verification_hash,
			'created_at'        => $this->created_at,
			'updated_at'        => $this->updated_at,
			'items'             => $items_array,
		];
	}
}
