<?php
/**
 * Order Creation Application Service.
 *
 * Coordinates the server-side workflow connecting the untrusted Cart state,
 * the authoritative catalog-aware CartValidatorService, and the persistence-owning
 * OrderService. Ensures order creation cannot accidentally bypass Phase 4C validation.
 *
 * Workflow:
 * Untrusted Cart (from CartStateService)
 *        ↓
 * CartValidatorService::validate()
 *        ↓
 * Validated Cart Snapshot
 *        ↓
 * OrderService::create_order()
 *        ↓
 * Persisted Order Snapshot
 *
 * Responsibility Boundary:
 * - Coordinates application-level cart-to-order transition.
 * - Enforces validation of cart state before order creation.
 * - Does NOT duplicate catalog validation, variation matrix resolution, or price calculation.
 * - Does NOT duplicate database persistence, transaction handling, or hashing.
 * - Does NOT automatically clear the cart upon success (deferred to caller/presentation layer).
 * - Does NOT interact with WhatsApp, delivery calculations, or external HTTP/REST globals.
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

use Maktomine\RestaurantCore\Cart\Cart;
use Maktomine\RestaurantCore\Cart\CartStateService;
use Maktomine\RestaurantCore\Cart\CartValidatorService;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Class OrderCreationService
 */
final class OrderCreationService {

	/**
	 * Error codes.
	 */
	public const ERROR_EMPTY_CART = 'empty_cart';

	/**
	 * Request-scoped singleton instance.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Cart state service coordinator.
	 *
	 * @var CartStateService
	 */
	private CartStateService $cart_state;

	/**
	 * Authoritative cart validator domain service.
	 *
	 * @var CartValidatorService
	 */
	private CartValidatorService $cart_validator;

	/**
	 * Order persistence and domain service.
	 *
	 * @var OrderService
	 */
	private OrderService $order_service;

	/**
	 * Constructor.
	 *
	 * Supports dependency injection for testing and isolation, falling back to
	 * request-scoped singletons when parameters are omitted.
	 *
	 * @param CartStateService|null     $cart_state     Optional CartStateService instance.
	 * @param CartValidatorService|null $cart_validator Optional CartValidatorService instance.
	 * @param OrderService|null         $order_service  Optional OrderService instance.
	 */
	public function __construct(
		?CartStateService $cart_state = null,
		?CartValidatorService $cart_validator = null,
		?OrderService $order_service = null
	) {
		$this->cart_state     = $cart_state ?? CartStateService::instance();
		$this->cart_validator = $cart_validator ?? new CartValidatorService();
		$this->order_service  = $order_service ?? OrderService::instance();
	}

	/**
	 * Retrieve request-scoped singleton instance.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Reset the request-scoped singleton instance.
	 *
	 * Useful for unit testing and request cycle isolation.
	 *
	 * @return void
	 */
	public static function reset_instance(): void {
		self::$instance = null;
	}

	/**
	 * Execute the authoritative Cart-to-Order application workflow.
	 *
	 * 1. Obtains the current Cart from CartStateService.
	 * 2. Enforces non-empty cart boundary before invoking external services.
	 * 3. Validates the cart against the authoritative catalog via CartValidatorService.
	 * 4. Passes only the authoritative validated cart snapshot and customer data to OrderService.
	 * 5. Returns the persisted Order entity on success or WP_Error on failure.
	 * 6. Does NOT automatically clear the Cart on success (caller retains full lifecycle control).
	 *
	 * @param array<string, mixed> $customer_data   Raw customer input payload.
	 * @param string|null          $idempotency_key Optional client idempotency key for deduplication.
	 * @return Order|WP_Error Persisted Order entity on success, WP_Error on validation or persistence failure.
	 */
	public function create_order( array $customer_data, ?string $idempotency_key = null ): Order|WP_Error {
		// 1. Obtain current Cart from CartStateService.
		$cart = $this->cart_state->get_cart();

		// 2. Reject empty cart before contacting validator or database.
		if ( $cart->is_empty() ) {
			return new WP_Error(
				self::ERROR_EMPTY_CART,
				__( 'Cannot create an order with an empty cart.', 'maktomine-restaurant-core' )
			);
		}

		// 3. Authoritative catalog validation and price calculation (Phase 4C).
		$validated_cart = $this->cart_validator->validate( $cart );
		if ( is_wp_error( $validated_cart ) ) {
			return $validated_cart;
		}

		// 4. Delegate validated cart snapshot, customer data, and optional idempotency key to OrderService.
		// OrderService atomically validates customer inputs, calculates delivery charges (0.00 in Phase 4D),
		// generates reference and verification hash, and executes transactional DB persistence.
		return $this->order_service->create_order( $validated_cart, $customer_data, $idempotency_key );
	}
}
