<?php
/**
 * WhatsApp Transport Interface.
 *
 * Defines the contract for low-level transport adapters delivering
 * deterministic WhatsApp messages to recipient destinations.
 * Decouples domain and application dispatch coordination from external
 * providers (e.g. Twilio, Meta Cloud API, or deferred local transports).
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Interface WhatsAppTransportInterface
 */
interface WhatsAppTransportInterface {

	/**
	 * Dispatch a plain-text message to a normalized telephone destination.
	 *
	 * Receives only the normalized destination phone number and plain-text message.
	 * Has no access to Order entities, Cart objects, Catalog services, or database queries.
	 *
	 * @param string $phone   Normalized E.164 destination telephone number.
	 * @param string $message Plain-text message body.
	 * @return bool|WP_Error True on successful dispatch, or WP_Error on transport rejection/failure.
	 */
	public function dispatch( string $phone, string $message ): bool|WP_Error;
}
