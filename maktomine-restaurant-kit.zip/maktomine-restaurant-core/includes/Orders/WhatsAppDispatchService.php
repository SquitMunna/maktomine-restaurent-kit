<?php
/**
 * WhatsApp Order Dispatch Application Service.
 *
 * Coordinates the application boundary between an already-persisted Order,
 * the Phase 4G OrderWhatsAppPayloadBuilder, and the replaceable transport boundary.
 *
 * Architecture Flow:
 * Persisted Order (loaded via OrderService)
 *        ↓
 * OrderWhatsAppPayloadBuilder::build()
 *        ↓
 * WhatsAppTransportInterface::dispatch()
 *        ↓
 * Structured Dispatch Result
 *
 * Invariants:
 * - OrderService and OrderCreationService remain completely unaware of WhatsApp.
 * - CatalogService, CartStateService, and Pricing services remain untouched.
 * - For Phase 4H, the default transport is deferred/unconfigured (zero HTTP requests).
 * - The Order status is NOT transitioned on deferred or failed dispatch.
 * - No PII or raw messages are logged.
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

use Maktomine\RestaurantCore\Core\Logger;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Class WhatsAppDispatchService
 */
final class WhatsAppDispatchService {

	/**
	 * Error codes.
	 */
	public const ERROR_ORDER_NOT_FOUND              = 'order_not_found';
	public const ERROR_INVALID_ORDER                = 'invalid_order';
	public const ERROR_WHATSAPP_PAYLOAD_ERROR       = 'whatsapp_payload_error';
	public const ERROR_DISPATCH_NOT_CONFIGURED      = 'whatsapp_dispatch_not_configured';
	public const ERROR_DISPATCH_FAILED              = 'whatsapp_dispatch_failed';

	/**
	 * Request-scoped singleton instance.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Order domain persistence manager.
	 *
	 * @var OrderService
	 */
	private OrderService $order_service;

	/**
	 * Replaceable transport adapter.
	 *
	 * @var WhatsAppTransportInterface|null
	 */
	private ?WhatsAppTransportInterface $transport;

	/**
	 * Constructor.
	 *
	 * Supports dependency injection for testing and isolation, falling back to
	 * request-scoped OrderService and a deferred transport when parameters are omitted.
	 *
	 * @param OrderService|null                $order_service Optional OrderService instance.
	 * @param WhatsAppTransportInterface|null  $transport     Optional WhatsAppTransportInterface adapter.
	 */
	public function __construct(
		?OrderService $order_service = null,
		?WhatsAppTransportInterface $transport = null
	) {
		$this->order_service = $order_service ?? OrderService::instance();
		$this->transport     = $transport;
	}

	/**
	 * Retrieve request-scoped singleton instance.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Reset the request-scoped singleton instance.
	 *
	 * Useful for unit testing and request cycle isolation.
	 *
	 * @return void
	 */
	public static function reset_instance(): void {
		self::$instance = null;
	}

	/**
	 * Set or replace the active transport adapter.
	 *
	 * @param WhatsAppTransportInterface|null $transport Transport adapter or null to revert to deferred.
	 * @return void
	 */
	public function set_transport( ?WhatsAppTransportInterface $transport ): void {
		$this->transport = $transport;
	}

	/**
	 * Retrieve the configured transport adapter.
	 *
	 * @return WhatsAppTransportInterface|null
	 */
	public function get_transport(): ?WhatsAppTransportInterface {
		return $this->transport;
	}

	/**
	 * Dispatch an existing persisted order to WhatsApp via the transport boundary.
	 *
	 * 1. Loads the persisted Order via OrderService.
	 * 2. Builds the authoritative plain-text payload via OrderWhatsAppPayloadBuilder.
	 * 3. Passes the payload to the configured transport (default deferred transport performs no network request).
	 * 4. Returns a structured result array or WP_Error.
	 * 5. Does NOT mutate order status, cart state, or catalog data.
	 *
	 * @param int $order_id Database primary key ID of the persisted order.
	 * @return array{
	 *     success: bool,
	 *     order_id: int,
	 *     order_reference: string,
	 *     phone: string,
	 *     message: string,
	 *     dispatched: bool
	 * }|WP_Error
	 */
	public function dispatch_order( int $order_id ): array|WP_Error {
		if ( $order_id <= 0 ) {
			return new WP_Error(
				self::ERROR_ORDER_NOT_FOUND,
				__( 'Invalid order ID provided for WhatsApp dispatch.', 'maktomine-restaurant-core' )
			);
		}

		// 1. Authoritative order retrieval via OrderService.
		$order = $this->order_service->get_order( $order_id );
		if ( ! ( $order instanceof Order ) ) {
			Logger::warning(
				'WhatsAppDispatchService: Order not found for dispatch.',
				[ 'order_id' => $order_id ]
			);

			return new WP_Error(
				self::ERROR_ORDER_NOT_FOUND,
				__( 'Order not found for WhatsApp dispatch.', 'maktomine-restaurant-core' )
			);
		}

		// 2. Build authoritative payload via OrderWhatsAppPayloadBuilder.
		$payload = OrderWhatsAppPayloadBuilder::build( $order );
		if ( is_wp_error( $payload ) ) {
			Logger::warning(
				'WhatsAppDispatchService: Failed to build WhatsApp order payload.',
				[
					'order_id'   => $order_id,
					'error_code' => $payload->get_error_code(),
				]
			);

			return new WP_Error(
				self::ERROR_WHATSAPP_PAYLOAD_ERROR,
				$payload->get_error_message(),
				[ 'original_error' => $payload->get_error_code() ]
			);
		}

		if ( ! is_array( $payload ) || ! isset( $payload['phone'], $payload['message'] ) || ! is_string( $payload['phone'] ) || ! is_string( $payload['message'] ) ) {
			Logger::error(
				'WhatsAppDispatchService: OrderWhatsAppPayloadBuilder returned an invalid payload structure.',
				[ 'order_id' => $order_id ]
			);

			return new WP_Error(
				self::ERROR_WHATSAPP_PAYLOAD_ERROR,
				__( 'Invalid WhatsApp payload generated from order snapshot.', 'maktomine-restaurant-core' )
			);
		}

		$phone   = $payload['phone'];
		$message = $payload['message'];

		// 3. Delegate to transport boundary.
		// Default Phase 4H behavior: No external provider configured; return deferred status.
		if ( null === $this->transport ) {
			Logger::info(
				'WhatsAppDispatchService: WhatsApp dispatch deferred (no external transport configured).',
				[
					'order_id'        => $order_id,
					'order_reference' => $order->get_order_reference(),
				]
			);

			return new WP_Error(
				self::ERROR_DISPATCH_NOT_CONFIGURED,
				__( 'WhatsApp dispatch is not configured. Outbound network transport is deferred.', 'maktomine-restaurant-core' ),
				[
					'order_id'        => $order_id,
					'order_reference' => $order->get_order_reference(),
					'dispatched'      => false,
				]
			);
		}

		// When an explicit transport is attached, execute dispatch.
		$dispatch_result = $this->transport->dispatch( $phone, $message );
		if ( is_wp_error( $dispatch_result ) ) {
			Logger::error(
				'WhatsAppDispatchService: External WhatsApp transport dispatch failed.',
				[
					'order_id'        => $order_id,
					'order_reference' => $order->get_order_reference(),
					'error_code'      => $dispatch_result->get_error_code(),
				]
			);

			return new WP_Error(
				self::ERROR_DISPATCH_FAILED,
				$dispatch_result->get_error_message(),
				[ 'transport_error' => $dispatch_result->get_error_code() ]
			);
		}

		if ( true !== $dispatch_result ) {
			Logger::error(
				'WhatsAppDispatchService: Transport rejected message without returning WP_Error.',
				[
					'order_id'        => $order_id,
					'order_reference' => $order->get_order_reference(),
				]
			);

			return new WP_Error(
				self::ERROR_DISPATCH_FAILED,
				__( 'WhatsApp transport failed to deliver message.', 'maktomine-restaurant-core' )
			);
		}

		Logger::info(
			'WhatsAppDispatchService: WhatsApp message successfully dispatched.',
			[
				'order_id'        => $order_id,
				'order_reference' => $order->get_order_reference(),
			]
		);

		return [
			'success'         => true,
			'order_id'        => $order_id,
			'order_reference' => $order->get_order_reference(),
			'phone'           => $phone,
			'message'         => $message,
			'dispatched'      => true,
		];
	}
}
