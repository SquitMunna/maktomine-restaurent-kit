<?php
/**
 * WhatsApp Order Payload Builder.
 *
 * Transforms an already-persisted Order domain snapshot entity into a
 * deterministic, plain-text WhatsApp-ready message and destination payload.
 *
 * Responsibilities:
 * - Reads authoritative destination phone from BusinessInfoRepository.
 * - Formats persisted Order & OrderItem fields into a clean plain-text message.
 * - Preserves immutable historical snapshot integrity (no catalog queries).
 * - Stateless, zero DB queries, zero order mutations, zero dispatch/network calls.
 *
 * @package Maktomine\RestaurantCore\Orders
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Orders;

use Maktomine\RestaurantCore\Core\Logger;
use Maktomine\RestaurantCore\Settings\BusinessInfoRepository;
use Maktomine\RestaurantCore\Support\Sanitizer;
use Maktomine\RestaurantCore\Support\Validator;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Class OrderWhatsAppPayloadBuilder
 */
final class OrderWhatsAppPayloadBuilder {

	/**
	 * Error codes.
	 */
	public const ERROR_MISSING_DESTINATION  = 'missing_whatsapp_destination';
	public const ERROR_INVALID_ORDER        = 'invalid_order_data';

	/**
	 * Transform a persisted Order entity into a deterministic WhatsApp payload.
	 *
	 * Pure, stateless builder method that consumes only the persisted snapshot
	 * and authoritative business settings.
	 *
	 * @param Order $order Persisted order entity snapshot.
	 * @return array{phone: string, message: string}|WP_Error Deterministic payload array or WP_Error on failure.
	 */
	public static function build( Order $order ): array|WP_Error {
		// 1. Defensively validate that required historical fields are present on the Order.
		$order_reference = trim( $order->get_order_reference() );
		$customer_name   = trim( $order->get_customer_name() );
		$customer_phone  = trim( $order->get_customer_phone() );
		$order_type      = trim( $order->get_order_type() );
		$currency        = trim( $order->get_currency() );

		if ( '' === $order_reference || '' === $customer_name || '' === $customer_phone ) {
			Logger::warning(
				'OrderWhatsAppPayloadBuilder: Order is missing required customer or reference identification fields.',
				[ 'order_id' => $order->get_id() ]
			);

			return new WP_Error(
				self::ERROR_INVALID_ORDER,
				__( 'The order snapshot is missing required reference or customer identification data.', 'maktomine-restaurant-core' )
			);
		}

		if ( ! in_array( $order_type, Order::ALL_TYPES, true ) ) {
			Logger::warning(
				'OrderWhatsAppPayloadBuilder: Order contains an invalid or unrecognized order type.',
				[
					'order_id'   => $order->get_id(),
					'order_type' => $order_type,
				]
			);

			return new WP_Error(
				self::ERROR_INVALID_ORDER,
				__( 'The order snapshot contains an unrecognized order type.', 'maktomine-restaurant-core' )
			);
		}

		if ( '' === $currency ) {
			return new WP_Error(
				self::ERROR_INVALID_ORDER,
				__( 'The order snapshot is missing a valid currency code.', 'maktomine-restaurant-core' )
			);
		}

		// 2. Validate and retrieve the restaurant's authoritative WhatsApp destination phone.
		$raw_destination = (string) BusinessInfoRepository::get( 'whatsapp', '' );
		$clean_phone     = Sanitizer::whatsapp_phone( $raw_destination );

		if ( ! Validator::is_valid_phone( $clean_phone ) ) {
			Logger::warning(
				'OrderWhatsAppPayloadBuilder: Restaurant WhatsApp destination number is missing or invalid in business settings.',
				[ 'order_reference' => $order_reference ]
			);

			return new WP_Error(
				self::ERROR_MISSING_DESTINATION,
				__( 'Restaurant WhatsApp destination phone number is not configured or is invalid.', 'maktomine-restaurant-core' )
			);
		}

		// 3. Assemble the deterministic plain-text message.
		$message = self::build_message_text( $order );

		return [
			'phone'   => $clean_phone,
			'message' => $message,
		];
	}

	/**
	 * Build the formatted plain-text WhatsApp message body from the Order snapshot.
	 *
	 * Formats values safely without HTML, raw markdown markup that could collide with
	 * customer input, or catalog queries.
	 *
	 * @param Order $order Persisted order entity snapshot.
	 * @return string Plain-text message.
	 */
	private static function build_message_text( Order $order ): string {
		$lines = [];

		// Header
		$restaurant_name = trim( (string) BusinessInfoRepository::get( 'restaurant_name', '' ) );
		if ( '' !== $restaurant_name ) {
			$lines[] = 'New Order - ' . self::clean_text( $restaurant_name );
		} else {
			$lines[] = 'New Order';
		}
		$lines[] = '--------------------------------';

		// Order Details
		$lines[] = 'Order: ' . $order->get_order_reference();
		$lines[] = 'Type: ' . ucfirst( $order->get_order_type() );
		$lines[] = 'Status: ' . ucfirst( str_replace( '_', ' ', $order->get_order_status() ) );
		$lines[] = '';

		// Customer Details
		$lines[] = 'Customer Details:';
		$lines[] = 'Name: ' . self::clean_text( $order->get_customer_name() );
		$lines[] = 'Phone: ' . self::clean_text( $order->get_customer_phone() );

		$customer_whatsapp = trim( $order->get_customer_whatsapp() );
		if ( '' !== $customer_whatsapp ) {
			$lines[] = 'WhatsApp: ' . self::clean_text( $customer_whatsapp );
		}
		$lines[] = '';

		// Fulfillment / Delivery Details
		if ( Order::TYPE_DELIVERY === $order->get_order_type() ) {
			$lines[] = 'Delivery Address:';
			$address = trim( (string) $order->get_delivery_address() );
			$lines[] = 'Address: ' . ( '' !== $address ? self::clean_text( $address ) : 'N/A' );

			$area = trim( (string) $order->get_delivery_area() );
			if ( '' !== $area ) {
				$lines[] = 'Area: ' . self::clean_text( $area );
			}

			$landmark = trim( (string) $order->get_delivery_landmark() );
			if ( '' !== $landmark ) {
				$lines[] = 'Landmark: ' . self::clean_text( $landmark );
			}
			$lines[] = '';
		}

		// Order Note
		$note = trim( (string) $order->get_order_note() );
		if ( '' !== $note ) {
			$lines[] = 'Customer Note:';
			$lines[] = self::clean_text( $note );
			$lines[] = '';
		}

		// Order Items
		$lines[] = 'Items Ordered:';
		$items = $order->get_items();
		$currency = $order->get_currency();

		if ( empty( $items ) ) {
			$lines[] = '(No items recorded)';
		} else {
			$index = 1;
			foreach ( $items as $item ) {
				if ( ! ( $item instanceof OrderItem ) ) {
					continue;
				}

				$item_title = self::clean_text( $item->get_item_name() );
				$qty        = $item->get_quantity();
				$unit_price = self::format_amount( $item->get_unit_price(), $currency );
				$line_total = self::format_amount( $item->get_line_total(), $currency );

				$lines[] = sprintf( '%d. %s (x%d)', $index, $item_title, $qty );

				$variation = trim( (string) $item->get_variation_summary() );
				if ( '' !== $variation ) {
					$lines[] = '   Variation: ' . self::clean_text( $variation );
				}

				$addons = trim( (string) $item->get_addons_summary() );
				if ( '' !== $addons ) {
					$lines[] = '   Add-ons: ' . self::clean_text( $addons );
				}

				$lines[] = sprintf( '   Price: %s each | Total: %s', $unit_price, $line_total );
				$index++;
			}
		}
		$lines[] = '';

		// Financial Summary (strictly using persisted Order numbers)
		$lines[] = 'Summary:';
		$lines[] = 'Subtotal: ' . self::format_amount( $order->get_subtotal(), $currency );

		if ( Order::TYPE_DELIVERY === $order->get_order_type() ) {
			$lines[] = 'Delivery Fee: ' . self::format_amount( $order->get_delivery_charge(), $currency );
		}

		$lines[] = 'Total: ' . self::format_amount( $order->get_total_amount(), $currency );
		$lines[] = '--------------------------------';

		return implode( "\n", $lines );
	}

	/**
	 * Format a monetary float value with the historical Order's currency code.
	 *
	 * Uses strict deterministic formatting without recalculating, rounding differently,
	 * or allowing current business settings to mutate historical order currency.
	 *
	 * @param float  $amount   Numeric monetary value.
	 * @param string $currency Historical ISO currency code (e.g. USD).
	 * @return string Formatted string, e.g. "12.50 USD".
	 */
	private static function format_amount( float $amount, string $currency ): string {
		return sprintf( '%s %s', number_format( $amount, 2, '.', '' ), strtoupper( $currency ) );
	}

	/**
	 * Sanitize arbitrary plain-text strings for safe inclusion in a WhatsApp message.
	 *
	 * Strips tags, normalizes whitespace, and prevents newlines from breaking field boundaries.
	 *
	 * @param string $text Raw text string.
	 * @return string Safe single-line or clean multi-line text.
	 */
	private static function clean_text( string $text ): string {
		$stripped = wp_strip_all_tags( $text );
		// Replace consecutive spaces and tabs with a single space.
		return trim( preg_replace( '/[ \t]+/', ' ', $stripped ) ?? '' );
	}
}
