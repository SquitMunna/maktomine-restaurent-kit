<?php
/**
 * Cart Domain Entity.
 *
 * Represents an in-memory mutable collection of distinct CartLine configurations.
 * Owns cart-level business rules: line limit enforcement, identical line merging,
 * total item counting, serialization to and hydration from plain arrays.
 *
 * Responsibility Boundary:
 * - Owns: Cart line collection, line count/quantity boundaries, deterministic merge logic,
 *   pure array serialization and hydration.
 * - Excludes: Price calculations, subtotals, delivery calculations, catalog database queries,
 *   browser localStorage, REST controllers, order creation, WhatsApp dispatch.
 *
 * @package Maktomine\RestaurantCore\Cart
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Cart;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Class Cart
 */
final class Cart {

	/**
	 * Cart specification version.
	 */
	public const CART_VERSION = 1;

	/**
	 * Maximum number of distinct cart lines permitted.
	 */
	public const MAX_CART_LINES = 25;

	/**
	 * Error codes.
	 */
	public const ERROR_CART_LINE_LIMIT_EXCEEDED = 'cart_line_limit_exceeded';
	public const ERROR_QUANTITY_LIMIT_EXCEEDED  = 'quantity_limit_exceeded';
	public const ERROR_LINE_NOT_FOUND           = 'line_not_found';
	public const ERROR_INVALID_VERSION          = 'invalid_cart_version';
	public const ERROR_MALFORMED_CART           = 'malformed_cart';

	/**
	 * Collection of cart lines indexed by their deterministic line_id.
	 *
	 * @var array<string, CartLine>
	 */
	private array $lines = [];

	/**
	 * Constructor.
	 *
	 * @param array<string, CartLine> $lines Optional initial lines map [ line_id => CartLine ].
	 */
	public function __construct( array $lines = [] ) {
		foreach ( $lines as $line ) {
			if ( $line instanceof CartLine ) {
				$this->lines[ $line->get_line_id() ] = $line;
			}
		}
	}

	/**
	 * Create a new empty Cart instance.
	 *
	 * @return self
	 */
	public static function create(): self {
		return new self();
	}

	/**
	 * Add a CartLine to the cart.
	 *
	 * If an identical logical line already exists, its quantity is merged.
	 * If it does not exist, a new line is added provided MAX_CART_LINES is not exceeded.
	 *
	 * @param CartLine $line CartLine instance to add.
	 * @return bool|WP_Error True on success, WP_Error if line limit or quantity limit is exceeded.
	 */
	public function add_line( CartLine $line ): bool|WP_Error {
		$line_id = $line->get_line_id();

		if ( isset( $this->lines[ $line_id ] ) ) {
			$existing_quantity = $this->lines[ $line_id ]->get_quantity();
			$new_quantity      = $existing_quantity + $line->get_quantity();

			if ( $new_quantity > CartLine::MAX_LINE_QUANTITY ) {
				return new WP_Error(
					self::ERROR_QUANTITY_LIMIT_EXCEEDED,
					sprintf(
						/* translators: %d: Maximum allowed quantity per line */
						__( 'Adding this item would exceed the maximum quantity limit of %d for this line configuration.', 'maktomine-restaurant-core' ),
						CartLine::MAX_LINE_QUANTITY
					)
				);
			}

			$updated_line = $this->lines[ $line_id ]->with_quantity( $new_quantity );
			if ( is_wp_error( $updated_line ) ) {
				return $updated_line;
			}

			$this->lines[ $line_id ] = $updated_line;
			return true;
		}

		if ( count( $this->lines ) >= self::MAX_CART_LINES ) {
			return new WP_Error(
				self::ERROR_CART_LINE_LIMIT_EXCEEDED,
				sprintf(
					/* translators: %d: Maximum allowed distinct cart lines */
					__( 'Cannot add more than %d distinct item configurations to the cart.', 'maktomine-restaurant-core' ),
					self::MAX_CART_LINES
				)
			);
		}

		$this->lines[ $line_id ] = $line;
		return true;
	}

	/**
	 * Convenience method: Validate, construct, and add a line to the cart.
	 *
	 * @param int   $food_id   Food item ID.
	 * @param array $selection Optional variation selection map [ attribute_id => option_id ].
	 * @param array $addons    Optional add-ons selection list [ [ 'id' => string, 'quantity' => int ] ].
	 * @param int   $quantity  Item quantity (1 to 50).
	 * @return bool|WP_Error True on success, WP_Error on validation or limit error.
	 */
	public function add(
		int $food_id,
		array $selection = [],
		array $addons = [],
		int $quantity = 1
	): bool|WP_Error {
		$line = CartLine::create( $food_id, $selection, $addons, $quantity );
		if ( is_wp_error( $line ) ) {
			return $line;
		}

		return $this->add_line( $line );
	}

	/**
	 * Update the quantity of an existing line.
	 *
	 * @param string $line_id  Deterministic line ID.
	 * @param int    $quantity New positive integer quantity (1 to 50).
	 * @return bool|WP_Error True on success, WP_Error if line not found or quantity invalid.
	 */
	public function update_quantity( string $line_id, int $quantity ): bool|WP_Error {
		if ( ! isset( $this->lines[ $line_id ] ) ) {
			return new WP_Error(
				self::ERROR_LINE_NOT_FOUND,
				__( 'The specified cart line was not found in the cart.', 'maktomine-restaurant-core' )
			);
		}

		$valid_quantity = CartLine::validate_quantity( $quantity );
		if ( is_wp_error( $valid_quantity ) ) {
			return $valid_quantity;
		}

		$updated_line = $this->lines[ $line_id ]->with_quantity( $valid_quantity );
		if ( is_wp_error( $updated_line ) ) {
			return $updated_line;
		}

		$this->lines[ $line_id ] = $updated_line;
		return true;
	}

	/**
	 * Remove a line from the cart by its line ID.
	 *
	 * @param string $line_id Deterministic line ID.
	 * @return bool True if line was found and removed, false otherwise.
	 */
	public function remove_line( string $line_id ): bool {
		if ( isset( $this->lines[ $line_id ] ) ) {
			unset( $this->lines[ $line_id ] );
			return true;
		}

		return false;
	}

	/**
	 * Clear all lines from the cart.
	 *
	 * @return void
	 */
	public function clear(): void {
		$this->lines = [];
	}

	/**
	 * Check whether a specific line exists in the cart.
	 *
	 * @param string $line_id Deterministic line ID.
	 * @return bool
	 */
	public function has_line( string $line_id ): bool {
		return isset( $this->lines[ $line_id ] );
	}

	/**
	 * Get a specific CartLine by its line ID.
	 *
	 * @param string $line_id Deterministic line ID.
	 * @return CartLine|null CartLine instance or null if not found.
	 */
	public function get_line( string $line_id ): ?CartLine {
		return $this->lines[ $line_id ] ?? null;
	}

	/**
	 * Get all CartLine instances in the cart.
	 *
	 * @return array<string, CartLine> Map of [ line_id => CartLine ].
	 */
	public function get_lines(): array {
		return $this->lines;
	}

	/**
	 * Get the total count of individual food items across all lines (sum of quantities).
	 *
	 * Note: This is an item unit count, NOT the distinct line count.
	 *
	 * @return int
	 */
	public function get_item_count(): int {
		$count = 0;
		foreach ( $this->lines as $line ) {
			$count += $line->get_quantity();
		}

		return $count;
	}

	/**
	 * Get the number of distinct line configurations in the cart.
	 *
	 * @return int
	 */
	public function get_line_count(): int {
		return count( $this->lines );
	}

	/**
	 * Check whether the cart is empty.
	 *
	 * @return bool
	 */
	public function is_empty(): bool {
		return empty( $this->lines );
	}

	/**
	 * Serialize the cart to a plain associative array.
	 *
	 * Produces a stable, portable array suitable for serialization.
	 * Contains strictly selection state and structural quantities; no monetary calculations.
	 *
	 * @return array{
	 *     version: int,
	 *     lines: array<int, array{
	 *         line_id: string,
	 *         food_id: int,
	 *         selection: array<string, string>,
	 *         addons: array<int, array{id: string, quantity: int}>,
	 *         quantity: int
	 *     }>
	 * }
	 */
	public function to_array(): array {
		$serialized_lines = [];
		foreach ( $this->lines as $line ) {
			$serialized_lines[] = $line->to_array();
		}

		return [
			'version' => self::CART_VERSION,
			'lines'   => $serialized_lines,
		];
	}

	/**
	 * Hydrate a Cart instance from an untrusted associative array.
	 *
	 * Strictly validates:
	 * 1. Version matches CART_VERSION.
	 * 2. Lines array structure and max line limits.
	 * 3. Individual line structures and cryptographic configuration hash matches.
	 * 4. Rejection of duplicate line configurations.
	 *
	 * @param array $data Serialized cart array.
	 * @return self|WP_Error Hydrated Cart instance or WP_Error on invalid input.
	 */
	public static function from_array( array $data ): self|WP_Error {
		if ( ! isset( $data['version'] ) || self::CART_VERSION !== $data['version'] ) {
			return new WP_Error(
				self::ERROR_INVALID_VERSION,
				sprintf(
					/* translators: %d: Expected cart version */
					__( 'Invalid cart schema version. Expected version %d.', 'maktomine-restaurant-core' ),
					self::CART_VERSION
				)
			);
		}

		if ( ! isset( $data['lines'] ) || ! is_array( $data['lines'] ) ) {
			return new WP_Error(
				self::ERROR_MALFORMED_CART,
				__( 'Serialized cart data must contain a valid lines array.', 'maktomine-restaurant-core' )
			);
		}

		if ( count( $data['lines'] ) > self::MAX_CART_LINES ) {
			return new WP_Error(
				self::ERROR_CART_LINE_LIMIT_EXCEEDED,
				sprintf(
					/* translators: %d: Maximum allowed distinct cart lines */
					__( 'Serialized cart exceeds maximum limit of %d distinct item configurations.', 'maktomine-restaurant-core' ),
					self::MAX_CART_LINES
				)
			);
		}

		$lines = [];

		foreach ( $data['lines'] as $index => $line_data ) {
			if ( ! is_array( $line_data ) ) {
				return new WP_Error(
					self::ERROR_MALFORMED_CART,
					sprintf(
						/* translators: %d: Cart line index */
						__( 'Cart line at index %d is malformed.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}

			$line = CartLine::from_array( $line_data );
			if ( is_wp_error( $line ) ) {
				return $line;
			}

			$line_id = $line->get_line_id();

			if ( isset( $lines[ $line_id ] ) ) {
				return new WP_Error(
					self::ERROR_MALFORMED_CART,
					__( 'Duplicate cart line configuration found in serialized cart data.', 'maktomine-restaurant-core' )
				);
			}

			$lines[ $line_id ] = $line;
		}

		return new self( $lines );
	}
}
