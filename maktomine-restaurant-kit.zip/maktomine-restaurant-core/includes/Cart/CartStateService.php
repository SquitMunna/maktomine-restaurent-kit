<?php
/**
 * Cart State Service.
 *
 * Application-level coordinator for managing in-memory Cart state and mediating
 * with generic storage adapters. Serves as the clean architectural boundary
 * between the pure Cart domain and the future browser persistence adapter.
 *
 * Responsibility Boundary:
 * - Owns: Current request-level Cart instance, delegation to domain rules,
 *   coordination with optional CartStorageInterface, serialization/hydration coordination.
 * - Excludes: Direct browser APIs, localStorage/cookies, database queries, price calculation,
 *   catalog validation, order persistence, delivery charge calculations, UI rendering.
 *
 * @package Maktomine\RestaurantCore\Cart
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Cart;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Class CartStateService
 */
final class CartStateService {

	/**
	 * Error codes.
	 */
	public const ERROR_INVALID_CART_STATE = 'invalid_cart_state';
	public const ERROR_STORAGE_FAILURE    = 'cart_storage_failure';

	/**
	 * Request-scoped singleton instance.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Active in-memory Cart instance.
	 *
	 * @var Cart
	 */
	private Cart $cart;

	/**
	 * Optional storage adapter.
	 *
	 * @var CartStorageInterface|null
	 */
	private ?CartStorageInterface $storage;

	/**
	 * Constructor.
	 *
	 * @param Cart|null                 $cart    Optional pre-existing Cart instance. Defaults to an empty Cart.
	 * @param CartStorageInterface|null $storage Optional storage adapter for persistence synchronization.
	 */
	public function __construct( ?Cart $cart = null, ?CartStorageInterface $storage = null ) {
		$this->cart    = $cart ?? Cart::create();
		$this->storage = $storage;
	}

	/**
	 * Retrieve request-scoped singleton instance.
	 *
	 * Ensures a single consistent in-memory cart coordinator per HTTP/CLI request.
	 * Does not use persistent caches, transients, or database records.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Reset the request-scoped singleton instance.
	 *
	 * Useful for testing and request isolation.
	 *
	 * @return void
	 */
	public static function reset_instance(): void {
		self::$instance = null;
	}

	/**
	 * Get the underlying domain Cart instance.
	 *
	 * @return Cart
	 */
	public function get_cart(): Cart {
		return $this->cart;
	}

	/**
	 * Add a CartLine to the active cart.
	 *
	 * Delegates directly to Cart::add_line() to enforce domain limits and line merging.
	 * Synchronizes with the storage adapter if configured.
	 *
	 * @param CartLine $line CartLine instance to add.
	 * @return bool|WP_Error True on success, WP_Error if line limit or quantity limit is exceeded.
	 */
	public function add_line( CartLine $line ): bool|WP_Error {
		$result = $this->cart->add_line( $line );

		if ( true === $result && null !== $this->storage ) {
			$this->storage->set( $this->cart->to_array() );
		}

		return $result;
	}

	/**
	 * Convenience method: Validate, construct, and add a line to the active cart.
	 *
	 * Delegates validation and construction to CartLine::create() and addition to Cart::add_line().
	 *
	 * @param int                           $food_id   Food item post ID.
	 * @param array<string, string>         $selection Optional variation selection map [ attribute_id => option_id ].
	 * @param array<int, array{id: string, quantity: int}> $addons Optional add-ons selection list.
	 * @param int                           $quantity  Item quantity (1 to 50).
	 * @return bool|WP_Error True on success, WP_Error on validation failure or limit violation.
	 */
	public function add(
		int $food_id,
		array $selection = [],
		array $addons = [],
		int $quantity = 1
	): bool|WP_Error {
		$line = CartLine::create( $food_id, $selection, $addons, $quantity );
		if ( is_wp_error( $line ) ) {
			return $line;
		}

		return $this->add_line( $line );
	}

	/**
	 * Update the quantity of an existing line in the active cart.
	 *
	 * Delegates to Cart::update_quantity() to enforce valid quantities (1 to 50).
	 * Synchronizes with the storage adapter if configured.
	 *
	 * @param string $line_id  Deterministic line ID.
	 * @param int    $quantity New positive integer quantity (1 to 50).
	 * @return bool|WP_Error True on success, WP_Error if line is not found or quantity is invalid.
	 */
	public function update_quantity( string $line_id, int $quantity ): bool|WP_Error {
		$result = $this->cart->update_quantity( $line_id, $quantity );

		if ( true === $result && null !== $this->storage ) {
			$this->storage->set( $this->cart->to_array() );
		}

		return $result;
	}

	/**
	 * Remove a line from the active cart.
	 *
	 * Returns WP_Error if the line does not exist to allow specific error handling.
	 * Synchronizes with the storage adapter if configured.
	 *
	 * @param string $line_id Deterministic line ID.
	 * @return bool|WP_Error True on success, WP_Error if line is not found.
	 */
	public function remove_line( string $line_id ): bool|WP_Error {
		if ( ! $this->cart->has_line( $line_id ) ) {
			return new WP_Error(
				Cart::ERROR_LINE_NOT_FOUND,
				__( 'The specified cart line was not found in the cart.', 'maktomine-restaurant-core' )
			);
		}

		$removed = $this->cart->remove_line( $line_id );

		if ( $removed && null !== $this->storage ) {
			$this->storage->set( $this->cart->to_array() );
		}

		return $removed;
	}

	/**
	 * Clear all lines from the active cart.
	 *
	 * Synchronizes with the storage adapter if configured.
	 *
	 * @return void
	 */
	public function clear(): void {
		$this->cart->clear();

		if ( null !== $this->storage ) {
			$this->storage->clear();
		}
	}

	/**
	 * Check whether a specific line exists in the active cart.
	 *
	 * @param string $line_id Deterministic line ID.
	 * @return bool
	 */
	public function has_line( string $line_id ): bool {
		return $this->cart->has_line( $line_id );
	}

	/**
	 * Get a specific CartLine from the active cart.
	 *
	 * @param string $line_id Deterministic line ID.
	 * @return CartLine|null CartLine instance or null if not found.
	 */
	public function get_line( string $line_id ): ?CartLine {
		return $this->cart->get_line( $line_id );
	}

	/**
	 * Get all CartLine instances in the active cart.
	 *
	 * @return array<string, CartLine> Map of [ line_id => CartLine ].
	 */
	public function get_lines(): array {
		return $this->cart->get_lines();
	}

	/**
	 * Get the total count of individual food items across all lines (sum of quantities).
	 *
	 * @return int
	 */
	public function get_item_count(): int {
		return $this->cart->get_item_count();
	}

	/**
	 * Get the number of distinct line configurations in the active cart.
	 *
	 * @return int
	 */
	public function get_line_count(): int {
		return $this->cart->get_line_count();
	}

	/**
	 * Check whether the active cart is empty.
	 *
	 * @return bool
	 */
	public function is_empty(): bool {
		return $this->cart->is_empty();
	}

	/**
	 * Serialize the active cart state to a plain array.
	 *
	 * Conforms strictly to the approved Phase 4B serialization schema.
	 * Contains strictly selection state and structural quantities; no prices, totals, or PII.
	 *
	 * @return array{
	 *     version: int,
	 *     lines: array<int, array{
	 *         line_id: string,
	 *         food_id: int,
	 *         selection: array<string, string>,
	 *         addons: array<int, array{id: string, quantity: int}>,
	 *         quantity: int
	 *     }>
	 * }
	 */
	public function to_array(): array {
		return $this->cart->to_array();
	}

	/**
	 * Hydrate a CartStateService instance from untrusted serialized cart data.
	 *
	 * Delegates strictly to Cart::from_array() which verifies:
	 * 1. Version integer matches CART_VERSION.
	 * 2. Lines array presence and maximum line boundary.
	 * 3. Individual line structures, types, and cryptographic SHA-256 identity hash.
	 * 4. Rejection of duplicate line configurations.
	 *
	 * Does not silently heal or alter invalid serialized data.
	 *
	 * @param array<string, mixed>      $data    Serialized cart array.
	 * @param CartStorageInterface|null $storage Optional storage adapter to attach.
	 * @return self|WP_Error New CartStateService instance or WP_Error on invalid data.
	 */
	public static function from_array( array $data, ?CartStorageInterface $storage = null ): self|WP_Error {
		$cart = Cart::from_array( $data );
		if ( is_wp_error( $cart ) ) {
			return $cart;
		}

		return new self( $cart, $storage );
	}

	/**
	 * Retrieve the configured storage adapter.
	 *
	 * @return CartStorageInterface|null
	 */
	public function get_storage(): ?CartStorageInterface {
		return $this->storage;
	}

	/**
	 * Set or replace the storage adapter.
	 *
	 * @param CartStorageInterface|null $storage Storage adapter or null to detach.
	 * @return void
	 */
	public function set_storage( ?CartStorageInterface $storage ): void {
		$this->storage = $storage;
	}

	/**
	 * Load and hydrate cart state from the configured storage adapter.
	 *
	 * @return bool|WP_Error True on success, false if no storage configured, or WP_Error on invalid stored data.
	 */
	public function load_from_storage(): bool|WP_Error {
		if ( null === $this->storage ) {
			return false;
		}

		$data = $this->storage->get();
		if ( null === $data ) {
			$this->cart->clear();
			return true;
		}

		$cart = Cart::from_array( $data );
		if ( is_wp_error( $cart ) ) {
			return $cart;
		}

		$this->cart = $cart;
		return true;
	}

	/**
	 * Explicitly save current cart state to the configured storage adapter.
	 *
	 * @return bool True if saved, false if no storage is configured or storage failed.
	 */
	public function save_to_storage(): bool {
		if ( null === $this->storage ) {
			return false;
		}

		return $this->storage->set( $this->cart->to_array() );
	}
}
