<?php
/**
 * Cart Storage Abstraction Interface.
 *
 * Defines the contract for external persistence adapters storing and retrieving
 * serialized cart state. Decouples the domain/service layers from specific
 * storage mediums (e.g. future browser localStorage adapter or in-memory stores).
 *
 * @package Maktomine\RestaurantCore\Cart
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Cart;

defined( 'ABSPATH' ) || exit;

/**
 * Interface CartStorageInterface
 */
interface CartStorageInterface {

	/**
	 * Retrieve serialized cart data from the storage medium.
	 *
	 * @return array<string, mixed>|null Serialized cart data or null if empty or unavailable.
	 */
	public function get(): ?array;

	/**
	 * Persist serialized cart data to the storage medium.
	 *
	 * @param array<string, mixed> $data Serialized cart array conforming to Cart::to_array().
	 * @return bool True on success, false on storage failure.
	 */
	public function set( array $data ): bool;

	/**
	 * Clear persisted cart data in the storage medium.
	 *
	 * @return bool True on success, false on storage failure.
	 */
	public function clear(): bool;
}
