<?php
/**
 * CartLine Domain Value Object.
 *
 * Represents an immutable customer selection state for a single distinct food item configuration.
 * Encapsulates food item ID, variation attribute selections, add-on selections, and quantity.
 *
 * Responsibility Boundary:
 * - Owns: Pure customer selection state, canonical normalization, deterministic line identity generation.
 * - Excludes: Authoritative price calculation, variation schema resolution, database queries,
 *   browser session storage, order persistence.
 *
 * @package Maktomine\RestaurantCore\Cart
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Cart;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Class CartLine
 */
final class CartLine {

	/**
	 * Quantity boundaries.
	 */
	public const MIN_LINE_QUANTITY = 1;
	public const MAX_LINE_QUANTITY = 50;

	/**
	 * Error codes.
	 */
	public const ERROR_INVALID_FOOD_ID   = 'invalid_food_id';
	public const ERROR_INVALID_SELECTION = 'invalid_selection';
	public const ERROR_INVALID_ADDONS    = 'invalid_addons';
	public const ERROR_INVALID_QUANTITY  = 'invalid_quantity';
	public const ERROR_MALFORMED_LINE    = 'malformed_cart_line';

	/**
	 * Deterministic line identity hash.
	 *
	 * @var string
	 */
	private string $line_id;

	/**
	 * Food item ID.
	 *
	 * @var int
	 */
	private int $food_id;

	/**
	 * Normalized variation attribute selection map: [ attribute_id => option_id ].
	 *
	 * @var array<string, string>
	 */
	private array $selection;

	/**
	 * Normalized add-on selection list: [ [ 'id' => string, 'quantity' => int ], ... ].
	 *
	 * @var array<int, array{id: string, quantity: int}>
	 */
	private array $addons;

	/**
	 * Line item quantity.
	 *
	 * @var int
	 */
	private int $quantity;

	/**
	 * Internal constructor.
	 *
	 * @param string                                       $line_id   Deterministic line identity.
	 * @param int                                          $food_id   Food item ID.
	 * @param array<string, string>                        $selection Normalized variation selection.
	 * @param array<int, array{id: string, quantity: int}> $addons    Normalized add-on selection.
	 * @param int                                          $quantity  Line quantity.
	 */
	private function __construct(
		string $line_id,
		int $food_id,
		array $selection,
		array $addons,
		int $quantity
	) {
		$this->line_id   = $line_id;
		$this->food_id   = $food_id;
		$this->selection = $selection;
		$this->addons    = $addons;
		$this->quantity  = $quantity;
	}

	/**
	 * Factory method: Validate input and create an immutable CartLine instance.
	 *
	 * @param int   $food_id   Food item post ID.
	 * @param array $selection Optional variation selection map [ attribute_id => option_id ].
	 * @param array $addons    Optional add-ons selection list [ [ 'id' => string, 'quantity' => int ] ].
	 * @param int   $quantity  Item quantity (default 1, max 50).
	 * @return self|WP_Error Validated CartLine on success, WP_Error on invalid input.
	 */
	public static function create(
		int $food_id,
		array $selection = [],
		array $addons = [],
		int $quantity = 1
	): self|WP_Error {
		$valid_food_id = self::validate_food_id( $food_id );
		if ( is_wp_error( $valid_food_id ) ) {
			return $valid_food_id;
		}

		$valid_selection = self::validate_selection( $selection );
		if ( is_wp_error( $valid_selection ) ) {
			return $valid_selection;
		}

		$valid_addons = self::validate_addons( $addons );
		if ( is_wp_error( $valid_addons ) ) {
			return $valid_addons;
		}

		$valid_quantity = self::validate_quantity( $quantity );
		if ( is_wp_error( $valid_quantity ) ) {
			return $valid_quantity;
		}

		$line_id = self::generate_line_id( $valid_food_id, $valid_selection, $valid_addons );

		return new self( $line_id, $valid_food_id, $valid_selection, $valid_addons, $valid_quantity );
	}

	/**
	 * Create a new CartLine instance with an updated quantity.
	 *
	 * @param int $new_quantity New integer quantity (1 to 50).
	 * @return self|WP_Error New CartLine on success, WP_Error on invalid quantity.
	 */
	public function with_quantity( int $new_quantity ): self|WP_Error {
		$valid_quantity = self::validate_quantity( $new_quantity );
		if ( is_wp_error( $valid_quantity ) ) {
			return $valid_quantity;
		}

		return new self(
			$this->line_id,
			$this->food_id,
			$this->selection,
			$this->addons,
			$valid_quantity
		);
	}

	/**
	 * Generate a deterministic hash representing the unique logical configuration of this line.
	 *
	 * Note: Quantity is strictly excluded so that identical configurations share the same identity.
	 * Prices, titles, permalinks, and timestamps are excluded to ensure identity stability.
	 *
	 * @param int                                          $food_id   Food item ID.
	 * @param array<string, string>                        $selection Normalized variation selection.
	 * @param array<int, array{id: string, quantity: int}> $addons    Normalized add-on selection.
	 * @return string SHA-256 hex string.
	 */
	public static function generate_line_id( int $food_id, array $selection, array $addons ): string {
		$payload = [
			'food_id'   => $food_id,
			'selection' => $selection,
			'addons'    => $addons,
		];

		$canonical = json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		return hash( 'sha256', (string) $canonical );
	}

	/**
	 * Serialize CartLine to a pure associative array.
	 *
	 * @return array{
	 *     line_id: string,
	 *     food_id: int,
	 *     selection: array<string, string>,
	 *     addons: array<int, array{id: string, quantity: int}>,
	 *     quantity: int
	 * }
	 */
	public function to_array(): array {
		return [
			'line_id'   => $this->line_id,
			'food_id'   => $this->food_id,
			'selection' => $this->selection,
			'addons'    => $this->addons,
			'quantity'  => $this->quantity,
		];
	}

	/**
	 * Hydrate a CartLine from an untrusted associative array.
	 *
	 * Validates data structure, types, and verifies that the provided line_id
	 * exactly matches the re-computed canonical identity.
	 *
	 * @param array $data Serialized line array.
	 * @return self|WP_Error Valid CartLine instance or WP_Error on invalid input.
	 */
	public static function from_array( array $data ): self|WP_Error {
		if ( ! isset( $data['food_id'] ) || ! is_int( $data['food_id'] ) ) {
			return new WP_Error(
				self::ERROR_INVALID_FOOD_ID,
				__( 'Serialized cart line is missing a valid integer food_id.', 'maktomine-restaurant-core' )
			);
		}

		$raw_selection = isset( $data['selection'] ) && is_array( $data['selection'] )
			? $data['selection']
			: ( isset( $data['selection'] ) ? null : [] );

		if ( null === $raw_selection ) {
			return new WP_Error(
				self::ERROR_INVALID_SELECTION,
				__( 'Serialized cart line selection must be an array.', 'maktomine-restaurant-core' )
			);
		}

		$raw_addons = isset( $data['addons'] ) && is_array( $data['addons'] )
			? $data['addons']
			: ( isset( $data['addons'] ) ? null : [] );

		if ( null === $raw_addons ) {
			return new WP_Error(
				self::ERROR_INVALID_ADDONS,
				__( 'Serialized cart line addons must be an array.', 'maktomine-restaurant-core' )
			);
		}

		if ( ! isset( $data['quantity'] ) || ! is_int( $data['quantity'] ) ) {
			return new WP_Error(
				self::ERROR_INVALID_QUANTITY,
				__( 'Serialized cart line quantity must be an integer.', 'maktomine-restaurant-core' )
			);
		}

		$valid_food_id = self::validate_food_id( $data['food_id'] );
		if ( is_wp_error( $valid_food_id ) ) {
			return $valid_food_id;
		}

		$valid_selection = self::validate_selection( $raw_selection );
		if ( is_wp_error( $valid_selection ) ) {
			return $valid_selection;
		}

		$valid_addons = self::validate_addons( $raw_addons );
		if ( is_wp_error( $valid_addons ) ) {
			return $valid_addons;
		}

		$valid_quantity = self::validate_quantity( $data['quantity'] );
		if ( is_wp_error( $valid_quantity ) ) {
			return $valid_quantity;
		}

		$expected_line_id = self::generate_line_id( $valid_food_id, $valid_selection, $valid_addons );

		if ( isset( $data['line_id'] ) ) {
			if ( ! is_string( $data['line_id'] ) || $data['line_id'] !== $expected_line_id ) {
				return new WP_Error(
					self::ERROR_MALFORMED_LINE,
					__( 'Serialized cart line_id does not match the canonical configuration hash.', 'maktomine-restaurant-core' )
				);
			}
		}

		return new self( $expected_line_id, $valid_food_id, $valid_selection, $valid_addons, $valid_quantity );
	}

	/**
	 * Validate food item ID.
	 *
	 * @param mixed $food_id Raw food item ID.
	 * @return int|WP_Error Valid positive integer ID or WP_Error.
	 */
	public static function validate_food_id( mixed $food_id ): int|WP_Error {
		if ( ! is_int( $food_id ) || $food_id <= 0 ) {
			return new WP_Error(
				self::ERROR_INVALID_FOOD_ID,
				__( 'Food item ID must be a positive integer.', 'maktomine-restaurant-core' )
			);
		}

		return $food_id;
	}

	/**
	 * Validate and canonically order variation selection.
	 *
	 * @param mixed $selection Raw selection array [ attribute_id => option_id ].
	 * @return array<string, string>|WP_Error Valid sorted selection map or WP_Error.
	 */
	public static function validate_selection( mixed $selection ): array|WP_Error {
		if ( ! is_array( $selection ) ) {
			return new WP_Error(
				self::ERROR_INVALID_SELECTION,
				__( 'Variation selection must be an associative array.', 'maktomine-restaurant-core' )
			);
		}

		$normalized = [];

		foreach ( $selection as $attr_key => $opt_val ) {
			if ( ! is_string( $attr_key ) || '' === $attr_key ) {
				return new WP_Error(
					self::ERROR_INVALID_SELECTION,
					__( 'Variation attribute identifier must be a non-empty string.', 'maktomine-restaurant-core' )
				);
			}

			if ( ! is_string( $opt_val ) || '' === $opt_val ) {
				return new WP_Error(
					self::ERROR_INVALID_SELECTION,
					sprintf(
						/* translators: %s: Attribute identifier */
						__( "Variation option identifier for attribute '%s' must be a non-empty string.", 'maktomine-restaurant-core' ),
						$attr_key
					)
				);
			}

			$normalized[ $attr_key ] = $opt_val;
		}

		// Sort keys alphabetically for canonical line identity stability.
		ksort( $normalized, SORT_STRING );

		return $normalized;
	}

	/**
	 * Validate and canonically order add-on selection.
	 *
	 * @param mixed $addons Raw add-ons list [ [ 'id' => string, 'quantity' => int ] ].
	 * @return array<int, array{id: string, quantity: int}>|WP_Error Valid sorted add-ons or WP_Error.
	 */
	public static function validate_addons( mixed $addons ): array|WP_Error {
		if ( ! is_array( $addons ) ) {
			return new WP_Error(
				self::ERROR_INVALID_ADDONS,
				__( 'Add-on selection must be an array.', 'maktomine-restaurant-core' )
			);
		}

		$normalized = [];
		$seen_ids   = [];

		foreach ( $addons as $index => $item ) {
			if ( ! is_array( $item ) ) {
				return new WP_Error(
					self::ERROR_INVALID_ADDONS,
					sprintf(
						/* translators: %d: Add-on item index */
						__( 'Add-on at index %d must be an associative array.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}

			if ( ! isset( $item['id'] ) || ! is_string( $item['id'] ) || '' === $item['id'] ) {
				return new WP_Error(
					self::ERROR_INVALID_ADDONS,
					sprintf(
						/* translators: %d: Add-on item index */
						__( 'Add-on at index %d must have a non-empty string id.', 'maktomine-restaurant-core' ),
						$index
					)
				);
			}

			$addon_id = $item['id'];

			if ( isset( $seen_ids[ $addon_id ] ) ) {
				return new WP_Error(
					self::ERROR_INVALID_ADDONS,
					sprintf(
						/* translators: %s: Duplicate add-on identifier */
						__( "Duplicate add-on identifier '%s' provided in selection.", 'maktomine-restaurant-core' ),
						$addon_id
					)
				);
			}

			$seen_ids[ $addon_id ] = true;

			if ( ! isset( $item['quantity'] ) || ! is_int( $item['quantity'] ) || $item['quantity'] < 1 ) {
				return new WP_Error(
					self::ERROR_INVALID_ADDONS,
					sprintf(
						/* translators: %s: Add-on identifier */
						__( "Add-on '%s' quantity must be a positive integer.", 'maktomine-restaurant-core' ),
						$addon_id
					)
				);
			}

			$normalized[] = [
				'id'       => $addon_id,
				'quantity' => $item['quantity'],
			];
		}

		// Sort add-ons by id string ascending for canonical identity stability.
		usort(
			$normalized,
			static fn( array $a, array $b ): int => strcmp( $a['id'], $b['id'] )
		);

		return $normalized;
	}

	/**
	 * Validate line quantity.
	 *
	 * @param mixed $quantity Raw quantity value.
	 * @return int|WP_Error Valid bounded integer or WP_Error.
	 */
	public static function validate_quantity( mixed $quantity ): int|WP_Error {
		if ( ! is_int( $quantity ) || $quantity < self::MIN_LINE_QUANTITY || $quantity > self::MAX_LINE_QUANTITY ) {
			return new WP_Error(
				self::ERROR_INVALID_QUANTITY,
				sprintf(
					/* translators: 1: Minimum quantity, 2: Maximum quantity */
					__( 'Cart line quantity must be an integer between %1$d and %2$d.', 'maktomine-restaurant-core' ),
					self::MIN_LINE_QUANTITY,
					self::MAX_LINE_QUANTITY
				)
			);
		}

		return $quantity;
	}

	/**
	 * Get the deterministic line identity hash.
	 *
	 * @return string
	 */
	public function get_line_id(): string {
		return $this->line_id;
	}

	/**
	 * Get the food item ID.
	 *
	 * @return int
	 */
	public function get_food_id(): int {
		return $this->food_id;
	}

	/**
	 * Get the normalized variation selection map.
	 *
	 * @return array<string, string>
	 */
	public function get_selection(): array {
		return $this->selection;
	}

	/**
	 * Get the normalized add-on selection list.
	 *
	 * @return array<int, array{id: string, quantity: int}>
	 */
	public function get_addons(): array {
		return $this->addons;
	}

	/**
	 * Get the line quantity.
	 *
	 * @return int
	 */
	public function get_quantity(): int {
		return $this->quantity;
	}
}
