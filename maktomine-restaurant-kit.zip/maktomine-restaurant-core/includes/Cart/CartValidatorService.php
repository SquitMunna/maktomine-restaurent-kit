<?php
/**
 * Server-Side Cart Validator and Authoritative Pricing Service.
 *
 * Validates transient/untrusted Cart selections against the authoritative
 * WordPress catalog, variation matrix, and business pricing models.
 *
 * Architectural Boundary:
 * - Owns: Cart-to-catalog validation, variation matching validation, add-on validation,
 *   authoritative price calculations (item, add-ons, line total, subtotal), and construction
 *   of validated cart domain representations.
 * - Excludes: Cart state mutation, database writes, order persistence, delivery charges,
 *   tax calculations, discounts, verification hashes, REST handling, browser APIs, WhatsApp messaging.
 *
 * @package Maktomine\RestaurantCore\Cart
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Cart;

use Maktomine\RestaurantCore\Catalog\CatalogService;
use Maktomine\RestaurantCore\Catalog\FoodItemMeta;
use Maktomine\RestaurantCore\Catalog\PriceCalculator;
use Maktomine\RestaurantCore\Catalog\VariationMatrixResolver;
use Maktomine\RestaurantCore\Settings\BusinessInfoRepository;
use Maktomine\RestaurantCore\Support\Sanitizer;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Class CartValidatorService
 */
final class CartValidatorService {

	/**
	 * Error codes.
	 */
	public const ERROR_INVALID_CART                = 'invalid_cart';
	public const ERROR_INVALID_FOOD_ITEM           = 'invalid_food_item';
	public const ERROR_FOOD_ITEM_UNAVAILABLE       = 'food_item_unavailable';
	public const ERROR_INVALID_VARIATION_SELECTION = 'invalid_variation_selection';
	public const ERROR_VARIATION_UNAVAILABLE       = 'variation_unavailable';
	public const ERROR_INVALID_ADDON               = 'invalid_addon';
	public const ERROR_ADDON_UNAVAILABLE           = 'addon_unavailable';
	public const ERROR_ADDON_QUANTITY_EXCEEDED     = 'addon_quantity_exceeded';
	public const ERROR_REQUIRED_ADDON_MISSING      = 'required_addon_missing';
	public const ERROR_INVALID_QUANTITY            = 'invalid_quantity';
	public const ERROR_INVALID_PRICE               = 'invalid_price';
	public const ERROR_CART_VALIDATION_FAILED      = 'cart_validation_failed';

	/**
	 * Authoritative catalog domain service.
	 *
	 * @var CatalogService
	 */
	private CatalogService $catalog_service;

	/**
	 * Constructor.
	 *
	 * @param CatalogService|null $catalog_service Optional injected CatalogService instance.
	 */
	public function __construct( ?CatalogService $catalog_service = null ) {
		$this->catalog_service = $catalog_service ?? CatalogService::instance();
	}

	/**
	 * Validate a Cart entity against authoritative catalog data and calculate authoritative prices.
	 *
	 * The input Cart instance is treated as untrusted customer intent and is NEVER mutated.
	 *
	 * @param Cart $cart Transient customer cart to validate.
	 * @return array{
	 *     lines: array<int, array{
	 *         line_id: string,
	 *         food_id: int,
	 *         title: string,
	 *         selection: array<string, string>,
	 *         variation: array{id: ?string, summary: ?string},
	 *         addons: array<int, array{id: string, name: string, quantity: int, unit_price: float, line_total: float}>,
	 *         quantity: int,
	 *         unit_price: float,
	 *         addons_total: float,
	 *         effective_unit_price: float,
	 *         line_total: float
	 *     }>,
	 *     item_count: int,
	 *     subtotal: float,
	 *     currency: string
	 * }|WP_Error Server-validated cart structure on success, WP_Error on validation failure.
	 */
	public function validate( Cart $cart ): array|WP_Error {
		// 1. Validate cart boundary limits and content.
		if ( $cart->is_empty() ) {
			return new WP_Error(
				self::ERROR_INVALID_CART,
				__( 'Cannot validate an empty cart.', 'maktomine-restaurant-core' )
			);
		}

		if ( $cart->get_line_count() > Cart::MAX_CART_LINES ) {
			return new WP_Error(
				self::ERROR_INVALID_CART,
				sprintf(
					/* translators: %d: maximum allowable cart lines */
					__( 'Cart exceeds maximum allowable distinct lines limit of %d.', 'maktomine-restaurant-core' ),
					Cart::MAX_CART_LINES
				)
			);
		}

		$validated_lines  = [];
		$total_item_count = 0;
		$subtotal         = 0.0;

		// 2. Validate each CartLine independently.
		foreach ( $cart->get_lines() as $line ) {
			$validated_line = $this->validate_line( $line );
			if ( is_wp_error( $validated_line ) ) {
				return $validated_line;
			}

			$validated_lines[] = $validated_line;
			$total_item_count += $validated_line['quantity'];
			$subtotal          = round( $subtotal + $validated_line['line_total'], 2 );
		}

		// 3. Resolve authoritative restaurant currency.
		$currency = (string) BusinessInfoRepository::get( 'currency', 'USD' );
		if ( '' === trim( $currency ) ) {
			$currency = 'USD';
		}

		// 4. Return complete authoritative validated result.
		return [
			'lines'      => $validated_lines,
			'item_count' => $total_item_count,
			'subtotal'   => $subtotal,
			'currency'   => $currency,
		];
	}

	/**
	 * Validate a single CartLine against the authoritative catalog.
	 *
	 * @param CartLine $line Untrusted cart line.
	 * @return array<string, mixed>|WP_Error Validated line array on success, WP_Error on failure.
	 */
	private function validate_line( CartLine $line ): array|WP_Error {
		$food_id   = $line->get_food_id();
		$selection = $line->get_selection();
		$addons    = $line->get_addons();
		$quantity  = $line->get_quantity();
		$line_id   = $line->get_line_id();

		// A. Validate Line Quantity against domain boundaries.
		$valid_quantity = CartLine::validate_quantity( $quantity );
		if ( is_wp_error( $valid_quantity ) ) {
			return new WP_Error(
				self::ERROR_INVALID_QUANTITY,
				$valid_quantity->get_error_message(),
				[
					'line_id'  => $line_id,
					'food_id'  => $food_id,
					'quantity' => $quantity,
				]
			);
		}

		// B. Load authoritative food item data from CatalogService.
		$food_item = $this->catalog_service->get_food_item( $food_id );
		if ( is_wp_error( $food_item ) ) {
			return new WP_Error(
				self::ERROR_INVALID_FOOD_ITEM,
				sprintf(
					/* translators: %d: food item ID */
					__( 'Food item #%d does not exist or is invalid.', 'maktomine-restaurant-core' ),
					$food_id
				),
				[
					'line_id' => $line_id,
					'food_id' => $food_id,
				]
			);
		}

		// C. Validate publication status.
		if ( 'publish' !== ( $food_item['status'] ?? '' ) ) {
			return new WP_Error(
				self::ERROR_FOOD_ITEM_UNAVAILABLE,
				sprintf(
					/* translators: %s: food item title */
					__( "Food item '%s' is not published.", 'maktomine-restaurant-core' ),
					$food_item['title'] ?? (string) $food_id
				),
				[
					'line_id' => $line_id,
					'food_id' => $food_id,
					'status'  => $food_item['status'] ?? '',
				]
			);
		}

		// D. Validate food-level availability status.
		$item_availability = (string) ( $food_item['availability_status'] ?? FoodItemMeta::STATUS_IN_STOCK );
		if ( FoodItemMeta::STATUS_OUT_OF_STOCK === $item_availability ) {
			return new WP_Error(
				self::ERROR_FOOD_ITEM_UNAVAILABLE,
				sprintf(
					/* translators: %s: food item title */
					__( "Food item '%s' is currently out of stock.", 'maktomine-restaurant-core' ),
					$food_item['title']
				),
				[
					'line_id'      => $line_id,
					'food_id'      => $food_id,
					'availability' => $item_availability,
				]
			);
		}

		if ( FoodItemMeta::STATUS_PRE_ORDER_ONLY === $item_availability ) {
			return new WP_Error(
				self::ERROR_FOOD_ITEM_UNAVAILABLE,
				sprintf(
					/* translators: %s: food item title */
					__( "Food item '%s' is available for pre-order only. Pre-orders are currently not supported.", 'maktomine-restaurant-core' ),
					$food_item['title']
				),
				[
					'line_id'      => $line_id,
					'food_id'      => $food_id,
					'availability' => $item_availability,
				]
			);
		}

		if ( FoodItemMeta::STATUS_IN_STOCK !== $item_availability ) {
			return new WP_Error(
				self::ERROR_FOOD_ITEM_UNAVAILABLE,
				sprintf(
					/* translators: %s: food item title */
					__( "Food item '%s' is unavailable.", 'maktomine-restaurant-core' ),
					$food_item['title']
				),
				[
					'line_id'      => $line_id,
					'food_id'      => $food_id,
					'availability' => $item_availability,
				]
			);
		}

		// E. Validate variation selection & calculate authoritative item unit price.
		$has_variations = ! empty( $food_item['variations'] );

		if ( ! $has_variations ) {
			// Simple food item: selection must be empty.
			if ( ! empty( $selection ) ) {
				return new WP_Error(
					self::ERROR_INVALID_VARIATION_SELECTION,
					sprintf(
						/* translators: %s: food item title */
						__( "Food item '%s' is not a variable item and does not accept variation selections.", 'maktomine-restaurant-core' ),
						$food_item['title']
					),
					[
						'line_id'   => $line_id,
						'food_id'   => $food_id,
						'selection' => $selection,
					]
				);
			}

			$price_result = PriceCalculator::calculate( $food_item['base_price'], $food_item['sale_price'], null );
			if ( ! $price_result['success'] ) {
				$err = $price_result['error'] ?? [];
				return new WP_Error(
					self::ERROR_INVALID_PRICE,
					$err['message'] ?? __( 'Failed to calculate base item price.', 'maktomine-restaurant-core' ),
					[
						'line_id' => $line_id,
						'food_id' => $food_id,
					]
				);
			}

			$effective_item_unit_price = (float) $price_result['price'];
			$variation_data            = [
				'id'      => null,
				'summary' => null,
			];
		} else {
			// Variable food item: must resolve variation through authoritative VariationMatrixResolver.
			$attributes_schema = [ 'attributes' => $food_item['attributes'] ?? [] ];
			$variations_schema = [ 'variations' => $food_item['variations'] ?? [] ];

			$resolution = VariationMatrixResolver::resolve( $attributes_schema, $variations_schema, $selection );

			if ( ! $resolution['success'] || ! $resolution['matched'] ) {
				$err  = $resolution['error'] ?? [];
				$code = ! empty( $err['code'] ) ? (string) $err['code'] : self::ERROR_INVALID_VARIATION_SELECTION;
				$msg  = ! empty( $err['message'] ) ? (string) $err['message'] : __( 'Invalid variation selection.', 'maktomine-restaurant-core' );

				return new WP_Error(
					$code,
					$msg,
					array_merge(
						$err,
						[
							'line_id'   => $line_id,
							'food_id'   => $food_id,
							'selection' => $selection,
						]
					)
				);
			}

			$resolved_variation = $resolution['variation'];

			// Validate variation availability.
			$var_availability = (string) ( $resolved_variation['availability'] ?? FoodItemMeta::STATUS_IN_STOCK );
			if ( FoodItemMeta::STATUS_OUT_OF_STOCK === $var_availability ) {
				return new WP_Error(
					self::ERROR_VARIATION_UNAVAILABLE,
					sprintf(
						/* translators: %s: food item title */
						__( "The selected variation for '%s' is currently out of stock.", 'maktomine-restaurant-core' ),
						$food_item['title']
					),
					[
						'line_id'      => $line_id,
						'food_id'      => $food_id,
						'variation_id' => $resolved_variation['id'] ?? '',
						'availability' => $var_availability,
					]
				);
			}

			if ( FoodItemMeta::STATUS_PRE_ORDER_ONLY === $var_availability ) {
				return new WP_Error(
					self::ERROR_VARIATION_UNAVAILABLE,
					sprintf(
						/* translators: %s: food item title */
						__( "The selected variation for '%s' is available for pre-order only. Pre-orders are currently not supported.", 'maktomine-restaurant-core' ),
						$food_item['title']
					),
					[
						'line_id'      => $line_id,
						'food_id'      => $food_id,
						'variation_id' => $resolved_variation['id'] ?? '',
						'availability' => $var_availability,
					]
				);
			}

			if ( FoodItemMeta::STATUS_IN_STOCK !== $var_availability ) {
				return new WP_Error(
					self::ERROR_VARIATION_UNAVAILABLE,
					sprintf(
						/* translators: %s: food item title */
						__( "The selected variation for '%s' is unavailable.", 'maktomine-restaurant-core' ),
						$food_item['title']
					),
					[
						'line_id'      => $line_id,
						'food_id'      => $food_id,
						'variation_id' => $resolved_variation['id'] ?? '',
						'availability' => $var_availability,
					]
				);
			}

			// Authoritative price calculation for resolved variation.
			$price_result = PriceCalculator::calculate( $food_item['base_price'], $food_item['sale_price'], $resolved_variation );
			if ( ! $price_result['success'] ) {
				$err = $price_result['error'] ?? [];
				return new WP_Error(
					self::ERROR_INVALID_PRICE,
					$err['message'] ?? __( 'Failed to calculate variation price.', 'maktomine-restaurant-core' ),
					[
						'line_id'      => $line_id,
						'food_id'      => $food_id,
						'variation_id' => $resolved_variation['id'] ?? '',
					]
				);
			}

			$effective_item_unit_price = (float) $price_result['price'];

			// Construct human-readable variation summary.
			$var_summary    = $this->build_variation_summary( $food_item['attributes'] ?? [], $resolution['selection'] );
			$variation_data = [
				'id'      => (string) ( $resolved_variation['id'] ?? '' ),
				'summary' => $var_summary,
			];
		}

		// F. Validate Add-ons against authoritative item schema.
		$validated_addons_result = $this->validate_addons( $food_item, $addons, $line_id );
		if ( is_wp_error( $validated_addons_result ) ) {
			return $validated_addons_result;
		}

		$validated_addons = $validated_addons_result['addons'];
		$addons_unit_cost = $validated_addons_result['addons_unit_cost'];

		// G. Monetary Calculations (deterministic 2-decimal arithmetic).
		$effective_line_unit_price = round( $effective_item_unit_price + $addons_unit_cost, 2 );
		$line_total                = round( $effective_line_unit_price * $quantity, 2 );

		return [
			'line_id'              => $line_id,
			'food_id'              => $food_id,
			'title'                => (string) $food_item['title'],
			'selection'            => $selection,
			'variation'            => $variation_data,
			'addons'               => $validated_addons,
			'quantity'             => $quantity,
			'unit_price'           => $effective_item_unit_price,
			'addons_total'         => $addons_unit_cost,
			'effective_unit_price' => $effective_line_unit_price,
			'line_total'           => $line_total,
		];
	}

	/**
	 * Validate selected add-ons against the authoritative food item add-on schema.
	 *
	 * @param array<string, mixed> $food_item Authoritative food item data.
	 * @param array<int, mixed>    $addons    Selected add-ons from CartLine.
	 * @param string               $line_id   Cart line ID for error context.
	 * @return array{
	 *     addons: array<int, array{id: string, name: string, quantity: int, unit_price: float, line_total: float}>,
	 *     addons_unit_cost: float
	 * }|WP_Error Validated add-ons and unit cost on success, WP_Error on failure.
	 */
	private function validate_addons( array $food_item, array $addons, string $line_id ): array|WP_Error {
		$food_id               = (int) $food_item['id'];
		$raw_schema_addons     = isset( $food_item['addons'] ) && is_array( $food_item['addons'] ) ? $food_item['addons'] : [];
		$auth_addons_by_id     = [];
		$required_addon_lookup = [];

		foreach ( $raw_schema_addons as $schema_addon ) {
			if ( ! is_array( $schema_addon ) ) {
				continue;
			}
			$aid = (string) ( $schema_addon['id'] ?? '' );
			if ( '' !== $aid ) {
				$auth_addons_by_id[ $aid ] = $schema_addon;
				if ( ! empty( $schema_addon['required'] ) ) {
					$required_addon_lookup[ $aid ] = $schema_addon;
				}
			}
		}

		$seen_addon_ids   = [];
		$validated_addons = [];
		$addons_unit_cost = 0.0;

		foreach ( $addons as $addon_entry ) {
			if ( ! is_array( $addon_entry ) || ! isset( $addon_entry['id'] ) ) {
				return new WP_Error(
					self::ERROR_INVALID_ADDON,
					__( 'Malformed add-on specification.', 'maktomine-restaurant-core' ),
					[
						'line_id' => $line_id,
						'food_id' => $food_id,
					]
				);
			}

			$aid = (string) $addon_entry['id'];
			$qty = isset( $addon_entry['quantity'] ) ? (int) $addon_entry['quantity'] : 1;

			// Defensive duplicate protection.
			if ( isset( $seen_addon_ids[ $aid ] ) ) {
				return new WP_Error(
					self::ERROR_INVALID_ADDON,
					sprintf(
						/* translators: %s: add-on identifier */
						__( "Duplicate add-on '%s' in selection.", 'maktomine-restaurant-core' ),
						$aid
					),
					[
						'line_id'  => $line_id,
						'food_id'  => $food_id,
						'addon_id' => $aid,
					]
				);
			}
			$seen_addon_ids[ $aid ] = true;

			// Verify existence in authoritative schema.
			if ( ! isset( $auth_addons_by_id[ $aid ] ) ) {
				return new WP_Error(
					self::ERROR_INVALID_ADDON,
					sprintf(
						/* translators: %s: add-on identifier */
						__( "Add-on '%s' does not exist for this food item.", 'maktomine-restaurant-core' ),
						$aid
					),
					[
						'line_id'  => $line_id,
						'food_id'  => $food_id,
						'addon_id' => $aid,
					]
				);
			}

			$auth_addon = $auth_addons_by_id[ $aid ];

			// Verify add-on availability.
			$addon_avail = (string) ( $auth_addon['availability'] ?? FoodItemMeta::STATUS_IN_STOCK );
			if ( FoodItemMeta::STATUS_OUT_OF_STOCK === $addon_avail ) {
				return new WP_Error(
					self::ERROR_ADDON_UNAVAILABLE,
					sprintf(
						/* translators: %s: add-on display name */
						__( "Add-on '%s' is currently out of stock.", 'maktomine-restaurant-core' ),
						$auth_addon['name'] ?? $aid
					),
					[
						'line_id'      => $line_id,
						'food_id'      => $food_id,
						'addon_id'     => $aid,
						'availability' => $addon_avail,
					]
				);
			}

			if ( FoodItemMeta::STATUS_PRE_ORDER_ONLY === $addon_avail ) {
				return new WP_Error(
					self::ERROR_ADDON_UNAVAILABLE,
					sprintf(
						/* translators: %s: add-on display name */
						__( "Add-on '%s' is available for pre-order only. Pre-orders are currently not supported.", 'maktomine-restaurant-core' ),
						$auth_addon['name'] ?? $aid
					),
					[
						'line_id'      => $line_id,
						'food_id'      => $food_id,
						'addon_id'     => $aid,
						'availability' => $addon_avail,
					]
				);
			}

			if ( FoodItemMeta::STATUS_IN_STOCK !== $addon_avail ) {
				return new WP_Error(
					self::ERROR_ADDON_UNAVAILABLE,
					sprintf(
						/* translators: %s: add-on display name */
						__( "Add-on '%s' is unavailable.", 'maktomine-restaurant-core' ),
						$auth_addon['name'] ?? $aid
					),
					[
						'line_id'      => $line_id,
						'food_id'      => $food_id,
						'addon_id'     => $aid,
						'availability' => $addon_avail,
					]
				);
			}

			// Validate requested quantity against authoritative max_quantity.
			$max_qty = max( 1, (int) ( $auth_addon['max_quantity'] ?? 1 ) );
			if ( $qty < 1 || $qty > $max_qty ) {
				return new WP_Error(
					self::ERROR_ADDON_QUANTITY_EXCEEDED,
					sprintf(
						/* translators: 1: add-on name, 2: requested quantity, 3: maximum quantity */
						__( "Add-on '%1\$s' quantity (%2\$d) exceeds allowable maximum of %3\$d.", 'maktomine-restaurant-core' ),
						$auth_addon['name'] ?? $aid,
						$qty,
						$max_qty
					),
					[
						'line_id'      => $line_id,
						'food_id'      => $food_id,
						'addon_id'     => $aid,
						'quantity'     => $qty,
						'max_quantity' => $max_qty,
					]
				);
			}

			// Extract authoritative price exclusively from schema.
			$addon_unit_price = Sanitizer::price( $auth_addon['price'] ?? 0.0 );
			$addon_line_total = round( $addon_unit_price * $qty, 2 );

			$validated_addons[] = [
				'id'         => $aid,
				'name'       => (string) ( $auth_addon['name'] ?? $aid ),
				'quantity'   => $qty,
				'unit_price' => $addon_unit_price,
				'line_total' => $addon_line_total,
			];

			$addons_unit_cost = round( $addons_unit_cost + $addon_line_total, 2 );
		}

		// Verify all required add-ons are present in selection.
		foreach ( $required_addon_lookup as $req_id => $req_addon ) {
			if ( ! isset( $seen_addon_ids[ $req_id ] ) ) {
				return new WP_Error(
					self::ERROR_REQUIRED_ADDON_MISSING,
					sprintf(
						/* translators: %s: add-on display name */
						__( "Required add-on '%s' is missing from line selection.", 'maktomine-restaurant-core' ),
						$req_addon['name'] ?? $req_id
					),
					[
						'line_id'  => $line_id,
						'food_id'  => $food_id,
						'addon_id' => $req_id,
					]
				);
			}
		}

		return [
			'addons'           => $validated_addons,
			'addons_unit_cost' => $addons_unit_cost,
		];
	}

	/**
	 * Build human-readable variation summary from authoritative attributes and selection.
	 *
	 * @param array<int, mixed>    $attributes_schema Food item attributes schema.
	 * @param array<string, string> $selection         Normalized attribute selections.
	 * @return string Human-readable summary (e.g. "Size: Large, Crust: Thin").
	 */
	private function build_variation_summary( array $attributes_schema, array $selection ): string {
		if ( empty( $selection ) ) {
			return '';
		}

		$attr_names = [];
		$opt_labels = [];

		foreach ( $attributes_schema as $attr ) {
			if ( ! is_array( $attr ) ) {
				continue;
			}
			$attr_id = (string) ( $attr['id'] ?? '' );
			if ( '' === $attr_id ) {
				continue;
			}

			$attr_names[ $attr_id ] = (string) ( $attr['name'] ?? $attr_id );
			$opt_labels[ $attr_id ] = [];

			$options = isset( $attr['options'] ) && is_array( $attr['options'] ) ? $attr['options'] : [];
			foreach ( $options as $opt ) {
				if ( ! is_array( $opt ) ) {
					continue;
				}
				$opt_id = (string) ( $opt['id'] ?? '' );
				if ( '' !== $opt_id ) {
					$opt_labels[ $attr_id ][ $opt_id ] = (string) ( $opt['label'] ?? $opt_id );
				}
			}
		}

		$parts = [];
		foreach ( $selection as $attr_key => $opt_val ) {
			$attr_label = $attr_names[ $attr_key ] ?? $attr_key;
			$opt_label  = $opt_labels[ $attr_key ][ $opt_val ] ?? $opt_val;
			$parts[]    = sprintf( '%s: %s', $attr_label, $opt_label );
		}

		return implode( ', ', $parts );
	}
}
