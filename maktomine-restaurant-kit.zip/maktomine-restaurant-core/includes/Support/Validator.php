<?php
/**
 * Validation Utility Service.
 *
 * @package Maktomine\RestaurantCore\Support
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Support;

defined( 'ABSPATH' ) || exit;

final class Validator {

	/**
	 * Validate standard international phone format (E.164: 7 to 15 digits).
	 *
	 * @param string $phone Raw phone string.
	 * @return bool
	 */
	public static function is_valid_phone( string $phone ): bool {
		$digits = Sanitizer::whatsapp_phone( $phone );
		$len = strlen( $digits );
		return $len >= 7 && $len <= 15;
	}

	/**
	 * Validate that a date string matches strict YYYY-MM-DD format.
	 *
	 * @param string $date Date string.
	 * @return bool
	 */
	public static function is_valid_date( string $date ): bool {
		$d = \DateTime::createFromFormat( 'Y-m-d', $date );
		return $d && $d->format( 'Y-m-d' ) === $date;
	}

	/**
	 * Validate that a time string matches strict HH:MM 24-hour format.
	 *
	 * @param string $time Time string.
	 * @return bool
	 */
	public static function is_valid_time( string $time ): bool {
		$t = \DateTime::createFromFormat( 'H:i', $time );
		return $t && $t->format( 'H:i' ) === $time;
	}
}
