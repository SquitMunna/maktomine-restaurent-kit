<?php
/**
 * Sanitization Utility Service.
 *
 * @package Maktomine\RestaurantCore\Support
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Support;

defined( 'ABSPATH' ) || exit;

final class Sanitizer {

	/**
	 * Clean a phone or WhatsApp number to strict digits with preserved leading plus sign.
	 *
	 * @param string $phone Raw phone string.
	 * @return string
	 */
	public static function phone( string $phone ): string {
		$trimmed = trim( $phone );
		$has_plus = str_starts_with( $trimmed, '+' );
		$digits = preg_replace( '/[^0-9]/', '', $trimmed ) ?? '';

		if ( empty( $digits ) ) {
			return '';
		}

		return $has_plus ? '+' . $digits : $digits;
	}

	/**
	 * Clean a phone number for direct WhatsApp query links (digits only, no plus sign or spaces).
	 *
	 * @param string $phone Raw phone string.
	 * @return string
	 */
	public static function whatsapp_phone( string $phone ): string {
		return preg_replace( '/[^0-9]/', '', trim( $phone ) ) ?? '';
	}

	/**
	 * Sanitize monetary amount to non-negative float rounded to 2 decimal places.
	 * Safe against null, non-numeric strings, or invalid inputs.
	 *
	 * @param mixed $amount Raw price.
	 * @return float
	 */
	public static function price( mixed $amount ): float {
		if ( null === $amount || ! is_numeric( $amount ) ) {
			return 0.0;
		}

		$numeric = floatval( $amount );
		return max( 0.0, round( $numeric, 2 ) );
	}

	/**
	 * Sanitize order or booking reference string.
	 *
	 * @param string $reference Raw reference.
	 * @return string
	 */
	public static function reference( string $reference ): string {
		return strtoupper( preg_replace( '/[^A-Z0-9\-_]/', '', trim( $reference ) ) ?? '' );
	}
}
