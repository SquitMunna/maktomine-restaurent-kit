<?php
/**
 * Global Procedural Helpers & Public API Contracts.
 * Safe global accessors for Theme, Elementor, and third-party integrations.
 *
 * @package Maktomine\RestaurantCore
 */

declare(strict_types=1);

use Maktomine\RestaurantCore\Core\Plugin;
use Maktomine\RestaurantCore\Settings\BusinessInfoRepository;
use Maktomine\RestaurantCore\Support\Sanitizer;
use Maktomine\RestaurantCore\Support\Validator;

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'maktomine_is_core_active' ) ) {
	/**
	 * Verify that Maktomine Restaurant Core is active and fully booted.
	 * Returns true ONLY after the application kernel has completed all boot stages.
	 * Safe to call at any stage of the WordPress lifecycle without producing fatal errors.
	 *
	 * @return bool
	 */
	function maktomine_is_core_active(): bool {
		if ( ! class_exists( Plugin::class, false ) ) {
			return false;
		}

		return Plugin::is_active();
	}
}

if ( ! function_exists( 'maktomine_get_restaurant_info' ) ) {
	/**
	 * Retrieve restaurant domain business information.
	 *
	 * @param string|null $key     Specific setting key (e.g., 'phone', 'whatsapp', 'address').
	 * @param mixed       $default Default fallback if key does not exist or database is unavailable.
	 * @return mixed
	 */
	function maktomine_get_restaurant_info( ?string $key = null, mixed $default = null ): mixed {
		if ( ! class_exists( BusinessInfoRepository::class ) || ! function_exists( 'get_option' ) ) {
			return $default;
		}

		return BusinessInfoRepository::get( $key, $default );
	}
}

if ( ! function_exists( 'maktomine_get_currency_symbol' ) ) {
	/**
	 * Retrieve active restaurant currency symbol.
	 *
	 * @return string
	 */
	function maktomine_get_currency_symbol(): string {
		$symbol = (string) maktomine_get_restaurant_info( 'currency_symbol', '$' );

		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filter currency symbol dynamically.
			 *
			 * @param string $symbol        Configured currency symbol.
			 * @param string $currency_code 3-letter currency code (e.g. USD).
			 */
			return (string) apply_filters(
				'maktomine/currency/symbol',
				$symbol,
				(string) maktomine_get_restaurant_info( 'currency', 'USD' )
			);
		}

		return $symbol;
	}
}

if ( ! function_exists( 'maktomine_format_price' ) ) {
	/**
	 * Format numerical amount into localized currency display string.
	 *
	 * @param float|int|string $amount Numeric price value.
	 * @return string
	 */
	function maktomine_format_price( float|int|string $amount ): string {
		$numeric  = class_exists( Sanitizer::class ) ? Sanitizer::price( $amount ) : (float) $amount;
		$symbol   = maktomine_get_currency_symbol();
		$position = (string) maktomine_get_restaurant_info( 'currency_position', 'left' );
		$formatted_number = number_format( (float) $numeric, 2, '.', ',' );

		$formatted = match ( $position ) {
			'right'       => $formatted_number . $symbol,
			'right_space' => $formatted_number . ' ' . $symbol,
			'left_space'  => $symbol . ' ' . $formatted_number,
			default       => $symbol . $formatted_number,
		};

		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filter price display string.
			 *
			 * @param string $formatted Formatted price string.
			 * @param float  $numeric   Raw numeric price.
			 */
			return (string) apply_filters( 'maktomine/catalog/price_display', $formatted, $numeric );
		}

		return $formatted;
	}
}

if ( ! function_exists( 'maktomine_get_cart_count' ) ) {
	/**
	 * Public helper to retrieve current cart items count.
	 * Returns the item count from the request-scoped CartStateService in-memory instance.
	 *
	 * @return int
	 */
	function maktomine_get_cart_count(): int {
		if ( class_exists( \Maktomine\RestaurantCore\Cart\CartStateService::class ) ) {
			return \Maktomine\RestaurantCore\Cart\CartStateService::instance()->get_item_count();
		}

		return 0;
	}
}

if ( ! function_exists( 'maktomine_get_whatsapp_url' ) ) {
	/**
	 * Build a safe WhatsApp universal click-to-chat URL.
	 * Normalizes telephone number to E.164 pure digits (no + sign or punctuation) and URL-encodes message.
	 * Returns empty string '' if phone number is empty or invalid to prevent broken link generation.
	 *
	 * @param string      $message      Text message payload.
	 * @param string|null $target_phone Optional phone override; defaults to primary restaurant WhatsApp.
	 * @return string
	 */
	function maktomine_get_whatsapp_url( string $message, ?string $target_phone = null ): string {
		$raw_phone = $target_phone ?: (string) maktomine_get_restaurant_info( 'whatsapp', '' );

		if ( class_exists( Sanitizer::class ) ) {
			$clean_phone = Sanitizer::whatsapp_phone( $raw_phone );
		} else {
			$clean_phone = preg_replace( '/[^0-9]/', '', (string) $raw_phone ) ?? '';
		}

		// Minimum E.164 length check (valid international numbers have 7-15 digits).
		if ( strlen( $clean_phone ) < 7 || strlen( $clean_phone ) > 15 ) {
			return '';
		}

		$encoded_message = rawurlencode( $message );
		return sprintf( 'https://api.whatsapp.com/send?phone=%s&text=%s', $clean_phone, $encoded_message );
	}
}
