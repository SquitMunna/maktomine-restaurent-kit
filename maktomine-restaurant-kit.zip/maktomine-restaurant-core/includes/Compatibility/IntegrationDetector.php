<?php
/**
 * Safe Integration and Environment Detection Service.
 * Defensively detects presence of Theme, Elementor, and other environment components.
 *
 * @package Maktomine\RestaurantCore\Compatibility
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Compatibility;

defined( 'ABSPATH' ) || exit;

final class IntegrationDetector {

	/**
	 * Detect if Maktomine Restaurant Theme is active.
	 *
	 * @return bool
	 */
	public static function is_theme_active(): bool {
		if ( ! function_exists( 'wp_get_theme' ) ) {
			return false;
		}

		$theme = wp_get_theme();
		$template = $theme->get_template();

		return 'maktomine-restaurant-theme' === $template || 'maktomine-restaurant-theme' === $theme->get_stylesheet();
	}

	/**
	 * Detect if Elementor Free is loaded.
	 * Defensively avoids triggering external autoloaders.
	 *
	 * @return bool
	 */
	public static function is_elementor_active(): bool {
		return did_action( 'elementor/loaded' )
			|| defined( 'ELEMENTOR_VERSION' )
			|| class_exists( '\Elementor\Plugin', false );
	}

	/**
	 * Detect if Elementor Pro is loaded.
	 * Defensively avoids triggering external autoloaders.
	 *
	 * @return bool
	 */
	public static function is_elementor_pro_active(): bool {
		return defined( 'ELEMENTOR_PRO_VERSION' )
			|| class_exists( '\ElementorPro\Plugin', false );
	}

	/**
	 * Detect if WooCommerce is loaded.
	 * Note: Maktomine works completely without WooCommerce, but detects it for compatibility checks.
	 *
	 * @return bool
	 */
	public static function is_woocommerce_active(): bool {
		return function_exists( 'WC' )
			|| defined( 'WC_VERSION' )
			|| class_exists( 'WooCommerce', false );
	}
}
