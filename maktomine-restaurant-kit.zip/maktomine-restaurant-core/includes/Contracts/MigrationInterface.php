<?php
/**
 * Migration Interface Contract.
 *
 * @package Maktomine\RestaurantCore\Contracts
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Contracts;

defined( 'ABSPATH' ) || exit;

interface MigrationInterface {

	/**
	 * Schema version string (semver, e.g., '1.0.0').
	 *
	 * @return string
	 */
	public function get_version(): string;

	/**
	 * Execute the schema upgrade logic.
	 *
	 * @return bool True on success, false on failure.
	 */
	public function up(): bool;

	/**
	 * Roll back the schema modification.
	 *
	 * @return bool True on success, false on failure.
	 */
	public function down(): bool;
}
