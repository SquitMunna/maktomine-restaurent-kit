<?php
/**
 * Module Interface Contract.
 *
 * @package Maktomine\RestaurantCore\Contracts
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore\Contracts;

defined( 'ABSPATH' ) || exit;

interface ModuleInterface {

	/**
	 * Unique identifier for the module.
	 *
	 * @return string
	 */
	public function get_id(): string;

	/**
	 * Early registration stage (bind services, declare hooks, register post types/taxonomies).
	 *
	 * @return void
	 */
	public function register(): void;

	/**
	 * Late execution stage (executed after all modules are registered).
	 *
	 * @return void
	 */
	public function boot(): void;
}
