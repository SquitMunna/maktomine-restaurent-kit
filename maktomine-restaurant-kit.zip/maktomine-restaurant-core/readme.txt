=== Maktomine Restaurant Core ===
Contributors: maktomine
Tags: restaurant, food menu, food ordering, whatsapp order, table booking, elementor
Requires at least: 6.2
Tested up to: 6.7
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Professional restaurant business engine, food catalog, and WhatsApp ordering system for WordPress. Operates independently of any theme.

== Description ==

Maktomine Restaurant Core is the dedicated domain engine for the Maktomine Restaurant Kit commercial WordPress ecosystem.
It provides food menu catalogs, variations, add-ons, table reservations, direct WhatsApp ordering, and custom transactional logging without requiring WooCommerce.

== Changelog ==

= 1.0.0 =
* Phase 1: Core Plugin foundation release.
* PSR-4 autoloader, service container, lifecycle management.
* Database migration framework with version tracking.
* Food Item, Block, Review, and Gallery CPT registration.
* Menu Categories, Dietary Tags, and Gallery Categories taxonomy registration.
* Restaurant business settings repository and public API helpers.
* REST API namespace `maktomine/v1` initialization.
