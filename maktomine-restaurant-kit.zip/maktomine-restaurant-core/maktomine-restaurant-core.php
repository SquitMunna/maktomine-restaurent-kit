<?php
/**
 * Plugin Name:       Maktomine Restaurant Core
 * Plugin URI:        https://maktomine.com/restaurant-kit
 * Description:       Core domain logic and business engine for Maktomine Restaurant Kit. Operates independently of any WordPress theme.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      8.1
 * Author:            Maktomine Architecture Team
 * Author URI:        https://maktomine.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       maktomine-restaurant-core
 * Domain Path:       /languages
 */

declare(strict_types=1);

namespace Maktomine\RestaurantCore;

defined( 'ABSPATH' ) || exit;

// Version and identity constants.
define( 'MAKTOMINE_CORE_VERSION', '1.0.0' );
define( 'MAKTOMINE_CORE_MIN_PHP_VERSION', '8.1.0' );
define( 'MAKTOMINE_CORE_MIN_WP_VERSION', '6.2' );
define( 'MAKTOMINE_CORE_DB_VERSION', '1.1.0' );

// Path constants.
define( 'MAKTOMINE_CORE_FILE', __FILE__ );
define( 'MAKTOMINE_CORE_PATH', plugin_dir_path( __FILE__ ) );
define( 'MAKTOMINE_CORE_URL', plugin_dir_url( __FILE__ ) );
define( 'MAKTOMINE_CORE_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Environment requirements check prior to execution.
 */
if ( version_compare( PHP_VERSION, MAKTOMINE_CORE_MIN_PHP_VERSION, '<' ) ) {
	add_action( 'admin_notices', static function(): void {
		$message = sprintf(
			/* translators: 1: Required PHP version, 2: Current PHP version */
			esc_html__( 'Maktomine Restaurant Core requires PHP version %1$s or higher. Your server is running PHP %2$s.', 'maktomine-restaurant-core' ),
			MAKTOMINE_CORE_MIN_PHP_VERSION,
			PHP_VERSION
		);
		printf( '<div class="notice notice-error"><p><strong>%s</strong></p></div>', $message );
	} );
	return;
}

// Load internal PSR-4 Autoloader.
require_once MAKTOMINE_CORE_PATH . 'includes/Autoloader.php';

// Register autoloader for Maktomine\RestaurantCore\ namespace.
Autoloader::register( 'Maktomine\\RestaurantCore\\', MAKTOMINE_CORE_PATH . 'includes/' );

// Load global procedural helper API and hook contracts.
require_once MAKTOMINE_CORE_PATH . 'includes/Support/Helpers.php';

/**
 * Activation lifecycle hook.
 */
register_activation_hook( __FILE__, static function(): void {
	\Maktomine\RestaurantCore\Core\Lifecycle::activate();
} );

/**
 * Deactivation lifecycle hook.
 */
register_deactivation_hook( __FILE__, static function(): void {
	\Maktomine\RestaurantCore\Core\Lifecycle::deactivate();
} );

/**
 * Initialize application singleton.
 */
add_action( 'plugins_loaded', static function(): void {
	\Maktomine\RestaurantCore\Core\Plugin::instance()->boot();
}, 0 );
