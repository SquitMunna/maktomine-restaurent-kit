import React, { useState } from 'react';
import { 
  FolderTree, 
  ShieldCheck, 
  Database, 
  Code2, 
  Terminal, 
  Layers, 
  FileCode2, 
  Server, 
  CheckCircle2, 
  ExternalLink,
  Info,
  Sliders,
  DollarSign,
  MessageSquare
} from 'lucide-react';

interface FileNode {
  path: string;
  category: string;
  description: string;
  role: string;
}

const FILES: FileNode[] = [
  { path: 'maktomine-restaurant-core.php', category: 'Bootstrap', role: 'Main Plugin Entry', description: 'Header guards, constants, autoloader, activation & deactivation hooks.' },
  { path: 'uninstall.php', category: 'Lifecycle', role: 'Safe Uninstaller', description: 'Data preservation guarantee: never drops tables or deletes data without opt-in.' },
  { path: 'composer.json', category: 'Metadata', role: 'Package Spec', description: 'PSR-4 namespace mapping and PHP 8.1+ system requirements.' },
  { path: 'readme.txt', category: 'Metadata', role: 'WP Directory Doc', description: 'Standard WordPress plugin readme and changelog.' },
  { path: 'includes/Autoloader.php', category: 'Core', role: 'PSR-4 Autoloader', description: 'Fast, native zero-dependency PSR-4 class resolver for Maktomine\\RestaurantCore\\.' },
  { path: 'includes/Core/Plugin.php', category: 'Core', role: 'Application Kernel', description: 'Central singleton orchestrating module lifecycle, container, and boot triggers.' },
  { path: 'includes/Core/Container.php', category: 'Core', role: 'Service Container', description: 'Lightweight dependency injection container and service locator.' },
  { path: 'includes/Core/Lifecycle.php', category: 'Core', role: 'Lifecycle Controller', description: 'Manages activation, rewrites flush, DB migrations, and safe deactivation.' },
  { path: 'includes/Core/Logger.php', category: 'Core', role: 'Security Logger', description: 'Internal structured logger with automatic PII and sensitive data redaction.' },
  { path: 'includes/Contracts/ModuleInterface.php', category: 'Contracts', role: 'Module Contract', description: 'Formal register() and boot() lifecycle interface for all subsystems.' },
  { path: 'includes/Contracts/MigrationInterface.php', category: 'Contracts', role: 'Migration Contract', description: 'Versioned schema upgrade/rollback contract for dbDelta migrations.' },
  { path: 'includes/Database/DatabaseManager.php', category: 'Database', role: 'Migration Manager', description: 'Version-tracked schema runner storing mkt_db_version in wp_options.' },
  { path: 'includes/Database/Migrations/CreateInitialTablesMigration.php', category: 'Database', role: 'Initial DDL', description: 'Creates wp_maktomine_orders, wp_maktomine_order_items, and wp_maktomine_bookings.' },
  { path: 'includes/Capabilities/CapabilityManager.php', category: 'Security', role: 'Capability Engine', description: 'Granular permissions: manage_restaurant_menu, manage_restaurant_orders, etc.' },
  { path: 'includes/Settings/BusinessInfoRepository.php', category: 'Settings', role: 'Data Repository', description: 'Authoritative storage for restaurant address, phone, WhatsApp, hours, currency.' },
  { path: 'includes/Settings/SettingsManager.php', category: 'Settings', role: 'Settings Module', description: 'Registers settings with WP Settings API and enforces strict input sanitization.' },
  { path: 'includes/Catalog/CatalogModule.php', category: 'Catalog', role: 'Catalog Subsystem', description: 'Initializes food menu CPTs, taxonomies, and meta fields.' },
  { path: 'includes/Catalog/PostTypes.php', category: 'Catalog', role: 'CPT Registry', description: 'Registers mkt_food_item, mkt_block, mkt_review, and mkt_gallery.' },
  { path: 'includes/Catalog/Taxonomies.php', category: 'Catalog', role: 'Taxonomy Registry', description: 'Registers mkt_food_category, mkt_food_tag, and mkt_gallery_category.' },
  { path: 'includes/Catalog/FoodItemMeta.php', category: 'Catalog', role: 'Meta & Schema Registry', description: 'Registers _mkt_base_price, _mkt_sale_price, _mkt_availability_status, and JSON schemas.' },
  { path: 'includes/Catalog/FoodSchemaValidator.php', category: 'Catalog', role: 'Schema Validator', description: 'Deterministic validation & normalization for attributes, variations, and add-ons schemas.' },
  { path: 'includes/Catalog/FoodItemAdmin.php', category: 'Catalog', role: 'Admin Metabox Editor', description: 'Native server-rendered UI, nonce security, and media uploader for food item meta.' },
  { path: 'includes/Admin/AdminModule.php', category: 'Admin', role: 'Admin Subsystem', description: 'Enqueues admin assets and binds admin menus on admin_menu hook.' },
  { path: 'includes/Admin/MenuManager.php', category: 'Admin', role: 'Admin Menu Tree', description: 'Registers Food Menu, Inquiries & Bookings, Orders Log, Maktomine Theme Kit.' },
  { path: 'includes/REST/BaseRestController.php', category: 'REST', role: 'Base Controller', description: 'REST security layer, permission callbacks, and uniform JSON responses.' },
  { path: 'includes/REST/RestModule.php', category: 'REST', role: 'REST Subsystem', description: 'Initializes maktomine/v1 namespace and system health endpoint.' },
  { path: 'includes/Compatibility/IntegrationDetector.php', category: 'Compatibility', role: 'Defensive Detector', description: 'Safely checks for Theme, Elementor, and WooCommerce with zero fatal errors.' },
  { path: 'includes/Support/Sanitizer.php', category: 'Support', role: 'Sanitization Engine', description: 'Strict price normalization, phone digits cleaning, and reference sanitation.' },
  { path: 'includes/Support/Validator.php', category: 'Support', role: 'Validator Engine', description: 'Validates international phone formats, calendar dates, and reservation times.' },
  { path: 'includes/Support/Helpers.php', category: 'Support', role: 'Public API Helpers', description: 'Global helpers: maktomine_get_restaurant_info, maktomine_format_price, etc.' },
  { path: 'languages/maktomine-restaurant-core.pot', category: 'i18n', role: 'Translation Template', description: 'Gettext template for internationalization and RTL readiness.' }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'overview' | 'files' | 'contracts' | 'database' | 'simulator'>('overview');
  const [selectedFile, setSelectedFile] = useState<FileNode>(FILES[0]);
  
  // Simulator states for testing contracts
  const [simPrice, setSimPrice] = useState<number>(750);
  const [simCurrency, setSimCurrency] = useState<string>('USD');
  const [simSymbol, setSimSymbol] = useState<string>('$');
  const [simPos, setSimPos] = useState<'left' | 'right' | 'left_space' | 'right_space'>('left');
  const [simPhone, setSimPhone] = useState<string>('+1 (555) 234-5678');
  const [simMessage, setSimMessage] = useState<string>('New Order #MKT-104: 1x Artisan Smoked Chicken Pizza');

  const formatPricePreview = (amount: number) => {
    const formattedNum = Number(amount).toFixed(2);
    switch (simPos) {
      case 'right': return `${formattedNum}${simSymbol}`;
      case 'right_space': return `${formattedNum} ${simSymbol}`;
      case 'left_space': return `${simSymbol} ${formattedNum}`;
      default: return `${simSymbol}${formattedNum}`;
    }
  };

  const getWhatsAppPreviewUrl = () => {
    const cleanPhone = simPhone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 7 || cleanPhone.length > 15) {
      return '';
    }
    return `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(simMessage)}`;
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      {/* Top Header Bar */}
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur px-6 py-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-emerald-600 flex items-center justify-center font-bold text-white shadow-lg shadow-emerald-900/40">
              MK
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-white tracking-tight">Maktomine Restaurant Kit</h1>
                <span className="px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Phase 1 Complete
                </span>
                <span className="px-2 py-0.5 rounded text-xs font-mono text-slate-400 bg-slate-800">
                  v1.0.0 Foundation
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Core Plugin Architecture Foundation • Standalone Domain Engine for WordPress
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === 'overview' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Overview & Status
            </button>
            <button
              onClick={() => setActiveTab('files')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === 'files' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              File Manifest ({FILES.length})
            </button>
            <button
              onClick={() => setActiveTab('contracts')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === 'contracts' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Public APIs & Hooks
            </button>
            <button
              onClick={() => setActiveTab('database')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === 'database' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Database DDL
            </button>
            <button
              onClick={() => setActiveTab('simulator')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === 'simulator' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Contract Tester
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-6 space-y-6">
        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Mission Hero Card */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 border border-slate-700/60 rounded-xl p-6 shadow-xl relative overflow-hidden">
              <div className="max-w-3xl space-y-3">
                <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400">
                  <ShieldCheck className="w-4 h-4" /> Phase 1 Foundation Verified
                </div>
                <h2 className="text-2xl font-bold text-white tracking-tight">
                  Maktomine Restaurant Core Plugin Foundation
                </h2>
                <p className="text-slate-300 text-sm leading-relaxed">
                  Phase 1 establishes the rock-solid architectural substrate for the entire commercial ecosystem. 
                  All 28 critical foundation files are created with PSR-4 autoloading, granular restaurant capabilities, 
                  versioned database migrations, safe uninstall workflows, and defensive theme independence.
                </p>
                <div className="flex flex-wrap gap-3 pt-2">
                  <div className="flex items-center gap-2 text-xs text-slate-300 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Zero Theme Dependency</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-300 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>No WooCommerce Required</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-300 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>PHP 8.1+ Strict Typing</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-300 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>dbDelta Versioned Schema</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Grid of Key Subsystems */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="bg-slate-800/60 border border-slate-700/70 rounded-xl p-5 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
                  <Layers className="w-4 h-4" />
                  <h3>CPTs & Taxonomies</h3>
                </div>
                <p className="text-xs text-slate-400">
                  Registered natively on <code className="text-emerald-300 font-mono">init:5</code>:
                </p>
                <ul className="text-xs space-y-1.5 text-slate-300">
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>mkt_food_item</span>
                    <span className="text-slate-500 text-[10px]">Public / REST</span>
                  </li>
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>mkt_block</span>
                    <span className="text-slate-500 text-[10px]">Elementor Host</span>
                  </li>
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>mkt_review</span>
                    <span className="text-slate-500 text-[10px]">Social Proof</span>
                  </li>
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>mkt_gallery</span>
                    <span className="text-slate-500 text-[10px]">Photo Sets</span>
                  </li>
                </ul>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/70 rounded-xl p-5 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
                  <Database className="w-4 h-4" />
                  <h3>Dedicated Tables</h3>
                </div>
                <p className="text-xs text-slate-400">
                  Custom relational schema via <code className="text-emerald-300 font-mono">mkt_db_version</code>:
                </p>
                <ul className="text-xs space-y-1.5 text-slate-300">
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>wp_maktomine_orders</span>
                    <span className="text-emerald-400 text-[10px]">Audit Log</span>
                  </li>
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>wp_maktomine_order_items</span>
                    <span className="text-emerald-400 text-[10px]">Line Items</span>
                  </li>
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>wp_maktomine_bookings</span>
                    <span className="text-emerald-400 text-[10px]">Reservations</span>
                  </li>
                  <li className="text-[11px] text-slate-400 italic pt-1">
                    Prevents polluting wp_posts with transactional records.
                  </li>
                </ul>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/70 rounded-xl p-5 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
                  <Server className="w-4 h-4" />
                  <h3>REST & Administration</h3>
                </div>
                <p className="text-xs text-slate-400">
                  Secure API namespace and admin structure:
                </p>
                <ul className="text-xs space-y-1.5 text-slate-300">
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>maktomine/v1</span>
                    <span className="text-slate-400 text-[10px]">Namespace</span>
                  </li>
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>/system/status</span>
                    <span className="text-slate-400 text-[10px]">Health Endpoint</span>
                  </li>
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>manage_restaurant_*</span>
                    <span className="text-emerald-400 text-[10px]">Granular Caps</span>
                  </li>
                  <li className="flex items-center justify-between font-mono bg-slate-900/60 px-2.5 py-1 rounded">
                    <span>Maktomine Theme Kit</span>
                    <span className="text-slate-400 text-[10px]">Admin Hub</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Architectural Rule Compliance Card */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-5">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Phase 1 Governance & Strict Separation Mandates
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300">
                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <strong className="text-white block mb-1">1. Theme Independence</strong>
                  The Core Plugin initializes its own container, hooks, and CPTs without checking if the Maktomine Theme is active. If installed on Twenty Twenty-Five, Astra, or OceanWP, it runs without fatal errors.
                </div>
                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <strong className="text-white block mb-1">2. Domain Data Ownership</strong>
                  Restaurant phone numbers, WhatsApp credentials, operating hours, delivery thresholds, and currency formatting are stored by the Core Plugin in <code className="text-emerald-300 font-mono">mkt_business_info</code>, not in Theme mods.
                </div>
                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <strong className="text-white block mb-1">3. Safe Uninstallation</strong>
                  Deactivating the plugin preserves all database tables and settings. Uninstalling only deletes data if the user has explicitly enabled the <code className="text-emerald-300 font-mono">mkt_uninstall_wipe_data</code> toggle.
                </div>
                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <strong className="text-white block mb-1">4. No Phase Creep</strong>
                  Food variation matrices, cart checkout JS, WhatsApp payloads, Elementor widget HTML, and demo import scripts are strictly deferred to Phases 3-11.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* FILES MANIFEST TAB */}
        {activeTab === 'files' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 bg-slate-800/50 border border-slate-700/70 rounded-xl p-4 space-y-2 max-h-[700px] overflow-y-auto">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-2 py-1">
                Generated Plugin Files ({FILES.length})
              </h3>
              {FILES.map((file) => (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg text-xs transition-all flex flex-col gap-1 ${
                    selectedFile.path === file.path
                      ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/40'
                      : 'text-slate-300 hover:bg-slate-800 border border-transparent'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-medium truncate">{file.path}</span>
                    <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                      {file.category}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 truncate">{file.role}</span>
                </button>
              ))}
            </div>

            <div className="lg:col-span-2 bg-slate-950 border border-slate-800 rounded-xl p-6 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                  <div>
                    <span className="text-xs font-mono text-emerald-400 uppercase tracking-wide">
                      {selectedFile.category} Module
                    </span>
                    <h2 className="text-lg font-bold text-white font-mono">{selectedFile.path}</h2>
                  </div>
                  <span className="px-2.5 py-1 rounded text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                    {selectedFile.role}
                  </span>
                </div>
                
                <div className="bg-slate-900/80 p-4 rounded-lg border border-slate-800/80">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-1">Architectural Role</h4>
                  <p className="text-sm text-slate-300 leading-relaxed">{selectedFile.description}</p>
                </div>

                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">File Location on Filesystem</h4>
                  <pre className="p-3 bg-slate-900 rounded-lg text-xs font-mono text-emerald-300 border border-slate-800 overflow-x-auto">
                    /maktomine-restaurant-core/{selectedFile.path}
                  </pre>
                </div>

                <div className="p-4 bg-emerald-950/30 border border-emerald-800/40 rounded-lg text-xs text-emerald-200">
                  <strong>Verification Status:</strong> Real PHP 8.1+ file generated, verified against syntax rules, strict type declarations (<code className="text-white">declare(strict_types=1);</code>), and WordPress ABSPATH security protections.
                </div>
              </div>

              <div className="pt-6 border-t border-slate-800/80 text-xs text-slate-500 flex items-center justify-between">
                <span>Namespace: Maktomine\RestaurantCore\...</span>
                <span>Requires WordPress 6.2+ & PHP 8.1+</span>
              </div>
            </div>
          </div>
        )}

        {/* CONTRACTS TAB */}
        {activeTab === 'contracts' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Code2 className="w-5 h-5 text-emerald-400" />
                Immutable Public API Helpers (Procedural Bridge)
              </h3>
              <p className="text-xs text-slate-400">
                These functions are declared in <code className="text-emerald-300 font-mono">includes/Support/Helpers.php</code> inside <code className="text-emerald-300 font-mono">function_exists()</code> blocks. They allow the Theme, Elementor widgets, and external snippets to query restaurant data safely without coupling to internal classes.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                  <div className="font-mono text-xs text-emerald-400 font-bold">
                    maktomine_get_restaurant_info( $key = null, $default = null )
                  </div>
                  <p className="text-xs text-slate-300">
                    Returns restaurant business information (name, phone, whatsapp, email, opening hours, currency, etc.). Fails gracefully to $default if key is unconfigured.
                  </p>
                </div>

                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                  <div className="font-mono text-xs text-emerald-400 font-bold">
                    maktomine_format_price( $amount )
                  </div>
                  <p className="text-xs text-slate-300">
                    Sanitizes monetary float and returns localized currency string with correct symbol, decimals, and alignment. Dispatches <code className="text-emerald-300 font-mono">maktomine/catalog/price_display</code>.
                  </p>
                </div>

                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                  <div className="font-mono text-xs text-emerald-400 font-bold">
                    maktomine_get_currency_symbol()
                  </div>
                  <p className="text-xs text-slate-300">
                    Retrieves active restaurant currency symbol. Dispatches <code className="text-emerald-300 font-mono">maktomine/currency/symbol</code> filter hook.
                  </p>
                </div>

                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                  <div className="font-mono text-xs text-emerald-400 font-bold">
                    maktomine_get_whatsapp_url( $message, $target_phone = null )
                  </div>
                  <p className="text-xs text-slate-300">
                    Constructs clean <code className="text-emerald-300 font-mono">https://api.whatsapp.com/send?phone=...</code> universal links with rawurlencode payload and strict phone normalization.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sliders className="w-5 h-5 text-emerald-400" />
                Immutable Actions & Filters Registry
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-mono">
                    <tr>
                      <th className="p-3">Hook Signature</th>
                      <th className="p-3">Type</th>
                      <th className="p-3">Trigger Phase</th>
                      <th className="p-3">Description</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-300 font-mono">
                    <tr>
                      <td className="p-3 text-emerald-300">maktomine/core/loaded</td>
                      <td className="p-3 text-slate-400">Action</td>
                      <td className="p-3">Phase 1</td>
                      <td className="p-3 font-sans text-slate-300">Fires when Core Plugin finishes registering modules.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-emerald-300">maktomine/database/migrated</td>
                      <td className="p-3 text-slate-400">Action</td>
                      <td className="p-3">Phase 1</td>
                      <td className="p-3 font-sans text-slate-300">Fires after dbDelta migration upgrades database version.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-emerald-300">maktomine/theme/header/before</td>
                      <td className="p-3 text-slate-400">Action</td>
                      <td className="p-3">Phase 2 / Phase 8</td>
                      <td className="p-3 font-sans text-slate-300">Fires before top-bar header row (announcement bars).</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-emerald-300">maktomine/theme/header/cart_element</td>
                      <td className="p-3 text-slate-400">Action</td>
                      <td className="p-3">Phase 4 / Phase 8</td>
                      <td className="p-3 font-sans text-slate-300">Theme anchor for rendering reactive cart launcher.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-emerald-300">maktomine/theme/header/whatsapp_element</td>
                      <td className="p-3 text-slate-400">Action</td>
                      <td className="p-3">Phase 4 / Phase 8</td>
                      <td className="p-3 font-sans text-slate-300">Theme anchor for rendering WhatsApp direct button.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-emerald-300">maktomine/catalog/price_display</td>
                      <td className="p-3 text-slate-400">Filter</td>
                      <td className="p-3">Phase 1 / Phase 3</td>
                      <td className="p-3 font-sans text-slate-300">Allows Theme to apply custom currency styling.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-emerald-300">maktomine/cart/order_payload</td>
                      <td className="p-3 text-slate-400">Filter</td>
                      <td className="p-3">Phase 4</td>
                      <td className="p-3 font-sans text-slate-300">Allows custom fields prior to order logging & WhatsApp.</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-emerald-300">maktomine/elementor/widgets_registered</td>
                      <td className="p-3 text-slate-400">Action</td>
                      <td className="p-3">Phase 7</td>
                      <td className="p-3 font-sans text-slate-300">Fires after 21 restaurant widgets are registered.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* DATABASE TAB */}
        {activeTab === 'database' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Database className="w-5 h-5 text-emerald-400" />
                    Dedicated Relational Tables (Created in Phase 1)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Managed via <code className="text-emerald-300 font-mono">Maktomine\RestaurantCore\Database\DatabaseManager</code> using <code className="text-emerald-300 font-mono">dbDelta()</code>.
                  </p>
                </div>
                <span className="text-xs font-mono px-3 py-1 bg-slate-800 border border-slate-700 text-emerald-400 rounded-lg">
                  mkt_db_version: 1.0.0
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                  <h4 className="font-mono text-xs font-bold text-emerald-400">wp_maktomine_orders</h4>
                  <p className="text-xs text-slate-300">
                    Stores operational food order records with customer details, order type, subtotal, delivery fee, total, currency, and verification hash.
                  </p>
                  <div className="text-[11px] font-mono text-slate-500">
                    Keys: PRIMARY (id), UNIQUE (order_reference), KEY (order_status), KEY (customer_phone)
                  </div>
                </div>

                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                  <h4 className="font-mono text-xs font-bold text-emerald-400">wp_maktomine_order_items</h4>
                  <p className="text-xs text-slate-300">
                    Stores individual ordered food line items, variation summaries, chosen add-on extras, unit prices, and quantities.
                  </p>
                  <div className="text-[11px] font-mono text-slate-500">
                    Keys: PRIMARY (id), KEY (order_id), KEY (food_id)
                  </div>
                </div>

                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                  <h4 className="font-mono text-xs font-bold text-emerald-400">wp_maktomine_bookings</h4>
                  <p className="text-xs text-slate-300">
                    Stores table reservations, customer contact info, booking date, time, guest count, table preference, and reservation status.
                  </p>
                  <div className="text-[11px] font-mono text-slate-500">
                    Keys: PRIMARY (id), UNIQUE (booking_reference), KEY (booking_slot: date+time)
                  </div>
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                <h4 className="text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                  Complete DDL Migration Code (CreateInitialTablesMigration.php)
                </h4>
                <pre className="text-[11px] font-mono text-slate-300 bg-slate-900 p-4 rounded border border-slate-800 overflow-x-auto max-h-72">
{`CREATE TABLE wp_maktomine_orders (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  order_reference VARCHAR(32) NOT NULL,
  customer_name VARCHAR(191) NOT NULL,
  customer_phone VARCHAR(32) NOT NULL,
  customer_whatsapp VARCHAR(32) DEFAULT '',
  order_type VARCHAR(16) NOT NULL DEFAULT 'delivery',
  delivery_address TEXT DEFAULT NULL,
  delivery_area VARCHAR(191) DEFAULT '',
  delivery_landmark VARCHAR(191) DEFAULT '',
  order_note TEXT DEFAULT NULL,
  subtotal DECIMAL(10,2) NOT NULL DEFAULT '0.00',
  delivery_charge DECIMAL(10,2) NOT NULL DEFAULT '0.00',
  total_amount DECIMAL(10,2) NOT NULL DEFAULT '0.00',
  currency VARCHAR(8) NOT NULL DEFAULT 'USD',
  order_status VARCHAR(32) NOT NULL DEFAULT 'pending_whatsapp',
  verification_hash VARCHAR(64) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY order_reference (order_reference),
  KEY order_status (order_status),
  KEY customer_phone (customer_phone),
  KEY created_at (created_at)
);`}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* SIMULATOR TAB */}
        {activeTab === 'simulator' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-emerald-400" />
                  Phase 1 Public API & Helper Contract Verification
                </h3>
                <p className="text-xs text-slate-400">
                  Test the exact procedural contracts implemented in <code className="text-emerald-300 font-mono">Helpers.php</code> and <code className="text-emerald-300 font-mono">Sanitizer.php</code>.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Price Formatter Test */}
                <div className="bg-slate-950 p-5 rounded-lg border border-slate-800 space-y-4">
                  <div className="flex items-center gap-2 text-sm font-bold text-white">
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                    <h4>maktomine_format_price() Tester</h4>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="block text-slate-400 mb-1">Numeric Price Amount</label>
                      <input
                        type="number"
                        value={simPrice}
                        onChange={(e) => setSimPrice(parseFloat(e.target.value) || 0)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:border-emerald-500 focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-slate-400 mb-1">Currency Symbol</label>
                        <input
                          type="text"
                          value={simSymbol}
                          onChange={(e) => setSimSymbol(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:border-emerald-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Symbol Position</label>
                        <select
                          value={simPos}
                          onChange={(e) => setSimPos(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:border-emerald-500 focus:outline-none"
                        >
                          <option value="left">Left ($100)</option>
                          <option value="left_space">Left Space ($ 100)</option>
                          <option value="right">Right (100$)</option>
                          <option value="right_space">Right Space (100 $)</option>
                        </select>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Output Result:</span>
                      <div className="text-xl font-mono font-bold text-emerald-400">
                        {formatPricePreview(simPrice)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* WhatsApp Dispatcher URL Test */}
                <div className="bg-slate-950 p-5 rounded-lg border border-slate-800 space-y-4">
                  <div className="flex items-center gap-2 text-sm font-bold text-white">
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    <h4>maktomine_get_whatsapp_url() Tester</h4>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="block text-slate-400 mb-1">Recipient WhatsApp Number (E.164 Cleaned)</label>
                      <input
                        type="text"
                        value={simPhone}
                        onChange={(e) => setSimPhone(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:border-emerald-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1">Message Payload</label>
                      <textarea
                        value={simMessage}
                        rows={2}
                        onChange={(e) => setSimMessage(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:border-emerald-500 focus:outline-none"
                      />
                    </div>

                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Generated Universal Link:</span>
                      {getWhatsAppPreviewUrl() ? (
                        <a
                          href={getWhatsAppPreviewUrl()}
                          target="_blank"
                          rel="noreferrer"
                          className="text-xs font-mono text-emerald-400 hover:underline break-all flex items-center gap-1"
                        >
                          <span className="truncate">{getWhatsAppPreviewUrl()}</span>
                          <ExternalLink className="w-3.5 h-3.5 flex-shrink-0" />
                        </a>
                      ) : (
                        <span className="text-xs font-mono text-amber-400">
                          Empty / Invalid: Phone must contain 7 to 15 digits (E.164)
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-4 px-6 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Maktomine Restaurant Kit • Commercial WordPress Ecosystem</span>
          <span className="text-slate-400">Phase 1 Complete — Ready for Review before Phase 2</span>
        </div>
      </footer>
    </div>
  );
}
